*******************************************************************************
* Read in data and clean up data
*******************************************************************************

insheet using "$rawdir/drivers-by-city-year.csv", clear

*******************************************************************************
* Create event time
*******************************************************************************

*DEFINE EVENT
g e =initial_entry_year

*binned
gen Dn5=year<=e-5 
gen Dn4=year==e-4 
gen Dn3=year==e-3
gen Dn2=year==e-2
gen D0=year==e
gen D1=year==e+1
gen D2=year==e+2
gen D3=year==e+3
gen D4=year==e+4
gen D5=year==e+5
*binned
gen D6=year>=e+6 

tab year if D0==1

*******************************************************************************
* Estimate event study
*******************************************************************************
tab year, gen(yeardum)

*areg driver_prop Dn5-D6, abs(year) cluster(met2013)
*areg driver_prop Dn5-D6 yeardum*, abs(met2013) cluster(met2013)
areg driver_prop Dn5-D6 yeardum* [aw=metro_pop], abs(met2013) cluster(met2013)

*******************************************************************************
* Save coefficients
*******************************************************************************
mat coeff = [_b[Dn5]\ _b[Dn4]\ _b[Dn3]\ _b[Dn2]\ 0\ ///
	_b[D0]\ _b[D1]\ _b[D2]\ _b[D3]\ _b[D4]\ _b[D5]\ _b[D6]]

* Shift coeff matrix to be normalized to mean in t-1, not 0
sum driver_prop if year == e-1
mat mean_pre = [r(mean)\r(mean)\r(mean)\r(mean)\r(mean)\ ///
	r(mean)\r(mean)\r(mean)\r(mean)\r(mean)\r(mean)\r(mean)]
mat coeff = coeff + mean_pre
	
mat se = [_se[Dn5]\ _se[Dn4]\ _se[Dn3]\ _se[Dn2]\ 0\ ///
	_se[D0]\ _se[D1]\ _se[D2]\ _se[D3]\ _se[D4]\ _se[D5]\ _se[D6]]	
	
/* Create upper and lower bounds */
mat upper = coeff + ((1.96)*se)
mat lower = coeff - ((1.96)*se)

/* Store event times */
mat t = [-5\-4\-3\-2\-1\0\1\2\3\4\5\6]

/* Take all the things we need to plot and turn it into a matrix */
mat data = [coeff,upper,lower,t]

/* Create variables from matrix */
svmat data

rename data1 coeff
rename data2 upper
rename data3 lower
rename data4 t

twoway (scatter coeff t, c(l) ms(s) lc(navy) mc(navy)) ///
	   (scatter upper t, c(l) ms(none) lc(navy) lpattern(dash)) ///
	   (scatter lower t, c(l) ms(none) lc(navy) lpattern(dash)), legend(off) ///
	xtitle(Years Since Entry) ytitle(Driver Share) ///
	title("Uber Entry and Driver-to-population ratio") ///
	xlabel(-5 -4 -3 -2 -1 0 1 2 3 4 5 6) ///
	graphregion(lcolor(white) fcolor(white)) plotregion(color(white))
	graph export "$figdir/ES_uberentry_driversh_popwgt.pdf", replace

*note: areg driver_prop Dn5-D6 yeardum*, abs(met2013) cluster(met2013) is ES_uberentry_driversh.pdf
	
*******************************************************************************
* Quick look at 4 of the biggest cities
*******************************************************************************
ssc install binscatter

replace met2013_name = "NY/NJ" 		     if met2013==35620
replace met2013_name = "LA"    			 if met2013==31080
replace met2013_name = "Chicago"   		 if met2013==16980
replace met2013_name = "San Francisco"	 if met2013==41860

binscatter driver_prop year if inlist(met2013,35620,31080,41860, 16980), line(connect) by(met2013_name) ///
graphregion(lcolor(white) fcolor(white)) plotregion(color(white))
graph export "$figdir/uberentry_driversh_4cities.pdf", replace
