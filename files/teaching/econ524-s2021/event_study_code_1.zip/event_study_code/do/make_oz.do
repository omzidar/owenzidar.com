********************************************************************************
* 0. Initialize environment.
*******************************************************************************
* Environment variables.

global localdir "/Users/ozidar/Downloads/event_study_code"
global dodir    "$localdir/do"
global rawdir   "$localdir/raw"
global dtadir   "$localdir/dta"
global logdir   "$localdir/log"
global outdir   "$localdir/out"
global figdir   "$localdir/out/figs"

capture log close
log using "$logdir/make_oz.log", text replace

display "$S_TIME  $S_DATE"
clear
set more off

*maptile_install using http://files.michaelstepner.com/geo_statehex.zip

*******************************************************************************
*******************************************************************************
* Build Files
*******************************************************************************
*******************************************************************************



*******************************************************************************
*******************************************************************************
* Analysis Files
*******************************************************************************
*******************************************************************************

do $dodir/xpoz_driver_city_eventstudy.do
