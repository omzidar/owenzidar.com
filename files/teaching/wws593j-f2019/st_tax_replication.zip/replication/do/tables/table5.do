* Local assignment
local tabnum = 5

clear
set more off

/*****************/
/*** Draw Data ***/
/*****************/

do "$dodir/jc_add_stats.ado"
set more off

use "$dtadir/state_taxes_analysis.dta", clear
cd "$tabdir"
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56
sort fips_state year


/*************************/
/*** Data Manipulation ***/
/*************************/
** Gen main variables 
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corporate_rate/100 ) /* Actually log keep rate */
gen log_rev_gdp = log(rev_corp/GDP) //Updated 02/08/2018
gen r_g = rev_corptax/GDP
gen r_gos = rev_corptax/GOS_s
gen log_rev_gos = log(rev_corp/GOS_s)
gen log_gos = log(GOS_s)
gen log_gdp = log(GDP)
gen gos = GOS_s/100000

** Center base components around state+year FE 
local base "sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit" 
foreach var in `base' { 
	reg `var' i.fips i.year 
	predict temp, res 
	replace `var' = temp 
	drop temp 
}

replace r_g = r_g*10000 //See figure note

bys fips: egen mean_GDP = mean(GDP)

local base  "rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed"
		
label var rec_val "R\&D Tax Credit"
label var log_corp "$\ln (1-\tau)$"		
label var corporate_rate "$\tau$"	
label var incr_ma "R\&D Incremental Mov Avg"
label var incr_fixed  "R\&D Incremental Fixed"
label var incr_ma "R\&D Incremental Mov Avg"
label var combined  "Combined Reporting"
label var throwback  "Throwback Rules"		
label var sales_wgt  "Sales Apportionment Wgt"		
label var FederalIncomeas  "Fed Income as Tax Base"		
label var Losscarryfo  "Loss Carryforward"		
label var Losscarryba  "Loss Carryback "		
	
	
** Keep final regression sample first 
qui: reg r_g corporate_rate i.fips i.year ///
	`base'  [aw=mean_GDP]
keep if e(sample) 			

** Generate Base Index
*replace r_g = r_g/10^4
local i = 1
foreach var of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
	gen s`i' = `var'
	sum s`i'  [aw=mean_GDP], d
	replace s`i'=(s`i'-r(mean))/r(sd)	
	local i = `i'+1 
}
** Generate index
local Z "s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12 s13 s14 s15" 
reg r_g corporate_rate `Z'   ///
 i.year i.fips [aw=mean_GDP], cl(fips)
capture: drop base_index
gen base_index= _b[s1]*s1+_b[s2]*s2+_b[s3]*s3+_b[s4]*s4+ ///
_b[s5]*s5+_b[s6]*s6+_b[s7]*s7+_b[s8]*s8+ ///
_b[s9]*s9+_b[s10]*s10+_b[s11]*s11+_b[s12]*s12+ ///
_b[s13]*s13 + _b[s14]*s14 + _b[s15]*s15

sum base_index, d 
replace base_index = (base_index-r(mean))/r(sd)

*replace r_g = r_g*10^4
reg r_g corporate_rate i.fips i.year ///
	base_index [aw=mean_GDP], vce(cluster fips)
lincom _b[base_index]
	jc_add_stats, ene(1550) stat(base_index_2)	
	local est = e(base_index_2)
	local est_SE = e(base_index_2_SE)
	local est_p = e(base_index_2_pval)
	
** Regression on R_g 
est clear 

eststo one_nb:  reg r_g corporate_rate i.fips i.year ///
	[aw=mean_GDP], vce(cluster fips)

eststo one:  reg r_g corporate_rate i.fips i.year ///
	`base' [aw=mean_GDP], vce(cluster fips)
estadd local est = `est'
estadd local est_SE = `est_SE'
estadd local est_p = `est_p'
	
eststo two_nb:  reg log_rev log_corp i.fips i.year ///
	 [aw=mean_GDP], vce(cluster fips)
	
eststo two:  reg log_rev log_corp i.fips i.year ///
	`base' [aw=mean_GDP], vce(cluster fips)	


eststo three_nb:  reg log_gdp log_corp i.fips i.year ///
	 [aw=mean_GDP], vce(cluster fips)

eststo three:  reg log_gdp log_corp i.fips i.year ///
	`base' [aw=mean_GDP], vce(cluster fips)


estout  one_nb one two_nb two  three_nb three  using table`tabnum'.tex,  keep(`base' log_corp corporate_rate) order(corporate_rate log_corp `base'  ) label ///
mlab(none) coll(none) cells(b(star fmt(3)) se(par)) starlevels(* .1 ** .05 *** .01) /*mlab( " \multicolumn{2}{c}{Revenue to GDP Ratio}" " \multicolumn{2}{c}{Log(Revenue)}"  " \multicolumn{2}{c}{Log(GDP)}" )*/ stats(N est est_SE , nostar /// 
labels("Observations" "Base Index" "(se)") fmt(%9.0fc 3 3)) sty(tex)  preh("{\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} " ///
			"\begin{tabular}{l*{6}{c}}" "\hline \hline" ///
			"&\multicolumn{1}{c}{(1)} &\multicolumn{1}{c}{(2)} &\multicolumn{1}{c}{(3)} & \multicolumn{1}{c}{(4)} & \multicolumn{1}{c}{(5)} &\multicolumn{1}{c}{(6)} \\" ///
                    " & \multicolumn{2}{c}{Revenue to GDP Ratio} & \multicolumn{2}{c}{Log(Revenue)} & \multicolumn{2}{c}{Log(GDP)} \\ \hline" ) ///
 prefoot("\hline") postfoot( ///
" \hline \hline " ///
"\end{tabular} }" ) replace 
