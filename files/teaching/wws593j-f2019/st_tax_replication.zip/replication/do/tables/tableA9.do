* Pass-through share of state employment, payroll and establishments
* Local assignment
local tabnum = "A9"

set more off

use "$dtadir/CBP_passthrough_2010.dta", clear

drop if fips==11 //Dropping DC since it is not part of the overall analysis


preserve
*Tab begin
g tab = "\begin{tabular}{lccc}" in 1
*Tabular
g titlerow1 = " & \multicolumn{3}{c}{Pass-through Share of State}" in 1
g titlerow2 = "State & Employment & Establishments & Payroll" in 1
*Hline
g hline = "\hline" in 1
g top = "\toprule" in 1
*Midrule
g mid = "\midrule" in 1 
g cmid = "\cline{2-4}" in 1 
*Bottomrule
g bot = "\bottomrule" in 1
*End
g end = "\end{tabular}" in 1
*Empty column
g c = ""
	

*Output: pass-through share of economic activity
listtex tab if _n == 1 using "$tabdir/table`tabnum'.tex", replace rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex titlerow1 if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
*listtex cmid if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex titlerow2 if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)	
listtex statename s_emp_pt s_est_pt s_ap_pt, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex end if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)

restore
