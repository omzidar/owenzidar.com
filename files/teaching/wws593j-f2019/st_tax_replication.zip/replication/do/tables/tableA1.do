* Summary statistics of Bartik metrics
* Local assignment
local tabnum = "A1"


clear
set more off


/*****************/
/*** Draw data ***/
/*****************/

	use $dtadir/state_taxes_analysis.dta, clear
	
	drop if fips==11|fips==0|fips>56 //Only keeping 50 states
	keep if inrange(year, 1980, 2010) //Only keeping years between 1980 and 2010

	#delimit ;
	local sumlist = "propertytax propabatement jobcreationcred";
	#delimit cr

	
/*******************************/
/*** 1. Pooled Summary Stats ***/
/*******************************/
	preserve
	
	foreach var in `sumlist'{
		qui{
		sum `var'
		local num_`var' = `r(N)'
		local m_`var' = `r(mean)'
		local sd_`var' = `r(sd)'
		
		if inlist("`var'", "investment_credit", "rec_val", "propertytax", "propabatement", "jobcreationcred"){
			local m_`var' = 100*`r(mean)'
			local sd_`var' = 100*`r(sd)'
		}
		}
	}
		
	g labels = ""
	local row = 1
	
	*Bartik
	replace labels = "Property Tax Rate" in `row'
	local ++row
	replace labels = "Property Tax Abatement" in `row'
	local ++row
	replace labels = "Job Creation Tax Credit" in `row'
	local ++row

	*Svae values in summary stats table format
	foreach var in num m sd{
	qui{
		local row = 1
		if "`var'"=="num"{
			local decimal = 0
		}
		else{
			local decimal = 3
		}
		g `var' = ""

		*Bartik
		replace `var' = string(``var'_propertytax', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_propabatement', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_jobcreationcred', "%12.`decimal'f") in `row'
		local ++row

	}
	}



	*Output to tex file
		*Tab begin
		g tab = "\begin{tabular}{lccc}" in 1
		*Title
		g titlerow = " & Observations & Mean & Std. Dev." in 1
		g panelA = "\multicolumn{4}{l}{\textit{Panel A. 1980-2010 Pooled Sample}}" in 1
		*Hline
		g hline = "\hline" in 1
		g top = "\toprule" in 1
		*Midrule
		g mid = "\midrule" in 1 
		*Bottomrule
		g bot = "\bottomrule" in 1
		*End
		g end = "\end{tabular}" in 1
		*Empty column
		g c = ""
			
		
		*Output		
			* Bartik
		listtex tab if _n == 1 using "$tabdir/table`tabnum'.tex", replace rstyle(none)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)

		listtex panelA if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex labels num m sd if _n<=3, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 
		listtex labels num m sd if _n==4, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 
		
	restore
	
	
/*****************************/
/*** 2. 2010 Summary Stats ***/
/*****************************/

preserve
	keep if year==2010
	
	foreach var in `sumlist'{
		qui{
		sum `var'
		local num_`var' = `r(N)'
		local m_`var' = `r(mean)'
		local sd_`var' = `r(sd)'
		
		if inlist("`var'", "investment_credit", "rec_val", "propertytax", "propabatement", "jobcreationcred"){
			local m_`var' = 100*`r(mean)'
			local sd_`var' = 100*`r(sd)'
		}
		}
	}
		
	g labels = ""
	local row = 1
	
	*Bartik
	replace labels = "Property Tax Rate" in `row'
	local ++row
	replace labels = "Property Tax Abatement" in `row'
	local ++row
	replace labels = "Job Creation Tax Credit" in `row'
	local ++row

	*Svae values in summary stats table format
	foreach var in num m sd{
	qui{
		local row = 1
		if "`var'"=="num"{
			local decimal = 0
		}
		else{
			local decimal = 3
		}
		g `var' = ""
		
		*Bartik
		replace `var' = string(``var'_propertytax', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_propabatement', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_jobcreationcred', "%12.`decimal'f") in `row'
		local ++row

	}
	}



	*Output to tex file
		
		*Title
		g titlerow = " & Observations & Mean & Std. Dev." in 1
		g panelB = "\multicolumn{4}{l}{\textit{Panel B. 2010 Cross Section}}" in 1
		*Hline
		g hline = "\hline" in 1
		g top = "\toprule" in 1
		*Midrule
		g mid = "\midrule" in 1 
		*Bottomrule
		g bot = "\bottomrule" in 1
		*End
		g end = "\end{tabular}" in 1
		*Empty column
		g c = ""
			
		* Bartik
		listtex panelB if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex labels num m sd if _n<=3, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 
		
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex end if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
	
	restore
