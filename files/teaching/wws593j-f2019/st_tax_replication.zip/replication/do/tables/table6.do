*Impact of base index 
*Update: Standard errors clustered by state
*Local assignment
local tabnum=6

clear
set more off

/*****************/
/*** Draw Data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56
sort fips_state year

cd "$tabdir"

/*************************/
/*** Data Manipulation ***/
/*************************/
** Gen main variables 
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corporate_rate/100 ) /* Actually log keep rate */
gen log_rev_gdp = log(rev_corp/GDP) //Updated 02/08/2018
gen r_g = rev_corptax/GDP
gen r_gos = rev_corptax/GOS_s
gen log_rev_gos = log(rev_corp/GOS_s)
gen log_gos = log(GOS_s)
gen log_gdp = log(GDP)
gen gos = GOS_s/100000

** Center base components around state+year FE 
local base "sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit" 
foreach var in `base' { 
	reg `var' i.fips i.year 
	predict temp, res 
	replace `var' = temp 
	drop temp 
}

replace r_g = r_g*10000 //See figure note

bys fips: egen mean_GDP = mean(GDP)


foreach xvar of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
	 sum `xvar'  [aw=mean_GDP], d
	 replace `xvar'=(`xvar'-r(mean))/r(sd)

}

local i = 1 
foreach var of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
	gen s`i' = `var'
	local i = `i'+1 
}


/***********************************/
/*** Analysis 1: Mean Elasticity ***/
/***********************************/
est clear
** Keep Final data first 
qui: reg r_g log_corp i.year i.fips rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed  ///	
	c.log_corp#(c.rec_val c.sales_wgt c.Losscarryback c.Losscarryforward c.FranchiseTax c.FedIncomeTaxDeductible c.FederalIncomeasStateTaxBase c.AllowFedAccDep c.ACRSDepreciation c.FederalBonusDepreciation c.throwback c.combined c.investment_credit c.incr_ma c.incr_fixed)	///
	[aw=mean_GDP]
keep if e(sample) 

gen temp_log = log_corp 
gen temp_corp = corporate_rate

foreach var in r_g log_rev log_gdp  {

if "`var'" == "r_g" { 
	replace log_corp = temp_corp
} 
if "`var'" != "r_g" { 
	replace log_corp = temp_log
} 

** Run interacted regression and Generate index
capture: drop index2
*if "`var'"=="r_g"{
*	replace r_g = r_g/10^4
*}
eststo inter_`var': reg `var' log_corp i.year i.fips rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed ///	
c.log_corp#(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) [aw=mean_GDP]		

gen index2 = (_b[c.log_corp#c.s1]*s1 ///
	 +_b[c.log_corp#c.s2]*s2+_b[c.log_corp#c.s3]*s3 ///   
	 +_b[c.log_corp#c.s4]*s4+_b[c.log_corp#c.s5]*s5 ///
	 +_b[c.log_corp#c.s6]*s6+_b[c.log_corp#c.s7]*s7 ///
	 +_b[c.log_corp#c.s8]*s8+_b[c.log_corp#c.s9]*s9 ///
	 +_b[c.log_corp#c.s10]*s10+_b[c.log_corp#c.s11]*s11+_b[c.log_corp#c.s12]*s12+_b[c.log_corp#c.s13]*s13 ///
	 +_b[c.log_corp#c.s14]*s14+_b[c.log_corp#c.s15]*s15) if e(sample) 
				
	sum index2 [aw=mean_GDP], d 			 
	replace index2=(index2)/r(sd)

if "`var'" == "r_g" { 
	replace log_corp = temp_corp
*	replace r_g = r_g*10^4
** Run base regression 
eststo base_`var' : reg `var' corporate_rate i.year i.fips ///
	c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15 ///
	 [aw=mean_GDP], vce(cluster fips)  

** Run joint specification
eststo joint_`var' : reg `var' corporate_rate i.year i.fips c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15 ///	
	c.log_corp#(c.index2 ) c.index2 ///
	 [aw=mean_GDP], vce(cluster fips) 	 	 	 

} 
if "`var'" != "r_g" { 
	replace log_corp = temp_log
	
** Run base regression 
eststo base_`var' : reg `var' log_corp i.year i.fips ///
	c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15 ///
	 [aw=mean_GDP], vce(cluster fips)  

** Run joint specification
eststo joint_`var' : reg `var' log_corp i.year i.fips c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15 ///	
	c.log_corp#(c.index2 ) c.index2 ///
	 [aw=mean_GDP], vce(cluster fips) 	 	
} 

}


** Make joint table for paper. 
esttab base_r_g joint_r_g base_log_rev joint_log_rev base_log_gdp joint_log_gdp  ///
using "$tabdir/table`tabnum'.tex", keep(_cons) stats() ///
b(3) se par label coeflabel(effective_rate "\hspace{1em}Effective Rate") starlevels($^{*}$ .1 $^{**}$ .05 $^{***}$ .01) ///
noobs nogap nomtitle nonumbers tex replace nocons postfoot("")  ///
 preh("{\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} " ///
			"\begin{tabular}{l*{7}{c}}" "\hline \hline" ///
			"&\multicolumn{1}{c}{(1)} &\multicolumn{1}{c}{(2)} &\multicolumn{1}{c}{(3)} & \multicolumn{1}{c}{(4)} & \multicolumn{1}{c}{(5)} &\multicolumn{1}{c}{(6)} \\" ///
			"& \multicolumn{2}{c}{Revenue to GDP Ratio} & \multicolumn{2}{c}{Log(Revenue)} & \multicolumn{2}{c}{Log(GDP)} \\" ) /*mlab( " \multicolumn{2}{c}{Revenue to GDP Ratio}" " \multicolumn{2}{c}{Log(Revenue)}"  " \multicolumn{2}{c}{Log(GDP)}" )*/

** First part from base and joint interactions 
estout base_r_g joint_r_g base_log_rev joint_log_rev base_log_gdp joint_log_gdp  ///
using "$tabdir/table`tabnum'.tex", keep(corporate_rate log_corp c.log_corp#c.index2 ) ///
order(corporate_rate log_corp c.log_corp#c.index2 )   ///
varlabel(corporate_rate "$\tau$" log_corp "$\log(1-\tau)$"  c.log_corp#c.index2 "Joint Interaction" ) ///  
mlab(none) coll(none) stats() append sty(tex) cells(b(star fmt(3)) se(par)) starlevels($^{*}$ .1 $^{**}$ .05 $^{***}$ .01) ///
preh("") postfoot("\hline") 

** Second part from base and single interactions 
estout base_r_g inter_r_g base_log_rev inter_log_rev base_log_gdp inter_log_gdp ///
using "$tabdir/table`tabnum'.tex", keep(c.log_corp#c.s* ) ///
mlab(none) coll(none) stats(N, fmt(%9.0fc)) cells(b(star fmt(3)) se(par)) starlevels($^{*}$ .1 $^{**}$ .05 $^{***}$ .01) ///
varlabel(c.log_corp#c.s1  "R\&D Credit" ///
c.log_corp#c.s2  "Sales Apportionment Wgt"  ///
c.log_corp#c.s3  "Loss Carryback" ///
c.log_corp#c.s4  "Loss Carryforward"  ///
c.log_corp#c.s5  "Franchise Tax"  ///
c.log_corp#c.s6  "Federal Inc Deductible"  ///
c.log_corp#c.s7  "Federal Inc as State Base"  ///
c.log_corp#c.s8  "Federal Accelerated Dep"  ///
c.log_corp#c.s9  "ACRS Depreciation"  ///
c.log_corp#c.s10  "Federal Bonus Dep"  ///
c.log_corp#c.s11 "Throwback Rules"  ///
c.log_corp#c.s12  "Combined Reporting"  ///
c.log_corp#c.s13  "Investment Tax Credit"  ///
c.log_corp#c.s14  "R\&D Incremental Mov Avg"  ///
c.log_corp#c.s15  "R\&D Incremental Fixed"	 ) ///
preh("\multicolumn{6}{l}{\textbf{Individual Interactions}}\\") prefoot("\hline")  postfoot( ///
" \hline " ///
" Base Controls     & Y & Y & Y & Y & Y & Y \\ " ///
"Year Fixed Effects     & Y & Y & Y & Y & Y & Y \\ " ///
"State Fixed Effects     & Y & Y & Y & Y & Y & Y   \\ \hline\hline " ///
"\end{tabular} }" ) append sty(tex)



