* Local assignment
local tabnum = 3

clear
set more off

/*****************/
/*** Draw Data ***/
/*****************/


use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56
cd "$tabdir"

/*************************/
/*** Data Manipulation ***/
/*************************/
*Generate variables
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corporate_rate/100 ) /* Really the log of keep rate */

gen r_g = rev_corptax/GDP 

replace corporate_rate = corporate_rate/100
sum corporate_rate , d
gen corporate_rate_demean = corporate_rate -r(mean)
gen corporate2 = corporate_rate^2
gen corporate_rate_demean2 = corporate_rate_demean^2

label var corporate2 "Corp. rate sq"

tsset fips year 

gen ln_gdp=  ln(GDP)

bys fips: egen mean_GDP = mean(GDP)

label var corporate_rate "Corp. rate"

sort fips year
gen ch_r_g = (r_g - L1.r_g)
gen ch_corporate_rate = (corporate_rate - L1.corporate_rate)
gen ch_corporate2 = (ch_corporate_rate*ch_corporate_rate)

replace r_g = 100*r_g

//Create base broadening or narrowing indicator
sort fips_state year
local baserules = "FedIncomeTaxDeductible"
foreach rule in `baserules' {
	gen b_it_`rule' = (-(`rule' - L1.`rule'))
}

local baserules = "FranchiseTax"
foreach rule in `baserules' {
	gen b_it_`rule' = -(`rule' - L1.`rule')
}

local baserules = "investment_credit rec_val Losscarryforward Losscarryback AllowFedAccDep ACRSDepreciation FederalBonusDepreciation"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "sales_wgt"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "FederalIncomeasStateTaxBase combined throwback"
foreach rule in `baserules' {
	gen b_it_`rule' = sign((`rule' - L1.`rule'))
}

local baserules = "incr_ma incr_fixed"
foreach rule in `baserules' {
	gen b_it_`rule' = sign((`rule' - L1.`rule'))
}

local baserules = "FedIncomeTaxDed investment_cred Losscarryf Losscarryb sales_wgt FederalIncomeas combined throwback AllowFedAc ACRSDep FederalBonusDep FranchiseTax rec_val incr_ma incr_fixed"
foreach rule in `baserules' {
	by fips_state: gen B_it_`rule' = sum(b_it_`rule')
	label var B_it_`rule' "`rule'"
}

egen B = rowtotal(B_it_*)

gen B_X_corporate = B*corporate_rate
gen B_X_corporate_sq = B*corporate2

label var B "Cumulative base change"
label var B_X_corporate "Rate $\times$ Cumulative base change"
label var B_X_corporate_sq "Rate sq $\times$ Cumulative base change"


egen basebroadened = rowtotal(b_it_FedIncomeTaxDed-b_it_throwback)
replace basebroadened = 1 if basebroadened >= 1
replace basebroadened = 0 if basebroadened < 1

egen basenarrow = rowtotal(b_it_FedIncomeTaxDed-b_it_throwback)
replace basenarrow = 0 if basenarrow >= 0
replace basenarrow = 1 if basenarrow < 0

gen anybasechange = 0
replace anybasechange = 1 if basebroadened == 1 | basenarrow == 1

gen tax_decrease = 0
replace tax_decrease = 1 if ch_corporate_rate < 0
gen tax_nochange = 0
replace tax_nochange = 1 if ch_corporate_rate == 0
gen tax_increase = 0
replace tax_increase = 1 if ch_corporate_rate > 0


** (Table 5 in KS) Frequency of tax base changes accompanying rate changes (state-years)
* Aggregate Level
gen basechange = 0
replace basechange = 1 if basebroadened == 1
replace basechange = -1 if basenarrow == 1
gen ratechange = 0
replace ratechange = 1 if tax_increase == 1
replace ratechange = -1 if tax_decrease == 1

label var ratechange "Change in Corp. Rate"
label define ratelabel -1 "Rate Decrease" 0 "No Change" 1 "Rate Increase", replace
label values ratechange ratelabel 

label var basechange "Change in Tax Base"
label define baselabel -1 "Narrowing" 0 "No Change" 1 "Broadening"
label values basechange baselabel

eststo clear
estpost tabulate basechange ratechange


estout using "$tabdir/table`tabnum'.tex", replace style(tex) cell(colpct(fmt(1)) b(fmt(1) par)) label ///
	mlabels(, none) coll(, none) unstack eqlabels(, none)
