*Correlation change corp tax rate and abse measures
*local assignment
local tabnum = "A8"


set more off

use "$dtadir/state_taxes_analysis.dta", clear

bysort fips_state: egen mean_GDP = mean(GDP)

keep if year >= 1980 & year <= 2010
drop if fips_state == 0 | fips_state == 11 | fips_state > 56

g keep_corporate_rate = 100-corporate_rate
g l_keep_rate = log(keep_corporate_rate)


g ch_keep_corporate_rate = keep_corporate_rate - L.keep_corporate_rate

#delimit ;
local baselist = "ACRSDepreciation AllowFedAccDep FedIncomeTaxDeductible 
	FederalBonusDepreciation FederalIncomeasStateTaxBase FranchiseTax
	Losscarryback  Losscarryforward combined
	investment_credit rec_val incr_ma incr_fixed sales_wgt throwback";
#delimit cr


corr ch_keep_corporate_rate `baselist'
matrix cov = r(C)
matrix list cov

preserve
clear
svmat cov
*qui ds cov*
local i = 1
foreach var in ch_keep_corporate_rate `baselist'{
	rename cov`i' `var'
	local ++i
}

g depvarlab = ""
replace depvarlab = "$ d(1-\tau) $" in 1
replace depvarlab = "ACRSDep" in 2
replace depvarlab = "FedAccDep" in 3
replace depvarlab = "FedIncTxDed" in 4
replace depvarlab = "FedBonusDepr" in 5
replace depvarlab = "FedIncTxBase" in 6
replace depvarlab = "FranchiseTx" in 7
replace depvarlab = "LossCarryback" in 8
replace depvarlab = "LossCarryfwd" in 9
replace depvarlab = "CombinedRep" in 10
replace depvarlab = "ITC" in 11
replace depvarlab = "R\&DCredit" in 12
replace depvarlab = "R\&D Base is MA" in 13
replace depvarlab = "Fixed R\&D Base" in 14
replace depvarlab = "SalesAppWgt" in 15
replace depvarlab = "ThrowbackRules" in 16

local i = 1
*set trace on
foreach var in `baselist'{
	local i1 = `i'+1
	replace `var' = . in 1/`i' if `var'[`i1']==1
	format `var' %12.3f
	local ++i
}
format ch_keep_corporate_rate %12.3f

*Tab begin
g tab = "\begin{tabular}{lcccccccccccccccc}" in 1
*Tabular
g titlerow = " & $ d(1-\tau)$ & ACRSDep & FedAccDep & FedIncTxDed & FedBonusDep & FedIncTxBase & FranchiseTx & LossCarryback & LossCarryfwd & Combined & ITC & R\&D & R\&D MA & R\&D Fixed & PayAppWgt & Throwback " in 1
*Hline
g hline = "\hline" in 1
g top = "\toprule" in 1
*Midrule
g mid = "\midrule" in 1 
*Bottomrule
g bot = "\bottomrule" in 1
*End
g end = "\end{tabular}" in 1


*Output: pass-through share of economic activity
listtex tab if _n == 1 using "$tabdir/table`tabnum'a.tex", replace rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)	
listtex depvarlab ch_keep_corporate_rate `baselist', appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
listtex end if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)

restore

foreach var in `baselist'{
	g ch_`var' = `var' - L.`var' 
	g nc_`var' = `var'
	replace `var' = ch_`var'
}

corr ch_keep_corporate_rate `baselist'

matrix cov = r(C)
matrix list cov

foreach var in `baselist'{
replace `var' = nc_`var' //go back to previous value
}
drop ch_* nc_*

preserve
clear
svmat cov
*qui ds cov*
local i = 1
foreach var in ch_keep_corporate_rate `baselist'{
	rename cov`i' `var'
	local ++i
}

g depvarlab = ""
replace depvarlab = "$1-\tau$" in 1
replace depvarlab = "ACRSDep" in 2
replace depvarlab = "FedAccDep" in 3
replace depvarlab = "FedIncTxDed" in 4
replace depvarlab = "FedBonusDepr" in 5
replace depvarlab = "FedIncTxBase" in 6
replace depvarlab = "FranchiseTx" in 7
replace depvarlab = "LossCarryback" in 8
replace depvarlab = "LossCarryfwd" in 9
replace depvarlab = "CombinedRep" in 10
replace depvarlab = "ITC" in 11
replace depvarlab = "R\&DCredit" in 12
replace depvarlab = "R\&D Base is MA" in 13
replace depvarlab = "Fixed R\&D Base" in 14
replace depvarlab = "SalesAppWgt" in 15
replace depvarlab = "ThrowbackRules" in 16

local i = 1
foreach var in `baselist'{
	local i1 = `i'+1
	replace `var' = . in 1/`i' if `var'[`i1']==1
	format `var' %12.3f
	local ++i
}
format ch_keep_corporate_rate %12.3f

*Tab begin
g tab = "\begin{tabular}{lcccccccccccccccc}" in 1
*Tabular
g titlerow = " & $1-\tau$ & ACRSDep & FedAccDep & FedIncTxDed & FedBonusDep & FedIncTxBase & FranchiseTx & LossCarryback & LossCarryfwd & Combined & ITC & R\&D & R\&D MA & R\&D Fixed & PayAppWgt & Throwback " in 1
*Hline
g hline = "\hline" in 1
g top = "\toprule" in 1
*Midrule
g mid = "\midrule" in 1 
*Bottomrule
g bot = "\bottomrule" in 1
*End
g end = "\end{tabular}" in 1


*Output: pass-through share of economic activity
listtex tab if _n == 1 using "$tabdir/table`tabnum'b.tex", replace rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)	
listtex depvarlab ch_keep_corporate_rate `baselist', appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
listtex end if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)

restore
