* ANOVA INCLUDEING TOP STATUTORY RATE
* Local assignment
local tabnum = "A11"

set more off
use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 0 | fips_state == 11 | fips_state > 56

bysort fips_state: egen mean_GDP = mean(GDP)


g period=0
replace period = 1 if year >= 1980 & year <= 1985
replace period = 2 if year >= 1986 & year <= 1990
replace period = 3 if year >= 1991 & year <= 1995
replace period = 4 if year >= 1996 & year <= 2000
replace period = 5 if year >= 2001 & year <= 2005
replace period = 6 if year >= 2006 & year <= 2010

gen corprev_share_gdp = (rev_corptax*100)/GDP

local base  "rec_val payroll_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit"

rename corprev_share_gdp r_g
g l_r_g=log(r_g)
g l_r  =log(rev_corptax*10000)
g r    =rev_corptax*10000
	
label var rec_val "R\&D Tax Credit"
label var corporate_rate "$\tau$"		
/*			
** Keep final regression sample first 
reg r_g corporate_rate  ///
	`base'  i.fips i.year [aw=mean_GDP]
*keep if e(sample) 	
*/

*Assign variables
g x0= corporate_rate
g x1= FederalIncomeasStateTaxBase
g x2= FedIncomeTaxDeductible 
g x3= throwback 
g x4= payroll_wgt 
g x5= Losscarryforward 
g x6= Losscarryback 
g x7= combined 
g x8= investment_credit 
g x9= rec_val
g x10= ACRSDepreciation 
g x11= AllowFedAccDep 
g x12= FederalBonusDepreciation 
g x13= FranchiseTax
g x14= incr_ma //includes rec val as moving avg
g x15= incr_fixed //includes rec val fixed
g x16= t_pinc_rate
	
*set trace on
*set tracedepth 1
foreach outcome in r_g{
foreach c in yes no{
	
	preserve

	if "`c'"=="yes"{
		local num =16
	}
	else if "`c'"=="no"{
		local num =15		
		}

	
	*REGRESSION
	reg `outcome' x0-x`num' [aw=mean_GDP] 

	g explained = e(r2)
	g unexplained = 1 - e(r2)

	* corp_sh_gdp = b0 + x1b1 + ...  x13b13 + e
	* --> var(corp_sh_gdp). = var(x1)b1^2 + ... + var(x13)b14 + var(e), assuming covs = 0
	forv i =0/`num'{
	local beta=_b[x`i']
	summ x`i'
	local var=(r(sd))^2

	g bsqXx`i' = (`beta')^2 *`var'
	}
	list bsqXx1 in 1

	egen sum_ss   = rowtotal(bsqX*)
	egen sum_base = rowtotal(bsqXx1-bsqXx15)
	gen base=	sum_base/sum_ss
	if `num'==16{
		gen topinc_sh=	bsqXx16/sum_ss
	}
	gen corp=	bsqXx0/sum_ss

	ds bsqXx1-bsqXx15
	foreach var in `r(varlist)' { /* Ratio of explanation by base rules */
		qui replace `var' = `var'/sum_base
	}
	
	
	keep if _n==1
	if `num'==16{
		keep bsqXx* corp base sum* explained topinc_sh
	}
	else if `num'==15{
		keep bsqXx* corp base sum* explained
	}
	
	xpose, varname clear
	
	replace v1 = 100*v1
	
	format v1 %12.2f
	
	rename v1 `outcome'_topinc`c'
	
	tempfile data_`outcome'_`c'
	save `data_`outcome'_`c''
	
	restore
}

preserve
	use `data_`outcome'_yes', clear
	merge 1:1 _varname using `data_`outcome'_no', nogen
	
	tempfile data_`outcome'
	save `data_`outcome''
restore


}
use `data_r_g', clear
*merge 1:1 _varname using `data_l_r_g', nogen
*merge 1:1 _varname using `data_l_r_g_topinc', nogen
*merge 1:1 _varname using `data_baseline', nogen

set obs 27


g label = ""
g order = .

local order = 1
replace label = "\multicolumn{2}{l}{ \% Explained}" if _varname=="explained"
replace order=`order' if _varname=="explained"
local ++order

replace label = "& Corporate Rate" if _varname=="corp"
replace order=`order' if _varname=="corp"
local ++order
replace label = "& Base Measures" if _varname=="base"
replace order=`order' if _varname=="base"
local ++order
replace label = "& Top Personal Rate" if _varname=="topinc_sh"
replace order=`order' if _varname=="topinc_sh"
local ++order

replace order=`order' in 25
local ++order

replace label = "\multicolumn{2}{l}{ \% Explained Var Among Base Rules}" in 24
replace order=`order' in 24
local ++order
replace label = "& Federal Inc as State Base" if _varname=="bsqXx1"
replace order=`order' if _varname=="bsqXx1"
local ++order
replace label = "& Federal Inc Deductible" if _varname=="bsqXx2"
replace order=`order' if _varname=="bsqXx2"
local ++order	
replace label = "& Throwback Rules" if _varname=="bsqXx3"
replace order=`order' if _varname=="bsqXx3"
local ++order	
replace label = "& Payroll Apportionment Wgt" if _varname=="bsqXx4"
replace order=`order' if _varname=="bsqXx4"
local ++order	
replace label = "& Loss Carryforward" if _varname=="bsqXx5"
replace order=`order' if _varname=="bsqXx5"
local ++order	
replace label = "& Loss Carryback" if _varname=="bsqXx6"
replace order=`order' if _varname=="bsqXx6"
local ++order		
replace label = "& Combined Reporting" if _varname=="bsqXx7"
replace order=`order' if _varname=="bsqXx7"
local ++order		
replace label = "& Investment Tax Credit" if _varname=="bsqXx8"
replace order=`order' if _varname=="bsqXx8"
local ++order	
replace label = "& R\&D Credit" if _varname=="bsqXx9"
replace order=`order' if _varname=="bsqXx9"
local ++order	
replace label = "& ACRS Depreciation" if _varname=="bsqXx10"
replace order=`order' if _varname=="bsqXx10"
local ++order	
replace label = "& Federal Accelerated Dep" if _varname=="bsqXx11"
replace order=`order' if _varname=="bsqXx11"
local ++order	
replace label = "& Federal Bonus Dep" if _varname=="bsqXx12"
replace order=`order' if _varname=="bsqXx12"
local ++order	
replace label = "& Franchise Tax" if _varname=="bsqXx13"
replace order=`order' if _varname=="bsqXx13"
local ++order			
replace label = "& Incremental R\&D, Moving Avg" if _varname=="bsqXx14"
replace order=`order' if _varname=="bsqXx14"
local ++order	
replace label = "& Incremental R\&D, Fixed" if _varname=="bsqXx15"
replace order=`order' if _varname=="bsqXx15"
local ++order	

sort order

keep if order!=.

*SETUP LATEX
g tab = "\begin{tabular}{llcccc}" in 1
g titlerow2 = " & & \multicolumn{3}{c}{Corp Tax Rev Share of GDP}" in 1
*Hline
g hline = "\hline" in 1
g top = "\toprule" in 1
*Midrule
g mid = "\midrule" in 1 
*Bottomrule
g bot = "\bottomrule" in 1
*End
g end = "\end{tabular}" in 1
*Empty column
g c = ""

*  13 tax measures
listtex tab if _n == 1 using "$tabdir/table`tabnum'.tex", rstyle(none) replace
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)	
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)	
listtex titlerow2 if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
listtex mid if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)	
listtex label c r_g_topincno r_g_topincyes if _n<=21, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex end if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
