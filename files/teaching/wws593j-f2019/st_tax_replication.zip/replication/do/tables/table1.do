* Summary statistics of 13 main tax base measures
* Local assignment
local tabnum = 1
clear
set more off


/*****************/
/*** Draw data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear

drop if fips==11|fips==0|fips>56 //Only keeping 50 states
keep if inrange(year, 1980, 2010) //Only keeping years between 1980 and 2010

gen r_gdp = (rev_corptax)/GDP*100

#delimit ;
local sumlist = "throwback combined investment_credit rec_val Losscarryback 
	Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase 
	AllowFedAccDep ACRSDepreciation FederalBonusDepreciation sales_wgt incr_ma incr_fixed r_gdp";
#delimit cr

/*******************************/
/*** 1. Pooled Summary Stats ***/
/*******************************/
	preserve
	
	foreach var in `sumlist'{
		qui{
		sum `var'
		local num_`var' = `r(N)'
		local m_`var' = `r(mean)'
		local sd_`var' = `r(sd)'
		
		if inlist("`var'", "investment_credit", "rec_val", "propertytax", "propabatement", "jobcreationcred"){
			local m_`var' = 100*`r(mean)'
			local sd_`var' = 100*`r(sd)'
		}
		}
	}
		
	g labels = ""
	local row = 1

	*Main metrics
	replace labels = "Corp Tax Revenue as Share of GDP (\%)" in `row'
	local ++row
	replace labels = "Throwback Rules" in `row'
	local ++row
	replace labels = "Combined Reporting" in `row'
	local ++row
	replace labels = "Investment Tax Credit" in `row'
	local ++row
	replace labels = "R\&D Tax Credit" in `row'
	local ++row
	replace labels = "Loss Carryback Rules" in `row'
	local ++row
	replace labels = "Loss Carryforward Rules" in `row'
	local ++row
	replace labels = "Franchise Tax" in `row'
	local ++row
	replace labels = "Fed Income Tax Deductible" in `row'
	local ++row
	replace labels = "Fed Income as State Tax Base" in `row'
	local ++row
	replace labels = "Fed Accelerated Depreciation" in `row'
	local ++row
	replace labels = "ACRS Depreciation" in `row'
	local ++row
	replace labels = "Federal Bonus Depreciation" in `row'
	local ++row
	replace labels = "Sales Apportionment Weight" in `row'
	local ++row
	replace labels = "Incremental R\&D Credit, Base is Fixed" in `row'
	local ++row
	replace labels = "Incremental R\&D Credit, Base is Moving Average" in `row'
	local ++row	

	*Svae values in summary stats table format
	foreach var in num m sd{
	qui{
		local row = 1
		if "`var'"=="num"{
			local decimal = 0
		}
		else{
			local decimal = 3
		}
		g `var' = ""
		replace `var' = string(``var'_r_gdp', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_throwback', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_combined', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_investment_credit', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_rec_val', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_Losscarryback', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_Losscarryforward', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_FranchiseTax', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_FedIncomeTaxDeductible', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_FederalIncomeasStateTaxBase', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_AllowFedAccDep', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_ACRSDepreciation', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_FederalBonusDepreciation', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_sales_wgt', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_incr_fixed', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_incr_ma', "%12.`decimal'f") in `row'
		local ++row
	}
	}



	*Output to tex file
		*Tab begin
		g tab = "\begin{tabular}{lccc}" in 1
		*Title
		g titlerow = " & Observations & Mean & Std. Dev." in 1
		g panelA = "\multicolumn{4}{l}{\textit{Panel A. 1980-2010 Pooled Sample}}" in 1
		*g panelA = "\multicolumn{4}{l}{\textit{Panel A. Main Tax Base Measures}}" in 1
		*g panelB = "\multicolumn{4}{l}{\textit{Panel A. Bartik (2017) Tax Base Measures}}" in 1
		*g titlerow = " & Observations & Mean & Std. Dev." in 1
		*Hline
		g hline = "\hline" in 1
		g top = "\toprule" in 1
		*Midrule
		g mid = "\midrule" in 1 
		*Bottomrule
		g bot = "\bottomrule" in 1
		*End
		g end = "\end{tabular}" in 1
		*Empty column
		g c = ""
			
		
		*Output
		
			*  13 tax measures
		listtex tab if _n == 1 using "$tabdir/table`tabnum'.tex", replace rstyle(none)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		
		listtex panelA if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)	
		listtex labels num m sd if _n<=16, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 
		listtex labels num m sd if _n==18, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 
	
	restore
	
	
/*****************************/
/*** 2. 2010 Summary Stats ***/
/*****************************/

preserve
	keep if year==2010
	
	foreach var in `sumlist'{
		qui{
		sum `var'
		local num_`var' = `r(N)'
		local m_`var' = `r(mean)'
		local sd_`var' = `r(sd)'
		
		if inlist("`var'", "investment_credit", "rec_val", "propertytax", "propabatement", "jobcreationcred"){
			local m_`var' = 100*`r(mean)'
			local sd_`var' = 100*`r(sd)'
		}
		}
	}
		
	g labels = ""
	local row = 1

	*Main metrics
	replace labels = "Corp Tax Revenue as Share of GDP (\%)" in `row'
	local ++row
	replace labels = "Throwback Rules" in `row'
	local ++row
	replace labels = "Combined Reporting" in `row'
	local ++row
	replace labels = "Investment Tax Credit" in `row'
	local ++row
	replace labels = "R\&D Tax Credit" in `row'
	local ++row
	replace labels = "Loss Carryback Rules" in `row'
	local ++row
	replace labels = "Loss Carryforward Rules" in `row'
	local ++row
	replace labels = "Franchise Tax" in `row'
	local ++row
	replace labels = "Fed Income Tax Deductible" in `row'
	local ++row
	replace labels = "Fed Income as State Tax Base" in `row'
	local ++row
	replace labels = "Fed Accelerated Depreciation" in `row'
	local ++row
	replace labels = "ACRS Depreciation" in `row'
	local ++row
	replace labels = "Federal Bonus Depreciation" in `row'
	local ++row
	replace labels = "Sales Apportionment Weight" in `row'
	local ++row
	replace labels = "Incremental R\&D Credit, Base is Fixed" in `row'
	local ++row
	replace labels = "Incremental R\&D Credit, Base is Moving Average" in `row'
	local ++row	

	*Svae values in summary stats table format
	foreach var in num m sd{
	qui{
		local row = 1
		if "`var'"=="num"{
			local decimal = 0
		}
		else{
			local decimal = 3
		}
		g `var' = ""
		replace `var' = string(``var'_r_gdp', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_throwback', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_combined', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_investment_credit', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_rec_val', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_Losscarryback', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_Losscarryforward', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_FranchiseTax', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_FedIncomeTaxDeductible', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_FederalIncomeasStateTaxBase', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_AllowFedAccDep', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_ACRSDepreciation', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_FederalBonusDepreciation', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_sales_wgt', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_incr_fixed', "%12.`decimal'f") in `row'
		local ++row
		replace `var' = string(``var'_incr_ma', "%12.`decimal'f") in `row'
		local ++row
	}
	}


	*Output to tex file
		g titlerow = " & Observations & Mean & Std. Dev." in 1
		g panelB = "\multicolumn{4}{l}{\textit{Panel B. 2010 Cross Section}}" in 1
		*Hline
		g hline = "\hline" in 1
		g top = "\toprule" in 1
		*Midrule
		g mid = "\midrule" in 1 
		*Bottomrule
		g bot = "\bottomrule" in 1
		*End
		g end = "\end{tabular}" in 1
		*Empty column
		g c = ""
		
		*  13 tax measures
		listtex panelB if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)	
		listtex labels num m sd if _n<=16, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 
		
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		listtex end if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
		
	restore
