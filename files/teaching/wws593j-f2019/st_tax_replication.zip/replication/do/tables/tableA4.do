*Local assignment
local tabnum = "A4"

clear
set more off

/*****************/
/*** Draw Data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56
cd "$tabdir"


/*************************/
/*** Data Manipulation ***/
/*************************/
*Generate variables
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corporate_rate/100 ) /* Really the log of keep rate */

gen r_g = rev_corptax/GDP 

replace corporate_rate = corporate_rate/100
sum corporate_rate , d
gen corporate_rate_demean = corporate_rate -r(mean)
gen corporate2 = corporate_rate^2
gen corporate_rate_demean2 = corporate_rate_demean^2

label var corporate2 "Corp. rate sq"

tsset fips year 

gen ln_gdp=  ln(GDP)

bys fips: egen mean_GDP = mean(GDP)

label var corporate_rate "Corp. rate"

sort fips year
gen ch_r_g = (r_g - L1.r_g)
gen ch_corporate_rate = (corporate_rate - L1.corporate_rate)
gen ch_corporate2 = (ch_corporate_rate*ch_corporate_rate)

replace r_g = 100*r_g

sort fips_state year
local baserules = "FedIncomeTaxDeductible"
foreach rule in `baserules' {
	gen b_it_`rule' = (-(`rule' - L1.`rule'))
}

local baserules = "FranchiseTax"
foreach rule in `baserules' {
	gen b_it_`rule' = -(`rule' - L1.`rule')
}

local baserules = "investment_credit rec_val Losscarryforward Losscarryback AllowFedAccDep ACRSDepreciation FederalBonusDepreciation"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "sales_wgt"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "FederalIncomeasStateTaxBase combined throwback"
foreach rule in `baserules' {
	gen b_it_`rule' = sign((`rule' - L1.`rule'))
}

local baserules = "incr_ma incr_fixed"
foreach rule in `baserules' {
	gen b_it_`rule' = sign((`rule' - L1.`rule'))
}
  
local baserules = "FedIncomeTaxDeductible investment_credit Losscarryforward Losscarryback sales_wgt FederalIncomeasStateTaxBase combined throwback AllowFedAccDep ACRSDepreciation FederalBonusDepreciation FranchiseTax rec_val incr_ma incr_fixed"
foreach rule in `baserules' {
	by fips_state: gen B_it_`rule' = sum(b_it_`rule')
	label var B_it_`rule' "`rule'"
}

** It depends on this number 
replace b_it_throwback = 0  if  year == 2007 

egen B = rowtotal(B_it_*)

gen B_X_corporate = B*corporate_rate
gen B_X_corporate_sq = B*corporate2

label var B "Cumulative base change"
label var B_X_corporate "Rate $\times$ Cumulative base change"
label var B_X_corporate_sq "Rate sq $\times$ Cumulative base change"

/*************************/
/*** Time Series Facts ***/
/*************************/

**** (a) Corp Rev/GDP and Tax Rate
egen mean_rate = mean(corporate_rate), by(year)
egen mean_R = mean(r_g), by(year)
egen tag = tag(year)
replace mean_R = mean_R*100

label var mean_rate "Mean Corp. Rate"
label var mean_R "Mean Corp. Rev/GDP"

** Define broadening and narrowing
egen basebroadened = rowtotal(b_it_FedIncomeTaxDeductible-b_it_incr_fixed)
replace basebroadened = 1 if basebroadened >= 1
replace basebroadened = 0 if basebroadened < 1

egen basenarrow = rowtotal(b_it_FedIncomeTaxDeductible-b_it_incr_fixed)
replace basenarrow = 0 if basenarrow >= 0
replace basenarrow = 1 if basenarrow < 0

gen anybasechange = 0
replace anybasechange = 1 if basebroadened == 1 | basenarrow == 1

gen tax_decrease = 0
replace tax_decrease = 1 if ch_corporate_rate < 0
gen tax_nochange = 0
replace tax_nochange = 1 if ch_corporate_rate == 0
gen tax_increase = 0
replace tax_increase = 1 if ch_corporate_rate > 0

label var tax_decrease "Rate decrease"
label var tax_nochange "No rate change"

eststo clear
eststo est1: probit anybasechange tax_decrease tax_nochange, vce(cluster state)
eststo est2: probit anybasechange tax_decrease tax_nochange i.year , vce(cluster state)
eststo est3: probit basebroadened tax_decrease tax_nochange i.year, vce(cluster state)
eststo est4: probit basenarrow tax_decrease tax_nochange i.year , vce(cluster state)

estout est2 est3 est4 using "$tabdir/table`tabnum'a.tex", replace style(tex) cells(b(star fmt(4)) se(par fmt(4))) label ///
	mlabels(, none) coll(, none) ///
	keep(tax_decrease tax_nochange) starlevels(* .1 ** .05 *** .01) 
	
*Another version (flipped)
gen anytaxchange = 1 - tax_nochange

label var basenarrow "Base narrowed"
label var basebroadened "Base broadened"

eststo clear
eststo est1: probit anytaxchange basenarrow basebroadened, vce(cluster state)
eststo est2: probit anytaxchange basenarrow basebroadened i.year , vce(cluster state)
eststo est3: probit tax_increase basenarrow basebroadened i.year , vce(cluster state)
eststo est4: probit tax_decrease basenarrow basebroadened i.year , vce(cluster state)

estout est2 est3 est4 using  "$tabdir/table`tabnum'b.tex", replace style(tex) cells(b(star fmt(4)) se(par fmt(4))) label ///
	mlabels(, none) coll(, none) ///
	keep(basenarrow basebroadened) starlevels(* .1 ** .05 *** .01) 
	
*Clean from estout (remove "main" row from both probits generated above)
preserve

import delim "$tabdir/table`tabnum'a.tex", clear
drop if _n == 1 /* Remove first row */
export delim using "$tabdir/table`tabnum'a.tex", replace novarnames

import delim "$tabdir/table`tabnum'b.tex", clear
drop if _n == 1 /* Remove first row */
export delim using "$tabdir/table`tabnum'b.tex", replace novarnames

restore
