*Local assignment
local tabnum = "A3"

clear
set more off

/*****************/
/*** Draw Data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56
cd "$tabdir"

/*************************/
/*** Data Manipulation ***/
/*************************/
*Generate variables
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corporate_rate/100 ) /* Really the log of keep rate */

gen r_g = rev_corptax/GDP 

replace corporate_rate = corporate_rate/100
sum corporate_rate , d
gen corporate_rate_demean = corporate_rate -r(mean)
gen corporate2 = corporate_rate^2
gen corporate_rate_demean2 = corporate_rate_demean^2

label var corporate2 "Corp. rate sq"

tsset fips year 

gen ln_gdp=  ln(GDP)

bys fips: egen mean_GDP = mean(GDP)

label var corporate_rate "Corp. rate"

sort fips year
gen ch_r_g = (r_g - L1.r_g)
gen ch_corporate_rate = (corporate_rate - L1.corporate_rate)
gen ch_corporate2 = (ch_corporate_rate*ch_corporate_rate)

replace r_g = 100*r_g

sort fips_state year
local baserules = "FedIncomeTaxDeductible"
foreach rule in `baserules' {
	gen b_it_`rule' = (-(`rule' - L1.`rule'))
}

local baserules = "FranchiseTax"
foreach rule in `baserules' {
	gen b_it_`rule' = -(`rule' - L1.`rule')
}

local baserules = "investment_credit rec_val Losscarryforward Losscarryback AllowFedAccDep ACRSDepreciation FederalBonusDepreciation"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "sales_wgt"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "FederalIncomeasStateTaxBase combined throwback"
foreach rule in `baserules' {
	gen b_it_`rule' = sign((`rule' - L1.`rule'))
}

local baserules = "incr_ma incr_fixed"
foreach rule in `baserules' {
	gen b_it_`rule' = sign((`rule' - L1.`rule'))
}
  
local baserules = "FedIncomeTaxDeductible investment_credit Losscarryforward Losscarryback sales_wgt FederalIncomeasStateTaxBase combined throwback AllowFedAccDep ACRSDepreciation FederalBonusDepreciation FranchiseTax rec_val incr_ma incr_fixed"
foreach rule in `baserules' {
	by fips_state: gen B_it_`rule' = sum(b_it_`rule')
	label var B_it_`rule' "`rule'"
}

egen B = rowtotal(B_it_*)

gen B_X_corporate = B*corporate_rate
gen B_X_corporate_sq = B*corporate2

label var B "Cumulative base change"
label var B_X_corporate "Rate $\times$ Cumulative base change"
label var B_X_corporate_sq "Rate sq $\times$ Cumulative base change"

/*************************/
/*** Time Series Facts ***/
/*************************/

drop if fips_state == 11 | fips_state == 0 // drop DC, US
drop if fips_state > 56 // Drop foreign

egen basebroadened = rowtotal(b_it_FedIncomeTaxDeductible-b_it_throwback)
replace basebroadened = 1 if basebroadened >= 1
replace basebroadened = 0 if basebroadened < 1

egen basenarrow = rowtotal(b_it_FedIncomeTaxDeductible-b_it_throwback)
replace basenarrow = 0 if basenarrow >= 0
replace basenarrow = 1 if basenarrow < 0

gen anybasechange = 0
replace anybasechange = 1 if basebroadened == 1 | basenarrow == 1

gen tax_decrease = 0
replace tax_decrease = 1 if ch_corporate_rate < 0
gen tax_nochange = 0
replace tax_nochange = 1 if ch_corporate_rate == 0
gen tax_increase = 0
replace tax_increase = 1 if ch_corporate_rate > 0

label var tax_decrease "Rate decrease"
label var tax_nochange "No rate change"

* Frequency of tax base changes accompanying rate changes (state-years)
* Aggregate Level
gen basechange = 0
replace basechange = 1 if basebroadened == 1
replace basechange = -1 if basenarrow == 1
gen ratechange = 0
replace ratechange = 1 if tax_increase == 1
replace ratechange = -1 if tax_decrease == 1

label var ratechange "Change in Corp. Rate"
label define ratelabel -1 "Rate Decrease" 0 "No Change" 1 "Rate Increase", replace
label values ratechange ratelabel 

label var basechange "Change in Tax Base"
label define baselabel -1 "Narrowing" 0 "No Change" 1 "Broadening"
label values basechange baselabel

	
* By Base Measures
local i = 1
foreach str in sales_wgt Losscarryback Losscarryforward FranchiseTax ///
 FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation ///
 FederalBonusDepreciation throwback combined investment_credit rec_val incr_ma incr_fixed  {
count if ratechange == -1 & b_it_`str' == -1
scalar A = `r(N)'
count if ratechange == -1 & b_it_`str' == 1
scalar B = `r(N)'
count if ratechange == 1 & b_it_`str' == -1
scalar C = `r(N)'
count if ratechange == 1 & b_it_`str' == 1
scalar D = `r(N)'
count if ratechange == 0 & b_it_`str' == -1
scalar E = `r(N)'
count if ratechange == 0 & b_it_`str' == 1
scalar F = `r(N)'
count if b_it_`str' == -1
scalar G = `r(N)'
count if b_it_`str' == 1
scalar H = `r(N)'

if `i' == 1 mat define out = A,B,C,D,E,F,G,H
if `i' > 1 mat define out = out\A,B,C,D,E,F,G,H

local ++i
}
 
 
 
 
* COUNT number of total tax changes
count if ratechange == -1
count if ratechange == 1
count if ratechange == 0
count if ratechange != 0

mat colnames out = -1 +1 -1 +1 -1 +1 -1 +1
mat rownames out = Sales_Wgt Loss_Carry_Back Loss_Carry_Forward Franchise_Tax ///
  Fed_Income_Tax_Deductible Federal_Income_as_State_Tax_Base Allow_Fed_Acc_Dep ACRS_Depreciation ///
  Federal_Bonus_Depreciation Throwback Combined Investment_Credit Rec_Val incr_ma incr_fixed 
matrix list out

svmat out /* Alternative to outtable */
keep out*
drop if missing(out1)
g varnames = "" /* Need to manually add tex-appropriate variable names due to svmat restrictions */
replace varnames = "Sales Apportionment Weight" in 1
replace varnames = "Loss Carryback" in 2
replace varnames = "Loss Carryforward" in 3
replace varnames = "Francise Tax" in 4
replace varnames = "Federal Income Tax Deductible" in 5
replace varnames = "Federal Income Tax as State Tax Base" in 6
replace varnames = "Federal Accelerated Depreciation" in 7
replace varnames = "ACRS Depreciation" in 8
replace varnames = "Federal Bonus Depreciation" in 9
replace varnames = "Throwback" in 10
replace varnames = "Combined Reporting" in 11
replace varnames = "Investment Credit" in 12
replace varnames = "R\&D Credit" in 13
replace varnames = "R\&D Credit Incremental Base, Mov Avg" in 14
replace varnames = "R\&D Credit Incremental Base, Fixed" in 15

order varnames out*
listtex using "$tabdir/table`tabnum'.tex", rstyle(tabular) replace

*outtable using "$tabdir/timeseries_comovetable2", mat(out) replace nobox
