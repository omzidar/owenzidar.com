
set more off

*Table A14
local tabnum = "A14"

*----- MERGE TAX RATE AND BASE CHANGE DATA FOR SIMILAR STATES  -----*
set more off
use "$dtadir/similar_states.dta", clear

xtset fips year

//Define changes in tax rate
local threshold = .5
qui {
g ch_corprate = corporate_rate - L.corporate_rate
gen abs_ch_corprate = abs(ch_corprate)
replace ch_corprate = 0 if abs(ch_corprate)<`threshold'
gen ch_corprate_ind = (ch_corprate != 0 & !missing(ch_corprate))
gen ch_corprate_inc = (ch_corprate > 0 & !missing(ch_corprate))
gen ch_corprate_dec = (ch_corprate < 0 & !missing(ch_corprate))

}
*egen totchange = rowtotal(ch_corprate_main_inc ch_corprate_main_dec c_*)
*g anychange = (totchange>=1)
	
//Create base broadening or narrowing indicator
sort fips_state year
local baserules = "FedIncomeTaxDed"
foreach rule in `baserules' {
	gen b_it_`rule' = (-(`rule' - L1.`rule'))
}

local baserules = "FranchiseTax"
foreach rule in `baserules' {
	gen b_it_`rule' = -(`rule' - L1.`rule')
}

local baserules = "investment_cred rec_val Losscarryf Losscarryb AllowFedAc ACRSDep FederalBonusDep"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "sales_wgt"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "FederalIncomeas combined throwback"
foreach rule in `baserules' {
	gen b_it_`rule' = sign((`rule' - L1.`rule'))
}

local baserules = "incr_ma incr_fixed"
foreach rule in `baserules' {
	gen b_it_`rule' = sign((`rule' - L1.`rule'))
}

egen basebroadened = rowtotal(b_it_FedIncomeTaxDed-b_it_incr_fixed)
replace basebroadened = 1 if basebroadened >= 1
replace basebroadened = 0 if basebroadened < 1

egen basenarrow = rowtotal(b_it_FedIncomeTaxDed-b_it_incr_fixed)
replace basenarrow = 0 if basenarrow >= 0
replace basenarrow = 1 if basenarrow < 0

gen anybasechange = 0
replace anybasechange = 1 if basebroadened == 1 | basenarrow == 1

//Make a table of similar states in year before  an event

g allsimstates = ""
levelsof stateabbrev, local(stateab)
foreach st in `stateab'{
	sort stateabbrev Lsimstates
	qui levelsof Lsimstates if ((anybasechange==1|ch_corprate_ind==1) & stateabbrev=="`st'"),  local(simstates)
	foreach simst in `simstates'{
		qui replace allsimstates = allsimstates + " " + "`simst'" if "`simst'"!="" & stateabbrev=="`st'"
	}
}

qui replace allsimstates = subinstr(allsimstates, " ", "", 1)
qui replace allsimstates = subinstr(allsimstates, " ", ", ", .)

sort stateabbrev year
egen tag = tag(stateabbrev)
keep if tag==1
drop tag

drop if allsimstates ==""

*Tab begin
g tab = "\begin{tabular}{ll}" in 1
*Tabular
g titlerow = " State & Similar States" in 1
*Hline
g hline = "\hline" in 1
g top = "\toprule" in 1
*Midrule
g mid = "\midrule" in 1 
*Bottomrule
g bot = "\bottomrule" in 1
*End
g end = "\end{tabular}" in 1

*Output: pass-through share of economic activity
listtex tab if _n == 1 using "$tabdir/table`tabnum'.tex", replace rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)	
listtex stateabbrev allsimstates, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)		
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex end if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
