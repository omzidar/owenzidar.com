set more off

*Table A5
local tabnum = "A5"
local num=1

/////////////////////////////////////
******* NERIGHBOR STATES ************
/////////////////////////////////////

	*Identify probability that a state has a tax change in t given that the average rate
	*for adjacent states changed
	use "$dtadir/adjacent_states.dta", clear

	*keep fips year avg_corp_rate_adj corporate_rate
	xtset fips year

	*Establish if other states changed taxes in last year
	g L1ch_adj_inc = L.ch_corprate_inc_adj
	g L1ch_adj_dec = L.ch_corprate_dec_adj
	g L1basenarrow_adj = L.basenarrow_adj
	g L1basebroadened_adj = L.basebroadened_adj
	
	g ch_inc = (L1ch_adj_inc==1)
	g ch_dec = (L1ch_adj_dec==1)
	g ch_basenarrow = (L1basenarrow_adj==1)
	g ch_basebroadened = (L1basebroadened_adj==1)

	*RATE INCREASE
	probit ch_corprate_inc  ch_inc ch_dec ch_basenarrow ch_basebroaden, cluster(fips)
		predict inc_hat
		g inc_hat0_tmp = inc_hat if ch_inc==ch_dec==ch_basenarrow==ch_basebroaden==0
		egen inc_hat0 = max(inc_hat0_tmp)
			
		foreach var in ch_inc ch_dec ch_basenarrow ch_basebroaden{
			local varname = subinstr("`var'", "ch_", "", .)
			*STARS
			g inc_star_`varname' = "" 
			qui{
			test `var'
			local pval = r(p)
			replace inc_star_`varname' = "$^{*}$" if `pval' < .1 & `pval' >= .05
			replace inc_star_`varname' = "$^{**}$" if `pval' < .05 & `pval' >= .01
			replace inc_star_`varname' = "$^{***}$" if `pval' < .01 
			
			g se_inc_`varname' = "("+string(_se[`var'], "%12.3f")+")"
			g phat_inc_`varname'_tmp = inc_hat if `var'==1
			egen phat_inc_`varname' = max(phat_inc_`varname'_tmp)
			
			g diff_inc_`varname'_tmp = phat_inc_`varname' - inc_hat0
			g diff_inc_`varname' = string(diff_inc_`varname'_tmp, "%12.3f")+inc_star_`varname'
			replace se_inc_`varname' = "" if diff_inc_`varname'=="."
			replace diff_inc_`varname' = "" if diff_inc_`varname'=="."
			}
			drop *tmp *star* phat*
			}
		g N_inc_hat = "(N = " +string(e(N))+")"
		
	*RATE DECREASE
	probit ch_corprate_dec ch_inc ch_dec ch_basenarrow ch_basebroaden, cluster(fips)
		predict dec_hat
		g dec_hat0_tmp = dec_hat if ch_inc==ch_dec==ch_basenarrow==ch_basebroaden==0
		egen dec_hat0 = max(dec_hat0_tmp)
		
		foreach var in ch_inc ch_dec ch_basenarrow ch_basebroaden{
			local varname = subinstr("`var'", "ch_", "", .)
			*STARS
			g dec_star_`varname' = "" 
			qui{
			test `var'
			local pval = r(p)
			replace dec_star_`varname' = "$^{*}$" if `pval' < .1 & `pval' >= .05
			replace dec_star_`varname' = "$^{**}$" if `pval' < .05 & `pval' >= .01
			replace dec_star_`varname' = "$^{***}$" if `pval' < .01 
			
			g se_dec_`varname' = "("+string(_se[`var'], "%12.3f")+")"
			g phat_dec_`varname'_tmp = dec_hat if `var'==1
			egen phat_dec_`varname' = max(phat_dec_`varname'_tmp)
			
			g diff_dec_`varname'_tmp = phat_dec_`varname' - dec_hat0
			g diff_dec_`varname' = string(diff_dec_`varname'_tmp, "%12.3f")+dec_star_`varname'
			replace se_dec_`varname' = "" if diff_dec_`varname'=="."
			replace diff_dec_`varname' = "" if diff_dec_`varname'=="."
			}
			drop *tmp *star* phat*
			}
		g N_dec_hat = "(N = " +string(e(N))+")"

	*-----BASE NARROW-----*
		probit basenarrow ch_inc ch_dec ch_basenarrow ch_basebroaden, cluster(fips)
		predict basenarrow_hat, pr
		g basenarrow_hat0_tmp = basenarrow_hat if ch_inc==ch_dec==ch_basenarrow==ch_basebroaden==0
		egen basenarrow_hat0 = max(basenarrow_hat0_tmp)
			
		foreach var in ch_inc ch_dec ch_basenarrow ch_basebroaden{
			local varname = subinstr("`var'", "ch_", "", .)
			*STARS
			g basenarrow_star_`varname' = "" 
			test `var'
			local pval = r(p)
			replace basenarrow_star_`varname' = "$^{*}$" if `pval' < .1 & `pval' >= .05
			replace basenarrow_star_`varname' = "$^{**}$" if `pval' < .05 & `pval' >= .01
			replace basenarrow_star_`varname' = "$^{***}$" if `pval' < .01 
			
			g se_basenarrow_`varname' = "("+string(_se[`var'], "%12.3f")+")"
			g phat_basenarrow_`varname'_tmp = basenarrow_hat if `var'==1
			egen phat_basenarrow_`varname' = max(phat_basenarrow_`varname'_tmp)
			*format phat_dec_`i' %12.3f
			
			g diff_basenarrow_`varname'_tmp = phat_basenarrow_`varname' - basenarrow_hat0
			g diff_basenarrow_`varname' = string(diff_basenarrow_`varname'_tmp, "%12.3f")+basenarrow_star_`varname'
			replace se_basenarrow_`varname' = "" if diff_basenarrow_`varname'=="."
			replace diff_basenarrow_`varname' = "" if diff_basenarrow_`varname'=="."
			
			drop *tmp *star* phat*
			}
				
		g N_basenarrow_hat = "(N = " +string(e(N))+")"
		
		*----BASE BROADEN-----*
		probit basebroadened ch_inc ch_dec ch_basenarrow ch_basebroaden, cluster(fips)
		predict basebroaden_hat
		g basebroaden_hat0_tmp = basebroaden_hat if ch_inc==ch_dec==ch_basenarrow==ch_basebroaden==0
		egen basebroaden_hat0 = max(basebroaden_hat0_tmp)
			
		foreach var in ch_inc ch_dec ch_basenarrow ch_basebroaden{
			local varname = subinstr("`var'", "ch_", "", .)
			*STARS
			g basebroaden_star_`varname' = "" 
			test `var'
			local pval = r(p)
			replace basebroaden_star_`varname' = "$^{*}$" if `pval' < .1 & `pval' >= .05
			replace basebroaden_star_`varname' = "$^{**}$" if `pval' < .05 & `pval' >= .01
			replace basebroaden_star_`varname' = "$^{***}$" if `pval' < .01 
			
			g se_basebroaden_`varname' = "("+string(_se[`var'], "%12.3f")+")"
			g phat_basebroaden_`varname'_tmp = basebroaden_hat if `var'==1
			egen phat_basebroaden_`varname' = max(phat_basebroaden_`varname'_tmp)
			
			g diff_basebroaden_`varname'_tmp = phat_basebroaden_`varname' - basebroaden_hat0
			g diff_basebroaden_`varname' = string(diff_basebroaden_`varname'_tmp, "%12.3f")+basebroaden_star_`varname'
			replace se_basebroaden_`varname' = "" if diff_basebroaden_`varname'=="."
			replace diff_basebroaden_`varname' = "" if diff_basebroaden_`varname'=="."

			drop *tmp *star* phat*
			}
				
		g N_basebroaden_hat = "(N = " +string(e(N))+")"
		
		
	keep if inc_hat!=.

	qui ds *hat0
	foreach var in `r(varlist)'{
		format `var' %12.3f
	}

	*Set up tex table
		*Tab begin
		g tab = "\begin{tabular}{lccccc}" in 1
		*Tabular
		g numrow = " & (1) &  (2) &  (3) & (4) & (5)" in 1
		g titlerow = "Dep Var & Baseline &  Corp Rate Inc &  Corp Rate Dec & Base Broadened & Base Narrowed" in 1
		*Hline
		g hline = "\hline" in 1
		g top = "\toprule" in 1
		*Midrule
		g mid = "\midrule" in 1 
		*Bottomrule
		g bot = "\bottomrule" in 1
		*End
		g end = "\end{tabular}" in 1
		*Empty column
		g c = ""
		*Empty row
		g empty = "\multicolumn{6}{c}{}" in 1
		g label_inc = "Corp Rate Increase" in 1
		g label_dec = "Corp Rate Decrease" in 1
		g label_basebroaden = "Tax Base Broadening" in 1
		g label_basenarrow = "Tax Base Narrowing" in 1
		
		*Output
		listtex tab if _n == 1 using "$tabdir/table`tabnum'a.tex", replace rstyle(none)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
		listtex numrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular)	
		listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular)	
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
		listtex label_inc inc_hat0 diff_inc_inc diff_inc_dec diff_inc_basebroaden diff_inc_basenarrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 
		listtex N_inc_hat c se_inc_inc se_inc_dec se_inc_basebroaden se_inc_basenarrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 	
		listtex empty if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 
		listtex label_dec dec_hat0 diff_dec_inc diff_dec_dec diff_dec_basebroaden diff_dec_basenarrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 
		listtex N_dec_hat c se_dec_inc se_dec_dec se_dec_basebroaden se_dec_basenarrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular)
		listtex empty if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 
		listtex label_basebroaden basebroaden_hat0 diff_basebroaden_inc diff_basebroaden_dec diff_basebroaden_basebroaden diff_basebroaden_basenarrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 
		listtex N_basebroaden_hat c se_basebroaden_inc se_basebroaden_dec se_basebroaden_basebroaden se_basebroaden_basenarrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular)
		listtex empty if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 
		listtex label_basenarrow basenarrow_hat0 diff_basenarrow_inc diff_basenarrow_dec diff_basenarrow_basebroaden diff_basenarrow_basenarrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular) 
		listtex N_basenarrow_hat c se_basenarrow_inc se_basenarrow_dec se_basenarrow_basebroaden se_basenarrow_basenarrow if _n==1, appendto("$tabdir/table`tabnum'a.tex") rstyle(tabular)
		listtex hline if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
		listtex end if _n == 1, appendto("$tabdir/table`tabnum'a.tex") rstyle(none)
	


///////////////////////////////////
******* SIMILAR STATES ************
///////////////////////////////////

	*----- MERGE TAX RATE AND BASE CHANGE DATA FOR SIMILAR STATES  -----*
	set more off
	use "$dtadir/similar_states.dta", clear

	xtset fips year

	//Define changes in tax rate
	local threshold = .5
	qui {
	g ch_corprate = corporate_rate - L.corporate_rate
	gen abs_ch_corprate = abs(ch_corprate)
	replace ch_corprate = 0 if abs(ch_corprate)<`threshold'
	gen ch_corprate_ind = (ch_corprate != 0 & !missing(ch_corprate))
	gen ch_corprate_inc = (ch_corprate > 0 & !missing(ch_corprate))
	gen ch_corprate_dec = (ch_corprate < 0 & !missing(ch_corprate))

	}
		
	//Create base broadening or narrowing indicator
	sort fips_state year
	local baserules = "FedIncomeTaxDed"
	foreach rule in `baserules' {
		gen b_it_`rule' = (-(`rule' - L1.`rule'))
	}

	local baserules = "FranchiseTax"
	foreach rule in `baserules' {
		gen b_it_`rule' = -(`rule' - L1.`rule')
	}

	local baserules = "investment_cred rec_val Losscarryf Losscarryb AllowFedAc ACRSDep FederalBonusDep"
	foreach rule in `baserules' {
		gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
	}

	local baserules = "sales_wgt"
	foreach rule in `baserules' {
		gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
	}

	local baserules = "FederalIncomeas combined throwback"
	foreach rule in `baserules' {
		gen b_it_`rule' = sign((`rule' - L1.`rule'))
	}

	local baserules = "incr_ma incr_fixed"
	foreach rule in `baserules' {
		gen b_it_`rule' = sign((`rule' - L1.`rule'))
	}

	egen basebroadened = rowtotal(b_it_FedIncomeTaxDed-b_it_incr_fixed)
	replace basebroadened = 1 if basebroadened >= 1
	replace basebroadened = 0 if basebroadened < 1

	egen basenarrow = rowtotal(b_it_FedIncomeTaxDed-b_it_incr_fixed)
	replace basenarrow = 0 if basenarrow >= 0
	replace basenarrow = 1 if basenarrow < 0

	gen anybasechange = 0
	replace anybasechange = 1 if basebroadened == 1 | basenarrow == 1

	//Keep change data only, tempfile

	preserve
	keep stateabbrev fips_state year ch_* base*

	rename stateabbrev Lsimstates

	//Set number of lags we are considering when calculating prob that state changes tax rate
	qui ds ch_* b* 
	sort fips_state year
	foreach var in `r(varlist)'{
		g L1sim`var' = L1.`var' 
	} 

	*Define any changes in the past n years. 
	g ch_sim_rate_inc = (L1simch_corprate_inc==1 & L1simch_corprate_inc!=.)
	g ch_sim_rate_dec = (L1simch_corprate_dec==1 & L1simch_corprate_dec!=.)	
	g ch_sim_basenarrow = (L1simbasenarrow==1 & L1simbasenarrow!=.)	
	g ch_sim_basebroaden = (L1simbasebroadened==1 & L1simbasebroadened!=.)	

	*drop *tmp
	
	replace year = year+1 //Want to match the data to their lagged similar states

	tempfile changes
	save `changes'

	restore

	// Merge lagged similar state change data
	// Allowing m:1 match because some states are multiples state's similar state
	// Might need to fix this, so that each matching state is only considered similar to one target state in a given year  
	sort stateabbrev year
	merge m:1 year Lsimstates using `changes', nogen keep(1 3)
	sort stateabbrev year

	*----- PROBIT: Rate and base change propensity, given changes in sim state's   -----*
	drop if Lsimstates==""
	*-----INCREASE-----*
	probit ch_corprate_inc ch_sim_rate_inc ch_sim_rate_dec ch_sim_basenarrow ch_sim_basebroaden, cluster(fips)
	predict inc_hat
	g inc_hat0_tmp = inc_hat if ch_sim_rate_inc==ch_sim_rate_dec==ch_sim_basenarrow==ch_sim_basebroaden==0
	egen inc_hat0 = max(inc_hat0_tmp)
		
	foreach var in ch_sim_rate_inc ch_sim_rate_dec ch_sim_basenarrow ch_sim_basebroaden{
		local varname = subinstr("`var'", "ch_sim_", "", .)
		*STARS
		g inc_star_`varname' = "" 
		qui{
		test `var'
		local pval = r(p)
		replace inc_star_`varname' = "$^{*}$" if `pval' < .1 & `pval' >= .05
		replace inc_star_`varname' = "$^{**}$" if `pval' < .05 & `pval' >= .01
		replace inc_star_`varname' = "$^{***}$" if `pval' < .01 
		
		g se_inc_`varname' = "("+string(_se[`var'], "%12.3f")+")"
		g phat_inc_`varname'_tmp = inc_hat if `var'==1
		egen phat_inc_`varname' = max(phat_inc_`varname'_tmp)
		
		g diff_inc_`varname'_tmp = phat_inc_`varname' - inc_hat0
		g diff_inc_`varname' = string(diff_inc_`varname'_tmp, "%12.3f")+inc_star_`varname'
		replace se_inc_`varname' = "" if diff_inc_`varname'=="."
		replace diff_inc_`varname' = "" if diff_inc_`varname'=="."
		}
		drop *tmp *star* phat*
		}
	g N_inc_hat = "(N = " +string(e(N))+")"

	*-----RATE DECREASE-----*
	probit ch_corprate_dec ch_sim_rate_inc ch_sim_rate_dec ch_sim_basenarrow ch_sim_basebroaden, cluster(fips)
	predict dec_hat
	g dec_hat0_tmp = dec_hat if ch_sim_rate_inc==ch_sim_rate_dec==ch_sim_basenarrow==ch_sim_basebroaden==0
	egen dec_hat0 = max(dec_hat0_tmp)
		
	foreach var in ch_sim_rate_inc ch_sim_rate_dec ch_sim_basenarrow ch_sim_basebroaden{
		local varname = subinstr("`var'", "ch_sim_", "", .)
		*STARS
		qui{
		g dec_star_`varname' = "" 
		test `var'
		local pval = r(p)
		replace dec_star_`varname' = "$^{*}$" if `pval' < .1 & `pval' >= .05
		replace dec_star_`varname' = "$^{**}$" if `pval' < .05 & `pval' >= .01
		replace dec_star_`varname' = "$^{***}$" if `pval' < .01 
		
		g se_dec_`varname' = "("+string(_se[`var'], "%12.3f")+")"
		g phat_dec_`varname'_tmp = dec_hat if `var'==1
		egen phat_dec_`varname' = max(phat_dec_`varname'_tmp)
		
		g diff_dec_`varname'_tmp = phat_dec_`varname' - dec_hat0
		g diff_dec_`varname' = string(diff_dec_`varname'_tmp, "%12.3f")+dec_star_`varname'
		replace se_dec_`varname' = "" if diff_dec_`varname'=="."
		replace diff_dec_`varname' = "" if diff_dec_`varname'=="."
		}
		drop *tmp *star* phat*
		}
		
	g N_dec_hat = "(N = " +string(e(N))+")"

	*-----BASE NARROW-----*
	probit basenarrow ch_sim_rate_inc ch_sim_rate_dec ch_sim_basenarrow ch_sim_basebroaden, cluster(fips)
	predict basenarrow_hat
	g basenarrow_hat0_tmp = basenarrow_hat if ch_sim_rate_inc==ch_sim_rate_dec==ch_sim_basenarrow==ch_sim_basebroaden==0
	egen basenarrow_hat0 = max(basenarrow_hat0_tmp)
		
	foreach var in ch_sim_rate_inc ch_sim_rate_dec ch_sim_basenarrow ch_sim_basebroaden{
		local varname = subinstr("`var'", "ch_sim_", "", .)
		*STARS
		g basenarrow_star_`varname' = "" 
		test `var'
		local pval = r(p)
		replace basenarrow_star_`varname' = "$^{*}$" if `pval' < .1 & `pval' >= .05
		replace basenarrow_star_`varname' = "$^{**}$" if `pval' < .05 & `pval' >= .01
		replace basenarrow_star_`varname' = "$^{***}$" if `pval' < .01 
		
		g se_basenarrow_`varname' = "("+string(_se[`var'], "%12.3f")+")"
		g phat_basenarrow_`varname'_tmp = basenarrow_hat if `var'==1
		egen phat_basenarrow_`varname' = max(phat_basenarrow_`varname'_tmp)
		*format phat_dec_`i' %12.3f
		
		g diff_basenarrow_`varname'_tmp = phat_basenarrow_`varname' - basenarrow_hat0
		g diff_basenarrow_`varname' = string(diff_basenarrow_`varname'_tmp, "%12.3f")+basenarrow_star_`varname'
		replace se_basenarrow_`varname' = "" if diff_basenarrow_`varname'=="."
		replace diff_basenarrow_`varname' = "" if diff_basenarrow_`varname'=="."
		
		drop *tmp *star* phat*
		}
			
	g N_basenarrow_hat = "(N = " +string(e(N))+")"

	*----BASE BROADEN-----*
	probit basebroaden ch_sim_rate_inc ch_sim_rate_dec ch_sim_basenarrow ch_sim_basebroaden, cluster(fips)
	predict basebroaden_hat
	g basebroaden_hat0_tmp = basebroaden_hat if ch_sim_rate_inc==ch_sim_rate_dec==ch_sim_basenarrow==ch_sim_basebroaden==0
	egen basebroaden_hat0 = max(basebroaden_hat0_tmp)
		
	foreach var in ch_sim_rate_inc ch_sim_rate_dec ch_sim_basenarrow ch_sim_basebroaden{
		local varname = subinstr("`var'", "ch_sim_", "", .)
		*STARS
		g basebroaden_star_`varname' = "" 
		test `var'
		local pval = r(p)
		replace basebroaden_star_`varname' = "$^{*}$" if `pval' < .1 & `pval' >= .05
		replace basebroaden_star_`varname' = "$^{**}$" if `pval' < .05 & `pval' >= .01
		replace basebroaden_star_`varname' = "$^{***}$" if `pval' < .01 
		
		g se_basebroaden_`varname' = "("+string(_se[`var'], "%12.3f")+")"
		g phat_basebroaden_`varname'_tmp = basebroaden_hat if `var'==1
		egen phat_basebroaden_`varname' = max(phat_basebroaden_`varname'_tmp)
		
		g diff_basebroaden_`varname'_tmp = phat_basebroaden_`varname' - basebroaden_hat0
		g diff_basebroaden_`varname' = string(diff_basebroaden_`varname'_tmp, "%12.3f")+basebroaden_star_`varname'
		replace se_basebroaden_`varname' = "" if diff_basebroaden_`varname'=="."
		replace diff_basebroaden_`varname' = "" if diff_basebroaden_`varname'=="."
		
		drop *tmp *star* phat*
		}
			
	g N_basebroaden_hat = "(N = " +string(e(N))+")"

	keep if inc_hat!=.

	qui ds *hat0
	foreach var in `r(varlist)'{
		format `var' %12.3f
	}

	*Set up tex table
	*Tab begin
	g tab = "\begin{tabular}{lcccccc}" in 1
	*Tabular
	g numrow = " & (1) &  (2) &  (3) & (4) & (5)" in 1
	g titlerow = "Dep Var & Baseline &  Corp Rate Inc &  Corp Rate Dec & Base Broadened & Base Narrowed" in 1
	*Hline
	g hline = "\hline" in 1
	g top = "\toprule" in 1
	*Midrule
	g mid = "\midrule" in 1 
	*g cmid = "\cline{2-2} \cline{4-4} \cline{6-6} \cline{8-8}" in 1 
	*Bottomrule
	g bot = "\bottomrule" in 1
	*End
	g end = "\end{tabular}" in 1
	*Empty column
	g c = ""
	*Empty row
	g empty = "\multicolumn{6}{c}{}" in 1
	g label_inc = "Corp Rate Increase" in 1
	g label_dec = "Corp Rate Decrease" in 1
	g label_basebroaden = "Tax Base Broadening" in 1
	g label_basenarrow = "Tax Base Narrowing" in 1
	g se = "\multicolumn{6}{l}{\footnotesize Standard errors in parentheses} \\"
	g pstar = "\multicolumn{6}{l}{\footnotesize $^*$ \(p<.1\), $^**$ \(p<.05\), $^***$ \(p<.01\)} \\"

	*Output
	listtex tab if _n == 1 using "$tabdir/table`tabnum'b.tex", replace rstyle(none)
	listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
	listtex numrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular)	
	listtex titlerow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular)	
	listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
	listtex label_inc inc_hat0 diff_inc_rate_inc diff_inc_rate_dec diff_inc_basebroaden diff_inc_basenarrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 
	listtex N_inc_hat c se_inc_rate_inc se_inc_rate_dec se_inc_basebroaden se_inc_basenarrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 	
	listtex empty if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 
	listtex label_dec dec_hat0 diff_dec_rate_inc diff_dec_rate_dec diff_dec_basebroaden diff_dec_basenarrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 
	listtex N_dec_hat c se_dec_rate_inc se_dec_rate_dec se_dec_basebroaden se_dec_basenarrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular)
	listtex empty if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 
	listtex label_basebroaden basebroaden_hat0 diff_basebroaden_rate_inc diff_basebroaden_rate_dec diff_basebroaden_basebroaden diff_basebroaden_basenarrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 
	listtex N_basebroaden_hat c se_basebroaden_rate_inc se_basebroaden_rate_dec se_basebroaden_basebroaden se_basebroaden_basenarrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular)
	listtex empty if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 
	listtex label_basenarrow basenarrow_hat0 diff_basenarrow_rate_inc diff_basenarrow_rate_dec diff_basenarrow_basebroaden diff_basenarrow_basenarrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular) 
	listtex N_basenarrow_hat c se_basenarrow_rate_inc se_basenarrow_rate_dec se_basenarrow_basebroaden se_basenarrow_basenarrow if _n==1, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular)
	listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
	listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
	listtex end if _n == 1, appendto("$tabdir/table`tabnum'b.tex") rstyle(none)
