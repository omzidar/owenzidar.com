* Local assignment
local tabnum = 7

clear
set more off


/*****************/
/*** Draw data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear

*TRY THIS
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56
sort fips_state year

/*************************/
/*** Data Manipulation ***/
/*************************/
*Generate variables
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corporate_rate/100 ) /* Really the log of keep rate */

gen r_g = 100*rev_corptax/GDP 

replace corporate_rate = corporate_rate/100
sum corporate_rate , d
gen corporate_rate_demean = corporate_rate -r(mean)
gen corporate2 = corporate_rate^2
gen corporate_rate_demean2 = corporate_rate_demean^2

label var corporate2 "Corp. rate sq"

tsset fips year 

gen ln_gdp=  ln(GDP)

bys fips: egen mean_GDP = mean(GDP)

label var corporate_rate "Corp. rate"


sort fips year
gen ch_r_g = (r_g - L1.r_g)
gen ch_corporate_rate = (corporate_rate - L1.corporate_rate)
gen ch_corporate2 = (ch_corporate_rate*ch_corporate_rate)


local i = 1 
foreach var of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed  {
	gen s`i' = `var'
	local ++i
}

/*************************/
/*** Create base index ***/
/*************************/
preserve


local Z "s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12 s13 s14 s15" 
reg r_g `Z'   ///
i.year i.fips, cl(fips)
capture: drop base_index
gen base_index= _b[s1]*s1+_b[s2]*s2+_b[s3]*s3+_b[s4]*s4+ ///
_b[s5]*s5+_b[s6]*s6+_b[s7]*s7+_b[s8]*s8+ ///
_b[s9]*s9+_b[s10]*s10+_b[s11]*s11+_b[s12]*s12 +_b[s13]*s13+_b[s14]*s14 + _b[s15]*s15

sum base_index, d 
replace base_index = (base_index-r(mean))/r(sd)

keep if base_index != . 


/**********************/
/*** Laffer Table 1 ***/
/**********************/

est clear

eststo est1: reg r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year  , cl(fips)
	estadd local hasy "Yes"

eststo est2: reg r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year i.fips , cl(fips)
	estadd local hasy "Yes"
	estadd local hass "Yes"
	
eststo est3: reg r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year base_index  , cl(fips) 
 	estadd local hasy "Yes"
 
eststo est4: reg r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year base_index i.fips  , cl(fips) 
	estadd local hasy "Yes"
	estadd local hass "Yes"
	nlcom -_b[c.corporate_rate]/(2*_b[c.corporate_rate#c.corporate_rate]) 
	local top_mean = el(r(b),1,1)
	estadd scalar top = `top_mean'
 
eststo est5: reg r_g c.corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year base_index   c.base_index#(c.corporate_rate c.corporate_rate#c.corporate_rate) i.fips  , cl(fips) 
	estadd local hasy "Yes"
	estadd local hass "Yes"
	nlcom -_b[c.corporate_rate]/(2*_b[c.corporate_rate#c.corporate_rate]) 
	local top_mean = el(r(b),1,1)
	estadd scalar top = `top_mean'
	
	
esttab est* using "$tabdir/table`tabnum'a.tex" , fragment style(tex) nofloat star(* .1 ** .05 *** .01) drop(*fips_state *year _cons) stats() scalars("N Observations"  "hasy Year Fixed Effects"  "hass State Fixed Effects"  "top Revenue-Maximizing Rate") sfmt(%9.0fc 1 1 3) ///
b(2) se(2) par label coeflabel(corporate_rate "State Corporate Tax Rate $\tau$ " ///
c.base_index#c.corporate_rate "State Corporate Tax Rate $\tau$ $\times$ Base Index" /// 
c.corporate_rate#c.corporate_rate "State Corporate Tax Rate$^2$ $(\tau)^2$ " ///
c.base_index#c.corporate_rate#c.corporate_rate "State Corporate Tax Rate$^2$ $(\tau)^2$ $\times$ Base Index" ///
base_index "Base Index $\times$ 100 ") transform(base_index @*100 100) ///
noobs nogap nomtitle replace nocons  ///
preh("{\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} " ///
			"\begin{tabular}{l*{6}{c}}" "\hline \hline") ///
postfoot( ///
" \hline \hline " ///
"\end{tabular} }" )


restore

/*************************************/
/*** Laffer Table 2, Total revenue ***/
/*************************************/


gen total_r_g = (rev_totaltaxes/GDP)*100

/*************************/
/*** Create base index ***/
/*************************/
preserve

* Total Tax Revenue/GDP:
local Z "s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12 s13 s14 s15" 
reg total_r_g `Z'   ///
i.year i.fips, cl(fips)
capture: drop base_index
gen base_index= _b[s1]*s1+_b[s2]*s2+_b[s3]*s3+_b[s4]*s4+ ///
_b[s5]*s5+_b[s6]*s6+_b[s7]*s7+_b[s8]*s8+ ///
_b[s9]*s9+_b[s10]*s10+_b[s11]*s11+_b[s12]*s12 +_b[s13]*s13+_b[s14]*s14 + _b[s15]*s15

sum base_index, d 
replace base_index = (base_index-r(mean))/r(sd)

keep if base_index != . 



est clear

eststo est1: reg total_r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year  , cl(fips)
	estadd local hasy "Yes"

eststo est2: reg total_r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year i.fips , cl(fips) 
	estadd local hasy "Yes"
	estadd local hass "Yes"
	
eststo est3: reg total_r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year base_index  , cl(fips) 
	estadd local hasy "Yes"
 
eststo est4: reg total_r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year base_index i.fips  , cl(fips) 
	estadd local hasy "Yes"
	estadd local hass "Yes"
	nlcom -_b[c.corporate_rate]/(2*_b[c.corporate_rate#c.corporate_rate]) 
	local top_mean = el(r(b),1,1)
	estadd scalar top = `top_mean'
 
eststo est5: reg total_r_g c.corporate_rate c.corporate_rate#c.corporate_rate ///
 i.year base_index   c.base_index#(c.corporate_rate c.corporate_rate#c.corporate_rate) i.fips  , cl(fips) 
	estadd local hasy "Yes"
	estadd local hass "Yes"
	nlcom -_b[c.corporate_rate]/(2*_b[c.corporate_rate#c.corporate_rate]) 
	local top_mean = el(r(b),1,1)
	estadd scalar top = `top_mean'
	
esttab est* using "$tabdir/table`tabnum'b.tex" , fragment nofloat star(* .1 ** .05 *** .01) ///
drop(*fips_state *year _cons) stats() ///
scalars("N Observations"  "hasy Year Fixed Effects"  "hass State Fixed Effects"  "top Revenue-Maximizing Rate")  sfmt(%9.0fc 1 1 3) ///
b(1) se(1) par label coeflabel(corporate_rate "State Corporate Tax Rate $\tau$ " ///
c.base_index#c.corporate_rate "State Corporate Tax Rate $\tau$ $\times$ Base Index" ///
c.corporate_rate#c.corporate_rate "State Corporate Tax Rate$^2$ $(\tau)^2$ " ///
c.base_index#c.corporate_rate#c.corporate_rate "State Corporate Tax Rate$^2$ $(\tau)^2$ $\times$ Base Index" ///
base_index "Base Index $\times$ 100 ") transform(base_index @*100 100) ///
noobs nogap nomtitle replace nocons ///
preh("{\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} " ///
		"\begin{tabular}{l*{6}{c}}" "\hline \hline") ///
postfoot( ///
" \hline \hline " ///
"\end{tabular} }" )




restore
