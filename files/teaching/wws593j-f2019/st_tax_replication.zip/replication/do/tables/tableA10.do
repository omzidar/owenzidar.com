* Local assignment
local tabnum = "A10"
clear
set more off

/*****************/
/*** Draw Data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear
sort fips_state year

cd "$tabdir"




/*************************/
/*** Data Manipulation ***/
/*************************/
** Gen main variables 
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corporate_rate/100 ) /* Actually log keep rate */
gen log_rev_gdp = log(rev_corp/GDP) //Updated 02/08/2018
gen r_g = rev_corptax/GDP
gen r_gos = rev_corptax/GOS_s
gen log_rev_gos = log(rev_corp/GOS_s)
gen log_gos = log(GOS_s)
gen log_gdp = log(GDP)
gen gos = GOS_s/100000

** Center base components around state+year FE 
local base "sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit" 
foreach var in `base' { 
	reg `var' i.fips i.year 
	predict temp, res 
	replace `var' = temp 
	drop temp 
}


replace r_g = r_g*100

bys fips: egen mean_GDP = mean(GDP)


foreach xvar of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
	 sum `xvar'  [aw=mean_GDP], d
	 replace `xvar'=(`xvar'-r(mean))/r(sd)

}

tsset fips year 
local i = 1 
foreach var of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
	gen s`i' = `var'
	gen l_s`i' = l1.`var'
	gen l2_s`i' = l2.`var'
	gen l3_s`i' = l3.`var'
	gen l4_s`i' = l4.`var'
	gen l5_s`i' = l5.`var'
	local i = `i'+1 
}

replace log_corp = corporate_rate 

gen l1_log_corp = l1.log_corp 
gen l2_log_corp = l2.log_corp 
gen l3_log_corp = l3.log_corp 
gen l4_log_corp = l4.log_corp 
gen l5_log_corp = l5.log_corp 

** Generate index
reg r_g log_corp i.year i.fips rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit  ///	
c.log_corp#(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) [aw=mean_GDP]		

gen index2 = (_b[c.log_corp#c.s1]*s1 ///
	 +_b[c.log_corp#c.s2]*s2+_b[c.log_corp#c.s3]*s3 ///   
	 +_b[c.log_corp#c.s4]*s4+_b[c.log_corp#c.s5]*s5 ///
	 +_b[c.log_corp#c.s6]*s6+_b[c.log_corp#c.s7]*s7 ///
	 +_b[c.log_corp#c.s8]*s8+_b[c.log_corp#c.s9]*s9 ///
	 +_b[c.log_corp#c.s10]*s10+_b[c.log_corp#c.s11]*s11+_b[c.log_corp#c.s12]*s12+_b[c.log_corp#c.s13]*s13 ///
	 +_b[c.log_corp#c.s14]*s14+_b[c.log_corp#c.s15]*s15) if e(sample) 
				
	sum index2 [aw=mean_GDP], d 			 
	replace index2=(index2)/r(sd)
	
tsset fips year 

********** 
do "$dodir/jc_add_stats.ado"
est clear 

eststo r1: areg r_g log_corp l1_log_corp i.year ///
[aw=mean_GDP]		, a(fips) cluster(fips)
lincom log_corp+l1_log_corp
jc_add_stats , ene(1700) stat("Total")

eststo r2: areg r_g log_corp l1_log_corp i.year ///
(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) ///
l1.(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) ///
[aw=mean_GDP]		, a(fips) cluster(fips)
lincom log_corp+l1_log_corp
jc_add_stats , ene(1455) stat("Total")

eststo r3: areg r_g log_corp l1_log_corp i.year ///
c.log_corp#c.index2  c.l1_log_corp#c.l1.index2 ///
(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) ///
[aw=mean_GDP]		, a(fips) cluster(fips)
lincom log_corp+l1_log_corp
jc_add_stats , ene(1455) stat("Total")

eststo r4: areg r_g log_corp l*_log_corp i.year ///
c.log_corp#c.index2  c.l1_log_corp#c.l1.index2 ///
c.l2_log_corp#c.l2.index2 ///
c.l3_log_corp#c.l3.index2 ///
c.l4_log_corp#c.l4.index2 ///
c.l5_log_corp#c.l5.index2 ///
(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) ///
(c.l*_s1 c.l*_s2 c.l*_s3 c.l*_s4 c.l*_s5 c.l*_s6 c.l*_s7 c.l*_s8 c.l*_s9 c.l*_s10 c.l*_s11 c.l*_s12 c.l*_s13 c.l*_s14 c.l*_s15) ///
[aw=mean_GDP]		, a(fips) cluster(fips)
lincom log_corp+l1_log_corp+l2_log_corp+l3_log_corp+l4_log_corp+l5_log_corp
jc_add_stats , ene(1455) stat("Total")

eststo r5: areg r_g log_corp l1_log_corp i.year ///
c.log_corp#(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) ///
c.l1_log_corp#(c.l_s1 c.l_s2 c.l_s3 c.l_s4 c.l_s5 c.l_s6 c.l_s7 c.l_s8 c.l_s9 c.l_s10 c.l_s11 c.l_s12 c.l_s13 c.l_s14 c.l_s15) ///
(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) ///
(c.l_s1 c.l_s2 c.l_s3 c.l_s4 c.l_s5 c.l_s6 c.l_s7 c.l_s8 c.l_s9 c.l_s10 c.l_s11 c.l_s12 c.l_s13 c.l*_s14 c.l*_s15) ///
[aw=mean_GDP]		, a(fips) cluster(fips)
lincom log_corp+l1_log_corp
jc_add_stats , ene(1455) stat("Total")

eststo r6: areg r_g log_corp l*_log_corp i.year ///
c.log_corp#(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) ///
c.l1_log_corp#(c.l_s1 c.l_s2 c.l_s3 c.l_s4 c.l_s5 c.l_s6 c.l_s7 c.l_s8 c.l_s9 c.l_s10 c.l_s11 c.l_s12 c.l_s13  c.l_s14 c.l_s15) ///
c.l2_log_corp#(c.l2_s1 c.l2_s2 c.l2_s3 c.l2_s4 c.l2_s5 c.l2_s6 c.l2_s7 c.l2_s8 c.l2_s9 c.l2_s10 c.l2_s11 c.l2_s12 c.l2_s13 c.l2_s14 c.l2_s15) ///
c.l3_log_corp#(c.l3_s1 c.l3_s2 c.l3_s3 c.l3_s4 c.l3_s5 c.l3_s6 c.l3_s7 c.l3_s8 c.l3_s9 c.l3_s10 c.l3_s11 c.l3_s12 c.l3_s13 c.l3_s14 c.l3_s15) ///
c.l4_log_corp#(c.l4_s1 c.l4_s2 c.l4_s3 c.l4_s4 c.l4_s5 c.l4_s6 c.l4_s7 c.l4_s8 c.l4_s9 c.l4_s10 c.l4_s11 c.l4_s12 c.l4_s13 c.l4_s14 c.l4_s15) ///
c.l5_log_corp#(c.l5_s1 c.l5_s2 c.l5_s3 c.l5_s4 c.l5_s5 c.l5_s6 c.l5_s7 c.l5_s8 c.l5_s9 c.l5_s10 c.l5_s11 c.l5_s12 c.l5_s13 c.l5_s14 c.l5_s15) ///
(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15) ///
(c.l*_s1 c.l*_s2 c.l*_s3 c.l*_s4 c.l*_s5 c.l*_s6 c.l*_s7 c.l*_s8 c.l*_s9 c.l*_s10 c.l*_s11 c.l*_s12 c.l*_s13  c.l*_s14 c.l*_s15) ///
[aw=mean_GDP]		, a(fips) cluster(fips)
lincom log_corp+l1_log_corp+l2_log_corp+l3_log_corp+l4_log_corp+l5_log_corp
jc_add_stats , ene(1455) stat("Total")

esttab  r* using table`tabnum'.tex, keep(_cons) stats() ///
b(3) se par label coeflabel(log_corp "\hspace{1em}Effective Rate")  starlevels(* .1 ** 0.05 *** 0.01) ///
noobs nogap nomtitle tex replace nocons postfoot("")

estout  r*  using table`tabnum'.tex, keep(*log_corp *index2) order(*log_corp *index2)  ///
 starlevels(* .1 ** 0.05 *** 0.01)  ///
cells(b(star fmt(3)) se(par) ) mlab(none) coll(none)  /// 
varlabel(log_corp "$\tau$"  ///
l1_log_corp "L1 Lagged $\tau$" ///
l2_log_corp "L2 Lagged $\tau$" ///
l3_log_corp "L3 Lagged $\tau$" ///
l4_log_corp "L4 Lagged $\tau$" ///
l5_log_corp "L5 Lagged $\tau$" ///
c.log_corp#c.index2  "$\tau\times $ Joint Interactions From Table 4"  ///
c.l1_log_corp#cL.index2  "L1 Lagged $\tau\times $ Lagged Joint Interactions From Table 4"  ///
c.l2_log_corp#cL2.index2  "L2 Lagged $\tau\times $ Lagged Joint Interactions From Table 4"  ///
c.l3_log_corp#cL3.index2  "L3 Lagged $\tau\times $ Lagged Joint Interactions From Table 4"  ///
c.l4_log_corp#cL4.index2  "L4 Lagged $\tau\times $ Lagged Joint Interactions From Table 4"  ///
c.l5_log_corp#cL5.index2  "L5 Lagged $\tau\times $ Lagged Joint Interactions From Table 4" ) ///
stats( Total Total_SE Total_pval , nostar /// 
labels( "Total Effect $\sum_t \beta^{\tau}_i $" " " " " ) fmt(%9.0fc 3)) ///
prefoot("\hline")  postfoot( ///
" \hline " ///
"Base and L1 Lagged Base Controls     			& N & Y & Y & Y & Y & Y  \\ "  ///
"	 L2-L5 Lagged Base Controls     		& N & N & N & Y & N & Y   \\ "  ///
"Base Interaction and Lagged Base Interaction    	& N & N & N & N & Y & Y   \\" ///
"	 L2-L5 Lagged Base Interaction    		& N & N & N & N & N & Y   \\" ///
"State Fixed Effects   					& Y & Y & Y & Y & Y & Y   \\" ///
"Year Fixed Effects				  	& Y & Y & Y & Y & Y & Y   \\  \hline\hline" ///
"\end{tabular} }" ) append sty(tex)


