*-------Make table with state-level states for 1980, 2010--------*
* Local assignment
local tabnum = "A13"
set more off

use "$dtadir/similar_states_prematch.dta", clear
	

g tag = (statename=="United States")

g ln_pop = log(pop)
	
*make table summarizing key characteristics in beginning and end of sample
keep statename year skill ln_pop man_shGDP inf_prof_serv_shGDP constr_mining_shGDP agr_shGDP tag
keep if inlist(year, 1980, 2010)
*adjust_inflation percapita_GDP wage, year(2010) month_3letter_or_annual(Annual)

replace skill = 100*skill //in pct

//Include US national average
*replace percapita_GDP = 33337.35 if statename=="United States" & year==1980
*replace percapita_GDP = 48373.879 if statename=="United States" & year==2010

foreach var in ln_pop skill man_shGDP inf_prof_serv_shGDP constr_mining_shGDP agr_shGDP{
	format `var' %12.1fc
}

reshape wide skill man_shGDP inf_prof_serv_shGDP constr_mining_shGDP agr_shGDP ln_pop, i(statename) j(year)

sort tag statename


*Output to tex file
*Tab begin
g colsetup = "{\newcolumntype{C}{>{\centering\arraybackslash}p{2em}}"
g tab = "\begin{tabular}{lCCcCCcCCcCCcCCcCC}" in 1
*Title
g titlerow0 = " & & & & & & & \multicolumn{11}{c}{Share of GDP} " in 1
g titlerow1 = " & \multicolumn{2}{c}{Log Pop} & & \multicolumn{2}{c}{Skill Share} & & \multicolumn{2}{c}{Agric} & & \multicolumn{2}{c}{Constr\&Mine}  & & \multicolumn{2}{c}{Manuf}  & & \multicolumn{2}{c}{Services} " in 1
g titlerow2 = "State & 1980 & 2010 & & 1980 & 2010 & & 1980 & 2010 & & 1980 & 2010 & & 1980 & 2010 & & 1980 & 2010" in 1
*Hline
g hline = "\hline" in 1
g top = "\toprule" in 1
*Midrule
g mid = "\midrule" in 1 
g cmid = "\cline{2-3} \cline{5-6} \cline{8-9} \cline{11-12} \cline{14-15} \cline{17-18}" in 1
g cmid2 = "\cline{8-18}" in 1
*Bottomrule
g bot = "\bottomrule" in 1
*End
g end = "\end{tabular}}" in 1
*Empty column
g c=""

*Output
listtex colsetup if _n == 1 using "$tabdir/table`tabnum'.tex", replace rstyle(none)
listtex tab if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex titlerow0 if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
listtex cmid2 if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex titlerow1 if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
listtex cmid if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex titlerow2 if _n==1, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular)
listtex mid if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)

listtex statename ln_pop1980 ln_pop2010 c skill1980 skill2010 c agr_shGDP1980 agr_shGDP2010 c agr_shGDP1980 agr_shGDP2010 c man_shGDP1980 man_shGDP2010 c inf_prof_serv_shGDP1980 inf_prof_serv_shGDP2010, appendto("$tabdir/table`tabnum'.tex") rstyle(tabular) 

listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)
listtex end if _n == 1, appendto("$tabdir/table`tabnum'.tex") rstyle(none)

