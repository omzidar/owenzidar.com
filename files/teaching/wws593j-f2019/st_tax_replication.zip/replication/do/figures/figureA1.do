*Local assignment
local fignum = "A1"

clear
set more off

/*****************/
/*** Draw Data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear
cd "$tabdir"


/*************************/
/*** Data Manipulation ***/
/*************************/

** Gen main varaibles 
gen r_g = rev_corptax/GDP
replace corporate_rate = corporate_rate/100
sum corporate_rate , d
gen corporate_rate_demean = corporate_rate -r(mean)
gen corporate2 = corporate_rate^2
gen corporate_rate_demean2 = corporate_rate_demean^2

label var corporate2 "Corp. rate sq"

sort fips year
gen ch_r_g = (r_g - L1.r_g)*100
gen ch_corporate_rate = (corporate_rate - L1.corporate_rate)
gen ch_corporate2 = (ch_corporate_rate*ch_corporate_rate)

** Create cumulative measure of changes to tax base
sort fips_state year
local baserules = "FedIncomeTaxDeductible"
foreach rule in `baserules' {
	gen b_it_`rule' = (-(`rule' - L1.`rule'))
}

local baserules = "FranchiseTax"
foreach rule in `baserules' {
	gen b_it_`rule' = (`rule' - L1.`rule')
}

local baserules = "investment_credit Losscarryforward Losscarryback AllowFedAccDep ACRSDepreciation FederalBonusDepreciation rec_val"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "sales_wgt FederalIncomeasStateTaxBase combined throwback"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}


  
local baserules = "FedIncomeTaxDeductible investment_credit Losscarryforward Losscarryback sales_wgt FederalIncomeasStateTaxBase combined throwback AllowFedAccDep ACRSDepreciation FederalBonusDepreciation FranchiseTax rec_val"
foreach rule in `baserules' {
	by fips_state: gen B_it_`rule' = sum(b_it_`rule')
	label var B_it_`rule' "`rule'"
}

egen B = rowtotal(B_it_*)

gen B_X_corporate = B*corporate_rate
gen B_X_corporate_sq = B*corporate2

label var B "Cumulative base change"
label var B_X_corporate "Rate $\times$ Cumulative base change"
label var B_X_corporate_sq "Rate sq $\times$ Cumulative base change"

**** (a) Corp Rev/GDP and Tax Rate
egen mean_rate = mean(corporate_rate), by(year)
egen mean_R = mean(r_g), by(year)
egen tag = tag(year)
replace mean_R = mean_R*100

label var mean_rate "Mean Corp. Rate"
label var mean_R "Mean Corp. Rev/GDP"

preserve

drop if missing(jobcreationcred)
drop if missing(propertytax)
drop if missing(propabatement)

drop mean_rate mean_R tag
egen mean_rate = mean(corporate_rate), by(year)
egen mean_R = mean(r_g), by(year)
egen tag = tag(year)
replace mean_R = mean_R*100

label var mean_rate "Mean Corp. Rate"
label var mean_R "Mean Corp. Rev/GDP"

twoway line mean_rate year if tag & year <= 2012, yaxis(1) yscale(range(0 .07)) ylabel(0 (.01) .07) yti("Mean State Corporate Tax Rate") || ///
	line mean_R year if tag & year <= 2012, xlabel(1990(5)2010) yaxis(2) yscale(range(.20 .50) axis(2)) ylabel(.20 (.05) .50, axis(2)) yti("State Corporate Tax Rev/GDP", axis(2)) ///
	graphregion(fcolor(white)) graphregion(color(white))
graph export "$figdir/figure`fignum'a.pdf", replace 

restore


*Same graph as above, but on bartik sample (UPDATED 4/20/17)
preserve
drop if missing(jobcreationcred)
drop if missing(propertytax)
drop if missing(propabatement)

gen change_rate = 0
replace change_rate = 1 if ch_corporate_rate != 0 & !missing(ch_corporate_rate)
foreach var of varlist b_it_FedIncomeTaxDeductible-b_it_throwback {
	replace `var' = abs(`var')
}

egen change_base_total = rowtotal(b_it_FedIncomeTaxDeductible-b_it_throwback)
g change_base = (change_base_total > 0 & !missing(change_base_total))

collapse (sum) change_rate (sum) change_base, by(year)

twoway (scatter change_rate change_base if year <= 2012, mlabel(year)) ///
	(line change_base change_base, sort), ///
	legend(off) ytitle("# States Changing Corporate Tax Rate") xtitle("# States Changing Base") graphregion(fcolor(white)) graphregion(color(white))

graph export "$figdir/figure`fignum'b.pdf", replace 

restore
