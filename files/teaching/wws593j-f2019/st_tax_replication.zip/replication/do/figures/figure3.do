*Update 02/22/2018

*Local assignment
local fignum = 3

clear
set more off


/*************/
/*** BEGIN ***/
/*************/

clear
set more off

/******************/
/*** Data/Setup ***/
/******************/

use "$dtadir/state_taxes_analysis.dta", clear
drop if fips_state == 0 | fips_state == 11 | fips_state > 56 /* U.S. & DC */
keep if year >= 1980 & year <= 2010

*Re-scale apportionment weights
gen corporate_rate_scaled = corporate_rate/100
replace sales_wgt = sales_wgt/100
replace payroll_wgt = payroll_wgt/100
replace prop_wgt = prop_wgt/100

*Number of states in different apportionment categories
global varlist "sales_wgt payroll_wgt prop_wgt"
foreach var in $varlist {
	gen `var'_low = (`var' < .33 & !missing(`var'))
	gen `var'_high = (`var' >= .33 & !missing(`var'))
	gen `var'_low_alt = (`var' < .50 & !missing(`var'))
	gen `var'_high_alt = (`var' >= .50 & !missing(`var'))
}

*Weighted by mean GDP
bysort fips_state: egen mean_GDP = mean(GDP)

*Figures A, B, D:

	preserve

	*Variables
	ds rec_val investment_credit Losscarryforward Losscarryback payroll_wgt sales_wgt
	collapse (mean) `r(varlist)' [aw = mean_GDP], by(year)

	*Credits
	line rec_val investment_credit year, lcolor(black black) lpattern(solid dash) lwidth(thick thick) ///
		   graphregion(fcolor(white) color(white)) ///
		   yti("Average Rate") ///
		   legend(order(1 2) label(1 "R&D Credit") label(2 "Investment Credit"))
	graph export "$figdir/figure`fignum'a.pdf", replace	   
		   
	*Loss carry
	line Losscarryforward Losscarryback year, lcolor(black black) lpattern(solid dash) lwidth(thick thick) ///
		   graphregion(fcolor(white) color(white)) ///
		   yti("Average Years") ///
		   legend(order(1 2) label(1 "Loss Carryforward") label(2 "Loss Carryback"))
	graph export "$figdir/figure`fignum'b.pdf", replace	 							 
								 
	*Sales and payroll weight
	line payroll_wgt sales_wgt year, lcolor(black black) lpattern(solid dash) lwidth(thick thick) ///
		   graphregion(fcolor(white) color(white)) ///
		   yti("Average Apportionment Weight") ///
		   legend(order(1 2) label(1 "Payroll Apportionment") label(2 "Sales Apportionment"))
	graph export "$figdir/figure`fignum'c.pdf", replace
	
	restore
	
	
*Figure C:

	preserve

	collapse (sum) throwback combined FedIncomeTaxDeductible FederalIncomeasStateTaxBase ///
				   ACRSDepreciation AllowFedAccDep FederalBonusDepreciation FranchiseTax ///
				   incr_ma incr_fixed, by(year)

	twoway (scatter throwback year, c(l)  msymbol(none) lcolor(black) lpattern(solid) lwidth(thick) ) ///
		(scatter combined year, c(l) msymbol(none) lcolor(black) lpattern(dash) lwidth(thick) ) ///
		(scatter FedIncomeTaxDeductible year, c(l) msymbol(none) lcolor(gs9) lpattern(solid)  ) ///
		(scatter FederalIncomeasStateTaxBase year, c(l) msymbol(none) lcolor(gs9) lpattern(dash) ) ///
		(scatter ACRSDepreciation year, c(l)  msymbol(circle) mcolor(black) lcolor(black) lpattern(solid) lwidth(medthick) ) ///
		(scatter AllowFedAccDep year, c(l) msymbol(circle) mcolor(black) lcolor(black) lpattern(dash) lwidth(medthick) ) ///
		(scatter FederalBonusDepreciation year, c(l) msymbol(circle) mcolor(gs9) lcolor(gs9) lpattern(solid)  ) ///
		(scatter FranchiseTax year, c(l) msymbol(circle) mcolor(gs9) lcolor(gs9) lpattern(dash) ) ///
		(scatter incr_ma year, c(l) msymbol(circle) mcolor(gs9) lcolor(gs9) lpattern("-.") ) ///
		(scatter incr_fixed year, c(l) msymbol(circle) mcolor(black) lcolor(black) lwidth(medthick) lpattern(dot) ), ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		xtitle(Year) ///
		ytitle(Number of States with Tax Rule) ylab(0(10)50) ///
		legend(rows(5) label(1 "Throwback Rule") label(2 "Combined Reporting Rule") ///
		label(3 "Fed Inc Tax Deductible") label(4 "Fed Inc as State Tax Base") ///
		label(5 "ACRS Depreciation") label(6 "Fed Accelerated Depreciation") ///
		label(7 "Fed Bonus Depreciation") label(8 "Franchise Tax") ///
		label(9 "R&D Base is Moving Avg") label(10 "R&D Base is Fixed")) 
	graph export "$figdir/figure`fignum'd.pdf", replace
		
	restore
