*Local assignment
local fignum = 1


*Draw data
use "$dtadir/state_taxes_analysis.dta", clear
sort fips_state year
tsset fips_state year

*Re-scale apportionment weights
gen corporate_rate_scaled = corporate_rate/100
replace sales_wgt = sales_wgt/100
replace payroll_wgt = payroll_wgt/100
replace prop_wgt = prop_wgt/100
g r_g = rev_corptax/GDP*100

*Panel A
kdensity_decade, var(corporate_rate_scaled) xmax(.12) xti(State Corporate Tax Rate) yti(Kernel Density) ///
	inc(.03) outname(figure`fignum'a)
	
*Panel B
kdensity_decade, var(r_g) xmax(1.1) xti(Corporate Tax Revenue as a Share of GDP) ///
	inc(.1) yti(Kernel Density) outname(figure`fignum'b)
