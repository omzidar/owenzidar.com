* Local assignment
local fignum = "A47"
	
clear
set more off

/********************************************************/
/***Analysis 3: Figures of Heterogeneous Elasticities ***/
/********************************************************/


use "$dtadir/state_taxes_analysis.dta", clear
drop if State == ""
set more off 

cd "$figdir"

bys fips: egen mean_GDP = mean(GDP)

foreach xvar of varlist rec_val payroll_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit  {
	 sum `xvar'  [aw=mean_GDP], d
	 replace `xvar'=(`xvar'-r(mean))/r(sd)

}

local i = 1 
foreach var of varlist rec_val payroll_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit  {
	gen s`i' = `var'
	local i = `i'+1 
}

label var rec_val "R\&D Tax Credit"



** Gen main varaibles 
gen log_rev = log( rev_corp)
replace corporate_rate = corporate_rate/100
gen log_corp = log( 1-corpo ) 
gen log_rev_gdp = log(rev_corp/GDP)
gen r_g = rev_corptax/GDP
replace r_g = r_g*100
gen r_gos = rev_corptax/GOS_s
gen log_rev_gos = log(rev_corp/GOS_s)
gen log_gos = log(GOS_s)
gen log_gdp = log(GDP)
gen gos = GOS_s/100000


reg r_g corporate_rate i.year i.fips c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 ///	
	c.corporate_rate#(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 )[aw=mean_GDP]	
	gen temp_prog = _b[corporate_rate]+_b[c.corporate_rate#c.s1]*s1 ///
				 +_b[c.corporate_rate#c.s2]*s2+_b[c.corporate_rate#c.s3]*s3 ///   
				 +_b[c.corporate_rate#c.s4]*s4+_b[c.corporate_rate#c.s5]*s5 ///
				 +_b[c.corporate_rate#c.s6]*s6+_b[c.corporate_rate#c.s7]*s7 ///
				 +_b[c.corporate_rate#c.s8]*s8+_b[c.corporate_rate#c.s9]*s9 ///
				 +_b[c.corporate_rate#c.s10]*s10+_b[c.corporate_rate#c.s11]*s11 ///
				 +_b[c.corporate_rate#c.s12]*s12+_b[c.corporate_rate#c.s13]*s13 if e(sample) 
	 
line temp_prog year if fips<30 & temp_prog!=. & inrange(year,1980,2010), by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Effect of {&tau} on Revenue to GDP Ratio") color(navy) 
graph export "$figdir/figure`fignum'a.pdf", replace	
	
line temp_prog year if fips>30 & temp_prog!=. & inrange(year,1980,2010), by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Effect of {&tau} on Revenue to GDP Ratio") color(navy) 	
graph export "$figdir/figure`fignum'b.pdf", replace	
