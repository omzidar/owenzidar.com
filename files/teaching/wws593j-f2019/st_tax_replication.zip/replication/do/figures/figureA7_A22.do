*A number of time series figures (rates and base rules)
*Update 4/29/17: Added payroll apportionment

clear
set more off

/*************/
/*** Setup ***/
/*************/

*Draw Data
use "$dtadir/state_taxes_analysis.dta", clear
drop if fips_state == 0 | fips_state == 11 | fips_state > 56 /* U.S. & DC */
keep if year >= 1980 & year <= 2012

replace payroll_wgt = payroll_wgt/100 /* Check scale if build updated; 4/29/17 */
replace sales_wgt = sales_wgt/100 /* Check scale if build updated; 4/29/17 */


sort fips_state year
tsset fips_state year 

/****************************************************************/
/*** First half of figures (fips 1-29); states up to Missouri ***/
/****************************************************************/

preserve

keep if fips_state <30

*State Corporate Tax Rate
line corporate_rate year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("State Corporate Tax Rate") color(navy) 
graph export "$figdir/figureA7a.pdf", replace

*Loss Carryforward
line Losscarryforward year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Loss Carryforward Rules (Years)") color(navy) 
graph export "$figdir/figureA8a.pdf", replace

*Loss Carryback
line Losscarryback year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Loss Carryback Rules (Years)") color(navy) 
graph export "$figdir/figureA9a.pdf", replace

*R&D Credit
line rec_val year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("R&D Credit Rate") color(navy)
graph export "$figdir/figureA10a.pdf", replace

*Investment Credit
line investment_credit year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Investment Credit Rate") color(navy)
graph export "$figdir/figureA11a.pdf", replace

*Throwback
line throwback year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Throwback Rule") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA12a.pdf", replace

*Combined Reporting
line combined year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Combined Reporting Rule") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA13a.pdf", replace

*Federal Income Tax Deductibility
line FedIncomeTaxDeductible year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Federal Income Tax Deductible") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA14a.pdf", replace

*Federal Income as State Tax Base
line FederalIncomeasStateTaxBase year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Federal Income as State Tax Base") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA15a.pdf", replace

*ACRS Depreciation
line ACRSDepreciation year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("ACRS Depreciation") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA16a.pdf", replace

*Federal Accelerated Depreciation Allowance
line AllowFedAccDep year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Allow Federal Accelerated Depreciation") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA17a.pdf", replace

*Federal Bonus Depreciation Allowance
line FederalBonusDepreciation year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Allow Federal Bonus Depreciation") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA18a.pdf", replace

*Sales Apportionment
line sales_wgt year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Sales Apportionment Weight") color(navy)
graph export "$figdir/figureA19a.pdf", replace


*Franchise Tax
line FranchiseTax year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Franchise Tax") color(navy)
graph export "$figdir/figureA20a.pdf", replace


*R&D Credit Base is MA
line incr_ma year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Incremental R&D Credit is Moving Average") color(navy)
graph export "$figdir/figureA21a.pdf", replace


*R&D Credit Base is Fixed
line incr_fixed year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Incremental R&D Credit is Fixed") color(navy)
graph export "$figdir/figureA22a.pdf", replace

restore

/***************************************************************/
/*** Second half of figures (fips 30+); states past Missouri ***/
/***************************************************************/

keep if fips_state >=30

*State Corporate Tax Rate
line corporate_rate year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("State Corporate Tax Rate") color(navy) 
graph export "$figdir/figureA7b.pdf", replace

*Loss Carryforward
line Losscarryforward year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Loss Carryforward Rules (Years)") color(navy) 
graph export "$figdir/figureA8b.pdf", replace

*Loss Carryback
line Losscarryback year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Loss Carryback Rules (Years)") color(navy) 
graph export "$figdir/figureA9b.pdf", replace

*R&D Credit
line rec_val year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("R&D Credit Rate") color(navy)
graph export "$figdir/figureA10b.pdf", replace

*Investment Credit
line investment_credit year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Investment Credit Rate") color(navy)
graph export "$figdir/figureA11b.pdf", replace

*Throwback
line throwback year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Throwback Rule") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA12b.pdf", replace

*Combined Reporting
line combined year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Combined Reporting Rule") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA13b.pdf", replace

*Federal Income Tax Deductibility
line FedIncomeTaxDeductible year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Federal Income Tax Deductible") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA14b.pdf", replace

*Federal Income as State Tax Base
line FederalIncomeasStateTaxBase year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Federal Income as State Tax Base") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA15b.pdf", replace

*ACRS Depreciation
line ACRSDepreciation year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("ACRS Depreciation") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA16b.pdf", replace

*Federal Accelerated Depreciation Allowance
line AllowFedAccDep year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Allow Federal Accelerated Depreciation") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA17b.pdf", replace

*Federal Bonus Depreciation Allowance
line FederalBonusDepreciation year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Allow Federal Bonus Depreciation") color(navy) ylabel(0 1, valuelabel)
graph export "$figdir/figureA18b.pdf", replace

*Sales Apportionment
line sales_wgt year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Sales Apportionment Weight") color(navy)
graph export "$figdir/figureA19b.pdf", replace

*Franchise Tax
line FranchiseTax year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Franchise Tax") color(navy)
graph export "$figdir/figureA20b.pdf", replace


*R&D Credit Base is MA
line incr_ma year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Incremental R&D Credit is Moving Average") color(navy)
graph export "$figdir/figureA21b.pdf", replace


*R&D Credit Base is Fixed
line incr_fixed year, by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Incremental R&D Credit is Fixed") color(navy)
graph export "$figdir/figureA22b.pdf", replace


