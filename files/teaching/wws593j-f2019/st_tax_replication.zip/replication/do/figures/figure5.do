*Local assignment
local fignum = 5

set more off
use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 0 | fips_state == 11 | fips_state > 56

bysort fips_state: egen mean_GDP = mean(GDP)

g period=0
replace period = 1 if year >= 1980 & year <= 1985
replace period = 2 if year >= 1986 & year <= 1990
replace period = 3 if year >= 1991 & year <= 1995
replace period = 4 if year >= 1996 & year <= 2000
replace period = 5 if year >= 2001 & year <= 2005
replace period = 6 if year >= 2006 & year <= 2010

gen r_g = rev_corptax/GDP*100

local base  "rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit"

g l_r_g=log(r_g)
g l_r  =log(rev_corptax)
g r    =rev_corptax
	


*Assign variables
g x0= corporate_rate
g x1= FederalIncomeasStateTaxBase
g x2= FedIncomeTaxDeductible 
g x3= throwback 
g x4= sales_wgt 
g x5= Losscarryforward 
g x6= Losscarryback 
g x7= combined 
g x8= investment_credit 
g x9= rec_val
g x10= ACRSDepreciation 
g x11= AllowFedAccDep 
g x12= FederalBonusDepreciation 
g x13= FranchiseTax
g x14= incr_ma 
g x15= incr_fixed


*REGRESSION
reg r_g x0-x15 i.period [aw=mean_GDP] 

g explained = e(r2)
g unexplained = 1 - e(r2)

* corp_sh_gdp = b0 + x1b1 + ...  x13b13 + e
* --> var(corp_sh_gdp). = var(x1)b1^2 + ... + var(x13)b14 + var(e), assuming covs = 0
forv j =0/15{
local beta=_b[x`j']
summ x`j'
local var=(r(sd))^2

g bsqXx`j' = (`beta')^2 *`var'
}
	
gen sum_corprate = bsqXx0
egen sum_base = rowtotal(bsqXx1-bsqXx15)
gen corp = sum_corprate/(sum_base+sum_corprate)
gen base = 1-corp

ds bsqXx1-bsqXx15
foreach var in `r(varlist)' { /* Ratio of explanation by base rules */
	qui replace `var' = 100*(`var'/sum_base)
}


*Panel A
preserve
keep if _n == 1

set obs 2

g corprate_exp = corp[1] in 2
g other = base[1] in 2
keep explained unexplained other corprate_exp

g id = ""
replace id = " R{sub:s}{sup:corp}/GDP{sub:s}" in 1 /* Space necessary to ensure this appears first.. */
replace id = "Base vs Rate" in 2

g rev = -_n
sort rev

graph bar explained unexplained corprate_exp other, stack over(id) ///
	ytitle("% of Explained Variation") ///
	graphregion(fcolor(white)) graphregion(color(white)) ///
	bar(1, color(dknavy)) bar(2, color(maroon)) bar(3, color(dknavy*.7)) bar(4, color(dknavy*.4)) ///
	legend(order(2 4 1 3) cols(2) label(1 "Explained") label(2 "Unexplained") label(3 "Corporate Rate") label(4 "Base Rules"))

*Output (and opportunity to edit manually)
graph display, ysize(5)
graph export "$figdir/figure`fignum'a.pdf", replace 
restore



*Panel B

preserve
keep bsqXx1-bsqXx15

*replace bsqXx9 = bsqXx9+ bsqXx14 +bsqXx15

graph hbar bsqXx1-bsqXx15, ///
	bargap(20) graphregion(fcolor(white)) graphregion(color(white)) ///
	nolabel ytitle("% Explained Among Base Rules") showyvars legend(off) ///
	yvaroptions(relabel(1 "Federal Inc as State Base" 2 "Federal Inc Tax Deductible" 3 "Throwback Rules" ///
						4 "Sales Apportionment Weight" 5 "Loss Carryforward" 6 "Loss Carryback" ///
						7 "Combined Reporting" 8 "Investment Tax Credit" 9 "R&D Tax Credit" ///
						10 "ACRS Depreciation" 11 "Federal Accelerated Depreciation" 12 "Federal Bonus Depreciation" 13 "Franchise Tax" ///
						14 "Incr R&D, Moving Avg Base" 15 "Incr R&D, Fixed Base")) ///
	bar(1, color(dknavy*.4)) bar(2, color(dknavy*.4)) bar(3, color(dknavy*.4)) bar(4, color(dknavy*.4)) bar(5, color(dknavy*.4)) bar(6, color(dknavy*.4)) ///
	bar(7, color(dknavy*.4)) bar(8, color(dknavy*.4)) bar(9, color(dknavy*.4)) bar(10, color(dknavy*.4)) bar(11, color(dknavy*.4)) bar(12, color(dknavy*.4)) ///
	bar(13, color(dknavy*.4)) bar(14, color(dknavy*.4)) bar(15, color(dknavy*.4))
	
graph display, ysize(3)
graph export "$figdir/figure`fignum'b.pdf", replace

graph hbar bsqXx1-bsqXx15, ///
	bargap(20) graphregion(fcolor(white)) graphregion(color(white)) ///
	nolabel ytitle("% Explained Among Base Rules") showyvars legend(off) ///
	yvaroptions(relabel(1 "Federal Inc as State Base" 2 "Federal Inc Tax Deductible" 3 "Throwback Rules" ///
						4 "Sales Apportionment Weight" 5 "Loss Carryforward" 6 "Loss Carryback" ///
						7 "Combined Reporting" 8 "Investment Tax Credit" 9 "R&D Tax Credit" ///
						10 "ACRS Depreciation" 11 "Federal Accelerated Depreciation" 12 "Federal Bonus Depreciation" 13 "Franchise Tax" ///
						14 "Incr R&D, Moving Avg Base" 15 "Incr R&D, Fixed Base")) ///
	bar(1, color(dknavy*.4)) bar(2, color(dknavy*.4)) bar(3, color(dknavy*.4)) bar(4, color(dknavy*.4)) bar(5, color(dknavy*.4)) bar(6, color(dknavy*.4)) ///
	bar(7, color(dknavy*.4)) bar(8, color(dknavy*.4)) bar(9, color(dknavy*.4)) bar(10, color(dknavy*.4)) bar(11, color(dknavy*.4)) bar(12, color(dknavy*.4)) ///
	bar(13, color(dknavy*.4)) bar(14, color(dknavy*.4)) bar(15, color(dknavy*.4)) ///
	yscale(range(0 30)) ylab(0(10)30)
	
graph display, ysize(3)
graph export "$figdir/figure`fignum'b_scaled.pdf", replace

restore

preserve
*bys fips: egen mean_GDP = mean(GDP)

g ln_keeprate = ln(1-(corporate_rate)/100)
replace sales_wgt = sales_wgt/100


**** for TS graph 
areg r_g FederalIncomeasStateTaxBase FedIncomeTaxDeductible ///
	throwback combined c.sales_wgt  c.Losscarryforward c.Losscarryback  ///
	c.investment_credit c.rec_val ACRSDepreciation ///
	AllowFedAccDep FederalBonusDepreciation FranchiseTax incr_ma incr_fixed ///
	[aw = mean_GDP], a(year)

predict r_hat, xb

*binscatter r_gdp_hat year , line(connect)

**** Normalized for graph 

foreach xvar of varlist r_g FederalIncomeasStateTaxBase FedIncomeTaxDeductible ///
	throwback sales_wgt  Losscarryforward Losscarryback combined ///
	investment_credit rec_val ACRSDepreciation ///
	AllowFedAccDep FederalBonusDepreciation FranchiseTax incr_ma incr_fixed{
	 sum `xvar'  [aw=mean_GDP], d
	 replace `xvar'=(`xvar'-r(mean))/r(sd)

}



**** Put revenue-to-gdp ratio in basis points (currently in %)
replace r_g = 100*r_g


label var rec_val "R&D Tax Credit"
label var throwback "Throwback Rules"
label var combined "Combined Reporting Rules"
label var investment_credit "Investment Tax Credit"
label var AllowFedAccDep "Allows Federal Accelerated Depreciation"
label var Losscarryforward "Loss Carryforward"
label var Losscarryback "Loss Carryback"
label var FranchiseTax "Franchise Tax"
label var incr_ma "Incremental R&D, Moving Avg Base"
label var incr_fixed "Incremental R&D, Fixed Base"
label var sales_wgt "Sales Apportionment Weight"

reg r_g FederalIncomeasStateTaxBase FedIncomeTaxDeductible ///
	throwback combined c.sales_wgt  c.Losscarryforward c.Losscarryback  ///
	c.investment_credit c.rec_val ACRSDepreciation ///
	AllowFedAccDep FederalBonusDepreciation FranchiseTax incr_ma incr_fixed ///
	[aw = mean_GDP], a(year)
	
coefplot	, drop(_cons) xline(0) level(95) xtitle("Basis Points") graphregion(color(white)) 

graph export "$figdir/figure`fignum'c.pdf", replace 
restore

