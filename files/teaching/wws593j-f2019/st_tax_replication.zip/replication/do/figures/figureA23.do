* Event Studies, Changes of all magnitudes

* Local assignment
local fignum = "A23"
	
		
*Draw main analysis dataset
use "$dtadir/state_taxes_analysis.dta", clear 
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56

sort fips_state year
tsset fips_state year 

*Logs
gen log_rev_corptax = 100*ln(rev_corptax)
gen log_gdp = 100*ln(GDP)

gen r_gdp = 100*(rev_corptax)/GDP


*Rate change with pre-determined threshold (.5 at the moment)
local threshold = 0
gen ch_corporate_rate = corporate_rate - L.corporate_rate
gen abs_ch_corporate_rate = abs(ch_corporate_rate)
replace ch_corporate_rate = 0 if abs(ch_corporate_rate) <= `threshold'
gen ch_corporate_rate_ind = (ch_corporate_rate != 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_inc = (ch_corporate_rate > 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_dec = (ch_corporate_rate < 0 & !missing(ch_corporate_rate))

*Base rules and changes therein (utilized as controls for portions of the event studies)
#delimit ;
local baserules = "FederalIncomeasStateTaxBase sales_wgt 
throwback FedIncomeTaxDeductible Losscarryforward FranchiseTax";
#delimit cr
sort fips_state year
local baserules = "FederalIncomeasStateTaxBase sales_wgt throwback FedIncomeTaxDeductible Losscarryforward FranchiseTax";
sort fips_state year
foreach rule in `baserules' {
	g abs_`rule' = abs(`rule' - L1.`rule')
	gen ch_`rule' = ( abs_`rule' != 0 &  abs_`rule'!=.)
}

drop abs*

global basecontrols = "`baserules'"

/***************************************************************/
/*** Execute ES Program; Send to dump for temp storage ***/
/***************************************************************/

foreach change in dec inc{
foreach control in nocont basecont{
if "`control'"=="basecont"{
	local includecont = " controls($basecontrols)"
}
else if "`control'"=="basecont"{
	local includecont = ""
}
Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_`change') `includecont'  ///
	outname(ES_`change'corprate_logcorprev_`control'_thresh0) 

Event_outcome, yvar(log_gdp) event(ch_corporate_rate_`change') `includecont'   ///
	outname(ES_`change'corprate_loggdp_`control'_thresh0) 
	
Event_outcome, yvar(r_gdp) event(ch_corporate_rate_`change') `includecont'   ///
	outname(ES_`change'corprate_rgdp_`control'_thresh0)

}
}

/******************************************/
/*** Combine raw event analysis results ***/
/******************************************/


/* Figure 1 (corp rev) */

*Decrease corporate rate, base controls
preserve

import delim "$dumpdir/ES_deccorprate_logcorprev_nocont_thresh0.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_logcorprev_basecont_thresh0.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Controls) lab2(Tax Base Controls) rawti(B. Log Corporate Tax Revenue) ///
	outname(figure`fignum'b)

restore

*Increase corporate rate, base cont
preserve

import delim "$dumpdir/ES_inccorprate_logcorprev_nocont_thresh0.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_logcorprev_basecont_thresh0.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Controls) lab2(Tax Base Controls) rawti(E. Log Corporate Tax Revenue) ///
	outname(figure`fignum'e)

restore

/* Figure A19 (GDP) */

*Decrease corporate rate, base cont
preserve

import delim "$dumpdir/ES_deccorprate_loggdp_nocont_thresh0.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_loggdp_basecont_thresh0.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Controls) lab2(Tax Base Controls) rawti(C. Log State GDP) ///
	outname(figure`fignum'c)

restore

*Increase corporate rate, base cont
preserve

import delim "$dumpdir/ES_inccorprate_loggdp_nocont_thresh0.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_loggdp_basecont_thresh0.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Controls) lab2(Tax Base Controls) rawti(F. Log State GDP) ///
	outname(figure`fignum'f)

restore

/* Corp tax rev share of gdp (added 4/20/17) */

*Decrease corporate rate, base cont
preserve

import delim "$dumpdir/ES_deccorprate_rgdp_nocont_thresh0.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_rgdp_basecont_thresh0.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percentage Points") ///
	lab1(No Controls) lab2(Tax Base Controls) rawti(A. Corp Tax Revenue Share of GDP) ///
	outname(figure`fignum'a)

restore

*Increase corporate rate, base cont
preserve

import delim "$dumpdir/ES_inccorprate_rgdp_nocont_thresh0.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_rgdp_basecont_thresh0.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percentage Points") ///
	lab1(No Controls) lab2(Tax Base Controls) rawti(D. Corp Tax Revenue Share of GDP) ///
	outname(figure`fignum'd)

restore

*Combines 6 figures to make an additional ES figure
*Local assignment
clear
set more off
*Draw gph data and create graph
grc1leg "$figdir/raw/figure`fignum'a.gph" ///
		"$figdir/raw/figure`fignum'b.gph" /// 
		"$figdir/raw/figure`fignum'c.gph" ///
		"$figdir/raw/figure`fignum'd.gph" ///
		"$figdir/raw/figure`fignum'e.gph" ///
		"$figdir/raw/figure`fignum'f.gph", ///
		col(3) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white) margin(vsmall)) ///
		iscale(.45)
		
graph display, ysize(4)
		
graph export "$figdir/figure`fignum'.pdf", replace

