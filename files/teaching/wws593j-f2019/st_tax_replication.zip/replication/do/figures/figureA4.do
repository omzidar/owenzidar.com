* State Share of pass-through annual payroll relative to change in corporate rate changes
* Local assignment
local fignum = "A4"
	
set more off

*--- Pass-through share of state employment, payroll and establishments ---*
use "$dtadir/state_taxes_analysis.dta", clear

keep if inlist(year, 1980, 2010)

gen corprev_share_gdp = (rev_corptax)/GDP*100

xtset fips year

g ch_corprev_share_gdp = corprev_share_gdp - corprev_share_gdp[_n-1] if fips[_n]==fips[_n-1]

keep if year==2010

rename fips_state fips

*replicate for all sample years
merge 1:1 year fips using "$dtadir/CBP_passthrough_2010.dta", nogen keep(1 3)

*make graph
binscatter ch_corprev_share_gdp s_ap_pt, $gpr xtitle("Pass-Through Share of Annual State Payroll in 2010") ///
	ytitle("Change in Corp Tax Rev Share of GDP (pp), 1980-2010") 
graph export "$figdir/figure`fignum'.pdf", replace
