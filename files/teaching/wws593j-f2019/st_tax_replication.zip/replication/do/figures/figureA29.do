*Local assignment
local fignum = "A29"

*set trace on
*set tracedepth 1
clear
set more off

/*************/
/*** Setup ***/
/*************/

*Draw Data
set more off
use "$dtadir/similar_states.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56

sort fips_state year
tsset fips_state year 

*Logs
gen log_rev_corptax = 100*ln(rev_corptax)
gen log_gdp = 100*ln(GDP)
gen log_corp = log( 1-corporate_rate/100 ) 

gen r_gdp = 100*((rev_corptax)/GDP)
bysort fips_state: egen mean_GDP = mean(GDP)


*Rate change with pre-determined threshold (.5 at the moment)
local threshold = 0.25
gen ch_corporate_rate = corporate_rate - L1.corporate_rate
replace ch_corporate_rate = 0 if abs(ch_corporate_rate) <= `threshold'
gen ch_corporate_rate_ind = (ch_corporate_rate != 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_inc = (ch_corporate_rate > 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_dec = (ch_corporate_rate < 0 & !missing(ch_corporate_rate))


*Base rules and changes therein (utilized as controls for portions of the event studies)
local baserules = " FederalIncomeas sales_wgt throwback FedIncomeTaxDed Losscarryf  FranchiseTax"
sort fips_state year
foreach rule in `baserules' {
	g abs_`rule' = abs(`rule' - L1.`rule')
	gen ch_`rule' = ( abs_`rule' != 0 &  abs_`rule'!=.)
}
drop abs*

global basecontrols = "`baserules'"



	/****************************************************************************************/
	/*** Average impact of a state corporate tax cut on different outcomes (in time = t): ***/
	/****************************************************************************************/
	capture program drop Event_outcome_simcontrol
	program define Event_outcome_simcontrol
	syntax [if] [in], yvar(varname) event(varname)  [ controls(string) outname(string) ]

	set more off
	
	preserve

	keep fips_state ch_* year

	rename fips_state Lfipssim 

	qui ds ch_*
	foreach var in `r(varlist)'{
		rename `var' `var'_sim
	}
	tempfile formerge
	save `formerge'

	restore

	preserve
	
	*Keep if specified
	if "`if'" != "" {
		keep `if'
	}
	*Setup event
	g e = year if `event' == 1
	qui sum year
	local years = `r(max)' - `r(min)' + 1
	
	*Define similar state for each particular event
	g e_simstate = Lfipssim if `event' == 1

	*Fill up:
	local i = 0
	while `i' < `years' {
		qui replace e = e[_n+1] if fips_state == fips_state[_n+1] & abs(year - e[_n+1]) < abs(year - e)
		qui replace e_simstate = e_simstate[_n+1] if fips_state == fips_state[_n+1] & e == e[_n+1]
		local ++i
	}
	*Fill down: 
	local i = 0
	while `i' < `years' {
		qui replace e = e[_n-1] if fips_state == fips_state[_n-1] & abs(year - e[_n-1]) < abs(year - e)
		qui replace e_simstate = e_simstate[_n-1] if fips_state == fips_state[_n-1] & e == e[_n-1]
		local ++i	
	}
	
	merge m:1 Lfipssim year using `formerge', nogen
	
	
	*DEFINE EVENT
	*binned
	gen Dn5=year<=e-5 
	gen Dn4=year==e-4
	gen Dn3=year==e-3
	gen Dn2=year==e-2
	gen D0=year==e
	gen D1=year==e+1
	gen D2=year==e+2
	gen D3=year==e+3
	gen D4=year==e+4
	gen D5=year==e+5
	*binned
	gen D6=year>=e+6


	*Proper GDP weight (4 years prior to event; in cases with no event, take GDP in median year as weight)
	sort fips_state year
	bysort fips_state: gen GDP_wgt = GDP[_n-4] if e == year/* If event 4 years in the future, capture gdp */
	*Conditional if year too soon (i.e. if event occurs in 1981, we don't have GDP prior to 1980, so capture 1980 GDP)
	bysort fips_state: replace GDP_wgt = GDP[1] if e == year & missing(GDP_wgt)
	*Now within that event (i.e. every year for which e == that), replace GDP_wgt as such; if no event, then take median year's GDP (assumed 1995, can generalize later)
	sort fips_state year e
	g e_id = e
	replace e_id = 0 if missing(e_id)
	egen tempgroup = group(fips_state e_id)
	levelsof tempgroup, local(groups)
	foreach group in `groups' {
		qui sum GDP_wgt if tempgroup == `group'
		if `r(N)' != 0 {
			qui replace GDP_wgt = `r(mean)' if tempgroup == `group'
		}
		else {
			qui sum GDP if tempgroup == `group' & year == 1995
			qui replace GDP_wgt = `r(mean)' if tempgroup == `group'
		}
	}


	*Base Controls (if specified) and sim state controls
	qui ds ch*sim
	local x = 1
	foreach control in  `r(varlist)'{
		local control = subinstr("`control'", "ch_", "", 1)
		
		g temp_e = year if ch_`control' != 0
		*Fill up:
		local i = 0
		while `i' < `years' {
			qui replace temp_e = temp_e[_n+1] if fips_state == fips_state[_n+1] & abs(year - temp_e[_n+1]) < abs(year - temp_e)
			local ++i
		}
		*Fill down: 
		local i = 0
		while `i' < `years' {
			qui replace temp_e = temp_e[_n-1] if fips_state == fips_state[_n-1] & abs(year - temp_e[_n-1]) < abs(year - temp_e)
			local ++i
		}
		*gen variable and increment
		g simcontrol`x' = year <= temp_e-5
		local ++x
		g simcontrol`x' = year == temp_e-4
		local ++x
		g simcontrol`x' = year == temp_e-3
		local ++x
		g simcontrol`x' = year == temp_e-2
		local ++x
		g simcontrol`x' = year == temp_e
		local ++x
		g simcontrol`x' = year == temp_e+1
		local ++x
		g simcontrol`x' = year == temp_e+2
		local ++x
		g simcontrol`x' = year == temp_e+3
		local ++x
		g simcontrol`x' = year == temp_e+4
		local ++x
		g simcontrol`x' = year == temp_e+5
		local ++x
		g simcontrol`x' = year >= temp_e+6
		local ++x
		
		drop temp_e
		}
		local --x		
		
	if "`controls'" != "" {
		local x = 1
		foreach control in `controls'{
			g temp_e = year if ch_`control' != 0
			*Fill up:
			local i = 0
			while `i' < `years' {
				qui replace temp_e = temp_e[_n+1] if fips_state == fips_state[_n+1] & abs(year - temp_e[_n+1]) < abs(year - temp_e)
				local ++i
			}
			*Fill down: 
			local i = 0
			while `i' < `years' {
				qui replace temp_e = temp_e[_n-1] if fips_state == fips_state[_n-1] & abs(year - temp_e[_n-1]) < abs(year - temp_e)
				local ++i
			}
			*gen variable and increment
			g control`x' = year <= temp_e-5
			local ++x
			g control`x' = year == temp_e-4
			local ++x
			g control`x' = year == temp_e-3
			local ++x
			g control`x' = year == temp_e-2
			local ++x
			g control`x' = year == temp_e
			local ++x
			g control`x' = year == temp_e+1
			local ++x
			g control`x' = year == temp_e+2
			local ++x
			g control`x' = year == temp_e+3
			local ++x
			g control`x' = year == temp_e+4
			local ++x
			g control`x' = year == temp_e+5
			local ++x
			g control`x' = year >= temp_e+6
			local ++x
			
			drop temp_e
		}
		local --x
	}

	*MAIN REG
	areg `yvar' Dn5-D6 i.fips_state simcontrol* , absorb(year) cluster(fips_state)
	
 
	*Alternative reg with controls if specified:
	if "`controls'" != "" {
		qui ds control*
		areg `yvar' Dn5-D6 control1-control`x' simcontrol*  i.fips_state, absorb(year) cluster(fips_state)
	}

	*Raw regression output
	regsave  
	drop if substr(var,1,1) != "D"
	drop N r2
	export delimited $dumpdir/`outname'.csv, replace

	restore

	end
	
	
/***************************************************************/
/*** Execute ES Program Above; Send to dump for temp storage ***/
/***************************************************************/

/* Event: Corporate Tax Rate Cuts */

Event_outcome_simcontrol, yvar(log_rev_corptax) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorp_logcorprev_similar) 
	

Event_outcome_simcontrol, yvar(log_gdp) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorp_loggdp_similar) 

	 
Event_outcome_simcontrol, yvar(r_gdp) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorp_rgdp_similar)
	

/* Event: Corporate Tax Rate Cuts - With base controls */

Event_outcome_simcontrol, yvar(log_rev_corptax) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols ) ///
	 outname(ES_deccorp_logcorprev_basecont_similar) 
	

Event_outcome_simcontrol, yvar(log_gdp) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols ) ///
	 outname(ES_deccorp_loggdp_basecont_similar) 

	 
Event_outcome_simcontrol, yvar(r_gdp) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols ) ///
	 outname(ES_deccorp_rgdp_basecont_similar)

	
/* Event: Corporate Tax Rate Increase */

Event_outcome_simcontrol, yvar(log_rev_corptax) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorp_logcorprev_similar) 
	

Event_outcome_simcontrol, yvar(log_gdp) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorp_loggdp_similar) 

	 
Event_outcome_simcontrol, yvar(r_gdp) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorp_rgdp_similar)
	

/* Event: Corporate Tax Rate Cuts - With base controls */

Event_outcome_simcontrol, yvar(log_rev_corptax) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols ) ///
	 outname(ES_inccorp_logcorprev_basecont_similar) 
	

Event_outcome_simcontrol, yvar(log_gdp) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols ) ///
	 outname(ES_inccorp_loggdp_basecont_similar) 

	 
Event_outcome_simcontrol, yvar(r_gdp) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols ) ///
	 outname(ES_inccorp_rgdp_basecont_similar)

	
	
*blah
	
/******************************************/
/*** Combine raw event analysis results ***/
/******************************************/

/* Figure A17 (corp rev) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorp_logcorprev_similar.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorp_logcorprev_basecont_similar.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(B. Log Corporate Tax Revenue) ///
	outname(figure`fignum'b)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorp_logcorprev_similar.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorp_logcorprev_basecont_similar.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(E. Log Corporate Tax Revenue) ///
	outname(figure`fignum'e)

restore

/* Figure A19 (GDP) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorp_loggdp_similar.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorp_loggdp_basecont_similar.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(C. Log State GDP) ///
	outname(figure`fignum'c)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorp_loggdp_similar.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorp_loggdp_basecont_similar.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(F. Log State GDP) ///
	outname(figure`fignum'f)

restore



/* Corp tax rev share of gdp (added 4/20/17) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorp_rgdp_similar.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorp_rgdp_basecont_similar.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percentage Points") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(A. Corp Tax Revenue Share of GDP) ///
	outname(figure`fignum'a)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorp_rgdp_similar.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorp_rgdp_basecont_similar.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percentage Points") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(D. Corp Tax Revenue Share of GDP) ///
	outname(figure`fignum'd)

restore

*Combines 6 figures to make an additional ES figure
*Local assignment
clear
set more off

*Draw gph data and create graph

grc1leg "$figdir/raw/figure`fignum'a.gph" ///
		"$figdir/raw/figure`fignum'b.gph" /// 
		"$figdir/raw/figure`fignum'c.gph" ///
		"$figdir/raw/figure`fignum'd.gph" ///
	    "$figdir/raw/figure`fignum'e.gph" ///
		"$figdir/raw/figure`fignum'f.gph", ///
		col(3) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(.45)
		
graph display, ysize(4)
		
graph export "$figdir/figure`fignum'.pdf", replace
