*Local assignment
local fignum = 4

*Draw data
use "$dtadir/state_taxes_analysis.dta", clear
sort fips_state year
tsset fips_state year 


*R&D credit rate
kdensity_decade, var(rec_val) xmax(0.2) xti(R&D Credit Rate) ///
	yti(Kernel Density) inc(.04) outname(figure`fignum'a)

*Loss Carryforward Rule
kdensity_decade, var(Losscarryforward) xmax(20) xti(Loss Carryforward Rule) ///
	yti(Kernel Density) inc(4) outname(figure`fignum'b)

*Investment Credit Rate
kdensity_decade, var(investment_credit) xmax(.1) xti(Investment Credit Rate) ///
	yti(Kernel Density) inc(.02) outname(figure`fignum'c)

*Loss Carryback Rule
kdensity_decade, var(Losscarryback) xmax(3) xti(Loss Carryback Rule) ///
	yti(Kernel Density) inc(1) outname(figure`fignum'd)
	
	
*Draw data
use "$dtadir/state_taxes_analysis.dta", clear
sort fips_state year
tsset fips_state year 

keep if year >= 1980 & year <= 2010
drop if fips_state == 0 | fips_state == 11 /* US and DC */

*Re-scale apportionment weights
gen corporate_rate_scaled = corporate_rate/100
replace sales_wgt = sales_wgt/100
replace payroll_wgt = payroll_wgt/100
replace prop_wgt = prop_wgt/100

*Number of states in different apportionment categories
global varlist "sales_wgt payroll_wgt prop_wgt"
foreach var in $varlist {
	gen `var'_low = (`var' < .33 & !missing(`var'))
	gen `var'_high = (`var' >= .33 & !missing(`var'))
	gen `var'_low_alt = (`var' < .50 & !missing(`var'))
	gen `var'_high_alt = (`var' >= .50 & !missing(`var'))
}


*Panel B
gen sales_corporate_rate = sales_wgt*corporate_rate
kdensity_decade, var(sales_corporate_rate) xmax(12) xti(Sales Apportioned Corporate Tax Rate) yti(Kernel Density) ///
	increment(3) outname(figure`fignum'e)
	
*Panel D
gen payroll_corporate_rate = payroll_wgt*corporate_rate
kdensity_decade, var(payroll_corporate_rate) xmax(5) xti(Payroll Apportioned Corporate Tax Rate) yti(Kernel Density) ///
	increment(1) outname(figure`fignum'f)	
