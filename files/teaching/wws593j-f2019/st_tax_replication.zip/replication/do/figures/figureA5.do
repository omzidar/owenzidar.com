*Local assignment
local fignum = "A5"

*Draw data
use "$dtadir/state_taxes_analysis.dta", clear
drop if fips_state == 11 | fips_state == 0 /* DC & US */
sort fips_state year
tsset fips_state year 


*Maps (panels)
keep if year == 2010
rename fips_state statefips


*Corp rate
replace corporate_rate = . if corporate_rate == 0
maptile corporate_rate, geo(state) geoid(statefips) ///
	spopt(legend(label(1 "No Corporate Tax") size(3.3))) ///
	ndf(yellow*.1) rangec(yellow*.4 red*1.65)
graph export "$figdir/figure`fignum'a.pdf", replace


*Corp rev taxshare
replace taxshare_rev_corptax = . if corporate_rate == .
replace taxshare_rev_corptax = taxshare_rev_corptax*100
maptile taxshare_rev_corptax, geo(state) geoid(statefips) legf(%9.3f) ///
	spopt(legend(label(1 "No Corporate Tax") ///
	size(3.3))) rangec(yellow*.4 red*1.65) ///
	ndf(yellow*.1) 
graph export "$figdir/figure`fignum'b.pdf", replace


*Sales Apportionment
tab sales_wgt
maptile sales_wgt, geo(state) geoid(statefips) ///
	cutv(35 55 65 85 88 95) ///
	spopt(legend(label(2 "33%") label(3 "50%") label(4 "60%") ///
	label(5 "80%") label(6 "87%") label(7 "90%") label(8 "100%")))
graph export "$figdir/figure`fignum'c.pdf", replace


