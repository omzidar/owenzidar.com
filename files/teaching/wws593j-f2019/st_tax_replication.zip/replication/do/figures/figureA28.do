*Local assignment
local fignum = "A28"


clear
set more off

/*************/
/*** Setup ***/
/*************/

*Draw Data
use "$dtadir/adjacent_states.dta", clear 
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56

sort fips_state year
tsset fips_state year 

*Logs
gen log_rev_corptax = 100*ln(rev_corptax)
gen log_gdp = 100*ln(GDP)
gen log_corp = log( 1-corporate_rate/100 ) 

gen log_r_gdp = ln((rev_corptax)/GDP)
gen r_gdp = 100*((rev_corptax)/GDP)
bysort fips_state: egen mean_GDP = mean(GDP)


*Rate change with pre-determined threshold (.5 at the moment)
local threshold = 0.25
gen ch_corporate_rate = corporate_rate - L1.corporate_rate
replace ch_corporate_rate = 0 if abs(ch_corporate_rate) <= `threshold'
gen ch_corporate_rate_ind = (ch_corporate_rate != 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_inc = (ch_corporate_rate > 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_dec = (ch_corporate_rate < 0 & !missing(ch_corporate_rate))

qui ds *_adj
global neighborcontrols = "`r(varlist)'"

*Base rules and changes therein (utilized as controls for portions of the event studies)
local baserules = " FederalIncomeasStateTaxBase sales_wgt throwback FedIncomeTaxDeductible Losscarryforward FranchiseTax"
sort fips_state year
foreach rule in `baserules' $neighborcontrols{
	g abs_`rule' = abs(`rule' - L1.`rule')
	gen ch_`rule' = ( abs_`rule' != 0 &  abs_`rule'!=.)
}
drop abs*

global basecontrols = "`baserules'"



/***************************************************************/
/*** Execute ES Program Above; Send to dump for temp storage ***/
/***************************************************************/

/* Event: Corporate Tax Rate Cuts */

Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_dec)  ///
	 controls($neighborcontrols) ///
	 outname(ES_deccorp_logcorprev_neighbor) 
	

Event_outcome, yvar(log_gdp) event(ch_corporate_rate_dec)  ///
	 controls($neighborcontrols) ///
	 outname(ES_deccorp_loggdp_neighbor) 

	 
Event_outcome, yvar(r_gdp) event(ch_corporate_rate_dec)  ///
	 controls($neighborcontrols) ///
	 outname(ES_deccorp_rgdp_neighbor)
	

/* Event: Corporate Tax Rate Cuts - With base controls */

Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols $neighborcontrols) ///
	 outname(ES_deccorp_logcorprev_basecont_neighbor) 
	

Event_outcome, yvar(log_gdp) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols $neighborcontrols) ///
	 outname(ES_deccorp_loggdp_basecont_neighbor) 

	 
Event_outcome, yvar(r_gdp) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols $neighborcontrols) ///
	 outname(ES_deccorp_rgdp_basecont_neighbor)

	
/* Event: Corporate Tax Rate Increase */

Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_inc)  ///
	 controls($neighborcontrols) ///
	 outname(ES_inccorp_logcorprev_neighbor) 
	

Event_outcome, yvar(log_gdp) event(ch_corporate_rate_inc)  ///
	 controls($neighborcontrols) ///
	 outname(ES_inccorp_loggdp_neighbor) 

	 
Event_outcome, yvar(r_gdp) event(ch_corporate_rate_inc)  ///
	 controls($neighborcontrols) ///
	 outname(ES_inccorp_rgdp_neighbor)
	

/* Event: Corporate Tax Rate Cuts - With base controls */

Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols $neighborcontrols) ///
	 outname(ES_inccorp_logcorprev_basecont_neighbor) 
	

Event_outcome, yvar(log_gdp) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols $neighborcontrols) ///
	 outname(ES_inccorp_loggdp_basecont_neighbor) 

	 
Event_outcome, yvar(r_gdp) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols $neighborcontrols) ///
	 outname(ES_inccorp_rgdp_basecont_neighbor)

	
/******************************************/
/*** Combine raw event analysis results ***/
/******************************************/

/* Figure A17 (corp rev) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorp_logcorprev_neighbor.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorp_logcorprev_basecont_neighbor.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(B. Log Corporate Tax Revenue) ///
	outname(figure`fignum'b)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorp_logcorprev_neighbor.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorp_logcorprev_basecont_neighbor.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(E. Log Corporate Tax Revenue) ///
	outname(figure`fignum'e)

restore

/* Figure A19 (GDP) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorp_loggdp_neighbor.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorp_loggdp_basecont_neighbor.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(C. Log State GDP) ///
	outname(figure`fignum'c)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorp_loggdp_neighbor.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorp_loggdp_basecont_neighbor.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(F. Log State GDP) ///
	outname(figure`fignum'f)

restore



/* Corp tax rev share of gdp (added 4/20/17) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorp_rgdp_neighbor.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorp_rgdp_basecont_neighbor.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percentage Points") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(A. Corp Tax Revenue Share of GDP) ///
	outname(figure`fignum'a)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorp_rgdp_neighbor.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorp_rgdp_basecont_neighbor.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percentage Points") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(D. Corp Tax Revenue Share of GDP) ///
	outname(figure`fignum'd)

restore

*Combines 6 figures to make an additional ES figure
*Local assignment
clear
set more off

*Draw gph data and create graph

grc1leg "$figdir/raw/figure`fignum'a.gph" ///
		"$figdir/raw/figure`fignum'b.gph" /// 
		"$figdir/raw/figure`fignum'c.gph" ///
		"$figdir/raw/figure`fignum'd.gph" ///
	    "$figdir/raw/figure`fignum'e.gph" ///
		"$figdir/raw/figure`fignum'f.gph", ///
		col(3) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(.45)
		
graph display, ysize(4)
		
graph export "$figdir/figure`fignum'.pdf", replace
