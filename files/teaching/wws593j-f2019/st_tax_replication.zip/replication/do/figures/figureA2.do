*Local assignment
local fignum = "A2"

set more off
use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 0 | fips_state == 11 | fips_state > 56

bysort fips_state: egen mean_GDP = mean(GDP)

g period=0
replace period = 1 if year >= 1980 & year <= 1985
replace period = 2 if year >= 1986 & year <= 1990
replace period = 3 if year >= 1991 & year <= 1995
replace period = 4 if year >= 1996 & year <= 2000
replace period = 5 if year >= 2001 & year <= 2005
replace period = 6 if year >= 2006 & year <= 2010

gen corprev_share_gdp = (rev_corptax)/GDP

local base  "rec_val payroll_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit"

rename corprev_share_gdp r_g
g l_r_g=log(r_g)
g l_r  =log(rev_corptax)
g r    =rev_corptax
	
label var rec_val "R\&D Tax Credit"
label var corporate_rate "$\tau$"		
/*			
** Keep final regression sample first 
reg r_g corporate_rate  ///
	`base'  i.fips i.year [aw=mean_GDP]
*keep if e(sample) 	
*/

*Assign variables
g x0= corporate_rate
g x1= FederalIncomeasStateTaxBase
g x2= FedIncomeTaxDeductible 
g x3= throwback 
g x4= payroll_wgt 
g x5= Losscarryforward 
g x6= Losscarryback 
g x7= combined 
g x8= investment_credit 
g x9= rec_val
g x10= ACRSDepreciation 
g x11= AllowFedAccDep 
g x12= FederalBonusDepreciation 
g x13= FranchiseTax
g x14= incr_ma //includes rec val as moving avg
g x15= incr_fixed //includes rec val fixed

*REGRESSION
reg l_r_g x0-x15 i.period [aw=mean_GDP]

g explained = e(r2)
g unexplained = 1 - e(r2)

* corp_sh_gdp = b0 + x1b1 + ...  x13b13 + e
* --> var(corp_sh_gdp). = var(x1)b1^2 + ... + var(x13)b14 + var(e), assuming covs = 0
	forv i =0/15{
	local beta=_b[x`i']
	summ x`i'
	local var=(r(sd))^2

	g bsqXx`i' = (`beta')^2 *`var'
	}
	list bsqXx1 in 1

egen sum_ss   = rowtotal(bsqXx*)
egen sum_base = rowtotal(bsqXx1-bsqXx15)
gen base=	sum_base/(sum_ss)
gen corp=	bsqXx0/(sum_ss)

ds bsqXx1-bsqXx15
foreach var in `r(varlist)' { /* Ratio of explanation by base rules */
	qui replace `var' = `var'/sum_base
}


*Panel A
preserve
keep if _n == 1

set obs 2

g corprate_exp = corp[1] in 2
g other = base[1] in 2
keep explained unexplained other corprate_exp

g id = ""
replace id = " Log (R{sub:s}{sup:corp}/GDP{sub:s})" in 1 /* Space necessary to ensure this appears first.. */
replace id = "Base vs Rate" in 2

g rev = -_n
sort rev


graph bar explained unexplained corprate_exp other, stack over(id) ///
	ytitle("% of Explained Variation") ///
	graphregion(fcolor(white)) graphregion(color(white)) ///
	bar(1, color(dknavy)) bar(2, color(maroon)) bar(3, color(dknavy*.7)) bar(4, color(dknavy*.4)) ///
	legend(order(2 4 1 3) cols(2) label(1 "Explained") label(2 "Unexplained") label(3 "Corporate Rate") label(4 "Base Rules"))

restore

*Output (and opportunity to edit manually)
graph display, ysize(5)
graph export "$figdir/figure`fignum'a.pdf", replace /* Won't overwrite if we just run the file */

*Panel B

preserve
keep bsqXx1-bsqXx15

*replace bsqXx9 = bsqXx9+ bsqXx14 +bsqXx15

graph hbar bsqXx1-bsqXx15, ///
	bargap(20) graphregion(fcolor(white)) graphregion(color(white)) ///
	nolabel ytitle("% Explained Among Base Rules") showyvars legend(off) ///
	yvaroptions(relabel(1 "Federal Inc as State Base" 2 "Federal Inc Tax Deductible" 3 "Throwback Rules" ///
						4 "Payroll Apportionment Weight" 5 "Loss Carryforward" 6 "Loss Carryback" ///
						7 "Combined Reporting" 8 "Investment Tax Credit" 9 "R&D Tax Credit" ///
						10 "ACRS Depreciation" 11 "Federal Accelerated Depreciation" 12 "Federal Bonus Depreciation" 13 "Franchise Tax" ///
						14 "Incr R&D, Moving Avg Base" 15 "Incr R&D, Fixed Base")) ///
	bar(1, color(dknavy*.4)) bar(2, color(dknavy*.4)) bar(3, color(dknavy*.4)) bar(4, color(dknavy*.4)) bar(5, color(dknavy*.4)) bar(6, color(dknavy*.4)) ///
	bar(7, color(dknavy*.4)) bar(8, color(dknavy*.4)) bar(9, color(dknavy*.4)) bar(10, color(dknavy*.4)) bar(11, color(dknavy*.4)) bar(12, color(dknavy*.4)) ///
	bar(13, color(dknavy*.4)) bar(14, color(dknavy*.4)) bar(15, color(dknavy*.4))
	
graph display, ysize(3)
graph export "$figdir/figure`fignum'b.pdf", replace
restore

preserve
*bys fips: egen mean_GDP = mean(GDP)

g ln_keeprate = ln(1-(corporate_rate)/100)
replace payroll_wgt = payroll_wgt/100


**** for TS graph 
areg l_r_g FederalIncomeasStateTaxBase FedIncomeTaxDeductible ///
	throwback combined c.payroll_wgt  c.Losscarryforward c.Losscarryback  ///
	c.investment_credit c.rec_val ACRSDepreciation ///
	AllowFedAccDep FederalBonusDepreciation FranchiseTax incr_ma incr_fixed ///
	[aw = mean_GDP], a(year)

predict r_hat, xb

*binscatter r_gdp_hat year , line(connect)

**** Normalized for graph 

foreach xvar of varlist l_r_g FederalIncomeasStateTaxBase FedIncomeTaxDeductible ///
	throwback payroll_wgt  Losscarryforward Losscarryback combined ///
	investment_credit rec_val ACRSDepreciation ///
	AllowFedAccDep FederalBonusDepreciation FranchiseTax incr_ma incr_fixed{
	 sum `xvar'  [aw=mean_GDP], d
	 replace `xvar'=(`xvar'-r(mean))/r(sd)

}

*replace r_gdp = r_gdp*100 

*Generate Base Index

label var rec_val "R&D Tax Credit"
label var throwback "Throwback Rules"
label var combined "Combined Reporting Rules"
label var investment_credit "Investment Tax Credit"
label var AllowFedAccDep "Allows Federal Accelerated Depreciation"
label var Losscarryforward "Loss Carryforward"
label var Losscarryback "Loss Carryback"
label var FranchiseTax "Franchise Tax"
label var incr_ma "Incremental R&D, Moving Avg Base"
label var incr_fixed "Incremental R&D, Fixed Base"

reg l_r_g FederalIncomeasStateTaxBase FedIncomeTaxDeductible ///
	throwback combined c.payroll_wgt  c.Losscarryforward c.Losscarryback  ///
	c.investment_credit c.rec_val ACRSDepreciation ///
	AllowFedAccDep FederalBonusDepreciation FranchiseTax incr_ma incr_fixed ///
	[aw = mean_GDP], a(year)
	
coefplot	, drop(_cons) xline(0) level(95) xtitle("Standardized Effect") graphregion(color(white)) 

graph export "$figdir/figure`fignum'c.pdf", replace 
restore
