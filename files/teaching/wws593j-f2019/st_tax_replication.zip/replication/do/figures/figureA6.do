*Local assignment
local fignum = "A6"


*Draw data
use "$dtadir/state_taxes_analysis.dta", clear
drop if fips_state == 11 | fips_state == 0 /* DC & US */
sort fips_state year
tsset fips_state year 

rename fips_state statefips

*Maps (2010 panels; i.e. no 2012 available)
preserve

keep if year == 2010

*R&D Credit 
maptile rec_val, geo(state) geoid(statefips) legf(%9.2f) ///
	spopt(legend(label(2 "No Credit")))
graph export "$figdir/figure`fignum'a.pdf", replace

*Throwback
maptile throwback, geo(state) geoid(statefips) ///
	fcolor(yellow*.1 red*1.65) ///
	spopt(legend(label(2 "No Throwback Rule") label(3 "Throwback Rule")))
graph export "$figdir/figure`fignum'c.pdf", replace

*Combined
maptile combined, geo(state) geoid(statefips) ///
	fcolor(yellow*.1 red*1.65) ///
	spopt(legend(label(2 "No Combined Rule") label(3 "Combined Rule")))
graph export "$figdir/figure`fignum'f.pdf", replace

*Incremental R&D Credit, Moving Average
maptile incr_ma, geo(state) geoid(statefips) legf(%9.2f) ///
	spopt(legend(order(3) label(3 "Moving Average"))) ///
	fcolor(yellow*.1 red*1.65)
graph export "$figdir/figure`fignum'g.pdf", replace

*Incremental R&D Credit, Fixed
maptile incr_fixed, geo(state) geoid(statefips) legf(%9.2f) ///
	spopt(legend(order(3) label(3 "Fixed"))) ///
	fcolor(yellow*.1 red*1.65) 
graph export "$figdir/figure`fignum'h.pdf", replace

restore


*Maps (2012 panels)
keep if year == 2012

*Investment credit
replace investment_credit = . if investment_credit == 0
maptile investment_credit, geo(state) geoid(statefips) legf(%9.2f) ///
	spopt(legend(label(1 "No Credit"))) ndf(yellow*.1) n(4) ///
	rangec(sandb*.7 red*1.65)
graph export "$figdir/figure`fignum'd.pdf", replace

*Loss carryforward
maptile Losscarryforward, geo(state) geoid(statefips) legf(%9.0f) ///
	cutv(5 10 15)
graph export "$figdir/figure`fignum'b.pdf", replace

*Loss carryback
replace Losscarryback = . if Losscarryback == 0
maptile Losscarryback, geo(state) geoid(statefips) legf(%9.0f) ///
	cutv(2) ndf(yellow*.1) rangec(sandb red*1.65) ///
	spopt(legend(label(1 "0") label(2 "2") label(3 "3")))
graph export "$figdir/figure`fignum'e.pdf", replace


*Incremental R&D Credit, Fixed
maptile FranchiseTax, geo(state) geoid(statefips) legf(%9.2f) ///
	spopt(legend(label(2 "No Franchise Tax") label(3 "Franchise Tax"))) ///
	fcolor(yellow*.1 red*1.65) 
graph export "$figdir/figure`fignum'i.pdf", replace
