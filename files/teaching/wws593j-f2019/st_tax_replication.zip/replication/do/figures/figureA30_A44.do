
set more off

*Draw analysis dataset
use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56
bys fips: egen mean_GDP = mean(GDP)

gen log_rev_corptax = 100*ln(rev_corptax)
gen log_gdp = 100*ln(GDP)

gen log_r_gdp = ln((rev_corptax)/GDP)
gen r_gdp = 100*rev_corptax/GDP


/*************************/
/*** Define base changes */
/*************************/

xtset fips_state year
//Create base broadening or narrowing indicator
sort fips_state year
local baserules = "FedIncomeTaxDed ACRSDep AllowFedAc FederalBonusDep"
foreach rule in `baserules' {
	gen b_it_`rule' = (-(`rule' - L1.`rule'))
}

local baserules = "FranchiseTax incr_ma incr_fixed combined throwback FederalIncomeas"
foreach rule in `baserules' {
	gen b_it_`rule' = (`rule' - L1.`rule')
}

local baserules = "investment_cred Losscarryf Losscarryb rec_val sales_wgt"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(-(`rule' - L1.`rule'))
}

local baserules = "payroll_wgt"
foreach rule in `baserules' {
	gen b_it_`rule' = sign(`rule' - L1.`rule')
}

#delimit ;
local allrules = "FedIncomeTaxDed FranchiseTax investment_cred Losscarryf 
		Losscarryb AllowFedAc ACRSDep FederalBonusDep rec_val sales_wgt 
		FederalIncomeas combined throwback incr_ma incr_fixed";
#delimit cr

foreach rule in `allrules'{
	g broaden_`rule' = (b_it_`rule' == 1 & !missing(b_it_`rule'))
	g narrow_`rule' = (b_it_`rule' ==-1 & !missing(b_it_`rule'))
	
	tab broaden_`rule'
	
	tab narrow_`rule'
}


/***************************************************************/
/*** Execute ES Program Above; Send to dump for temp storage ***/
/***************************************************************/
foreach rule in `allrules'{
	foreach ch in broaden narrow{

	Event_outcome, yvar(log_rev_corptax) event(`ch'_`rule')  ///
	outname(ES_`ch'_`rule'_logcorprev) 
		
	Event_outcome, yvar(log_gdp) event(`ch'_`rule')  ///
		outname(ES_`ch'_`rule'_loggdp) 
		
	Event_outcome, yvar(r_gdp) event(`ch'_`rule')  ///
		outname(ES_`ch'_`rule'_rgdp)
	}
}

set more off

#delimit ;
local allrules = "FedIncomeTaxDed FranchiseTax investment_cred Losscarryf 
		Losscarryb AllowFedAc ACRSDep FederalBonusDep rec_val sales_wgt 
		FederalIncomeas combined throwback incr_ma incr_fixed";
#delimit cr

/******************************************/
/*** Combine raw event analysis results ***/
/******************************************/
foreach rule in `allrules' {
		if "`rule'" == "rec_val"{
			local lab = "R&D Credit"
			local fignum = "A38"
		}
		else if "`rule'" == "throwback"{
			local lab = "Throwback Rule"
			local fignum = "A42"
		}
		else if "`rule'" == "combined"{
			local lab = "Combined Reporting"
			local fignum = "A41"
		}
		else if "`rule'" == "investment_cred"{
			local lab = "Investment Tax Credit"
			local fignum = "A34"
		}
		else if "`rule'" == "FederalBonusDep"{
			local lab = "Fed Bonus Dep"
			local fignum = "A32"
		}
		else if "`rule'" == "ACRSDep"{
			local lab = "ACRS Depreciation"
			local fignum = "A31"
		}
		else if "`rule'" == "AllowFedAc"{
			local lab = "Fed Acc Depr"
			local fignum = "A30"
		}
		else if "`rule'" == "Losscarryf"{
			local lab = "Loss Carryfwd"
			local fignum = "A36"
		}
		else if "`rule'" == "Losscarryb"{
			local lab = "Loss Carryback"
			local fignum = "A37"
		}
		else if "`rule'" == "FedIncomeTaxDed"{
			local lab = "Fed Inc Tax Ded"
			local fignum = "A33"
		}
		else if "`rule'" == "FederalIncomeas"{
			local lab = "Fed Inc Tax Base"
			local fignum = "A40"
		}
		else if "`rule'" == "payroll_wgt"{
			local lab = "Payroll App Wgt"
		}
		else if "`rule'" == "sales_wgt"{
			local lab = "Sales App Wgt"
			local fignum = "A39"
		}
		else if "`rule'" == "FranchiseTax"{
			local lab = "Franchise Tax"
			local fignum = "A35"
		}
		else if "`rule'" == "incr_ma"{
			local lab = "Incr R&D Base is Moving Avg"
			local fignum = "A43"
		}
		else if "`rule'" == "incr_fixed"{
			local lab = "Incr R&D Base is Fixed"
			local fignum = "A44"
		}
		
		
	local i=1

foreach ch in broaden narrow{
	local letter_title1 = "A."
	local letter1 = "a"
	local letter_title2 = "B."
	local letter2 = "b"
	local letter_title3 = "C."
	local letter3 = "c"
	local letter_title4 = "D."
	local letter4 = "d"
	local letter_title5 = "E."
	local letter5 = "e"
	local letter_title6 = "F."
	local letter6 = "f"
	

	if "`ch'"== "broaden"{
		local labch = "Broadening of"
		local letter = "a"
	}
	else if "`ch'"== "narrow"{
		local labch = "Narrowing of"
		local letter = "b"
	}

	preserve

	import delim "$dumpdir/ES_`ch'_`rule'_rgdp.csv", clear
	rename (coef stderr) (b1 se1)
	gen t = 95 + _n
	replace t=t+1 if t>=100
	set obs 12
	replace t=100 in 12
	replace b1=0 in 12
	replace se1=0 in 12
	sort t

	ES_graph, ci(1.96) xti(Years Since `labch' `lab') yti("Percentage Points") ///
		rawti(`letter_title`i'' Corp Tax Revenue Share of GDP) ///
		lab1(Impact) outname(figure`fignum'`letter`i'')
	restore
	local ++i

	
	preserve

	import delim "$dumpdir/ES_`ch'_`rule'_logcorprev.csv", clear
	rename (coef stderr) (b1 se1)
	gen t = 95 + _n
	replace t=t+1 if t>=100
	set obs 12
	replace t=100 in 12
	replace b1=0 in 12
	replace se1=0 in 12
	sort t

	ES_graph, ci(1.96) xti(Years Since `labch' `lab') yti("Percent") ///
		rawti(`letter_title`i'' Log Corporate Tax Revenue) ///
		lab1(Impact) outname(figure`fignum'`letter`i'')

	restore
	
	local ++i
	
	preserve

	import delim "$dumpdir/ES_`ch'_`rule'_loggdp.csv", clear
	rename (coef stderr) (b1 se1)
	gen t = 95 + _n
	replace t=t+1 if t>=100
	set obs 12
	replace t=100 in 12
	replace b1=0 in 12
	replace se1=0 in 12
	sort t

	ES_graph, ci(1.96) xti(Years Since `labch' `lab') yti("Percent") ///
		rawti(`letter_title`i'' Log State GDP) ///
		lab1(Impact) outname(figure`fignum'`letter`i'')

	restore
	local ++i
	
}

	clear
	set more off

	*Draw gph data and create graph

	grc1leg "$figdir/raw/figure`fignum'a.gph" ///
			"$figdir/raw/figure`fignum'b.gph" /// 
			"$figdir/raw/figure`fignum'c.gph" ///
			"$figdir/raw/figure`fignum'd.gph" ///
			"$figdir/raw/figure`fignum'e.gph" ///
			"$figdir/raw/figure`fignum'f.gph", ///
			col(3) ///
			plotregion(fcolor(white) lcolor(white)) ///
			graphregion(fcolor(white) lcolor(white) margin(vsmall)) ///
			iscale(.45)
	graph display, ysize(4)
			
	graph export "$figdir/figure`fignum'.pdf", replace

}


foreach rule in FederalIncomeas {
	local fignum = "A40"
	clear
	set more off

	*Draw gph data and create graph

	grc1leg "$figdir/raw/figure`fignum'a.gph" ///
			"$figdir/raw/figure`fignum'b.gph" /// 
			"$figdir/raw/figure`fignum'c.gph" ///
			, ///
			col(3) ///
			plotregion(fcolor(white) lcolor(white)) ///
			graphregion(fcolor(white) lcolor(white) margin(vsmall)) ///
			iscale(.9)
	graph display, ysize(2)
			
	graph export "$figdir/figure`fignum'.pdf", replace
	
}
