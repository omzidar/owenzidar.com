* Figures of Heterogeneous Elasticities
* Local assignment
local fignum = 10

clear
set more off

/*****************/
/*** Draw Data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear
drop if State == ""
set more off 


bys fips: egen mean_GDP = mean(GDP)

foreach xvar of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
	 sum `xvar'  [aw=mean_GDP], d
	 replace `xvar'=(`xvar'-r(mean))/r(sd)

}

local i = 1 
foreach var of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
	gen s`i' = `var'
	local i = `i'+1 
}

gen r_g = rev_corptax/GDP*10^4

** Gen main varaibles 
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corpo/100 ) 
gen log_rev_gdp = log(rev_corp/GDP)
gen r_gos = rev_corptax/GOS_s
gen log_rev_gos = log(rev_corp/GOS_s)
gen log_gos = log(GOS_s)
gen log_gdp = log(GDP)
gen gos = GOS_s/100000


replace log_corp = corporate_rate

reg r_g log_corp i.year i.fips c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15 ///	
	c.log_corp#(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15)[aw=mean_GDP]	
	gen temp_prog = _b[log_corp]+_b[c.log_corp#c.s1]*s1 ///
				 +_b[c.log_corp#c.s2]*s2+_b[c.log_corp#c.s3]*s3 ///   
				 +_b[c.log_corp#c.s4]*s4+_b[c.log_corp#c.s5]*s5 ///
				 +_b[c.log_corp#c.s6]*s6+_b[c.log_corp#c.s7]*s7 ///
				 +_b[c.log_corp#c.s8]*s8+_b[c.log_corp#c.s9]*s9 ///
				 +_b[c.log_corp#c.s10]*s10+_b[c.log_corp#c.s11]*s11+_b[c.log_corp#c.s12]*s12+_b[c.log_corp#c.s13]*s13 ///
				 +_b[c.log_corp#c.s14]*s14+_b[c.log_corp#c.s15]*s15 if e(sample) 
				 
line temp_prog year if inlist(fips,10,26,42,44) & temp_prog!=. & inrange(year,1980,2010), yline(0) by(State, graphregion(fcolor(white) color(white)) note("")) ///
	yti("Effect of {&tau} on Revenue to GDP Ratio") color(navy) xlab(,labsize(small))
graph export "$figdir/figure`fignum'.pdf", replace
