*Local assignment
local fignum = "A46"

*Draw Data
use "$dtadir/state_taxes_analysis.dta", clear
keep if year >= 1980 & year <= 2010
drop if fips_state == 0 | fips_state == 11 /* U.S., DC */

sort fips_state year
tsset fips_state year 

*Region Categories:
gen region_broad = 1 if region == 1 | region == 2 /* Northeast */
replace region_broad = 2 if region == 3 | region == 4 /* Midwest */
replace region_broad = 3 if region == 5 | region == 6 | region == 7 /* South */
replace region_broad = 4 if region == 8 | region == 9 /* West */
label var region_broad "1 = NE, 2 = MW, 3 = South, 4 = West"

*Execute kernel desnity (region) program
kdensity_region, var(taxshare_rev_indinctax) xmax(0.8) xti(Share of Total Rev as Individual Income Tax Rev - 1980-2010) ///
	yti(Kernel Density) outname(figure`fignum')
