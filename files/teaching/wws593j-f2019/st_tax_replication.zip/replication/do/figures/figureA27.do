* Local assignment
local fignum = "A27"

clear
set more off

/*************/
/*** Setup ***/
/*************/

*Draw Data
use "$dtadir/state_taxes_analysis.dta", clear 
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56

sort fips_state year
tsset fips_state year 

*Logs
gen log_rev_totaltaxes = 100*ln(rev_totaltaxes)
gen log_beaemp = 100*ln(BEAemp)
gen log_beawage = 100*ln(avg_wages)
gen log_est = 100*ln(est)
gen log_gos = 100*ln(GOS_s)


*Rate change with pre-determined threshold (.5 at the moment)
local threshold = 0.50
gen ch_corporate_rate = corporate_rate - L1.corporate_rate
replace ch_corporate_rate = 0 if abs(ch_corporate_rate) <= `threshold'
gen ch_corporate_rate_ind = (ch_corporate_rate != 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_inc = (ch_corporate_rate > 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_dec = (ch_corporate_rate < 0 & !missing(ch_corporate_rate))

*Base rules and changes therein (utilized as controls for portions of the event studies)
local baserules = "FederalIncomeasStateTaxBase payroll_wgt throwback FedIncomeTaxDeductible Losscarryforward FranchiseTax"
sort fips_state year
foreach rule in `baserules' {
	g abs_`rule' = abs(`rule' - L1.`rule')
	gen ch_`rule' = ( abs_`rule' != 0 &  abs_`rule'!=.)
}
drop abs*
global basecontrols = "`baserules'"

/***************************************************************/
/*** Execute ES Program Above; Send to dump for temp storage ***/
/***************************************************************/

/* Event: Corporate Tax Rate Cuts */
	
Event_outcome, yvar(log_rev_totaltaxes) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorprate_logtotrev) 

Event_outcome, yvar(log_beaemp) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorprate_logbeaemp) 
	
Event_outcome, yvar(log_beawage) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorprate_logbeawage)
	
Event_outcome, yvar(log_est) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorprate_logest) 

Event_outcome, yvar(log_gos) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorprate_loggos)
	

/* Event: Corporate Tax Rate Cuts - With base controls */

Event_outcome, yvar(log_rev_totaltaxes) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols) ///
	outname(ES_deccorprate_logtotrev_basecont) 
	
Event_outcome, yvar(log_beaemp) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols) ///
	outname(ES_deccorprate_logbeaemp_basecont)  
	
Event_outcome, yvar(log_beawage) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols) ///
	outname(ES_deccorprate_logbeawage_basecont)
	
Event_outcome, yvar(log_est) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols) ///
	outname(ES_deccorprate_logest_basecont) 
	
Event_outcome, yvar(log_gos) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols) ///
	outname(ES_deccorprate_loggos_basecont)

	
/* Event: Corporate Tax Rate Increases */
	
Event_outcome, yvar(log_rev_totaltaxes) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorprate_logtotrev) 
	
Event_outcome, yvar(log_beaemp) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorprate_logbeaemp) 
	
Event_outcome, yvar(log_beawage) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorprate_logbeawage) 
	
Event_outcome, yvar(log_est) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorprate_logest) 
	
Event_outcome, yvar(log_gos) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorprate_loggos)


/* Event: Corporate Tax Rate Increases - With base controls */

Event_outcome, yvar(log_rev_totaltaxes) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols) ///
	outname(ES_inccorprate_logtotrev_basecont) 

Event_outcome, yvar(log_beaemp) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols) ///
	outname(ES_inccorprate_logbeaemp_basecont) 
	
Event_outcome, yvar(log_beawage) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols) ///
	outname(ES_inccorprate_logbeawage_basecont) 
	
Event_outcome, yvar(log_est) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols) ///
	outname(ES_inccorprate_logest_basecont) 
	
Event_outcome, yvar(log_gos) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols) ///
	outname(ES_inccorprate_loggos_basecont) 
	
/******************************************/
/*** Combine raw event analysis results ***/
/******************************************/

/* Figure A20 (Est) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorprate_logest.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_logest_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(B. Log Establishments) ///
	outname(figure`fignum'b)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorprate_logest.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_logest_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(F. Log Establishments) ///
	outname(figure`fignum'f)

restore


/* Figure A21 (Emp) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorprate_logbeaemp.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_logbeaemp_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(C. Log Employment) ///
	outname(figure`fignum'c)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorprate_logbeaemp.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_logbeaemp_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(G. Log Employment) ///
	outname(figure`fignum'g)

restore


/* Figure A22 (Wage) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorprate_logbeawage.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_logbeawage_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(A. Log Wages) ///
	outname(figure`fignum'a)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorprate_logbeawage.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_logbeawage_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(E. Log Wages) ///
	outname(figure`fignum'e)

restore



/* Figure A23 (GOS) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorprate_loggos.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_loggos_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(D. Log GOS) ///
	outname(figure`fignum'd)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorprate_loggos.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_loggos_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(H. Log GOS) ///
	outname(figure`fignum'h)

restore
	

*Combines 6 figures to make an additional ES figure (similar to A17, except combines wage, est, and emp)
*Local assignment
clear
set more off

*Draw gph data and create graph

grc1leg "$figdir/raw/figure`fignum'a.gph" ///
	    "$figdir/raw/figure`fignum'b.gph" ///
		"$figdir/raw/figure`fignum'c.gph" ///
		"$figdir/raw/figure`fignum'd.gph" ///
	    "$figdir/raw/figure`fignum'e.gph" ///
	    "$figdir/raw/figure`fignum'f.gph" ///
		"$figdir/raw/figure`fignum'g.gph" ///
		"$figdir/raw/figure`fignum'h.gph", ///
		col(4) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(.53)
		
graph display, ysize(3.3)
		
graph export "$figdir/figure`fignum'.pdf", replace
