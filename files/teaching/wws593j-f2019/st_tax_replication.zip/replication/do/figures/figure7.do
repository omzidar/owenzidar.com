*This file creates a series of event studies whereby the event is an increase or decrease in the state corporate tax rate; currently assigned Appendix Figures 17-23

clear
set more off

/*************/
/*** Setup ***/
/*************/

*Draw Data
use "$dtadir/state_taxes_analysis.dta", clear 
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56

sort fips_state year
tsset fips_state year 

*Logs
gen log_rev_corptax = 100*ln(rev_corptax)
gen log_gdp = 100*ln(GDP)
g r_g = 100*rev_corptax/GDP


*Rate change with pre-determined threshold (.5 at the moment)
local threshold = 0.50
gen ch_corporate_rate = corporate_rate - L1.corporate_rate
replace ch_corporate_rate = 0 if abs(ch_corporate_rate) <= `threshold'
gen ch_corporate_rate_ind = (ch_corporate_rate != 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_inc = (ch_corporate_rate > 0 & !missing(ch_corporate_rate))
gen ch_corporate_rate_dec = (ch_corporate_rate < 0 & !missing(ch_corporate_rate))

*Base rules and changes therein (utilized as controls for portions of the event studies)
local baserules = "FederalIncomeasStateTaxBase sales_wgt throwback FedIncomeTaxDeductible Losscarryforward FranchiseTax"
sort fips_state year
foreach rule in `baserules' {
	g abs_`rule' = abs(`rule' - L1.`rule')
	gen ch_`rule' = ( abs_`rule' != 0 &  abs_`rule'!=.)
}

drop abs*

global basecontrols = "`baserules'"

/***************************************************************/
/*** Execute ES Program Above; Send to dump for temp storage ***/
/***************************************************************/

/* Event: Corporate Tax Rate Cuts */

Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorprate_logcorprev) 
	
Event_outcome, yvar(log_gdp) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorprate_loggdp) 
	 
Event_outcome, yvar(r_g) event(ch_corporate_rate_dec)  ///
	 outname(ES_deccorprate_rgdp)
	

/* Event: Corporate Tax Rate Cuts - With base controls */

Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols) ///
	outname(ES_deccorprate_logcorprev_basecont) 
	
Event_outcome, yvar(log_gdp) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols) ///
	outname(ES_deccorprate_loggdp_basecont) 

Event_outcome, yvar(r_g) event(ch_corporate_rate_dec)  ///
	 controls($basecontrols) ///
	outname(ES_deccorprate_rgdp_basecont)

	
/* Event: Corporate Tax Rate Increases */

Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorprate_logcorprev) 
	
Event_outcome, yvar(log_gdp) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorprate_loggdp) 
	 
Event_outcome, yvar(r_g) event(ch_corporate_rate_inc)  ///
	 outname(ES_inccorprate_rgdp)
	

/* Event: Corporate Tax Rate Increases - With base controls */

Event_outcome, yvar(log_rev_corptax) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols) ///
	outname(ES_inccorprate_logcorprev_basecont) 
	
Event_outcome, yvar(log_gdp) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols) ///
	outname(ES_inccorprate_loggdp_basecont) 
	
Event_outcome, yvar(r_g) event(ch_corporate_rate_inc)  ///
	 controls($basecontrols) ///
	outname(ES_inccorprate_rgdp_basecont) 

set more off
/******************************************/
/*** Combine raw event analysis results ***/
/******************************************/

/* Figure A17 (corp rev) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorprate_logcorprev.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'


import delim "$dumpdir/ES_deccorprate_logcorprev_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen

ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(B. Log Corporate Tax Revenue) ///
	outname(figure7b)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorprate_logcorprev.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_logcorprev_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen


ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(E. Log Corporate Tax Revenue) ///
	outname(figure7e)

restore

/* Figure A19 (GDP) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorprate_loggdp.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_loggdp_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen


ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(C. Log State GDP) ///
	outname(figure7c)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorprate_loggdp.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_loggdp_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen


ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percent") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(F. Log State GDP) ///
	outname(figure7f)

restore	
	
	
/* Corp tax rev share of gdp (added 4/20/17) */

*Decrease corporate rate
preserve

import delim "$dumpdir/ES_deccorprate_rgdp.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_deccorprate_rgdp_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen


ES_graph2, ci(1.96) xti(Years Since Decrease in Corporate Rate) yti("Percentage Points") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(A. Corp Tax Revenue Share of GDP) ///
	outname(figure7a)

restore

*Increase corporate rate
preserve

import delim "$dumpdir/ES_inccorprate_rgdp.csv", clear
rename (coef stderr) (b1 se1)
gen t = 95 + _n
replace t=t+1 if t>=100
set obs 12
replace t=100 in 12
replace b1=0 in 12
replace se1=0 in 12
sort t
tempfile data1
save `data1'

import delim "$dumpdir/ES_inccorprate_rgdp_basecont.csv", clear
rename (coef stderr) (b2 se2)
gen t = 94.85 + _n
replace t=t+1 if t>99.8
replace t=t+.15 if var=="D6"
set obs 12
replace t=99.85 in 12
replace b2=0 in 12
replace se2=0 in 12
sort t
merge 1:1 t using `data1', nogen


ES_graph2, ci(1.96) xti(Years Since Increase in Corporate Rate) yti("Percentage Points") ///
	lab1(No Tax Base Controls) lab2(Tax Base Controls) rawti(D. Corp Tax Revenue Share of GDP) ///
	outname(figure7d)

restore

*Combines 6 figures to make an additional ES figure
*Local assignment
local fignum = "7"

clear
set more off

*Draw gph data and create graph

grc1leg "$figdir/raw/figure7a.gph" ///
		"$figdir/raw/figure7b.gph" /// 
		"$figdir/raw/figure7c.gph" ///
		"$figdir/raw/figure7d.gph" ///
	    "$figdir/raw/figure7e.gph" ///
		"$figdir/raw/figure7f.gph", ///
		col(3) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(.45)
		
graph display, ysize(4)
		
graph export "$figdir/figure`fignum'.pdf", replace
