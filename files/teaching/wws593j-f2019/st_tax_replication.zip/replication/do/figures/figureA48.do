*Local assignment
local fignum = "A48"

clear
set more off

/*********************************************/
/*** Figures of Heterogeneous Elasticities ***/
/*********************************************/

global baserules "rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed"

use "$dtadir/state_taxes_analysis.dta", clear
drop if State == ""
set more off 

cd "$figdir"

bys fips: egen mean_GDP = mean(GDP)

local i = 1
foreach xvar of varlist $baserules  {
	 sum `xvar'  [aw=mean_GDP], d
	 replace `xvar'=(`xvar'-r(mean))/r(sd)
	 
	 gen s`i' = `xvar'
	 local ++i
}

label var rec_val "R\&D Tax Credit"

gen r_g = rev_corptax/GDP*10^4

** Gen main varaibles 
gen log_rev = log( rev_corp)
gen log_corp = log( 1-corpo/100 ) 
gen log_rev_gdp = log(rev_corp/GDP)
gen r_gos = rev_corptax/GOS_s
gen log_rev_gos = log(rev_corp/GOS_s)
gen log_gos = log(GOS_s)
gen log_gdp = log(GDP)
gen gos = GOS_s/100000

replace log_corp = corporate_rate


reg r_g log_corp i.year i.fips c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15 ///	
	c.log_corp#(c.s1 c.s2 c.s3 c.s4 c.s5 c.s6 c.s7 c.s8 c.s9 c.s10 c.s11 c.s12 c.s13 c.s14 c.s15  )[aw=mean_GDP]	
	gen temp_prog = _b[log_corp]+_b[c.log_corp#c.s1]*s1 ///
				 +_b[c.log_corp#c.s2]*s2+_b[c.log_corp#c.s3]*s3 ///   
				 +_b[c.log_corp#c.s4]*s4+_b[c.log_corp#c.s5]*s5 ///
				 +_b[c.log_corp#c.s6]*s6+_b[c.log_corp#c.s7]*s7 ///
				 +_b[c.log_corp#c.s8]*s8+_b[c.log_corp#c.s9]*s9 ///
				 +_b[c.log_corp#c.s10]*s10+_b[c.log_corp#c.s11]*s11 ///
				 +_b[c.log_corp#c.s12]*s12+_b[c.log_corp#c.s13]*s13 ///
				 +_b[c.log_corp#c.s14]*s14+_b[c.log_corp#c.s15]*s15 if e(sample) 
*drop state 			
rename state_abbr state
*gen state = state_abbr
drop if fips == 0 
drop if fips == .

centile temp_prog if e(sample) & inlist(year,1985,2005) , centile(20(20)80)
mat cuts = (r(c_1) ,r(c_2), r(c_3), r(c_4)) 
sum temp_prog if e(sample) & inlist(year,1985,2005) , d
*mat cuts = (r(min),cuts,r(max))
* forval i = 1/6 { 
forval i = 1/4 { 
	mat cuts[1,`i'] = round(cuts[1,`i'],.001)
} 

mat li cuts 

preserve 
keep if year == 1985
maptile temp_prog  ,  geo(state) spopt(title("1985")) cutv("`=cuts[1,1]'  `=cuts[1,2]' `=cuts[1,3]' `=cuts[1,4]' ")
*maptile temp_prog  ,  geo(state) cutv(-15.46   -7.18    -5.8   -4.62   -3.45    2.27) spopt(title("1985"))
*maptile temp_prog  ,  geo(state) spopt(title("1985"))
graph export figure`fignum'a.pdf, replace 
restore 

preserve 
keep if year == 2005
maptile temp_prog  ,  geo(state) spopt(title("2005")) cutv("`=cuts[1,1]'  `=cuts[1,2]' `=cuts[1,3]' `=cuts[1,4]' ")
*maptile temp_prog  ,  geo(state) cutv(-15.46   -7.18    -5.8   -4.62   -3.45    2.27) spopt(title("2005"))
*maptile temp_prog  ,  geo(state) spopt(title("2005"))
graph export figure`fignum'b.pdf, replace 
restore 
