*Distribution of tax changes, by magnitude of change
* Local assignment
local fignum = "A24"

*Draw Data
set more off
use "$dtadir/state_taxes_analysis.dta", clear 
keep if year >= 1980 & year <= 2010
drop if fips_state == 11 | fips_state == 0 | fips_state > 56
bys fips: egen mean_GDP = mean(GDP)


sort fips_state year
tsset fips_state year 

gen r_g = (rev_corptax*10000)/GDP

/*************************/
/*** Create base index ***/
/*************************/

capture: drop s1-s12

local i = 1 
foreach var of varlist rec_val payroll_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
	gen s`i' = `var'
	local i = `i'+1 
}

local Z "s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12 s13 s14 s15" 
reg r_g `Z'   ///
 i.year i.fips [aw=mean_GDP], cl(fips)
capture: drop base_index
gen base_index= _b[s1]*s1+_b[s2]*s2+_b[s3]*s3+_b[s4]*s4+ ///
_b[s5]*s5+_b[s6]*s6+_b[s7]*s7+_b[s8]*s8+ ///
_b[s9]*s9+_b[s10]*s10+_b[s11]*s11+_b[s12]*s12+_b[s13]*s13+_b[s14]*s14 +_b[s15]*s15

sum base_index, d 
replace base_index = (base_index-r(mean))/r(sd)

keep if base_index != . 

sort fips_state year
tsset fips_state year

*Logs
gen log_rev_corptax = ln(rev_corptax)
gen log_rev_totaltaxes = ln(rev_totaltaxes)
gen log_gdp = ln(GDP)
gen log_beaemp = ln(BEAemp)
gen log_beawage = ln(avg_wages)
gen log_est = ln(est)
gen log_gos = ln(GOS_s)

gen log_r_gdp = ln((rev_corptax*10000)/GDP)

*Rate change with pre-determined threshold (.5 at the moment)
local threshold = 0.50
gen ch_corporate_rate = corporate_rate - L1.corporate_rate
gen abs_ch_corporate_rate = abs(ch_corporate_rate)

hist ch_corporate_rate if abs_ch_corporate_rate!=0, percent width(.5) ///
	xlab(-3.5(.5)5.5) xtitle(Corporate Rate Change (pp)) ///
	plotregion(fcolor(white) lcolor(white)) /// 
	graphregion(fcolor(white) lcolor(white) m(medsmall)) legend(region(lcolor(white)))
graph export "$figdir/figure`fignum'.pdf", replace
