
*Local assignment
local fignum = "A49"

clear
set more off

/*************************/
/*** Corporate Revenue ***/
/*************************/

/*****************/
/*** Draw data ***/
/*****************/

use "$dtadir/state_taxes_analysis.dta", clear

** Gen main varaibles 
gen r_g = rev_corptax/GDP
replace corporate_rate = corporate_rate/100
sum corporate_rate , d
gen corporate_rate_demean = corporate_rate -r(mean)
gen corporate2 = corporate_rate^2
gen corporate_rate_demean2 = corporate_rate_demean^2

label var corporate2 "Corp. rate sq"

tsset fips year 

replace r_g = 10000*r_g //in basis points

/*************************/
/*** Create base index ***/
/*************************/

*drop s1-s12

local i = 1 
foreach var of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
gen s`i' = `var'
local i = `i'+1 
}

local Z "s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12 s13 s14 s15" 
reg r_g `Z'   ///
i.year i.fips, cl(fips)
capture: drop base_index
gen base_index= _b[s1]*s1+_b[s2]*s2+_b[s3]*s3+_b[s4]*s4+ ///
_b[s5]*s5+_b[s6]*s6+_b[s7]*s7+_b[s8]*s8+ ///
_b[s9]*s9+_b[s10]*s10+_b[s11]*s11+_b[s12]*s12 +_b[s13]*s13+_b[s14]*s14 + _b[s15]*s15

sum base_index, d 
replace base_index = (base_index-r(mean))/r(sd)

keep if base_index != . 

/**********************/
/*** Laffer Table 1 ***/
/**********************/

est clear

eststo est1: reg r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year  , cl(fips)
estadd local hasy "Yes"

eststo est2: reg r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year  , cl(fips)
estadd local hasy "Yes"
estadd local hass "Yes"

eststo est3: reg r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year base_index  , cl(fips) 
estadd local hasy "Yes"

eststo est4: reg r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year base_index i.fips  , cl(fips) 
estadd local hasy "Yes"
estadd local hass "Yes"
nlcom -_b[c.corporate_rate]/(2*_b[c.corporate_rate#c.corporate_rate]) 
local top_mean = el(r(b),1,1)
estadd scalar top = `top_mean'

eststo est5: reg r_g c.corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year base_index   c.base_index#(c.corporate_rate c.corporate_rate#c.corporate_rate) i.fips  , cl(fips) 
estadd local hasy "Yes"
estadd local hass "Yes"
nlcom -_b[c.corporate_rate]/(2*_b[c.corporate_rate#c.corporate_rate]) 
local top_mean = el(r(b),1,1)
estadd scalar top = `top_mean'

* Linear effect is sig at 10percent level 
nlcom (_b[corporate_rate]-1.3*_b[c.corporate_rate#c.base_index])

* Decreasing returns to raising revenues 
nlcom ((_b[corporate_rate#corporate_rate]-1.3*_b[c.corporate_rate#corporate_rate#c.base_index]))

* Top rate is 14.8% and can reject 0 in one-sided test with p-value of .07. 
nlcom (_b[corporate_rate]-1.3*_b[c.corporate_rate#c.base_index])/(-2*(_b[corporate_rate#corporate_rate]-1.3*_b[c.corporate_rate#corporate_rate#c.base_index]))



/***********************/
/*** Laffer Figure 1 ***/
/***********************/

* Laffer curve with base-independent rate:
twoway (function y = (x<.52)*(x*_b[c.corporate_rate]+x^2*_b[c.corporate_rate#c.corporate_rate] ), ///
xline(`top_mean', lpattern(dash)) yline(0)  range(0 .6) xlab(0(.05).6) xtitle("Corporate Tax Rate") ///
ytitle("Tax Revenue/GDP") ///
plotregion(fcolor(white) lcolor(white)) ///
graphregion(fcolor(white) lcolor(white)))

graph export "$figdir/figure`fignum'a.pdf", replace

* Laffer curve with base-dependent rate:

** create base-dependent rate:

gen top_base = -(_b[c.corporate_rate]+base_index*_b[c.corporate_rate#c.base_index])/(2*(_b[c.corporate_rate#c.corporate_rate]+base_index*_b[c.corporate_rate#c.corporate_rate#c.base_index]))

gen denom = (2*(_b[c.corporate_rate#c.corporate_rate]+base_index*_b[c.corporate_rate#c.corporate_rate#c.base_index])) 

** replace top rate equal to one if quadratic term (denom) is positive 
replace top_base = 1 if denom >= 0 & top_base !=. 
** top code to rate at 1 
replace top_base = 1 if top_base >1 & top_base != . 

** create a high top base indicator 
sum top_base 
sum top_base if top_base<1
gen high_top_base = (top_base > r(mean)) 

** Graphs 
sum top_base , d
cdfplot top_base , xlab(0(.05)1)  xline(`top_mean') xline(`r(mean)',lpattern(dash)) yline(0) ///
			   xtitle("Corporate Tax Rate") ///
			   ytitle("Cumulative Probability") ///
			   plotregion(fcolor(white) lcolor(white)) ///
			   graphregion(fcolor(white) lcolor(white)) ///
			   text(1.05 `top_mean' "Base-independent Rate", size(vsmall)) ///
			   text(1.05 `r(mean)' "Mean Base-dependent Rate", size(vsmall))
			   
graph export "$figdir/figure`fignum'b.pdf", replace	


/*********************************************************/
/*** Total Revenue, INCLUDING SALES AND TOP PINC RATE  ***/
/*********************************************************/

use "$dtadir/state_taxes_analysis.dta", clear

g total_r_g = (rev_totaltaxes/GDP) //in basis points

replace corporate_rate = corporate_rate/100
sum corporate_rate , d
gen corporate_rate_demean = corporate_rate -r(mean)
gen corporate2 = corporate_rate^2
gen corporate_rate_demean2 = corporate_rate_demean^2

label var corporate2 "Corp. rate sq"

tsset fips year 

replace total_r_g = 10000*total_r_g //in basis points


/*************************/
/*** Create base index ***/
/*************************/

* Total Tax Revenue/GDP:

local i = 1 
foreach var of varlist rec_val sales_wgt Losscarryback Losscarryforward FranchiseTax FedIncomeTaxDeductible FederalIncomeasStateTaxBase AllowFedAccDep ACRSDepreciation FederalBonusDepreciation throwback combined investment_credit incr_ma incr_fixed {
gen s`i' = `var'
local i = `i'+1 
}
local Z "s1 s2 s3 s4 s5 s6 s7 s8 s9 s10 s11 s12 s13 s14 s15" 
reg total_r_g `Z'   ///
i.year i.fips, cl(fips)
capture: drop base_index
gen base_index= _b[s1]*s1+_b[s2]*s2+_b[s3]*s3+_b[s4]*s4+ ///
_b[s5]*s5+_b[s6]*s6+_b[s7]*s7+_b[s8]*s8+ ///
_b[s9]*s9+_b[s10]*s10+_b[s11]*s11+_b[s12]*s12 ///
+_b[s13]*s13+_b[s14]*s14 + _b[s15]*s15

sum base_index, d 
replace base_index = (base_index-r(mean))/r(sd)

keep if base_index != . 


/**********************/
/*** Laffer Table 1, INCLUDING SALES AND TOPINC ***/
/**********************/

est clear

eststo est1: reg total_r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year  , cl(fips)
estadd local hasy "Yes"

eststo est2: reg total_r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year  , cl(fips)
estadd local hasy "Yes"
estadd local hass "Yes"

eststo est3: reg total_r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year base_index  , cl(fips) 
estadd local hasy "Yes"

eststo est4: reg total_r_g corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year base_index i.fips  , cl(fips) 
estadd local hasy "Yes"
estadd local hass "Yes"
nlcom -_b[c.corporate_rate]/(2*_b[c.corporate_rate#c.corporate_rate]) 
local top_mean = el(r(b),1,1)
estadd scalar top = `top_mean'

eststo est5: reg total_r_g c.corporate_rate c.corporate_rate#c.corporate_rate ///
 c.t_sales c.t_pinc_rate ///
i.year base_index   c.base_index#(c.corporate_rate c.corporate_rate#c.corporate_rate) i.fips  , cl(fips) 
estadd local hasy "Yes"
estadd local hass "Yes"
nlcom -_b[c.corporate_rate]/(2*_b[c.corporate_rate#c.corporate_rate]) 
local top_mean = el(r(b),1,1)
estadd scalar top = `top_mean'

* Linear effect is sig at 10percent level 
nlcom (_b[corporate_rate]-1.3*_b[c.corporate_rate#c.base_index])

* Decreasing returns to raising revenues 
nlcom ((_b[corporate_rate#corporate_rate]-1.3*_b[c.corporate_rate#corporate_rate#c.base_index]))

* Top rate is 14.8% and can reject 0 in one-sided test with p-value of .07. 
nlcom (_b[corporate_rate]-1.3*_b[c.corporate_rate#c.base_index])/(-2*(_b[corporate_rate#corporate_rate]-1.3*_b[c.corporate_rate#corporate_rate#c.base_index]))



/***********************/
/*** Laffer Figure 2 ***/
/***********************/

* Laffer curve with base-independent rate:
twoway (function y = max((x<.58)*(x*_b[c.corporate_rate]+x^2*_b[c.corporate_rate#c.corporate_rate]),0) if c.corporate_rate <= 0.3, ///
xline(`top_mean', lpattern(dash)) yline(0)  range(0 .21) xlab(0(.05).6) xtitle("Corporate Tax Rate") ///
ytitle("Tax Revenue/GDP") /// //xscale(range(0 0.2)) xlabel(0(0.02)0.2)
plotregion(fcolor(white) lcolor(white)) ///
graphregion(fcolor(white) lcolor(white)))

graph export "$figdir/figure`fignum'c.pdf", replace

* Laffer curve with base-dependent rate:

** create base-dependent rate:
gen top_base = -(_b[c.corporate_rate]+base_index*_b[c.corporate_rate#c.base_index])/(2*(_b[c.corporate_rate#c.corporate_rate]+base_index*_b[c.corporate_rate#c.corporate_rate#c.base_index]))

gen denom = (2*(_b[c.corporate_rate#c.corporate_rate]+base_index*_b[c.corporate_rate#c.corporate_rate#c.base_index])) 

** replace top rate equal to one if quadratic term (denom) is positive 
replace top_base = 1 if denom >= 0 & top_base !=. 
** top code to rate at 1 
replace top_base = 1 if top_base >1 & top_base != . 

** create a high top base indicator 
sum top_base 
sum top_base if top_base<1
gen high_top_base = (top_base > r(mean)) 

** Graphs 
sum top_base , d
cdfplot top_base, xlab(0(.05)1)  xline(`top_mean') xline(`r(mean)',lpattern(dash)) yline(0) ///
				   xtitle("Corporate Tax Rate") ///
				   ytitle("Cumulative Probability") xscale(range(0.00 0.28)) xlabel(0.00(0.02)0.28) ///
				   plotregion(fcolor(white) lcolor(white)) ///
				   graphregion(fcolor(white) lcolor(white)) ///
				   text(1.05 .075 "Base-independent Rate", size(vsmall) ) ///
				   text(1.05 .135 "Mean Base-dependent Rate", size(vsmall) )
				   
graph export "$figdir/figure`fignum'd.pdf", replace	
