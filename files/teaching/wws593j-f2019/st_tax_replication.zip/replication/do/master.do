* Master .do file for State Corporate Tax Structure
* Owners: Juan Carlos Suárez Serrato and Owen Zidar
* Date: July 23, 2018

/*******************/
/*** Environment ***/
/*******************/

/* Set root directory */
global localdir "/Users/ozidar/Downloads/replication" //Set origin path

global dodir    "$localdir/do"
global dtadir   "$localdir/data"
global dumpdir  "$localdir/out/csv"
global tabdir   "$localdir/out/tables"
global figdir 	"$localdir/out/figures"

display "$S_TIME  $S_DATE"
clear
set mem 5g
set more off

capture program drop _all

/*************************************************/
/*** Necesssary packages & supplementary files ***/
/*************************************************/

*Stata packages
ssc install coefplot, replace 
ssc install listtex, replace 
ssc install cdfplot, replace 
ssc install regsave, replace 
ssc install maptile, replace 
ssc install spmap, replace 
ssc install estout, replace
ssc install binscatter, replace
net install grc1leg, from("http://www.stata.com/users/vwiggins")
maptile_install using "http://files.michaelstepner.com/geo_state.zip", replace 

*Define programs
do "$dodir/programs.do" 

/***************/
/*** Figures ***/
/***************/
do "$dodir/figures/figure1.do"

do "$dodir/figures/figure2.do"

do "$dodir/figures/figure3.do"

do "$dodir/figures/figure4.do"

do "$dodir/figures/figure5.do"

do "$dodir/figures/figure6.do"

do "$dodir/figures/figure7.do"

do "$dodir/figures/figure8.do"  

do "$dodir/figures/figure9.do"

do "$dodir/figures/figure10.do"  

do "$dodir/figures/figure11.do"

do "$dodir/figures/figureA1.do"  

do "$dodir/figures/figureA2.do" 

do "$dodir/figures/figureA3.do" 

do "$dodir/figures/figureA4.do" 

do "$dodir/figures/figureA5.do" 

do "$dodir/figures/figureA6.do" 

do "$dodir/figures/figureA7_A22.do"

do "$dodir/figures/figureA23.do"

do "$dodir/figures/figureA24.do"

do "$dodir/figures/figureA25.do"

do "$dodir/figures/figureA26.do"

do "$dodir/figures/figureA27.do"

do "$dodir/figures/figureA28.do"

do "$dodir/figures/figureA29.do"

do "$dodir/figures/figureA30_A44.do"

do "$dodir/figures/figureA45.do"

do "$dodir/figures/figureA46.do"

do "$dodir/figures/figureA47.do"

do "$dodir/figures/figureA48.do"

do "$dodir/figures/figureA49.do"


/**************/
/*** Tables ***/
/**************/
do "$dodir/tables/table1.do"

do "$dodir/tables/table2.do"

do "$dodir/tables/table3.do" 

do "$dodir/tables/table4.do" 

do "$dodir/tables/table5.do" 

do "$dodir/tables/table6.do"

do "$dodir/tables/table7.do"

do "$dodir/tables/tableA1.do" 

do "$dodir/tables/tableA2.do" 

do "$dodir/tables/tableA3.do" 

do "$dodir/tables/tableA4.do" 

do "$dodir/tables/tableA5.do" 

do "$dodir/tables/tableA6.do" 

do "$dodir/tables/tableA6.do" 

do "$dodir/tables/tableA7.do" 

do "$dodir/tables/tableA8.do" 

do "$dodir/tables/tableA9.do"

do "$dodir/tables/tableA10.do"

do "$dodir/tables/tableA11.do"

do "$dodir/tables/tableA12.do"

do "$dodir/tables/tableA13.do"

do "$dodir/tables/tableA14.do"

