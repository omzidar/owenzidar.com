
% Function that computes group-specific rates of return

function [r1,r2,coef_ri_grp1, coef_rc_grp1, coef_ri_grp2, coef_rc_grp2] = computerates(thetahat,k,ln_ri,ln_rc)

    % Extract estimated parameters
    if k==20 || k==18 || k==19
        pi_i1       = thetahat(15);
        pi_i2       = thetahat(16);
        pi_c1       = thetahat(17);
        pi_c2       = thetahat(18);
    elseif k==12 
        pi_i1       = thetahat(9);
        pi_i2       = thetahat(10);
        pi_c1       = thetahat(11);
        pi_c2       = thetahat(12);
   elseif k==4 
        pi_i1       = thetahat(1);
        pi_i2       = thetahat(2);
        pi_c1       = thetahat(3);
        pi_c2       = thetahat(4);    
    end

    % Log rates of return accruing to each group
    ln_r1       = (pi_c2/(pi_i1*pi_c2-pi_i2*pi_c1))*ln_ri-...
                (pi_i2/(pi_i1*pi_c2-pi_i2*pi_c1))*ln_rc;
    ln_r2       = -(pi_c1/(pi_i1*pi_c2-pi_i2*pi_c1))*ln_ri+...
                (pi_i1/(pi_i1*pi_c2-pi_i2*pi_c1))*ln_rc;
            
    % Coefficients on credit and interestt rate risk in regressions
    coef_ri_grp1 = (pi_c2/(pi_i1*pi_c2-pi_i2*pi_c1));
    coef_rc_grp1 = -(pi_i2/(pi_i1*pi_c2-pi_i2*pi_c1));
    coef_ri_grp2 = -(pi_c1/(pi_i1*pi_c2-pi_i2*pi_c1));
    coef_rc_grp2 = (pi_i1/(pi_i1*pi_c2-pi_i2*pi_c1));
    
    % Rates of return accruing to each group
    r1          = exp(ln_r1);
    r2          = exp(ln_r2);
    