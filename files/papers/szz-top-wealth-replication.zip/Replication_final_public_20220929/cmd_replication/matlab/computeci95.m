
% Function that computes bounds of 95% confidence intervals

function [lb,ub] = computeci95(b,se,n,k)

    % 97.5th percentile of Student's T distribution
    t975        = tinv(0.975,n-k);

    % Compute bounds of 95% confidence interval
    lb          = b-t975*se;
    ub          = b+t975*se;