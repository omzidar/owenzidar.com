
% Function that computes sample moments from SCF

function mhat_scf_param4 = mhat_scf_param4(ln_r1,ln_r2,ln_a1,ln_a2)

    % Matrix to extract covariance from variance-covariance matrix
    M           = [0,0;1,0];

    % Sample moments
    mu_r1       = mean(ln_r1);
    mu_r2       = mean(ln_r2);
    mu_a1       = mean(ln_a1);
    mu_a2       = mean(ln_a2);
    
    var_r1      = var(ln_r1);
    var_r2      = var(ln_r2);
    var_a1      = var(ln_a1);
    var_a2      = var(ln_a2);
  
    
    % Sample moments from SCF
    cov_r1r2    = sum(cov(ln_r1,ln_r2).*M,'all');
    cov_r1a1    = sum(cov(ln_r1,ln_a1).*M,'all');
    cov_r1a2    = sum(cov(ln_r1,ln_a2).*M,'all');
    cov_r2a1    = sum(cov(ln_r2,ln_a1).*M,'all');
    cov_r2a2    = sum(cov(ln_r2,ln_a2).*M,'all');
    cov_a1a2    = sum(cov(ln_a1,ln_a2).*M,'all');
    clear M
    

    
    % Vector of sample moments from SCF
    mhat_scf_param4    = [mu_r1;mu_r2; mu_a1; mu_a2;var_r1;var_r2; var_a1;var_a2; cov_r1r2;cov_r1a1;cov_r1a2;cov_r2a1;cov_r2a2;cov_a1a2];
