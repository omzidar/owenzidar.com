
function [beta,info] = cmd_ipopt4(mhat,mhat_scf,sa1,invV,mhat_scf_param4)
    
    % Number of parameters
    k               = 4;
    
    % Set initial values and parameter bounds
    rng(555);
    x0              = rand(k,1);
    options.lb      = -1.*ones(4,1);
    options.ub      = 2.*ones(4,1);
  
    % Set IPOPT options
    options.ipopt.mu_strategy           = 'adaptive';
    options.ipopt.tol                   = 1e-9;
    options.ipopt.acceptable_tol        = 1e-9;
    options.ipopt.max_iter              = 1e4;
    options.ipopt.hessian_constant      = 'no';
    options.ipopt.hessian_approximation = 'limited-memory';
    
    % Set up auxiliary data
    options.auxdata         = { mhat mhat_scf sa1 invV mhat_scf_param4};
    
    % Callback functions
    funcs.objective         = @cmd_objective4;
    funcs.gradient          = @cmd_gradient4;
    %funcs.hessian           = @cmd_hessian;
    %funcs.hessianstructure  = @(auxdata) sparse(tril(ones(k)));
    
    % Run IPOPT
    [beta,info]     = ipopt_auxdata(x0,funcs,options);
    