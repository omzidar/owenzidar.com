/* 
  Title: master_torun.do
  Author: -
  Created: 2022-07-13
  Purpose: Specific config for running master.do
*/

********************************************************************************
** Environment variables (system specific)
********************************************************************************
ssc install freduse

global localcodedir "/path/to/wealth/Code"
global root $localcodedir

global inputs "../Inputs"

cd $localcodedir
do master.do
