/* 
  Title: master.do
  Author: EZ
  Created: 2019-02-02
  Purpose: Collected analysis wealth project, external.
  
*/

********************************************************************************
** Environment variables (system invariant)
** localcodedir, dboxdir, librarydir should be defined in parent do file
**   for the author's specific setup (see, e.g., master_torun.do)
********************************************************************************
local dodir "$localcodedir/do"
global outputdir "$localcodedir/output"
global repodir "$localcodedir/../.."
global dboxdatadir "$dboxdir/data"

* Evolving analysis paths
global analysis "PATH/TO/ANALYSIS"

gl maincollapses "PATH/TO/COLLAPSES"

cap do $librarydir/system-config.do
cap do $librarydir/programs.do


* QJE Final Version
do `dodir'/programs_final.do
do `dodir'/draft_final.do
main

do `dodir'/appendix_final.do
main

capture log c
