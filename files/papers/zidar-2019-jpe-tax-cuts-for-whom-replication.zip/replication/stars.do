/*************************************/
/*** Stars (Supplementary) Program ***/
/*************************************/


*Stars program with option for variable and right-justified format
*Note that coefficients are default scaled by 100 so this may not fit all programs perfectly; be sure to check
*Also the way the coefficients are read in is fairly rigid
capture program drop stars
program stars
syntax, var(string) [ rj(real 2) ]
	disp "Checking star for `var'"
	local pval = tprob(e(df_r), abs(_b[`var']/_se[`var']))
	local val : di %-12.`rj'f = _b[`var']*100
	forv i = 1/10 {
		local val: subinstr local val " " ""
	}
	global coef = "`val'"
	if `pval' < .1 & `pval' >= .05 {
		global coef = "`val'*"
	}
	if `pval' < .05 & `pval' >= .01 {
		global coef = "`val'**"
	} 
	if `pval' < .01 {
		global coef = "`val'***"
	}
	disp "$coef"
end


/*
*Same as stars above but without scales enforced
*Also the way the coefficients are read in is fairly rigid
capture program drop stars_alt
program stars_alt
syntax, var(string) [ rj(real 2) ]
	disp "Checking star for `var'"
	local pval = tprob(e(df_r), abs(_b[`var']/_se[`var']))
	disp "pval = `pval'"
	local val : di %-12.`rj'f = _b[`var']
	forv i = 1/10 {
		local val: subinstr local val " " ""
	}
	global coef = "`val'"
	if `pval' < .1 & `pval' >= .05 {
		global coef = "`val'*"
	}
	if `pval' < .05 & `pval' >= .01 {
		global coef = "`val'**"
	} 
	if `pval' < .01 {
		global coef = "`val'***"
	}
end
*/


*Alternate stars program for linear combination tests (results are stored differently, so have to use different calls)
*Note that this program is still fairly rigid and still scales results by 100 due to the scales we use (for interpretation)
capture program drop stars_lincom
program stars_lincom
syntax, [ rj(real 2) ]
	local pval = tprob(`r(df)', abs(`r(estimate)'/`r(se)'))
	local val : di %-12.`rj'f = `r(estimate)'*100
	forv i = 1/10 {
		local val: subinstr local val " " ""
	}
	global coef = "`val'"
	if `pval' < .1 & `pval' >= .05 {
		global coef = "`val'*"
	}
	if `pval' < .05 & `pval' >= .01 {
		global coef = "`val'**"
	} 
	if `pval' < .01 {
		global coef = "`val'***"
	}
	disp "$coef"
end



/*
*Same as above stars (lincom) program but with no scalar
*Program is still rigid
capture program drop stars_lincom_alt
program stars_lincom_alt
syntax, [ rj(real 2) ]
	local pval = tprob(`r(df)', abs(`r(estimate)'/`r(se)'))
	local val : di %-12.`rj'f = `r(estimate)'
	forv i = 1/10 {
		local val: subinstr local val " " ""
	}
	global coef = "`val'"
	if `pval' < .1 & `pval' >= .05 {
		global coef = "`val'*"
	}
	if `pval' < .05 & `pval' >= .01 {
		global coef = "`val'**"
	} 
	if `pval' < .01 {
		global coef = "`val'***"
	}
	disp "$coef"
end
