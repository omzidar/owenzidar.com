***Master do file for TCFW paper

/*******************/
/*** Environment ***/
/*******************/

/* Choose dropbox root */
global root					"/Users/ruggieri/Dropbox/TCFW/stata/replication"

/* Main directories */

global dodir_build 		 	"$root/build/do"
global dodir_tab		 	"$root/tables/do"
global dodir_fig		 	"$root/figures/do"
global dodir_apptab		 	"$root/appendix/tables/do"
global dodir_appfig		 	"$root/appendix/figures/do"

global datadir				"$root/data"
global dtadir_bea			"$datadir/bea"
global dtadir_bls	     	"$datadir/bls"
global dtadir_taxsim     	"$datadir/taxsim"
global dtadir_qcew		 	"$datadir/qcew"
global dtadir_cps	     	"$datadir/cps"
global dtadir_compcons   	"$datadir/comp_constant_wage"
global dtadir_st_pop	 	"$datadir/census"
global dtadir_govfin     	"$datadir/govfin"
global dtadir_minwage    	"$datadir/minwage"
global dtadir_oil		 	"$datadir/oil"
global dtadir_irate		 	"$datadir/irate"
global dtadir_regions	 	"$datadir/regions"
global dtadir_nipa		 	"$datadir/nipa"
global pricedir				"$datadir/prices"
global dtadir_accra		 	"$pricedir/accra"
global dtadir_cpi_bls 	 	"$pricedir/bls"
global dtadir_hpi		 	"$pricedir/hpi"
global dtadir_local_cpi	 	"$pricedir/cpi_local" /* Moretti-esque CPI construction */
global socinsdir			"$datadir/socins"
global dtadir_ssi		 	"$socinsdir/ssi"
global dtadir_snap 			"$socinsdir/snap"
global dtadir_tanf  	 	"$socinsdir/tanf"
global dtadir_afdc 	     	"$socinsdir/afdc"
global dtadir_fmap		 	"$socinsdir/fmap"
global dtadir_fpl			"$socinsdir/fpl"
global dtadir_medicaid	 	"$socinsdir/medicaid"
global dtadir_medicare	 	"$socinsdir/medicare"
global dtadir_oasdi	     	"$socinsdir/oasdi"
global dtadir_controls	 	"$datadir/socins_microsim"
global dtadir_oecd		 	"$datadir/oecd"
global dtadir_fipsxwalk  	"$datadir/fips"

/* Output directories */
global dtadir_final      	"$root/build/dta"
global tabdir 	         	"$root/tables/out"
global figdir			 	"$root/figures/out"
global apptabdir 	        "$root/appendix/tables/out"
global appfigdir			"$root/appendix/figures/out"

display "$S_TIME  $S_DATE"
clear
set mem 5g
set more off


/************************************************/
/*** Necessary packages & supplementary files ***/
/************************************************/

do "$root/real_usd.do"
do "$root/stars.do"

ssc inst freduse, replace
ssc install unique, replace
ssc inst _gwtmean, replace

*grc1leg
net from http://www.stata.com
net cd users
net cd vwiggins
net install grc1leg


/*****************/
/*** (1) Build ***/
/*****************/

*Build National Data
do "$dodir_build/build_national_tcfw.do"

*Build State Data
do "$dodir_build/build_state_tcfw.do"
do "$dodir_build/clean_state_tcfw.do"


/*******************/
/*** (2) Figures ***/
/*******************/

*Figure 1 (Selected Historical Tax Changes for Each AGI Percentile)
do "$dodir_fig/figure1.do"

*Figure 2a (Federal Income and Payroll Tax Changes by AGI Quintile)
do "$dodir_fig/figure2a.do"

*Figure 2b (Share of High-Income Taxpayers)
do "$dodir_fig/figure2b.do"

*Figure 3 (Cumulative Growth in State Employment-to-Population Ratio and Employment)
do "$dodir_fig/figure3.do"

*Figure 4 (Cumulative Growth in State Economic Activity)
do "$dodir_fig/figure4.do"

*Figure 5 (Cumulative Growth in State Labor Market Outcomes and Consumption)
do "$dodir_fig/figure5.do"


/******************/
/*** (3) Tables ***/
/******************/

*Table 1 (State-level Effects of Tax Changes for Different Income Groups)
do "$dodir_tab/table1.do" 

*Table 2 (State-level Effects of Tax Changes by Income Group on Employment: Cyclical Robustness)
do "$dodir_tab/table2.do"

*Table 3 (State-level Effects of Tax Changes by Income Group on Employment: Policy Robustness)
do "$dodir_tab/table3.do"

*Table 4 (National Effects of Tax Changes for Different Income Groups)
do "$dodir_tab/table4.do"


/****************************/
/*** (4) Appendix Figures ***/
/****************************/

*Appendix Figure 10 (Cumulative Growth in Emp-to-Pop Ratio and Employment: Lagged Tax Changes as Controls)
do "$dodir_appfig/figureA10.do"

*Appendix Figure 11 (Cumulative Growth in Prices, GDP, and Earnings: Lagged Tax Changes as Controls)
do "$dodir_appfig/figureA11.do"

*Appendix Figure 12 (Cumulative Growth in State-level Labor Market Outcomes: Lagged Tax Changes as Controls)
do "$dodir_appfig/figureA12.do"

*Appendix Figure 13 (Cumulative Growth in Prices)
do "$dodir_appfig/figureA13.do"

*Appendix Figure 14 (Cumulative Growth in State-level Real Wages)
do "$dodir_appfig/figureA14.do"

*Appendix Figure 15 (Cumulative Growth in Employment-to-Population Ratio by Demographic Split)
do "$dodir_appfig/figureA15.do"

*Appendix Figure 16 (Cumulative Growth in Employment Rate by Demographic Split)
do "$dodir_appfig/figureA16.do"

*Appendix Figure 17 (Cumulative Growth in Labor Force Participation Rate by Demographic Split)
do "$dodir_appfig/figureA17.do"

*Appendix Figure 18 (Cumulative Growth in Hours by Demographic Split)
do "$dodir_appfig/figureA18.do"

*Appendix Figure 19 (Cumulative Growth in Wage by Demographic Split)
do "$dodir_appfig/figureA19.do"

*Appendix Figure 20 (Cumulative Growth in Real Wage by Demographic Split)
do "$dodir_appfig/figureA20.do"

*Appendix Figure 21 (Cumulative Growth in Income by Type of Income)
do "$dodir_appfig/figureA21.do"

*Appendix Figure 22 (Cumulative Growth in Payrolls and Earnings)
do "$dodir_appfig/figureA22.do"

*Appendix Figure 23 (Cumulative Growth in State Wages)
do "$dodir_appfig/figureA23.do"

*Appendix Figure 24 (Cumulative Growth in Part-time Employment Rate)
do "$dodir_appfig/figureA24.do"

*Appendix Figure 25 (Cumulative Growth in State Emp-to-Pop Ratio and Employment: Includes Non-Personal Income Taxes in Top Decile)
do "$dodir_appfig/figureA25.do"

*Appendix Figure 26 (Cumulative Growth in Emp-to-Pop Ratio and Employment: Bottom 80% and Top 20%)
do "$dodir_appfig/figureA26.do"


/***************************/
/*** (5) Appendix Tables ***/
/***************************/

*Appendix Table 3 (Summary Statistics)
do "$dodir_apptab/tableA3.do"

*Appendix Table 4 (2-Year Change - Demographic Robustness)
do "$dodir_apptab/tableA4.do"

*Appendix Table 5 (2-Year Change - Policy Robustness (Additional))
do "$dodir_apptab/tableA5.do"

*Appendix Table 6 (State-level Effects of Tax Changes by Income Group on Economic Activity: Cyclical Robustness)
do "$dodir_apptab/tableA6.do"

*Appendix Table 7 (State-level Effects of Tax Changes by Income Group on Economic Activity: Policy Robustness)
do "$dodir_apptab/tableA7.do"

*Appendix Table 8 (State-level Effects of Tax Changes by Income Group on State GDP: Cyclical Robustness)
do "$dodir_apptab/tableA8.do"

*Appendix Table 9 (State-level Effects of Tax Changes by Income Group on State GDP: Policy Robustness)
do "$dodir_apptab/tableA9.do"

*Appendix Table 10 (State-level Effects of Tax Changes by Income Group on Real State GDP: Cyclical Robustness)
do "$dodir_apptab/tableA10.do"

*Appendix Table 11 (State-level Effects of Tax Changes by Income Group on Real State GDP: Policy Robustness)
do "$dodir_apptab/tableA11.do"


/* End */
