*This file creates TCFW table 2 (national table)

*Local assignment
local tabnum = "2"

 
/************************/
/*** Notes/Parameters ***/
/************************/

*Note that outcomes are default logged in loop (unless specified; currently employment rate and epop do not trigger log(outcome))
global outcomes_main = "GDP_NIPA Investment_NIPA Res_Investment_NIPA Consumption_NIPA Dur_Consumption_NIPA NonDur_Consumption_NIPA" 


*******************************************************************************
* 1. Data setup
*******************************************************************************

set more off
use "$dtadir_final/analysis_natl_tcfw.dta", clear

sort year

*******************************************************************************
* 2. MAIN TABLE
*******************************************************************************

*Main table

preserve

g col0 = "B90" in 1
replace col0 = "B90 1-Year Lag" in 3
replace col0 = "B90 2-Year Lag" in 5
replace col0 = "T10" in 7
replace col0 = "T10 1-Year Lag" in 9
replace col0 = "T10 2-Year Lag" in 11

*Will break these off into supplemental tex files so position matters less:
replace col0 = " \textbf{B90 Sum: $\beta_t$ + $\beta_{t-1}$ + $\beta_{t-2}$} " in 13
replace col0 = " \textbf{T10 Sum: $\beta_t$ + $\beta_{t-1}$ + $\beta_{t-2}$} " in 15
replace col0 = " \textbf{Bottom - Top:}" in 17


local column = 1 /* Will iterate and place these appropriately */
foreach outcome in $outcomes_main {
	
	*Variables for spec
	g y0 = ln(`outcome')
	g y = y0 - L1.y0
	g x1 = nonrich
	g x2 = rich
	
	*Spec
	reg y L(0/2)x1 L(0/2)x2 L(0/2)othertaxes, r
	
	*Place coefficients in dataset
	g col`column' = ""
	
	*Nonrich
	stars, var(x1)
	replace col`column' = "$coef" in 1
	replace col`column' = subinstr("("+string(_se[x1]*100, "%-12.2f")+")", " ", "", .) in 2
	
	*L1.Nonrich
	stars, var(L1.x1)
	replace col`column' = "$coef" in 3
	replace col`column' = subinstr("("+string(_se[L1.x1]*100, "%-12.2f")+")", " ", "", .) in 4
	
	*L2.Nonrich
	stars, var(L2.x1)
	replace col`column' = "$coef" in 5
	replace col`column' = subinstr("("+string(_se[L2.x1]*100, "%-12.2f")+")", " ", "", .) in 6

	
	*Rich
	stars, var(x2)
	replace col`column' = "$coef" in 7
	replace col`column' = subinstr("("+string(_se[x2]*100, "%-12.2f")+")", " ", "", .) in 8
	
	*L1.Rich
	stars, var(L1.x2)
	replace col`column' = "$coef" in 9
	replace col`column' = subinstr("("+string(_se[L1.x2]*100, "%-12.2f")+")", " ", "", .) in 10
	
	*L2.Rich
	stars, var(L2.x2)
	replace col`column' = "$coef" in 11
	replace col`column' = subinstr("("+string(_se[L2.x2]*100, "%-12.2f")+")", " ", "", .) in 12
	
	*Tests and pass coefficients into dataset
		
	*B90 tax change
	lincom x1 + L1.x1 + L2.x1
	stars_lincom
	replace col`column' = "$coef" in 13
	replace col`column' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 14
	
		
	*T10 tax change
	lincom x2 + L1.x2 + L2.x2
	stars_lincom
	replace col`column' = "$coef" in 15
	replace col`column' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 16
		
	*Bottom - Top
	lincom x1 + L1.x1 + L2.x1 - (x2 + L1.x2 + L2.x2)
	stars_lincom
	replace col`column' = "$coef" in 17
	replace col`column' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 18
	
	local ++column /* Iterate column */
	
	*Drop variables for next iteration
	drop y y0 x1 x2
}

*Now pull columns out and then restore
keep col*
keep if _n <= 18
*Main Table
listtex using "$tabdir/table`tabnum'a.tex" if inrange(_n, 1, 12), replace rstyle(tabular)

*Tests
listtex using "$tabdir/table`tabnum'b.tex" if inrange(_n, 13, 18), replace rstyle(tabular)

restore
