*This file creates TCFW table 4
local tabnum = 4

*Outcome: GDP
local outcome = "ln_emp"
local outcome_2yr = "emp" 

*******************************************************************************
* 1. Data setup
*******************************************************************************

set more off
use "$dtadir_final/analysis_st_tcfw.dta", clear

sort fips_state year
tsset fips year

*******************************************************************************
* 2. Distributed Lag
*******************************************************************************

*Number of specs (loops)
local numspecs = 12 /* Number of specifications that we want to loop over; each pass prompts a different spec */
local expobs = 1300 /* Expected number of observations */

preserve
	
local pass = 1 /* Will iterate as we go; this will specify the spec used */

*Assign variables on iteration
g y0 = `outcome'
g y  = y0 - L1.y0
g x1 = nonrich
g x2 = rich
	
*Lags
g L1x1 = L1.x1
g L2x1 = L2.x1

g L1x2 = L1.x2
g L2x2 = L2.x2
	
*Generate intended structure of table (dependent on number of specs; currently 11)
forv i = 0/`numspecs' {
	g col`i' = ""
}
replace col0 = "$ T_{s,t}^{B90}$" in 1
replace col0 = "$ T_{s,t-1}^{B90}$" in 3
replace col0 = "$ T_{s,t-2}^{B90}$" in 5
replace col0 = "$ T_{s,t}^{T10}$" in 7
replace col0 = "$ T_{s,t-1}^{T10}$" in 9
replace col0 = "$ T_{s,t-2}^{T10}$" in 11
	
*Will break these off into supplemental tex files so position matters less:
replace col0 = " \textbf{B90 Sum: $\beta_t$ + $\beta_{t-1}$ + $\beta_{t-2}$} " in 13
replace col0 = " \textbf{T10 Sum: $\beta_t$ + $\beta_{t-1}$ + $\beta_{t-2}$} " in 15
replace col0 = " \textbf{Bottom - Top:}" in 17
	
forv i = 1/`numspecs' { /* Loop over specs */
	
	*Main portion of specification
	local mainspec = "y x1 x2 L1x1 L2x1 L1x2 L2x2"
	
	*Spec (varies on pass)
	if `pass' == 1 {
		areg `mainspec' i.FX_beta_diff [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 2 {
		areg `mainspec' i.year [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 3 {
		areg `mainspec' i.yearXcyclicality [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 4 {
		areg `mainspec' i.FX_beta_diff_alt1 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 5 {
		areg `mainspec' i.FX_beta_diff_alt2 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 6 {
		areg `mainspec' i.year oil_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 7 {
		areg `mainspec' i.year irate_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}	
	if `pass' == 8 {
		areg `mainspec' i.year oil_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 9 {
		areg `mainspec' i.year irate_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 10 {
		areg `mainspec' i.FX_beta_diff oil_cross* irate_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 11 {
		areg `mainspec' i.FX_beta_diff oil_cross* irate_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 12 {
		areg `mainspec' i.FX_beta_diff statedum* [aw = L2.pop], absorb(fips) cluster(fips)
	}
		
	*Assertion to pass
	assert `e(N)' == `expobs'
		
		
	*Pass coefficients into position in table
		
	*x1
	stars, var(x1)
	replace col`pass' = "$coef" in 1
	replace col`pass' = subinstr("("+string(_se[x1]*100, "%-12.2f")+")", " ", "", .) in 2
	*L1x1
	stars, var(L1x1)
	replace col`pass' = "$coef" in 3
	replace col`pass' = subinstr("("+string(_se[L1x1]*100, "%-12.2f")+")", " ", "", .) in 4
	*L2x1
	stars, var(L2x1)
	replace col`pass' = "$coef" in 5
	replace col`pass' = subinstr("("+string(_se[L2x1]*100, "%-12.2f")+")", " ", "", .) in 6
		
	*x2
	stars, var(x2)
	replace col`pass' = "$coef" in 7
	replace col`pass' = subinstr("("+string(_se[x2]*100, "%-12.2f")+")", " ", "", .) in 8
	*L1x2
	stars, var(L1x2)
	replace col`pass' = "$coef" in 9
	replace col`pass' = subinstr("("+string(_se[L1x2]*100, "%-12.2f")+")", " ", "", .) in 10
	*L2x2
	stars, var(L2x2)
	replace col`pass' = "$coef" in 11
	replace col`pass' = subinstr("("+string(_se[L2x2]*100, "%-12.2f")+")", " ", "", .) in 12
		
		
	*Tests and pass test results into dataset
		
	*B90 tax change
	lincom x1 +L1x1+ L2x1
	stars_lincom
	replace col`pass' = "$coef" in 13
	replace col`pass' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 14
	
		
	*T10 tax change
	lincom x2 +L1x2+ L2x2
	stars_lincom
	replace col`pass' = "$coef" in 15
	replace col`pass' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 16
		
	*Bottom - Top
	lincom x1 +L1x1+ L2x1-(x2 +L1x2+ L2x2)
	stars_lincom
	replace col`pass' = "$coef" in 17
	replace col`pass' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 18
		
		
	*Iterate pass (move to next column
	local ++pass
		
 
} /* End passes; make table corresponding to outcome */

*After all passes, create tex outputs
keep col0-col`numspecs'
drop if _n > 18
	
*Main table (coefficients, etc.)
listtex if inrange(_n, 1, 12) using "$tabdir/table`tabnum'a.tex", replace rstyle(tabular)

*Tests
listtex if inrange(_n, 13, 18) using "$tabdir/table`tabnum'b.tex", replace rstyle(tabular)

restore /* Restore default structure before next loop */
	
 
*******************************************************************************
* 3. 2-Year Change
*******************************************************************************

preserve

*Total number of specifications
local numspecs = 12 /* Number of specifications that we want to loop over; each pass prompts a different spec */
local expobs = 1300 /* Expected number of observations */

*Establishing columns
g col0 = "Bottom 90" in 1
replace col0 = "Top 10" in 3
replace col0 = "P-Value (Bottom 90 = Top 10)" in 5

forv i = 1/`numspecs' {
	g col`i' = "" 
}

local pass = 1 /* Initialize pass */
forv i = 1/`numspecs' { /* Each pass corresponds to a different specification */
	
	*Variables for spec
	g y0 = `outcome_2yr'
	g y = (y0 - L2.y0)/L2.y0
	g x1 = nonrichlast2
	g x2 = richlast2
	
	*Spec (varies based on pass)
	if `pass' == 1 {
		areg y x1 x2 i.FX_beta_diff [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 2 {
		areg y x1 x2 i.year [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 3 {
		areg y x1 x2 i.yearXcyclicality [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 4 {
		areg y x1 x2 i.FX_beta_diff_alt1 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 5 {
		areg y x1 x2 i.FX_beta_diff_alt2 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 6 {
		areg y x1 x2 i.year oil_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 7 {
		areg y x1 x2 i.year irate_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}	
	if `pass' == 8 {
		areg y x1 x2 i.year oil_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 9 {
		areg y x1 x2 i.year irate_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 10 {
		areg y x1 x2 i.FX_beta_diff oil_cross* irate_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 11 {
		areg y x1 x2 i.FX_beta_diff oil_cross* irate_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 12 {
		areg y x1 x2 i.FX_beta_diff statedum* [aw = L2.pop], absorb(fips) cluster(fips)
	}
	
	*Assertion
	assert `e(N)' == `expobs'
	
	*Place coefficients in dataset (and draw using listtex after set)
	stars, var(x1)
	replace col`pass' = "$coef" in 1
	replace col`pass' = subinstr("("+string(_se[x1]*100, "%-12.2f")+")", " ", "", .) in 2

	stars, var(x2)
	replace col`pass' = "$coef" in 3
	replace col`pass' = subinstr("("+string(_se[x2]*100, "%-12.2f")+")", " ", "", .) in 4
	
	*Test whether difference between b90 and t10
	lincom _b[x1] - _b[x2]
	local pval = tprob(`r(df)', abs(`r(estimate)'/`r(se)'))
	replace col`pass' = string(`pval', "%-12.2f") in 5
	
	*Drop variables for next iteration
	drop y0 y x1 x2
	
	*Next pass
	local ++pass
	
}

*Now pull columns out and then restore
keep col0-col`numspecs'
keep if _n <= 5

listtex if _n <= 4 using "$tabdir/table`tabnum'c.tex", replace rstyle(tabular)
*Need hline before test returned (for tex format)
gen hline = "\hline" in 1
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'c.tex")
drop hline
listtex if _n == 5, appendto("$tabdir/table`tabnum'c.tex") rstyle(tabular)

restore
