*Note that this do file creates 2yrch and Dist Lag tables for main FX

*Local assignments
local tabnum = 1

*Outcomes
global outcomes_main = "emp epop gsp2014 real_gsp real_gsp_hpi"
global outcomes = "ln_emp epop ln_gsp2014 ln_real_gsp ln_real_gsp_hpi"

*******************************************************************************
* 1. Data setup
*******************************************************************************

set more off
use "$dtadir_final/analysis_st_tcfw.dta", clear

sort fips_state year
tsset fips year

*******************************************************************************
* 2. 2-Year Change
*******************************************************************************

*Main table
*NOTE THAT ALL VALUES ARE SCALED BY 100 FOR THE TABLES (i.e. .009 -> .9 == .9%)
preserve

*Establishing columns
g col0 = "Bottom 90" in 2
replace col0 = "Top 10" in 4
replace col0 = "P-Value (Bottom 90 = Top 10)" in 6

g col1 = "\underline{Employment}" in 1
g col2 = "\underline{Emp/Pop}" in 1
g col3 = "\underline{Nominal GDP}" in 1
g col4 = "\underline{Real GDP (ACCRA)}" in 1
g col5 = "\underline{Real GDP (Moretti)}" in 1

local column = 1 /* Will iterate and place these appropriately */
foreach outcome in $outcomes_main { /* Note that we're iterating over "outcomes_main" for this table */
	disp "2-year change for: `outcome'"
	
	*Variables for spec
	g y0 = `outcome'
	g y = (y0 - L2.y0)/L2.y0
	if "`outcome'" == "epop" {
		replace y = y0 - L2.y0 /* Want different measure for these */
	}
	*g x1 = L2.nonrich
	*g x2 = L2.rich
	g x1 = nonrichlast2
	g x2 = richlast2
		
	*Spec
	areg y x1 x2 i.FX_beta_diff [aw = L2.pop], absorb(fips) cluster(fips)
	
	*Place coefficients in dataset
	stars, var(x1)
	replace col`column' = "$coef" in 2
	replace col`column' = subinstr("("+string(_se[x1]*100, "%-12.2f")+")", " ", "", .) in 3

	stars, var(x2)
	replace col`column' = "$coef" in 4
	replace col`column' = subinstr("("+string(_se[x2]*100, "%-12.2f")+")", " ", "", .) in 5
	
	*Test whether difference between b90 and t10
	lincom _b[x1] - _b[x2]
	local pval = tprob(`r(df)', abs(`r(estimate)'/`r(se)'))
	replace col`column' = string(`pval', "%-12.2f") in 6
	
	local ++column /* Iterate column */	
	
	*Drop variables for next iteration
	drop y0 y x1 x2
}

*Now pull columns out and then restore
keep col0-col5
keep if _n <= 6
listtex if _n <= 5 using "$tabdir/table`tabnum'b.tex", replace rstyle(tabular)
*Need hline before test returned
gen hline = "\hline" in 1
listtex hline if _n == 1, appendto("$tabdir/table`tabnum'b.tex")
drop hline
listtex if _n == 6, appendto("$tabdir/table`tabnum'b.tex") rstyle(tabular)

restore


*******************************************************************************
* 3. Distributed Lag AND lin com tests (3)
******************************************************************************* 

preserve

g col0 = "B90" in 2
replace col0 = "B90 1-Year Lag" in 4
replace col0 = "B90 2-Year Lag" in 6
replace col0 = "T10" in 8
replace col0 = "T10 1-Year Lag" in 10
replace col0 = "T10 2-Year Lag" in 12

*Will break these off into supplemental tex files so position matters less:
replace col0 = " \textbf{B90 Sum: $\beta_t$ + $\beta_{t-1}$ + $\beta_{t-2}$} " in 13
replace col0 = " \textbf{T10 Sum: $\beta_t$ + $\beta_{t-1}$ + $\beta_{t-2}$} " in 15
replace col0 = " \textbf{Bottom - Top:}" in 17

*Outcome columns
g col1 = "\underline{Employment}" in 1
g col2 = "\underline{Emp/Pop}" in 1
g col3 = "\underline{Nominal GDP}" in 1
g col4 = "\underline{Real GDP (ACCRA)}" in 1
g col5 = "\underline{Real GDP (Moretti)}" in 1


local column = 1 /* Iterate as we go */
foreach outcome in $outcomes {

	*Variables for spec
	g y0 = `outcome'
	g y = y0 - L1.y0
	g x1 = nonrich
	g x2 = rich

	*Spec
	areg y L(0/2).x1 L(0/2).x2 i.FX_beta_diff [aw=L2.pop], absorb(fips) cluster(fips)
	
	*Place coefficients in dataset
	
	***Bottom 90%
	
	*x1
	stars, var(x1) rj(2)
	replace col`column' = "$coef" in 2
	replace col`column' = subinstr("("+string(_se[x1]*100, "%-12.2f")+")", " ", "", .) in 3
	
	*L1.x1
	stars, var(L1.x1) rj(2)
	replace col`column' = "$coef" in 4
	replace col`column' = subinstr("("+string(_se[L1.x1]*100, "%-12.2f")+")", " ", "", .) in 5
	
	*L2.x1
	stars, var(L2.x1) rj(2)
	replace col`column' = "$coef" in 6
	replace col`column' = subinstr("("+string(_se[L2.x1]*100, "%-12.2f")+")", " ", "", .) in 7
	
	***Top 10%
	
	*x2
	stars, var(x2) rj(2)
	replace col`column' = "$coef" in 8
	replace col`column' = subinstr("("+string(_se[x2]*100, "%-12.2f")+")", " ", "", .) in 9
	
	*L1.x2
	stars, var(L1.x2) rj(2)
	replace col`column' = "$coef" in 10
	replace col`column' = subinstr("("+string(_se[L1.x2]*100, "%-12.2f")+")", " ", "", .) in 11
	
	*L2.x2
	stars, var(L2.x2) rj(2)
	replace col`column' = "$coef" in 12
	replace col`column' = subinstr("("+string(_se[L2.x2]*100, "%-12.2f")+")", " ", "", .) in 13
	
	
	*Tests and pass coefficients into dataset
		
	*B90 tax change
	lincom x1 + L1.x1 + L2.x1
	stars_lincom
	replace col`column' = "$coef" in 13
	replace col`column' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 14
	
		
	*T10 tax change
	lincom x2 + L1.x2 + L2.x2
	stars_lincom
	replace col`column' = "$coef" in 15
	replace col`column' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 16
		
	*Bottom - Top
	lincom x1 + L1.x1 + L2.x1 - (x2 + L1.x2 + L2.x2)
	stars_lincom
	replace col`column' = "$coef" in 17
	replace col`column' = subinstr("("+string(`r(se)'*100, "%-12.2f")+")", " ", "", .) in 18
	
	*Drop variables for next iteration
	local ++column /* Increment column */
	drop y0 y x1 x2
}
	
*Now pull columns out and then restore
keep col0-col5
keep if _n <= 18
*Main table (coefficients, etc.)
listtex if inrange(_n, 1, 12) using "$tabdir/table`tabnum'a.tex", replace rstyle(tabular)

*Tests
listtex if inrange(_n, 13, 18) using "$tabdir/table`tabnum'c.tex", replace rstyle(tabular)

restore
