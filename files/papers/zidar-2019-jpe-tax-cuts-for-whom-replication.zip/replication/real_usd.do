capture program drop real_usd
program real_usd
syntax, yr(int) 

tempfile orig
save `orig', replace

freduse CPIAUCSL, clear
gen year = yofd(date(date, "YMD"))
collapse CPIAUCSL, by(year)
gen cpi_h = CPIAUCSL * (year == `yr')
egen cpi = max(cpi_h)
g cpi_scale_factor= cpi/CPIAUCSL
label var cpi_scale_factor "Scaling factor to convert to `yr' USD"
drop CPIAUCSL cpi_h cpi
 
tempfile dta_cpi_scaling
sort year
save `dta_cpi_scaling', replace

    use `orig', clear
        merge m:1 year using `dta_cpi_scaling', keep(3) nogen
		
end
