
*******************************************************************************
* 0. Program (ES setup and run; inflexible, horizons/etc always the same)
*******************************************************************************

*ES program
*Options:
	*outcome := Outcome variable in main regression.
	*outname := PDF output name (string).  This will be sent to "figdir" by default.
	*xti := x-axis title
	*yti := y-axis title
	*fx := Additional FX to be included in main specification.  See program or examples for how this is implemented (although it is simple)
	*ci := How large the confidence intervals will be for the figures.  1.96 SE is the default.
	*rawti := title of raw graph output if included

capture program drop TCFW_ES_panel1

program define TCFW_ES_panel1

set more off	
syntax, outcome(varname) outname(string) xti(string) [ yti(string) fx(string) ci(real 1.96) rawti(string) ]

	preserve
	
	qui { /* Supress output; remove this part if you want everything to be displayed */
	
	*Initialize and recast LHS var to short descriptor
	g y = `outcome'
		
	*Time variable to keep track/for the figure, as well as point estimates to be filled in below
	g fig_t = _n - 4 in 1/10
	g fig_b1 = .
	g fig_b2 = .
	g se_b1 = .
	g se_b2 = .

	*Generate difference variables (outcomes for event study) and iterate on point estimates
	sort fips year
	tsset fips year
	g y0 = y - L1.y /* Event time */
	
	*MAIN SPECIFICATION FOR EVENT TIME
	areg y0 x1 x2 `fx' [aw = L4.pop], absorb(fips) cluster(fips)
	
	*Draw variables and se
	replace fig_b1 = _b[x1] if fig_t == 0
	replace fig_b2 = _b[x2] if fig_t == 0
	replace se_b1 = _se[x1] if fig_t == 0
	replace se_b2 = _se[x2] if fig_t == 0

	*Normalized to 0 at time = -1
	replace fig_b1 = 0 if fig_t == -1 
	replace fig_b2 = 0 if fig_t == -1 
	replace se_b1 = 0 if fig_t == -1
	replace se_b2 = 0 if fig_t == -1

	*Loop over 6 event times (lags and leads)
	forv i = 1/6 {
		*Lags
		if `i' == 2 | `i' == 3 { /* Binned to 3 on lags; -1 normalized to 0 */
			local relative_t = -`i'
			g yn`i' = L`i'.y - L1.y
			
			*MAIN SPECIFICATION		
			areg yn`i' x1 x2 `fx' [aw = L4.pop], absorb(fips) cluster(fips)
			
			*Draw coefficients and se
			replace fig_b1 = _b[x1] if fig_t == `relative_t'
			replace fig_b2 = _b[x2] if fig_t == `relative_t'
			replace se_b1 = _se[x1] if fig_t == `relative_t'
			replace se_b2 = _se[x2] if fig_t == `relative_t'
		}
		
		*Leads
		g y`i' = F`i'.y - L1.y /* Leads allowed to extend to 6 */
		
		*MAIN SPECIFICATION
		areg y`i' x1 x2 `fx' [aw = L4.pop], absorb(fips) cluster(fips)
		
		*Draw coefficients and se
		replace fig_b1 = _b[x1] if fig_t == `i'
		replace fig_b2 = _b[x2] if fig_t == `i'
		replace se_b1 = _se[x1] if fig_t == `i'
		replace se_b2 = _se[x2] if fig_t == `i'
	}


	*Figure (event study) utilizing above
	keep fig_t fig_b* se_b*
	drop if missing(fig_t)

	*Upper and lower bounds (CIs)
	gen fig_upper1=fig_b1+`ci'*se_b1
	gen fig_lower1=fig_b1-`ci'*se_b1
	gen fig_upper2=fig_b2+`ci'*se_b2
	gen fig_lower2=fig_b2-`ci'*se_b2
	
	*Break horizons beyond some point
	local fig_T=4
	drop if fig_t>`fig_T'
	
	} /* End display suppression */
	
	sort fig_t

	*Figure
	twoway(scatter fig_upper1 fig_t, lpattern(dash) lcolor(dknavy*.2) c(l) m(i) xline(-0.5, lc(gs11)) yline(0, lc(gs11) )) ///
		(scatter fig_lower1 fig_t, lpattern(dash) lcolor(dknavy*.2) c(l) m(i) ) ///
		(scatter fig_upper2 fig_t, lpattern(dash) lcolor(cranberry*.2) c(l) m(i) ) ///
		(scatter fig_lower2 fig_t, lpattern(dash) lcolor(cranberry*.2) c(l) m(i) ) ///
		(scatter fig_b1 fig_t, msymbol(circle) c(l) mcolor(dknavy) lcolor(dknavy)) ///
		(scatter fig_b2 fig_t, msymbol(smdiamond) c(l) mcolor(cranberry)  lcolor(cranberry)), ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		xtitle("`xti'") ///
		ytitle("`yti'") ///
		xlab(-3/`fig_T') ///
		legend(order(5 6) label(5 "Bottom 80") label(6 "Top 20")) 
		
		graph export "$appfigdir/`outname'.pdf", replace
		
	*Figure in gph format with title (only if specified with rawti option)
	if "`rawti'" != "" {
	twoway(scatter fig_upper1 fig_t, lpattern(dash) lcolor(dknavy*.2) c(l) m(i) xline(-0.5, lc(gs11)) yline(0, lc(gs11) )) ///
		(scatter fig_lower1 fig_t, lpattern(dash) lcolor(dknavy*.2) c(l) m(i) ) ///
		(scatter fig_upper2 fig_t, lpattern(dash) lcolor(cranberry*.2) c(l) m(i) ) ///
		(scatter fig_lower2 fig_t, lpattern(dash) lcolor(cranberry*.2) c(l) m(i) ) ///
		(scatter fig_b1 fig_t, msymbol(circle) c(l) mcolor(dknavy) lcolor(dknavy)) ///
		(scatter fig_b2 fig_t, msymbol(smdiamond) c(l) mcolor(cranberry)  lcolor(cranberry)), ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		xtitle("`xti'") ///
		ytitle("`yti'") ///
		xlab(-3/`fig_T') ///
		title("`rawti'", color(black)) ///
		legend(order(5 6) label(5 "Bottom 80") label(6 "Top 20"))
		
		graph save "$appfigdir/raw/`outname'.gph", replace
	}
	
	restore

end
