
*****************************************************
********* INSTALL MAPTILE AND RELATED FILES *********
*****************************************************

/*
ssc install maptile
ssc install spmap
ssc install shp2dta
ssc install mergepoly
maptile_install using "http://files.michaelstepner.com/geo_county1990.zip"
maptile_install using "http://files.michaelstepner.com/geo_county2000.zip"
maptile_install using "http://files.michaelstepner.com/geo_county2010.zip"
maptile_install using "http://files.michaelstepner.com/geo_cz1990.zip"
maptile_install using "http://files.michaelstepner.com/geo_cz2000.zip"
maptile_install using "http://files.michaelstepner.com/geo_state.zip"
maptile_install using "http://files.michaelstepner.com/geo_zip3.zip"
maptile_install using "http://files.michaelstepner.com/geo_zip5.zip"
More instructions: https://michaelstepner.com/maptile/
*/

*****************************************************
************ GENERATE FIGURE 2B (HEATMAP) ***********
*****************************************************

use "$dtadir_taxsim/sh_top10_state_fig2b.dta", clear

maptile mean_s_stateig10, geo(state) 
graph export "$figdir/figure2b.pdf", replace
