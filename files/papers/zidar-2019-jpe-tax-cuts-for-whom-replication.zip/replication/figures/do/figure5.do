
*Local assignment:
local panelnum = "1"

do "$dodir_fig/tcfw_es_panel1.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = nonrich 
g x2 = rich

*Baseline fx
global baseline = "i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"

*******************************************************************************
* 3. Execute 
*******************************************************************************

*Figure 5 (Mechanisms)
TCFW_ES_panel1, outcome(lfp) xti(Years Since Tax Change) yti(Percentage points) ///
	fx($baseline) outname(figure5_lfp) rawti(A. Labor Force Participation Rate)	
TCFW_ES_panel1, outcome(ln_hours_atleast48wks) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figure5_ln_hours_atleast48wks) rawti(B. Hours) /* NOTE: AT LEAST 48 WEEKS */
TCFW_ES_panel1, outcome(ln_real_wage_comp_cons) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figure5_ln_real_wage_comp_cons) rawti(C. Composition-Constant Real Wages (ACCRA))
TCFW_ES_panel1, outcome(ln_c) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figure5_ln_c) rawti(D. Consumption)

*Local assignment
local fignum = "5"


*Draw gph data and create graph
		
grc1leg "$figdir/raw/figure5_lfp.gph" ///
		"$figdir/raw/figure5_ln_hours_atleast48wks.gph" ///
		"$figdir/raw/figure5_ln_real_wage_comp_cons.gph" ///
		"$figdir/raw/figure5_ln_c.gph", ///
		col(2) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(*.7)
		
graph display, ysize(4)
		
graph export "$figdir/figure`fignum'.pdf", replace
