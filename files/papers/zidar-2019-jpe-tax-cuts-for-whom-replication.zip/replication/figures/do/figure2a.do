*This file creates the tax change figure for TCFW
*Local assignment:
local fignum = "2a"
 
/*****************/
/*** Draw data ***/
/*****************/

*Note already restricted to 1950-2007
use "$dtadir_final/analysis_natl_tcfw.dta", clear
keep year exo q1-q5 q1_exo-q5_exo

*Grey bars
gen bartop = .6
gen barbot = -.6


/**************/
/*** Figure ***/
/**************/

*Changes
twoway(bar bartop year if exo == 1, base(-.7) bcolor(gs14) lcolor(none) lpattern(blank) fintensity(100)) ///
	(scatteri 0 1949 0 2010, c(l) m(i) lc(gs11)) ///
	(scatter q1 year, c(l) lc("95 105 15") mc("95 105 15") ms(smtriangle) lwidth(medthin) msize(vsmall)) ///
	(scatter q2 year, c(l) lc(midblue) mc(midblue) ms(smx) lwidth(medthin) msize(vsmall)) ///
	(scatter q3 year, c(l) lc(dkgreen) mc(dkgreen) ms(smdiamond) lwidth(medthin) msize(vsmall)) ///
	(scatter q4 year, c(l) lc(maroon) mc(maroon) ms(smcircle) lwidth(medthin) msize(vsmall)) ///
	(scatter q5 year, c(l) lc(dknavy) mc(dknavy) ms(none) lwidth(medthin) msize(vsmall)), ///
	ylab(-.6 (.2) .6, nogrid) ///
	xlab(1950 (10) 2010) ///
	graphregion(fcolor(white) lcolor(white)) ///
	plotregion(fcolor(white) lcolor(white)) ///
	yti(Percent of GDP) xti(Year) ///
	legend( cols(2) order(3 4 5 6 7 1) label(3 "Tax Change: Bottom 20%") ///
	label(4 "Tax Change: 21-40%") ///
	label(5 "Tax Change: 41-60%") ///
	label(6 "Tax Change: 61-80%") ///
	label(7 "Tax Change: Top 20%") ///
	label(1 "Exogenous Changes")) 
	
graph export "$figdir/figure`fignum'.pdf", replace

