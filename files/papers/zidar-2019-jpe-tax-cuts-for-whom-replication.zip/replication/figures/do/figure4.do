
*Local assignment:
local panelnum = "1"

do "$dodir_fig/tcfw_es_panel1.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = nonrich 
g x2 = rich

*Baseline fx
global baseline = "i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"

*******************************************************************************
* 3. Execute 
*******************************************************************************

*Figure 4
TCFW_ES_panel1, outcome(ln_gsp2014) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figure4_ln_gsp) rawti(A. Nominal GDP)
TCFW_ES_panel1, outcome(ln_ACCRA_state_cpi) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figure4_ln_ACCRA_state_cpi) rawti(B. ACCRA Price Index)
TCFW_ES_panel1, outcome(ln_real_gsp) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figure4_ln_real_gsp) rawti(C. Real GDP (ACCRA)) /* Uses ACCRA unweighted index */
TCFW_ES_panel1, outcome(ln_real_gsp_hpi) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figure4_ln_real_gsp_hpi) rawti(D. Real GDP (Moretti HPI)) /* Uses Moretti Index with HPI in construction */

*Combines multiple panels for figure 4 (baseline results with SEs); see panel1.do
*Local assignment
local fignum = "4"


*Draw gph data and create graph
		
grc1leg "$figdir/raw/figure4_ln_gsp.gph" ///
		"$figdir/raw/figure4_ln_ACCRA_state_cpi.gph" ///
		"$figdir/raw/figure4_ln_real_gsp.gph" ///
		"$figdir/raw/figure4_ln_real_gsp_hpi.gph", ///
		col(2) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(*.7)
		
graph display, ysize(4)
		
graph export "$figdir/figure`fignum'.pdf", replace
