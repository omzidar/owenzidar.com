
*Figure 1
set more off

use "$dtadir_taxsim/taxchanges_fig1", clear
	
	label var year "Year"
	
	twoway (line d_rev_agi incomegroup, lwidth(medthick)) ///
	if incomegroup!=1, ytitle("Average Change in Tax Liability as Share of AGI") ///
	xtitle("AGI Percentile") by(, graphregion(fcolor(white) lcolor(white) ///
	ifcolor(white) ilcolor(white)) plotregion(fcolor(white) lcolor(white) /// 
	ifcolor(white) ilcolor(white))) by(year, note("")) subtitle(, box)
	graph export "$figdir/figure1.pdf", replace
