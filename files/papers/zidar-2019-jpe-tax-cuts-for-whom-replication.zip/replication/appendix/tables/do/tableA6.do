*Note that this do file creates 2yrch table for cyclicality robustness checks (for outcomes other than main outcomes)
*Local assignments
local tabnum = "A6"

*Outcomes
global outcomes_main = "employed epop payroll2014 net_earnings_residence2014"

*******************************************************************************
* 1. Data setup
*******************************************************************************

set more off
use "$dtadir_final/analysis_st_tcfw.dta", clear

sort fips_state year
tsset fips year

*******************************************************************************
* 2. 2-Year Change
*******************************************************************************

*Main table (cyclicality robustness checks)
*All values are scaled by 100 for the tables (i.e. .009 -> .9 == .9%)
preserve

*Total number of specifications
local numspecs = 12 /* Number of specifications that we want to loop over; each pass prompts a different spec */
local expobs = 1300 /* Expected number of observations */

*Establishing columns
g col0 = "\underline{Employment Rate}" in 2
replace col0 = "\underline{Emp/Pop}" in 7
replace col0 = "\underline{Payroll}" in 12
replace col0 = "\underline{Net Earnings}" in 17

replace col0 = "Bottom 90" if mod(_n, 5) == 3 & _n <= 21
replace col0 = "Top 10" if mod(_n, 5) == 0 & _n <= 21

forv i = 1/`numspecs' {
	g col`i' = "" 
}

local add_rowpos = 0 /* initialize, will be used to add to row position as we iterate over outcomes */

foreach outcome in $outcomes_main { 

local pass = 1 /* Initialize pass */
forv i = 1/`numspecs' { /* Each pass corresponds to a different specification */

	*Initialize starting row position on each outcome
	local rowpos = 3 + `add_rowpos'
	
	*Variables for spec
	g y0 = `outcome'
	g y = (y0 - L2.y0)/L2.y0
	if "`outcome'" == "employed" | "`outcome'" == "lfp" | "`outcome'" == "epop" {
		replace y = y0 - L2.y0 /* Want different measure for this */
	}
	*g x1 = L2.nonrich
	*g x2 = L2.rich
	g x1 = nonrichlast2 /* Update 12/29 */
	g x2 = richlast2
	
	*Spec (varies based on pass)
	if `pass' == 1 {
		areg y x1 x2 i.FX_beta_diff [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 2 {
		areg y x1 x2 i.year [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 3 {
		areg y x1 x2 i.yearXcyclicality [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 4 {
		areg y x1 x2 i.FX_beta_diff_alt1 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 5 {
		areg y x1 x2 i.FX_beta_diff_alt2 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 6 {
		areg y x1 x2 i.year oil_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 7 {
		areg y x1 x2 i.year irate_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}	
	if `pass' == 8 {
		areg y x1 x2 i.year oil_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 9 {
		areg y x1 x2 i.year irate_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 10 {
		areg y x1 x2 i.FX_beta_diff oil_cross* irate_cross* [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 11 {
		areg y x1 x2 i.FX_beta_diff oil_cross* irate_cross* [aw = L2.pop], absorb(region) cluster(region)
	}
	if `pass' == 12 {
		areg y x1 x2 i.FX_beta_diff statedum* [aw = L2.pop], absorb(fips) cluster(fips)
	}
	
	*Assertion
	assert `e(N)' == `expobs'
	
	*Place coefficients in dataset (and draw using listtex after set)
	stars, var(x1)
	replace col`pass' = "$coef" in `rowpos'
	local ++rowpos
	replace col`pass' = subinstr("("+string(_se[x1]*100, "%-12.2f")+")", " ", "", .) in `rowpos'
	local ++rowpos

	stars, var(x2)
	replace col`pass' = "$coef" in `rowpos'
	local ++rowpos
	replace col`pass' = subinstr("("+string(_se[x2]*100, "%-12.2f")+")", " ", "", .) in `rowpos'
	local ++rowpos
	local ++rowpos /* increment row position twice at the end of the pass */
	
	*Drop variables for next iteration
	drop y0 y x1 x2
	
	*Next pass
	local ++pass
	
}
*Increment add_rowpos (allows us to move down the rows and fill in as we iterate over outcomes) */
local add_rowpos = `add_rowpos' + 5

}

*Now pull columns out and then restore
keep col0-col`numspecs'
keep if _n <= 21 & _n != 1
listtex using "$apptabdir/table`tabnum'.tex", replace rstyle(tabular)

restore
