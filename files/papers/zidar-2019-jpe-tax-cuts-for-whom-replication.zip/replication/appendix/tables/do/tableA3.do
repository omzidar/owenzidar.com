*Note that this do file creates a summary stat table for all variables listed in global below (in the order listed)
*Local assignments
local tabnum = "A3"

*Variable list(s); loop will draw variables from each of these; note that order matters in the following list due to loop (see below)
global general "year"

global state_LHS  "ln_emp ln_gsp2014 employed epop lfp parttime_emp ln_payroll2014 ln_hours_atleast48wks ln_wage2014 ln_wage_comp_cons2014"
global state_LHS2 "ln_emp ln_gsp2014 ln_real_gsp ln_real_gsp_hpi" /* Will be drawn as growth of outcomes */
global state_RHS  "nonrich rich"

global natl_LHS "GDP_NIPA Investment_NIPA Res_Investment_NIPA Consumption_NIPA Dur_Consumption_NIPA NonDur_Consumption_NIPA"
global natl_RHS "nonrich rich"

/*********************************/
/*** Structure State Panel (A) ***/
/*********************************/

use "$dtadir_final/analysis_st_tcfw.dta", clear

*Restrict to sample 
keep if year >= 1980 & year <= 2007
sort fips_state year
tsset fips_state year

*Scale appropriate variables (those whose simple difference we take)
qui ds employed epop lfp parttime_emp
foreach var in `r(varlist)' {
	replace `var' = `var'*100
}

*Create placeholder columns (currently includes [var, mean, sd, min, max, obs])
forv i = 0/5 {
	g col`i' = ""
}

*Fill variable list (order from globals matters)
replace col0 = "Year" in 1
replace col0 = "Log Employment" in 2
replace col0 = "Log State GDP" in 3
replace col0 = "Employment Rate" in 4
replace col0 = "Emp/Pop" in 5
replace col0 = "LFP Rate" in 6
replace col0 = "Part-Time Emp Rate" in 7
replace col0 = "Log Payroll" in 8
replace col0 = "Log Hours" in 9
replace col0 = "Log Wages" in 10
replace col0 = "Log Comp-Constant Wages" in 11
replace col0 = "Employment Growth" in 12
replace col0 = "GDP Growth" in 13
replace col0 = "Real GDP Growth (ACCRA)" in 14
replace col0 = "Real GDP Growth (Moretti)" in 15
replace col0 = "$ T_{s,t}^{B90}$" in 16
replace col0 = "$ T_{s,t}^{T10}$" in 17

*Initialize row position and iterate on variable loop
local rowpos = 1

*Call summary statistics and place values into table
foreach var in $general $state_LHS $state_LHS2 $state_RHS {

	*Var
	g y = `var'
	if `rowpos' >= 12 & `rowpos' <= 15 { /* For "Growth in outcomes", we want to change call */
		replace y = 100*(`var' - L1.`var') /* Scaled so we have in pp terms */
	}
	
	*Call summary
	qui sum y [aw = pop], d
	
	*Place each value into appropriate column:
	*Mean
	replace col1 = subinstr(string(`r(mean)', "%-12.3f"), " ", "", .) in `rowpos'
	*SD
	replace col2 = subinstr(string(`r(sd)', "%-12.3f"), " ", "", .) in `rowpos'
	*Min
	if "`var'" == "year" { /* Different justification for year */
		replace col3 = subinstr(string(`r(min)', "%-12.0f"), " ", "", .) in `rowpos'
	}
	else {
		replace col3 = subinstr(string(`r(min)', "%-12.2f"), " ", "", .) in `rowpos'
	}
	*Max
	if "`var'" == "year" {
		replace col4 = subinstr(string(`r(max)', "%-12.0f"), " ", "", .) in `rowpos'
	}
	else {
		replace col4 = subinstr(string(`r(max)', "%-12.2f"), " ", "", .) in `rowpos'
	}
	*Obs
	replace col5 = subinstr(string(`r(N)', "%-12.0f"), " ", "", .) in `rowpos'
	
	*For year, don't generate mean and sd (looks strange and doesn't help with interpretation)
	if "`var'" == "year" {
		replace col1 = "" in `rowpos'
		replace col2 = "" in `rowpos'
	}
	
	*Increment row position for next variable
	drop y
	local ++rowpos
}

*Keep appropriate columns and rows
keep col0-col5
keep if _n <= 17

*Output
listtex using "$apptabdir/table`tabnum'a.tex", replace rstyle(tabular)


/********************************/
/*** Structure Natl Panel (B) ***/
/********************************/

use "$dtadir_final/analysis_natl_tcfw.dta", clear
 
keep if year >= 1950 & year <= 2007
sort year

*Replace with logs so we can take log growth
replace GDP_NIPA = ln(GDP_NIPA)
replace Consumption_NIPA = ln(Consumption_NIPA)
replace Dur_Consumption_NIPA = ln(Dur_Consumption_NIPA)
replace Investment_NIPA = ln(Investment_NIPA)
replace Res_Investment_NIPA = ln(Res_Investment_NIPA)
replace NonDur_Consumption_NIPA = ln(NonDur_Consumption_NIPA)

*Create placeholder columns (currently includes [var, mean, sd, min, max, obs])
forv i = 0/5 {
	g col`i' = ""
}

*Fill variable list
replace col0 = "Year" in 1
replace col0 = "GDP Growth" in 2
replace col0 = "Investment Growth" in 3
replace col0 = "Residential Investment Growth" in 4
replace col0 = "Consumption Growth" in 5
replace col0 = "Durable Consumption Growth" in 6
replace col0 = "Non-Durable Consumption Growth" in 7
replace col0 = "$ T_{t}^{B90}$" in 8
replace col0 = "$ T_{t}^{T10}$" in 9

*Initialize row position and iterate on variable loop
local rowpos = 1

*Call summary statistics and place values into table
foreach var in $general $natl_LHS $natl_RHS {

	if "`var'" != "year" & "`var'" != "nonrich" & "`var'" != "rich" {
		g y = 100*(`var' - L1.`var') /* Growth, scaled to % */
	}
	else {
		g y = `var'
	}
	*Call summary
	qui sum y, d
	
	*Place each value into appropriate column:
	*Mean
	replace col1 = subinstr(string(`r(mean)', "%-12.3f"), " ", "", .) in `rowpos'
	*SD
	replace col2 = subinstr(string(`r(sd)', "%-12.3f"), " ", "", .) in `rowpos'
	*Min
	if "`var'" == "year" {
		replace col3 = subinstr(string(`r(min)', "%-12.0f"), " ", "", .) in `rowpos'
	}
	else {
		replace col3 = subinstr(string(`r(min)', "%-12.2f"), " ", "", .) in `rowpos'
	}
	*Max
	if "`var'" == "year" {
		replace col4 = subinstr(string(`r(max)', "%-12.0f"), " ", "", .) in `rowpos'
	}
	else {
		replace col4 = subinstr(string(`r(max)', "%-12.2f"), " ", "", .) in `rowpos'
	}
	*Obs
	replace col5 = subinstr(string(`r(N)', "%-12.0f"), " ", "", .) in `rowpos'
	
	*For year, don't generate mean and sd
	if "`var'" == "year" {
		replace col1 = "" in `rowpos'
		replace col2 = "" in `rowpos'
	}
	
	*Increment row position for next variable
	drop y
	local ++rowpos
}

*Keep appropriate columns and rows
keep col0-col5
keep if _n <= 9

*Output
listtex using "$apptabdir/table`tabnum'b.tex", replace rstyle(tabular)
