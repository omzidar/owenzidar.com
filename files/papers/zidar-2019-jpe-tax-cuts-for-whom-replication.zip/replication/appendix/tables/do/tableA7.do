*Note that this do file creates 2yrch table for policy robustness checks (for outcomes other than main outcomes)
*Local assignments
local tabnum = "A7"

*Outcomes
global outcomes_main = "employed epop payroll2014 net_earnings_residence2014"


*******************************************************************************
* 1. Data setup
*******************************************************************************

set more off
use "$dtadir_final/analysis_st_tcfw.dta", clear 

sort fips_state year
tsset fips_state year


*******************************************************************************
* 2. 2-Year Change
*******************************************************************************

*Main table
*All values are scaled by 100 for the tables (i.e. .009 -> .9 == .9%)
preserve

*Total number of specifications
local numspecs = 12 /* Number of specifications that we want to loop over; each pass prompts a different spec */
local expobs = 1300 /* Expected number of observations */

*Establishing columns (structure of the table)
g col0 = "\underline{Employment Rate}" in 2
replace col0 = "\underline{Emp/Pop}" in 7
replace col0 = "\underline{Payroll}" in 12
replace col0 = "\underline{Net Earnings}" in 17

replace col0 = "Bottom 90" if mod(_n, 5) == 3 & _n <= 21
replace col0 = "Top 10" if mod(_n, 5) == 0 & _n <= 21

*Generate other empty columns that will be filled; 1 column for each control
forv i = 1/`numspecs' { /* 1 pass for each control */
	g col`i' = ""
}


/* STRUCTURE OF THE LOOP:

We've already established empty columns above that will be filled in below (through the loop)

For each outcome:
	
	For each control:
	
		1) Generate appropriate variables for each (outcome, control) pair
			- These are the "g y0 = `outcome'", etc. lines
			
		2) Run appropriate regression specification
			- These are the "if `pass' == ..." lines
			
		3) Draw regression coefficients and SE and:
			a) Determine whether the coefficient is significant using "stars" program above
				- If it is, adds appropriate number of *
			b) Ensures that justification and general look out coefficient and se are appropriate
				- That is, SE has "(se)" and includes 2 digits
				- Similarly, coefficient has 2 digits unless otherwise specified
				- Note that coefficient and se are multiplied by 100 so that interpretation in final table is simpler; nothing else changes
			c) Place these coefficients and se into the current row-column position that we're on
				- col`pass' is current column
				- `rowpos' is current row
				- Each of these is iterated appropriately as we move from control to control and from outcome to outcome
				
	
	After looping over all controls for THAT OUTCOME, we move to the next outcome and do it again except 5 rows further down 
		- 5 rows is because we leave room for: coefficient and se for both B90 & T10 for previous outcome, as well as the name of the outcome, which is included in the table
		
Once we're done looping over all outcomes, we keep appropriate rows and columns and output this into tex

*/


local add_rowpos = 0 /* Initialize; will be used to add to row position as we iterate over outcomes */

foreach outcome in $outcomes_main {

local pass = 1 /* Initialize pass */
forv i = 1/`numspecs' { /* 13 (currently) passes, each utilizes a different control */

	*Initialize starting row position on each outcome
	local rowpos = 3 + `add_rowpos'
	
	*Variables for spec
	g y0 = `outcome'
	g y = (y0 - L2.y0)/L2.y0
	if "`outcome'" == "employed" | "`outcome'" == "lfp" | "`outcome'" == "epop" {
		replace y = y0 - L2.y0 /* Want different measure for this */
	}
	*g x1 = L2.nonrich
	*g x2 = L2.rich
	g x1 = nonrichlast2
	g x2 = richlast2
	
	*Spec (varies based on pass)
	if `pass' == 1 { /* Gov Transfer Per Capita control */
		areg y x1 x2 i.FX_beta_diff ln_govtrans_per_capita2014 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 2 { /* Fed IG Spending Per Capita Control */
		areg y x1 x2 i.FX_beta_diff ln_totalfedigrevenue_pc2014 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 3 { /* State minwage control */
		areg y x1 x2 i.FX_beta_diff minwage [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 4 { /* Social security control */
		areg y x1 x2 i.FX_beta_diff ssec_cont [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 5 { /* SSI control */
		areg y x1 x2 i.FX_beta_diff ssi_cont [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 6 { /* SNAP control 2 */
		areg y x1 x2 i.FX_beta_diff snap_cont2 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 7 { /* Medicaid Control 2 */
		areg y x1 x2 i.FX_beta_diff medicaid_cont2 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 8 { /* AFDC + TANF Control 1 */
		areg y x1 x2 i.FX_beta_diff afdc_tanf_cont1 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 9 { /* AFDC + TANF Change Controls */
		areg y x1 x2 i.FX_beta_diff afdc_tanf_chg1 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 10 { /* SSI + SNAP Change Controls */
		areg y x1 x2 i.FX_beta_diff snap_chg1 ssi_chg1 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 11 { /* Medicaid Change Controls */
		areg y x1 x2 i.FX_beta_diff medaid_chg1 [aw = L2.pop], absorb(fips) cluster(fips)
	}
	if `pass' == 12 { /* Multiple controls */
		areg y x1 x2 i.FX_beta_diff i.FX_beta_diff medicaid_cont2 ssec_cont ssi_cont afdc_tanf_cont1 minwage snap_cont2 afdc_tanf_chg1 snap_chg1 ssi_chg1 medaid_chg1 ///
									[aw = L2.pop], absorb(fips) cluster(fips)
	}
	
	*Assertion
	assert `e(N)' == `expobs'
	
	*Place coefficients into dataset (and draw using listtex); note that most of the "subinstr" command is used to remove spaces that are occasionally created when we force alignment (justification to 2 digits)
	stars, var(x1)
	replace col`pass' = "$coef" in `rowpos'
	local ++rowpos
	replace col`pass' = subinstr("("+string(_se[x1]*100, "%-12.2f")+")", " ", "", .) in `rowpos'
	local ++rowpos

	stars, var(x2)
	replace col`pass' = "$coef" in `rowpos'
	local ++rowpos
	replace col`pass' = subinstr("("+string(_se[x2]*100, "%-12.2f")+")", " ", "", .) in `rowpos'
	local ++rowpos
	local ++rowpos /* increment row position twice at the end of the pass */
	
	*Drop variables for next iteration
	drop y0 y x1 x2
	
	*Next pass
	local ++pass
	
}
*Increment add_rowpos (allows us to move down the rows and fill in as we iterate over outcomes) */
local add_rowpos = `add_rowpos' + 5
}

*Now pull columns out and then restore
keep col0-col`numspecs'
keep if _n <= 21 & _n != 1
listtex using "$apptabdir/table`tabnum'.tex", replace rstyle(tabular)

restore
