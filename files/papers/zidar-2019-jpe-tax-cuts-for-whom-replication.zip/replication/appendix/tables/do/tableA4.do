*Note that this do file creates 2yrch table for demographic robustness checks (currently assigned table A4)
*Local assignments
local tabnum = "A4"

*Outcomes
global outcomes_main = "lfp employed hours_48wk wage2014 real_wage" /* Non-logs for main table (2-year change) */

*******************************************************************************
* 1. Data setup
*******************************************************************************

set more off
use "$dtadir_final/analysis_st_tcfw.dta", clear

sort fips_state year
tsset fips_state year

*******************************************************************************
* 2. 2-Year Change
*******************************************************************************

*Main table
preserve

*Establishing columns (8 different groups)
g col0 = "Bottom 90" if inlist(_n, 3, 8, 14, 19, 25, 30, 36, 41)
replace col0 = "Top 10" if col0[_n-2] == "Bottom 90"
replace col0 = "\underline{Skilled} " in 2
replace col0 = "\underline{Unskilled} " in 7
replace col0 = "\underline{Aged 25-45} " in 13
replace col0 = "\underline{Aged 45-60} " in 18
replace col0 = "\underline{Men} " in 24
replace col0 = "\underline{Women} " in 29
replace col0 = "\underline{White} " in 35
replace col0 = "\underline{Non-White} " in 40

*Split panels
replace col0 = " \multicolumn{6}{c}{ \textbf{ Panel A: Skill }} \\ \hline" in 1
replace col0 = " \multicolumn{6}{c}{ \textbf{ Panel B: Age }} \\ \hline" in 12
replace col0 = " \multicolumn{6}{c}{ \textbf{ Panel C: Sex }} \\ \hline" in 23
replace col0 = " \multicolumn{6}{c}{ \textbf{ Panel D: Race }} \\ \hline" in 34

*Initialize and begin loop
local pass = 1

*Each pass goes through a different group (see above)
forv i = 1/8 { /* 8 passes */

local column = 1 /* Will iterate and place these appropriately */
foreach outcome in $outcomes_main { /* Will loop over each outcome in the global */
	disp "2-year change for: `outcome'"
	
	*Outcome for spec (varies based on pass) and establish row starting position (local strowpos, which is then passed into `rowpos' which dictates the current row position)
	if `pass' == 1 { /* Skilled */
		g y0 = `outcome'_skill1
		local strowpos = 3
	}
	if `pass' == 2 { /* Unskilled */
		g y0 = `outcome'_skill0
		local strowpos = 8
	}
	if `pass' == 3 { /* Young */
		g y0 = `outcome'_age1
		local strowpos = 14
	}
	if `pass' == 4 { /* Old */
		g y0 = `outcome'_age2
		local strowpos = 19
	}
	if `pass' == 5 { /* Men */
		g y0 = `outcome'_sex1
		local strowpos = 25
	}
	if `pass' == 6 { /* Women */
		g y0 = `outcome'_sex0
		local strowpos = 30
	}
	if `pass' == 7 { /* White */
		g y0 = `outcome'_white1
		local strowpos = 36
	}
	if `pass' == 8 { /* Non-White */
		g y0 = `outcome'_white0
		local strowpos = 41
	}
	
	*Establish actual variables (using outcome based on pass)
	g y = (y0 - L2.y0)/L2.y0
	if "`outcome'" == "employed" | "`outcome'" == "lfp" {
		replace y = y0 - L2.y0 /* Want different measure for these outcomes (emp rate, lfp) */
	}
	g x1 = nonrichlast2 /* Update 12/29 */
	g x2 = richlast2
	
	*Spec
	areg y x1 x2 i.FX_beta_diff [aw = L2.pop], absorb(fips) cluster(fips)
	
	*Draw from strowpos
	local rowpos = `strowpos'
	
	*Place coefficients in dataset
	if `pass' == 1 { /* Only need to establish these columns once, so do it on first pass */
		g col`column' = ""
	}
	stars, var(x1)
	replace col`column' = "$coef" in `rowpos'
	local ++rowpos
	replace col`column' = subinstr("("+string(_se[x1]*100, "%-12.2f")+")", " ", "", .) in `rowpos'
	local ++rowpos

	stars, var(x2)
	replace col`column' = "$coef" in `rowpos'
	local ++rowpos
	replace col`column' = subinstr("("+string(_se[x2]*100, "%-12.2f")+")", " ", "", .) in `rowpos'
	local ++rowpos
	local ++column /* Iterate column */
	
	*Drop variables for next iteration
	drop y0 y x1 x2
	
}
*Next pass
local ++pass
}

*Groups; note that these numbers aren't ambiguous, there are differences of 11 between each outcome group which allows for row placement (see final table in processed tex file for clarity)
replace col1 = " \underline{LFP Rate} " if inlist(_n, 2, 13, 24, 35)
replace col2 = " \underline{Emp Rate} " if inlist(_n, 2, 13, 24, 35)
replace col3 = " \underline{Hours} " if inlist(_n, 2, 13, 24, 35)
replace col4 = " \underline{Wage} " if inlist(_n, 2, 13, 24, 35)
replace col5 = " \underline{Real Wage} " if inlist(_n, 2, 13, 24, 35)

***Now pull columns out and then restore
keep col0-col5
keep if _n <= 45 /* Keep row 45 for blank rows appended in listtex */
*Draw table name from local tabnum
local tabname = "table`tabnum'"

*Panel A (initialize tex file)
listtex if _n == 45 using "$apptabdir/`tabname'.tex" , replace rstyle(tabular)
listtex col0 if _n == 1, appendto("$apptabdir/`tabname'.tex")
listtex if inrange(_n, 2, 11), appendto("$apptabdir/`tabname'.tex") rstyle(tabular)
*Panel B
listtex if _n == 45, appendto("$apptabdir/`tabname'.tex") rstyle(tabular)
listtex col0 if _n == 12, appendto("$apptabdir/`tabname'.tex")
listtex if inrange(_n, 13, 22), appendto("$apptabdir/`tabname'.tex") rstyle(tabular)
*Panel C
listtex if _n == 45, appendto("$apptabdir/`tabname'.tex") rstyle(tabular)
listtex col0 if _n == 23, appendto("$apptabdir/`tabname'.tex")
listtex if inrange(_n, 24, 33), appendto("$apptabdir/`tabname'.tex") rstyle(tabular)
*Panel D
listtex if _n == 45, appendto("$apptabdir/`tabname'.tex") rstyle(tabular)
listtex col0 if _n == 34, appendto("$apptabdir/`tabname'.tex")
listtex if inrange(_n, 35, 44), appendto("$apptabdir/`tabname'.tex") rstyle(tabular)


restore
