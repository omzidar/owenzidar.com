
*Local assignment:
local panelnum = "1_top10other"

do "$dodir_fig/tcfw_es_panel1_top10other.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = nonrich 
g x2 = top10_plus_othertaxes

*Baseline fx
global baseline = "i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"

*******************************************************************************
* 3. Execute 
*******************************************************************************

*A25
TCFW_ES_panel1, outcome(ln_emp) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA25_ln_emp)
TCFW_ES_panel1, outcome(epop) xti(Years Since Tax Change) yti(Percentage points) ///
	fx($baseline) outname(figureA25_epop)
