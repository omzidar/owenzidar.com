
*Does 80-20 split for employment
*Local assignment:
local panelnum = "1_altsplit"

do "$dodir_fig/tcfw_es_panel1_altsplit.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = bottom80 
g x2 = top20

*Baseline fx
global baseline = "i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"

*******************************************************************************
* 3. Execute 
*******************************************************************************

*A26
TCFW_ES_panel1, outcome(ln_emp) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA26_ln_emp)
TCFW_ES_panel1, outcome(epop) xti(Years Since Tax Change) yti(Percentage points) ///
	fx($baseline) outname(figureA26_epop)
