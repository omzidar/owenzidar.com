
*Local assignment:
local panelnum = "1"

do "$dodir_fig/tcfw_es_panel1_appendix.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = nonrich 
g x2 = rich

*Baseline fx
global baseline = "i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"

*******************************************************************************
* 3. Execute 
*******************************************************************************

*Real Wages (A14)
TCFW_ES_panel1, outcome(ln_real_wage_hpi) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA14_ln_real_wage_hpi)
TCFW_ES_panel1, outcome(ln_real_wage_priceBLS) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA14_ln_real_wage_priceBLS)
