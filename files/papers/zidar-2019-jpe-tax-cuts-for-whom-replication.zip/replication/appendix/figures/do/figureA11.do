
*Local assignment:
local panelnum = "1_appendix"

do "$dodir_fig/tcfw_es_panel1_appendix.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = nonrich 
g x2 = rich

*Baseline fx
global baseline = "L(1/2).x1 L(1/2).x2 i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"


*******************************************************************************
* 3. Execute 
*******************************************************************************
	
*Figure A11
TCFW_ES_panel1, outcome(ln_gsp2014) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA11_ln_gsp) rawti(A. Nominal GDP)
TCFW_ES_panel1, outcome(ln_ACCRA_state_cpi) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA11_ln_ACCRA_state_cpi) rawti(B. ACCRA Index)
TCFW_ES_panel1, outcome(ln_real_gsp) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA11_ln_real_gsp) rawti(C. Real GDP (ACCRA)) /* Uses ACCRA unweighted index */
TCFW_ES_panel1, outcome(ln_real_gsp_hpi) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA11_ln_real_gsp_hpi) rawti(D. Real GDP (Moretti HPI)) /* Uses Moretti Index with HPI in construction */
TCFW_ES_panel1, outcome(ln_net_earnings_residence2014) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA11_ln_net_earnings) rawti(E. Net Earnings)
TCFW_ES_panel1, outcome(ln_c) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA11_ln_c) rawti(F. Consumption)
TCFW_ES_panel1, outcome(ln_real_net_earnings) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA11_ln_real_net_earnings) rawti(G. Real Net Earnings (ACCRA))
TCFW_ES_panel1, outcome(ln_real_net_earnings_hpi) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA11_ln_real_net_earnings_hpi) rawti(H. Real Net Earnings (Moretti HPI))

*Combines multiple panels for figure A11; see panel1_appendix.do for details of initial strucuture/specifications
*Local assignment
local fignum = "A11"

*Draw gph data and create graph

grc1leg "$appfigdir/raw/figureA11_ln_gsp.gph" ///
		"$appfigdir/raw/figureA11_ln_ACCRA_state_cpi.gph" ///
		"$appfigdir/raw/figureA11_ln_real_gsp.gph" ///
		"$appfigdir/raw/figureA11_ln_real_gsp_hpi.gph" ///
		"$appfigdir/raw/figureA11_ln_net_earnings.gph" ///
		"$appfigdir/raw/figureA11_ln_c.gph" ///
		"$appfigdir/raw/figureA11_ln_real_net_earnings.gph" ///
		"$appfigdir/raw/figureA11_ln_real_net_earnings_hpi.gph", ///
		col(4) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(*.7)
		
graph display, ysize(2.7)
		
graph export "$appfigdir/figure`fignum'.pdf", replace
