
*Local assignment:
local panelnum = "1"

do "$dodir_fig/tcfw_es_panel1_appendix.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = nonrich 
g x2 = rich

*Baseline fx
global baseline = "i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"

*******************************************************************************
* 3. Execute 
*******************************************************************************

*Employment Rate (Figure A16)
TCFW_ES_panel1, outcome(employed_skill1) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA16_employed_skill1) rawti(A. Skilled)
TCFW_ES_panel1, outcome(employed_skill0) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA16_employed_skill0) rawti(B. Unskilled) 
TCFW_ES_panel1, outcome(employed_age1) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA16_employed_age1) rawti(C. Aged 25-45)
TCFW_ES_panel1, outcome(employed_age2) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA16_employed_age2) rawti(D. Aged 45-60)
TCFW_ES_panel1, outcome(employed_sex1) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA16_employed_sex1) rawti(E. Men)
TCFW_ES_panel1, outcome(employed_sex0) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA16_employed_sex0) rawti(F. Women)
TCFW_ES_panel1, outcome(employed_white1) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA16_employed_white1) rawti(G. White)
TCFW_ES_panel1, outcome(employed_white0) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA16_employed_white0) rawti(H. Non-White)

*Outcome = Emp rate
*Local assignment
local fignum = "A16"


*Draw gph data and create graph
		
grc1leg "$appfigdir/raw/figureA16_employed_skill1.gph" ///
		"$appfigdir/raw/figureA16_employed_skill0.gph" ///
		"$appfigdir/raw/figureA16_employed_age1.gph" ///
		"$appfigdir/raw/figureA16_employed_age2.gph" ///
		"$appfigdir/raw/figureA16_employed_sex1.gph" ///
		"$appfigdir/raw/figureA16_employed_sex0.gph" ///
		"$appfigdir/raw/figureA16_employed_white1.gph" ///
		"$appfigdir/raw/figureA16_employed_white0.gph", ///
		col(4) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(*.7)
		
graph display, ysize(2.7)
		
graph export "$appfigdir/figure`fignum'.pdf", replace
