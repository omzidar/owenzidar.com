
*Local assignment:
local panelnum = "1"

do "$dodir_fig/tcfw_es_panel1_appendix.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = nonrich 
g x2 = rich

*Baseline fx
global baseline = "i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"

*******************************************************************************
* 3. Execute 
*******************************************************************************

*Figure A26 (Payrolls and Net Earnings)
TCFW_ES_panel1, outcome(ln_payroll2014) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA22_ln_payroll_qcew) rawti(A. Payroll)
TCFW_ES_panel1, outcome(ln_real_payroll) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA22_ln_real_payroll_qcew) rawti(B. Real Payroll (ACCRA))
TCFW_ES_panel1, outcome(ln_real_payroll_hpi) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA22_ln_real_payroll_hpi_qcew) rawti(C. Real Payroll (Moretti))
TCFW_ES_panel1, outcome(ln_net_earnings_residence2014) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA22_ln_net_earnings) rawti(D. Net Earnings)
TCFW_ES_panel1, outcome(ln_real_net_earnings) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA22_ln_real_net_earnings) rawti(E. Real Net Earnings (ACCRA))
TCFW_ES_panel1, outcome(ln_real_net_earnings_hpi) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA22_ln_real_net_earnings_hpi) rawti(F. Real Net Earnings (Moretti HPI))

*Local assignment
local fignum = "A22"

*Draw gph data and create graph
		
grc1leg "$appfigdir/raw/figureA22_ln_payroll_qcew.gph" ///
		"$appfigdir/raw/figureA22_ln_real_payroll_qcew.gph" ///
		"$appfigdir/raw/figureA22_ln_real_payroll_hpi_qcew.gph" ///
		"$appfigdir/raw/figureA22_ln_net_earnings.gph" ///
		"$appfigdir/raw/figureA22_ln_real_net_earnings.gph" ///
		"$appfigdir/raw/figureA22_ln_real_net_earnings_hpi.gph", ///
		col(3) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(*.7)
		
graph display, ysize(2.9)

graph export "$appfigdir/figure`fignum'.pdf", replace
