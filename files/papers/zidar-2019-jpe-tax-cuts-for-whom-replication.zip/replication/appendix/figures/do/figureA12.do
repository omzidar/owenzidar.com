
*Local assignment:
local panelnum = "1_appendix"

do "$dodir_fig/tcfw_es_panel1_appendix.do"

*******************************************************************************
* 1. Bring in Data
*******************************************************************************

use "$dtadir_final/analysis_st_tcfw.dta", clear
set more off

*******************************************************************************
* 2. Define RHS
*******************************************************************************

sort fips_state year
tsset fips_state year

*RHS variables
g x1 = nonrich 
g x2 = rich

*Baseline fx
global baseline = "L(1/2).x1 L(1/2).x2 i.FX_beta_diff afdc_tanf_chg1 ssi_chg1 snap_chg1 medaid_chg1"


*******************************************************************************
* 3. Execute 
*******************************************************************************
	
*Figure A12
TCFW_ES_panel1, outcome(ln_payroll2014) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA12_ln_payroll_qcew) rawti(A. Payroll)
TCFW_ES_panel1, outcome(lfp) xti(Years Since Tax Change) yti(Percentage points) ///
	fx($baseline) outname(figureA12_lfp) rawti(B. Labor Force Participation Rate)
TCFW_ES_panel1, outcome(ln_hours_atleast48wks) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA12_ln_hours_atleast48wks) rawti(C. Hours) /* NOTE: AT LEAST 48 WEEKS */
TCFW_ES_panel1, outcome(ln_real_wage) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA12_ln_real_wage) rawti(D. Real Wage (ACCRA))
TCFW_ES_panel1, outcome(ln_real_payroll) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA12_ln_real_payroll_qcew) rawti(E. Real Payroll (ACCRA))
TCFW_ES_panel1, outcome(employed) xti(Years Since Tax Change) yti(Percentage points) ///
	fx($baseline) outname(figureA12_employed) rawti(F. Employment Rate)
TCFW_ES_panel1, outcome(ln_wage2014) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA12_ln_wage) rawti(G. Wage)
TCFW_ES_panel1, outcome(ln_real_wage_comp_cons) xti(Years Since Tax Change) yti(Percent) ///
	fx($baseline) outname(figureA12_ln_real_wage_comp_cons) rawti(H. Real Comp-Constant Wage (ACCRA))

*Local assignment
local fignum = "A12"

*Draw gph data and create graph

grc1leg "$appfigdir/raw/figureA12_ln_payroll_qcew.gph" ///
		"$appfigdir/raw/figureA12_lfp.gph" ///
		"$appfigdir/raw/figureA12_ln_hours_atleast48wks.gph" ///
		"$appfigdir/raw/figureA12_ln_real_wage.gph" ///
		"$appfigdir/raw/figureA12_ln_real_payroll_qcew.gph" ///
		"$appfigdir/raw/figureA12_employed.gph" ///
		"$appfigdir/raw/figureA12_ln_wage.gph" ///
		"$appfigdir/raw/figureA12_ln_real_wage_comp_cons.gph", ///
		col(4) ///
		plotregion(fcolor(white) lcolor(white)) ///
		graphregion(fcolor(white) lcolor(white)) ///
		iscale(*.7)
		
graph display, ysize(2.7)
		
graph export "$appfigdir/figure`fignum'.pdf", replace
