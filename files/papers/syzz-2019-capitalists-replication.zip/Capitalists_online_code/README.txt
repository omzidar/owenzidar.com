/*****************************************************************************/
/**********   		Overview of replication files	  	  ************/
/*****************************************************************************/

The replication files are organized into two major parts: analysis and exhibits 
code. The analysis code constructs the data and the exhibits code uses that data 
to produce the figures and tables in the paper. 

/*****************************************************************************/
/**********   			I. ANALYSIS CODE		  ************/
/*****************************************************************************/

There are two main parts of the build files: 

1. analysis/stata has the code that we use to process our linked firm-owner-worker
data. The main file is main.do.
It describes all the inputs, outputs, and code used in the Stata-portion of 
the build. 

/*****************************************************************************/
/**********   		     II. EXHIBITS CODE			  ************/
/*****************************************************************************/

Then with our main data built, we use the following exhibits
files to produce the figures and tables in the text.

1. The files in exhibits/1_run_syzz process output from analysis/stata to create 
disclosable input files, which we use to make our main figures and tables.

2. exhibits/2_process_output uses the output from exhibits/code/1_run_syzz
 to make the final tables and figures. See the README in exhibits for more 
information.

/*****************************************************************************/
/**********   	III. FORMULAS FOR PSZ TB2f VARIABLES	 ************/
/*****************************************************************************/

See Formulas_for_PSZ_TB2f_variables.pdf for our formulas that closely replicate the top 1% aggregate income categories in Piketty-Saez-Zucman's (2018) Online Appendix Table TB2f.
