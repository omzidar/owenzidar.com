The build folder has code that we use to make firm-level data. 
