args dofile

do headers.do

log using ${logs}/`dofile'.log, text replace
do $do/`dofile'.do

log close
