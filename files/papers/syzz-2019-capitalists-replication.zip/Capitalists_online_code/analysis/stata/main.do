capture program drop dispatch
program define dispatch

	** helper to run programs in parallel
	** input: list of dofiles, number p to run simultaneously
	** does: runs <=p programs simultaneously using logger
	syntax anything(name=dofiles id=dofiles), p(integer)
	
	local n_dofiles : word count `dofiles'
	local last_dofile : word `n_dofiles' of `dofiles'
	
	** indexes number of subshells
	local i 1
	
	foreach dofile of local dofiles {
		** add to command
		local cmd `cmd' (stata-mp -b do logger.do `dofile' & disown -h);
		
		if mod(`i', `p') == 0 | ("`dofile'" == "`last_dofile'") {
			** if i is multiple of p OR on last input, run dofile
			!`cmd'
			
			** then reset command
			local cmd
		}
		
		local ++i
	}

end

** run programs
** number of programs (at most) to run simultaneously
local p 5

#delimit ;

** define lists of programs;
** first build;
local build1 	build_cdw_20181108
				build_cdw_20171025_ez
				scorp_geo_inside
				prep_thresholds_inside
				clean_panel
				makesoi_inside
				makesoi_20170210
				vary_ls_archived_usdina
				make_usdinaclps19622014
				;

** second build (depend on first build);
local build2 	decomp_nocontractors_inside
				decomp_wcontractors_inside
				decomp_bystate_inside
				decomp_byownerage_inside
				adhoc_clps_for_zwick
				salesbins_inside
				ownerdeaths_build_inside
				orderlyexits_build_inside
				summstats_inside_prep_s
				summstats_inside_prep_p
				conductor_build_usdinasyzz
				;

** analysis;
local analysis_parallel xpez_20170210
						ownerdeaths_analysis_inside
						orderlyexits_analysis_inside
						gen_simple_person_stats_fi_20181016_plus_byPT
						gen_simple_person_stats_fi_20181016_plus_mean_age
						gen_simple_person_stats_fi_20181016_plus_prim_age
						gen_simple_person_stats_tb2f_20181019
						gen_decomp_inputs_P_by_numw2_and1099_v181108
						gen_decomp_inputs_S_by_numw2_and1099_v180710
						size_bins_scorp_v4
						size_bins_pship_v4
						size_bins_soi_v3
						size_bins_soi_v4
						size_bins_scorp_v5
						size_bins_pship_v5
						state_shares_soi
						state_shares_scorp
						summstats_inside_spfirms
						summstats_inside_sfirms
						summstats_inside_pfirms
						;

** define list of lists;
local lol /*build1*/
		  /*build2*/
		  analysis_parallel
		  ;

#delimit cr

** run programs in parallel!
foreach l of local lol {
	dispatch ``l'', p(`p')
}


** run programs in sequence
#delimit ;
local analysis_sequential graph_hockeys_inside
						  graph_startups_5yr_inside
						  graph_exitrate_inside
						  ;

#delimit cr

foreach d of local analysis_sequential {
	dispatch `d', p(1)
}
