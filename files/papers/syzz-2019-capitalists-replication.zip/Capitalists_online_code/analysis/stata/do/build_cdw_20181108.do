capture program drop usd2014
program usd2014
    syntax, var(varname) yr(varname)
    replace `var'= `var'*1.503062988  if `yr'==1993 & `var'!=.
    replace `var'= `var'*1.47180133   if `yr'==1994 & `var'!=.
    replace `var'= `var'*1.441698831  if `yr'==1995 & `var'!=.
    replace `var'= `var'*1.415894851  if `yr'==1996 & `var'!=.
    replace `var'= `var'*1.391942424  if `yr'==1997 & `var'!=.
    replace `var'= `var'*1.377006398  if `yr'==1998 & `var'!=.
    replace `var'= `var'*1.357571973  if `yr'==1999 & `var'!=.
    replace `var'= `var'*1.327317133  if `yr'==2000 & `var'!=.
    replace `var'= `var'*1.297761328  if `yr'==2001 & `var'!=.
    replace `var'= `var'*1.278151458  if `yr'==2002 & `var'!=.
    replace `var'= `var'*1.253173459  if `yr'==2003 & `var'!=.
    replace `var'= `var'*1.219663817  if `yr'==2004 & `var'!=.
    replace `var'= `var'*1.181649182  if `yr'==2005 & `var'!=.
    replace `var'= `var'*1.146416065  if `yr'==2006 & `var'!=.
    replace `var'= `var'*1.116642696  if `yr'==2007 & `var'!=.
    replace `var'= `var'*1.095506864  if `yr'==2008 & `var'!=.
    replace `var'= `var'*1.08694      if `yr'==2009 & `var'!=.
    replace `var'= `var'*1.073775512  if `yr'==2010 & `var'!=.
    replace `var'= `var'*1.052064076  if `yr'==2011 & `var'!=.
    replace `var'= `var'*1.033016537  if `yr'==2012 & `var'!=.
    replace `var'= `var'*1.016449245  if `yr'==2013 & `var'!=.
    replace `var'= `var'*1            if `yr'==2014 & `var'!=.
end



capture program drop sizebin
program sizebin
  syntax, binningvar(varname) newvar(name)
  gen `newvar'=-9
  replace `newvar'=1 if inrange(`binningvar',0,5000000)
  replace `newvar'=2 if inrange(`binningvar',5000000,20000000)
  replace `newvar'=3 if inrange(`binningvar',20000000,50000000)
  replace `newvar'=4 if inrange(`binningvar',50000000,100000000)
  replace `newvar'=5 if inrange(`binningvar',100000000,500000000)
  replace `newvar'=6 if inrange(`binningvar',500000000,9999999999999999999)
end



capture program drop compress_rawfiles
*SAVES 50G OF SPACE IN 1.25HRS
program compress_rawfiles
  forv year=$yrminoverall/$yrmaxoverall {
    global year = `year'
    use ${raw}/f1120s_$year, clear
    compress
    save ${raw}/f1120s_$year, replace
    use ${raw}/f1120_$year, clear
    compress
    save ${raw}/f1120_$year, replace
    use ${raw}/f1120s_k1_$year, clear
    compress
    save ${raw}/f1120s_k1_$year, replace
  }
  use ${raw}/rpi_f1040se_pull, clear
  compress
  save ${raw}/rpi_f1040se_pull, replace
  use ${raw}/rpi_worker_chars, clear
  compress
  save ${raw}/rpi_worker_chars, replace
  use ${raw}/rpi_pullallfirmyears, clear
  compress
  save ${raw}/rpi_pullallfirmyears, replace
  use ${raw}/rpi_agirandsamppull, clear
  compress
  save ${raw}/rpi_agirandsamppull, replace
end



capture program drop build_pikettysaez_thresholds
program define build_pikettysaez_thresholds
  insheet using ${raw}/pikettysaez_nomthresholdsandparetoparams.csv, comma clear
  keep if nocg_p9000!=.
  foreach prefix in nocg wcg {
    global prefix "`prefix'"
    forv p=90/95 {
      gen zz1_p`p'00 = ${prefix}_p9000 * (.1/(1-.`p'))^(1/${prefix}_p9000_a)
    }
    gen zz1ff = (${prefix}_p9500-${prefix}_p9000)/(zz1_p9500-${prefix}_p9000)
    forv p=90/95 {
      replace zz1_p`p'00 = zz1ff*(zz1_p`p'00-${prefix}_p9000) + ${prefix}_p9000
    }
    forv p=90/95 {
      gen zz2_p`p'00 = ${prefix}_p9500 * (.05/(1-.`p'))^(1/${prefix}_p9500_a)
    }
    gen zz2ff = (${prefix}_p9500-${prefix}_p9000)/(${prefix}_p9500-zz2_p9000)
    forv p=90/95 {
      replace zz2_p`p'00 = ${prefix}_p9500 - zz2ff*(${prefix}_p9500-zz2_p`p'00)
    }
    forv p=91/94 {
      gen ${prefix}_p`p'00 = (zz1_p`p'00+zz2_p`p'00)/2
    }
    drop zz*
    forv p=95/99 {
      gen zz1_p`p'00 = ${prefix}_p9500 * (.05/(1-.`p'))^(1/${prefix}_p9500_a)
    }
    gen zz1ff = (${prefix}_p9900-${prefix}_p9500)/(zz1_p9900-${prefix}_p9500)
    forv p=95/99 {
      replace zz1_p`p'00 = zz1ff*(zz1_p`p'00-${prefix}_p9500) + ${prefix}_p9500
    }
    forv p=95/99 {
      gen zz2_p`p'00 = ${prefix}_p9900 * (.01/(1-.`p'))^(1/${prefix}_p9900_a)
    }
    gen zz2ff = (${prefix}_p9900-${prefix}_p9500)/(${prefix}_p9900-zz2_p9500)
    forv p=95/99 {
      replace zz2_p`p'00 = ${prefix}_p9900 - zz2ff*(${prefix}_p9900-zz2_p`p'00)
    }
    forv p=96/98 {
      gen ${prefix}_p`p'00 = (zz1_p`p'00+zz2_p`p'00)/2
    }
    drop zz*
  }
  drop *_a
  order nocg*, alpha
  order wcg*, alpha
  order tax_yr nocg* wcg*
  foreach var of varlist * {
    replace `var' = round(`var')
  }
  format * %10.0g
  save ${dta}/pikettysaez_nomthresholds_imputed_topdecile, replace
  reshape long nocg_p wcg_p, i(tax_yr) j(fractile)
  rename nocg_p nocg_thresholds_
  rename wcg_p wcg_thresholds_
  reshape wide nocg wcg, i(fractile) j(tax_yr)
  compress
  save ${dta}/pikettysaez_nomthresholds_imputed_topdecile_forxtile, replace
end



capture program drop build_f1040se_prep
program define build_f1040se_prep
  use ${raw}/rpi_f1040se_pull, clear
  rename tin tin_pe
  duplicates drop tin tax_yr, force
  compress
  save ${dta}/rpi_f1040se_pull_nodups, replace
end



capture program drop build_s_firmowner_raw
program define build_s_firmowner_raw
  forv year=$yrminoverall/$yrmaxoverall {
    global year = `year'
	noi di "${year}"
	di "$S_TIME"
	di "(i)"
    *LOAD OWNERS AND MERGE 1040 SCHEDULE E VARS
    use tin tin_typ tax_yr tin_pe${year} ord_inc psinc* payer_tin* wages_max wages_smax ssa_yob ssa_yod using ${raw}/f1120s_k1_$year, clear
    rename tin_pe$year tin_pe
    merge m:1 tin_pe tax_yr using ${dta}/rpi_f1040se_pull_nodups, keep(1 3) nogen keepusing(npassinc npasslss pass_inc plsscor corpinc corploss)
    rename tin_pe tin_pe$year
    *SAVE
    compress
    save ${dump}/owners_binned_agi_$year, replace 
    
	di "(ii)"
    *LOAD FIRMS DATA AND MERGE ON W2 DATA
    use ein tin tax_prd toinclos totalded costsold slwgljob compofcr penplded empbene intrded totabamt tassend naics_cd using ${raw}/f1120s_$year, clear
    rename tin payer_tin
    destring ein, replace
    gen tax_yr = ${year}
    merge m:1 payer_tin tax_yr using ${raw}/rpi_worker_chars, keep(1 3) keepusing(w2_num wagebill num1099 comp1099) nogen
    rename w2_num numw2 
    gen zzanymissing = (toinclos==. | totalded==. | costsold==.)
    gen zzmaxamt = max(abs(toinclos),abs(totalded),abs(costsold))
    gsort payer_tin zzanymissing -tax_prd -zzmaxamt
    by payer_tin: keep if _n==1
    drop zz* 
    *MERGE ON START AND END YEARS OF THE FIRMS
    rename payer_tin tin
    merge m:1 tin using ${raw}/rpi_pullallfirmyears, keep(1 3) keepusing(tyfirst tylast) nogen 
    rename tin payer_tin

	di "(iii)"
    *MERGE ONTO OWNERS DATA, KEEPING ONLY OWNERS
    merge 1:m payer_tin using ${dump}/owners_binned_agi_$year, keep(2 3) nogen    
    *SAVE
    compress
    save ${dta}/s_firmowner_raw_${year}, replace
  }
end



capture program drop build_s_firmowner_full
program define build_s_firmowner_full
  forv year=$yrminoverall/$yrmaxoverall {
    global year = `year'
	di "${year}"
	di "$S_TIME"
    use ${dta}/s_firmowner_raw_${year}, clear 
    foreach var in ord_inc {
      replace `var'=0 if `var'==.  
    }
    *SET DATABANK VARS TO MISSING FOR PAYEES WE KNOW ARE EINS (LIKE ESTATES AND TRUSTS)
    foreach var in psinc1996 psinc1997 psinc1998 psinc1999 psinc2000 psinc2001 psinc2002 psinc2003 psinc2004 psinc2005 psinc2006 psinc2007 psinc2008 psinc2009 psinc2010 psinc2011 psinc2012 psinc2013 psinc2014 wages_max wages_smax {
      replace `var'=. if inrange(tin_typ,5,6)
    }     
    *BIN AGI (note that missing values are handled well: bin vars are missing when underlying vars are missing)
    merge 1:1 _n using ${dta}/pikettysaez_nomthresholds_imputed_topdecile_forxtile, nogen
    forv t=$yrminoverall/$year {
	  di "l-in-l `t' in $year"
      xtile agipctilebin`t' = psinc`t', c(nocg_thresholds_`t')
      replace agipctilebin`t'=45 if agipctilebin`t'==1
      replace agipctilebin`t'=90.5 if agipctilebin`t'==2
      replace agipctilebin`t'=91.5 if agipctilebin`t'==3
      replace agipctilebin`t'=92.5 if agipctilebin`t'==4
      replace agipctilebin`t'=93.5 if agipctilebin`t'==5
      replace agipctilebin`t'=94.5 if agipctilebin`t'==6
      replace agipctilebin`t'=95.5 if agipctilebin`t'==7
      replace agipctilebin`t'=96.5 if agipctilebin`t'==8
      replace agipctilebin`t'=97.5 if agipctilebin`t'==9
      replace agipctilebin`t'=98.5 if agipctilebin`t'==10
      replace agipctilebin`t'=99.25 if agipctilebin`t'==11
      replace agipctilebin`t'=99.7 if agipctilebin`t'==12
      replace agipctilebin`t'=99.95 if agipctilebin`t'==13 | agipctilebin`t'==14
    }
    gen agibin = agipctilebin$year
    gen aginoscorppship = psinc$year - (corpinc - corploss)
    xtile aginoscorppshipbin = aginoscorppship, c(nocg_thresholds_$year)
    replace aginoscorppshipbin=45 if aginoscorppshipbin==1
    replace aginoscorppshipbin=90.5 if aginoscorppshipbin==2
    replace aginoscorppshipbin=91.5 if aginoscorppshipbin==3
    replace aginoscorppshipbin=92.5 if aginoscorppshipbin==4
    replace aginoscorppshipbin=93.5 if aginoscorppshipbin==5
    replace aginoscorppshipbin=94.5 if aginoscorppshipbin==6
    replace aginoscorppshipbin=95.5 if aginoscorppshipbin==7
    replace aginoscorppshipbin=96.5 if aginoscorppshipbin==8
    replace aginoscorppshipbin=97.5 if aginoscorppshipbin==9
    replace aginoscorppshipbin=98.5 if aginoscorppshipbin==10
    replace aginoscorppshipbin=99.25 if aginoscorppshipbin==11
    replace aginoscorppshipbin=99.7 if aginoscorppshipbin==12
    replace aginoscorppshipbin=99.95 if aginoscorppshipbin==13 | aginoscorppshipbin==14
    rename psinc$year zz
    drop fractile *thresholds* psinc*
    rename zz psinc
    *CREATE OTHER OWNER-LEVEL COVARIATES
    gen hasw2 = ((payer_tin==payer_tin_w2_max & payer_tin!=.) | (payer_tin==payer_tin_w2_smax & payer_tin !=.))
    gen spousehasw2 = ((payer_tin==payer_tin_w2_max_spouse & payer_tin!=.) | (payer_tin==payer_tin_w2_smax_spouse & payer_tin!=.))
    gen onlypassive = (npassinc==0 & npasslss==0 & (pass_inc>0 | plsscor>0))
    drop npassinc npasslss pass_inc plsscor  
    foreach var in toinclos totalded costsold slwgljob compofcr penplded empbene intrded totabamt tassend numw2 {
      replace `var'=0 if `var'==.  
    } 
    foreach var in toinclos totalded costsold slwgljob compofcr penplded empbene intrded {
      replace `var'=0 if `var'<0
    }    
    *CREATE FIRM-LEVEL OUTCOMES AND COVARIATES
    gen profits = toinclos - totalded
    gen sales = toinclos + costsold
    gen costs = sales - profits
    rename tassend ass
    replace ass = totabamt if ass==0
    destring naics_cd, force replace
    gen standard_naics = cond(naics_cd < 1000, naics_cd*1000, cond(naics_cd < 10000, naics_cd*100, cond(naics_cd < 100000, naics_cd*10, naics_cd)))
    *CREATE PROFIT MARGIN AND OTHER FIRM-BASED OWNER-LEVEL COVARIATES
    **PROFIT MARGIN
    bys tin: egen zz_p = total(profits)
    bys tin: egen zz_s = total(sales)
    gen pm = zz_p/zz_s
    drop zz*
    **RETURN ON ASSETS
    bys tin: egen zzprofits = total(profits)
    by tin: egen zzass = total(ass)
    gen roa = zzprofits/zzass
    drop zz*
    **INFLATE SALES TO 2014 DOLLARS
    gen sales_14dollars = sales
    usd2014, var(sales_14dollars) yr(tax_yr)
    gen sales10M=(sales_14dollars>10000000)
    replace sales10M=. if sales_14dollars==.
    gen sales5M=(sales_14dollars>5000000)
    replace sales5M=. if sales_14dollars==.
	
    **WEIGHTS
    bys tin: egen zztinnumrows = count(tin)
    gen one_tinnumrows_allfirms = 1/zztinnumrows
    drop zz*
    gen zzgt5m = (sales_14dollars > 5000000)
    bys tin: egen zztinnumrows = sum(zzgt5m)
    gen one_tinnumrows = 1/zztinnumrows
    drop zz*
    bys ein: egen einnumrows = count(tin)
    gen one_einnumrows = 1/einnumrows
    **INDUSTRY AND INDUSTRY-X-SALEBIN
    xtile salebin = sales_14dollars [w=one_einnumrows], n(20)
    gen nc4 = floor(standard_naics/100)
    gen nc4salebin = 100*nc4 + salebin
    **ANGEL INVESTORS BY SAVING NUMBER OF COMPANIES
    bys tin: egen tinnumrows_allfirms = count(tin)
    gen zzgt5m = (sales_14dollars)
    bys tin: egen tinnumrows = sum(zzgt5m)
    gen zzgt5mnow2 = (sales_14dollars & numw2>0 & numw2!=. & hasw2==0 & spousehasw2==0)
    bys tin: egen tinnumrows_now2 = sum(zzgt5mnow2)
    drop zz*
	**NEW VARS IN JUNE 2018
	replace wagebill=0 if wagebill==.
	replace comp1099=0 if comp1099==.
	gen wagebill1 = wagebill + comp1099
	***OFFICER COMP VAR EXISTS ONLY IN THE S-CORP FILE
	replace compofcr=0 if compofcr==.
	gen wagebill2 = compofcr + slwgljob + penplded + empbene
	gen valine3 = sales - costsold
	***DUE TO ROUNDING ERROR, A FEW OBS HAVE NEGATIVE VALINE3, SO SET TO ZERO
	replace valine3=0 if valine3<0
	gen wagesfromfirm = 0
	replace wagesfromfirm = wagesfromfirm + wages_max if payer_tin==payer_tin_w2_max & payer_tin!=. & 	payer_tin!=0
	replace wagesfromfirm = wagesfromfirm + wages_smax if payer_tin==payer_tin_w2_smax & payer_tin!=. & payer_tin!=0
	***ADD SOME NEW FIRM-LEVEL VARS
	capture drop ord_inc_totein
	bys payer_tin: egen ord_inc_totein = total(ord_inc)
	by payer_tin: egen wagesfromfirm_totein = total(wagesfromfirm)
	***ADD SOME NEW OWNER-LEVEL VARS
	bys tin: egen numfirms = count(tin)
	***PROCESS NEW OUTCOME VARS
	gen va = wagebill2 + ord_inc_totein
	gen ownerpay = wagesfromfirm + ord_inc
	gen ownerpay_totein = wagesfromfirm_totein + ord_inc_totein
	gen ownshare = ord_inc/ord_inc_totein
    **FLAG FIRMS DEPENDING ON OWNERS' AGI RANKS
    egen agi_max = max(agipctilebin$year), by(ein)
    gen own_top10 = (agi_max>90 & agi_max != .)
    gen own_top1  = (agi_max>99 & agi_max != .)
    gen own_toppt1  = (agi_max>99.9 & agi_max != .)
    gen own_top1_sales5M =(own_top1 ==1 & sales5M==1)
    gen own_toppt1_sales5M =(own_toppt1 ==1 & sales5M==1)
    *CREATE SIZEBIN
    sizebin, binningvar(sales_14dollars) newvar(sizebin)   
    *VALIDATE WITH SIMPLE HOCKEY STICK
    tabstat pm [w=one_tinnumrows] if inrange(pm,-1,1) & sales5M==1, by(agibin) stat(mean)   
    *SAVE
    compress
    format ein tin ord_inc profits sales %15.0g
    save ${dta}/s_firmowner_full_${year}, replace
  }
end



capture program drop build_s_firmowner
program define build_s_firmowner
  forv year = $yrminoverall/$yrmaxoverall {
    global year = `year'
	di "$year"
	di "$S_TIME"
    disp ${year}
    *LOAD DATA, RESTRICTING TO TINS MATCHED TO A 1040 AND DROP UNMATCHED OWNERS B/C OF A 2003 OUTLIER
    use ${dta}/s_firmowner_full_${year} if psinc!=. & profits!=., clear
    set seed 1000
    gen zzrand = uniform()
    gsort tin ein zzrand
    by tin ein: keep if _n==1
    drop zz*
    *SET WRONG-SIDED ord_inc VALUES TO ZERO (at least for rows with non-missing profits)
    replace ord_inc=0 if sign(ord_inc)!=sign(profits) & profits!=.
    *CENSOR ord_inc USING profits
    replace ord_inc=profits if ord_inc>profits & ord_inc>0 & ord_inc!=. & profits!=.
    replace ord_inc=profits if ord_inc<profits & ord_inc<0 & ord_inc!=. & profits!=.
    *SET ord_inc_gain AND ord_inc_loss
    gen ord_inc_gain = 0
    gen ord_inc_loss = 0
    replace ord_inc_gain=ord_inc if ord_inc>0 & ord_inc!=.
    replace ord_inc_loss=ord_inc if ord_inc<0 & ord_inc!=.
    *APPORTION PROFITS AND SALES TO INDIVIDUAL OWNERS TO AVOID DOUPLE-COUNTING ACROSS OWNERS
    foreach var in profits sales {
      gen `var'_apportioned = (ord_inc/ord_inc_totein)*`var'
    }
    compress
    save ${dta}/s_firmowner_${year}, replace
  }
end



capture program drop collapse_s_firmowner
program define collapse_s_firmowner
  capture rm ${dump}/collapse_s_firmowner.dta
  forv year = $yrminoverall/$yrmaxoverall {
    global year = `year'
    disp ${year}
    *LOAD DATA
    use agibin profits_apportioned sales_apportioned pm ord_inc ein tin one_tinnumrows_allfirms nc4 payer_tin payer_tin_w2_max payer_tin_w2_smax wages_max wages_smax sizebin using ${dta}/s_firmowner_${year}, clear
    *SET OWNERWAGES
    gen ownerwages=0
    replace ownerwages = wages_max if payer_tin==payer_tin_w2_max
    replace ownerwages = wages_smax if payer_tin==payer_tin_w2_smax & ownerwages==0
    *ADDITIONAL BINNINGS
    gen top01 = inrange(agibin,99.9,100)
    gen pmbin = -9
    replace pmbin=0 if inrange(pm,-1,0)
    replace pmbin=1 if inrange(pm,0,1)
    gen human = (tin!=.)
    *COLLAPSE
    collapse (sum) profits=profits_apportioned sales=sales_apportioned ord_inc ownerwages, by(human top01 pmbin nc4 sizebin)
    gen year = ${year}
    capture append using ${dump}/collapse_s_firmowner
    save ${dump}/collapse_s_firmowner, replace
  }
  save ${dta}/collapse_s_firmowner, replace
end



capture program drop build_p_firmowner_raw
program define build_p_firmowner_raw

    forv year=$yrminoverall/$yrmaxoverall {
        global year = `year'
        *LOAD OWNERS AND MERGE 1040 SCHEDULE E VARS
        use tin tin_typ tax_yr tin_pe${year} ord_inc psinc* payer_tin* wages_max ///
            wages_smax ssa_yob ssa_yod using ${raw}/pship_owners/f1065_k1_$year, clear
        rename tin_pe$year tin_pe
        merge m:1 tin_pe tax_yr using ${dta}/rpi_f1040se_pull_nodups, keep(1 3) nogen keepusing(npassinc npasslss pass_inc plsscor corpinc corploss)
        rename tin_pe tin_pe$year
        *SAVE
        compress
        tempfile owners_binned
        save `owners_binned' 

        *LOAD FIRMS DATA AND MERGE ON W2 DATA
        use ein tin tax_prd tot_inc totalded costsold salywage pmtsprts retplan empbene intrded totalass naics_cd using ${raw}/pship_firms/f1065_$year, clear
        rename tin payer_tin
        destring ein, replace
        gen tax_yr = ${year}
		rename tot_inc toinclos
		rename totalass tassend
		rename salywage slwgljob
		rename retplan penplded
        merge m:1 payer_tin tax_yr using ${raw}/rpi_worker_chars, keep(1 3) keepusing(w2_num wagebill num1099 comp1099) nogen
        rename w2_num numw2 
        *CHOOSE AMONG DUPLICATES (PRIORITIZING NON-MISSING ROWS AND LATE-YEAR TAX PERIODS)
        gen zzanymissing = (toinclos==. | totalded==. | costsold==.)
        gen zzmaxamt = max(abs(toinclos), abs(totalded), abs(costsold))
        gsort payer_tin zzanymissing -tax_prd -zzmaxamt
        by payer_tin: keep if _n==1
        drop zz* 
        *MERGE ON START AND END YEARS OF THE FIRMS
        rename payer_tin tin
        merge m:1 tin using ${raw}/rpi_pullallfirmyears, keep(1 3) keepusing(tyfirst tylast) nogen 
        rename tin payer_tin

        *MERGE ONTO OWNERS DATA, KEEPING ONLY OWNERS
        merge 1:m payer_tin using `owners_binned', keep(2 3) nogen    
        *SAVE
        compress
        save ${dta}/p_firmowner_raw_${year}, replace
    }

end



capture program drop build_p_firmowner_full
program define build_p_firmowner_full

    forv year=$yrminoverall/$yrmaxoverall {
        global year = `year'

        use ${dta}/p_firmowner_raw_${year}, clear 

        foreach var in ord_inc {
          replace `var'=0 if `var'==.  
        }

        *SET DATABANK VARS TO MISSING FOR PAYEES WE KNOW ARE EINS (LIKE ESTATES AND TRUSTS)
        foreach var in psinc1996 psinc1997 psinc1998 psinc1999 psinc2000 psinc2001 psinc2002 psinc2003 psinc2004 psinc2005 psinc2006 psinc2007 psinc2008 psinc2009 psinc2010 psinc2011 psinc2012 psinc2013 psinc2014 wages_max wages_smax {
          replace `var'=. if inrange(tin_typ,5,6)
        }     

        *BIN AGI (note that missing values are handled well: bin vars are missing when underlying vars are missing)
        merge 1:1 _n using ${dta}/pikettysaez_nomthresholds_imputed_topdecile_forxtile, nogen
        forv t=$yrminoverall/$year {
          xtile agipctilebin`t' = psinc`t', c(nocg_thresholds_`t')
          replace agipctilebin`t'=45 if agipctilebin`t'==1
          replace agipctilebin`t'=90.5 if agipctilebin`t'==2
          replace agipctilebin`t'=91.5 if agipctilebin`t'==3
          replace agipctilebin`t'=92.5 if agipctilebin`t'==4
          replace agipctilebin`t'=93.5 if agipctilebin`t'==5
          replace agipctilebin`t'=94.5 if agipctilebin`t'==6
          replace agipctilebin`t'=95.5 if agipctilebin`t'==7
          replace agipctilebin`t'=96.5 if agipctilebin`t'==8
          replace agipctilebin`t'=97.5 if agipctilebin`t'==9
          replace agipctilebin`t'=98.5 if agipctilebin`t'==10
          replace agipctilebin`t'=99.25 if agipctilebin`t'==11
          replace agipctilebin`t'=99.7 if agipctilebin`t'==12
          replace agipctilebin`t'=99.95 if agipctilebin`t'==13 | agipctilebin`t'==14
        }
        gen agibin = agipctilebin$year
        gen aginoscorppship = psinc$year - (corpinc - corploss)
        xtile aginoscorppshipbin = aginoscorppship, c(nocg_thresholds_$year)
        replace aginoscorppshipbin=45 if aginoscorppshipbin==1
        replace aginoscorppshipbin=90.5 if aginoscorppshipbin==2
        replace aginoscorppshipbin=91.5 if aginoscorppshipbin==3
        replace aginoscorppshipbin=92.5 if aginoscorppshipbin==4
        replace aginoscorppshipbin=93.5 if aginoscorppshipbin==5
        replace aginoscorppshipbin=94.5 if aginoscorppshipbin==6
        replace aginoscorppshipbin=95.5 if aginoscorppshipbin==7
        replace aginoscorppshipbin=96.5 if aginoscorppshipbin==8
        replace aginoscorppshipbin=97.5 if aginoscorppshipbin==9
        replace aginoscorppshipbin=98.5 if aginoscorppshipbin==10
        replace aginoscorppshipbin=99.25 if aginoscorppshipbin==11
        replace aginoscorppshipbin=99.7 if aginoscorppshipbin==12
        replace aginoscorppshipbin=99.95 if aginoscorppshipbin==13 | aginoscorppshipbin==14
        rename psinc$year zz
        drop fractile *thresholds* psinc*
        rename zz psinc

        *CREATE OTHER OWNER-LEVEL COVARIATES
        gen hasw2 = ((payer_tin==payer_tin_w2_max & payer_tin!=.) | (payer_tin==payer_tin_w2_smax & payer_tin !=.))
        gen spousehasw2 = ((payer_tin==payer_tin_w2_max_spouse & payer_tin!=.) | (payer_tin==payer_tin_w2_smax_spouse & payer_tin!=.))
        gen onlypassive = (npassinc==0 & npasslss==0 & (pass_inc>0 | plsscor>0))
        drop npassinc npasslss pass_inc plsscor  

		foreach var in toinclos totalded costsold slwgljob pmtsprts penplded empbene intrded tassend numw2 {
          replace `var'=0 if `var'==.  
        } 
        foreach var in toinclos totalded costsold slwgljob pmtsprts penplded empbene intrded {
          replace `var'=0 if `var'<0
        }    
        *CREATE FIRM-LEVEL OUTCOMES AND COVARIATES
        gen profits = toinclos - totalded
        gen sales = toinclos + costsold
        gen costs = sales - profits
        **TYPICALLY MISSING totabamt AT LEAST IN 2000 SO JUST USE tassend
        rename tassend ass
        destring naics_cd, force replace
        gen standard_naics = cond(naics_cd < 1000, naics_cd*1000, cond(naics_cd < 10000, naics_cd*100, cond(naics_cd < 100000, naics_cd*10, naics_cd)))

        *CREATE PROFIT MARGIN AND OTHER FIRM-BASED OWNER-LEVEL COVARIATES
        **PROFIT MARGIN
        bys tin: egen zz_p = total(profits)
        bys tin: egen zz_s = total(sales)
        gen pm = zz_p/zz_s
        drop zz*
        **RETURN ON ASSETS
        bys tin: egen zzprofits = total(profits)
        by tin: egen zzass = total(ass)
        gen roa = zzprofits/zzass
        drop zz*
        **INFLATE SALES TO 2014 DOLLARS
        gen sales_14dollars = sales
        usd2014, var(sales_14dollars) yr(tax_yr)
        gen sales10M=(sales_14dollars>10000000)
        replace sales10M=. if sales_14dollars==.
        gen sales5M=(sales_14dollars>5000000)
        replace sales5M=. if sales_14dollars==.
        **WEIGHTS
        bys tin: egen zztinnumrows = count(tin)
        gen one_tinnumrows_allfirms = 1/zztinnumrows
        drop zz*
        gen zzgt5m = (sales_14dollars > 5000000)
        bys tin: egen zztinnumrows = sum(zzgt5m)
        gen one_tinnumrows = 1/zztinnumrows
        drop zz*
        bys ein: egen einnumrows = count(tin)
        gen one_einnumrows = 1/einnumrows if sales_14dollars > 5000000
        **INDUSTRY AND INDUSTRY-X-SALEBIN
        xtile salebin = sales_14dollars [w=one_einnumrows], n(20)
        gen nc4 = floor(standard_naics/100)
        gen nc4salebin = 100*nc4 + salebin
        **ANGEL INVESTORS BY SAVING NUMBER OF COMPANIES
        bys tin: egen tinnumrows_allfirms = count(tin)
        gen zzgt5m = (sales_14dollars)
        bys tin: egen tinnumrows = sum(zzgt5m)
        gen zzgt5mnow2 = (sales_14dollars & numw2>0 & numw2!=. & hasw2==0 & spousehasw2==0)
        bys tin: egen tinnumrows_now2 = sum(zzgt5mnow2)
        drop zz*
		**NEW VARS IN JUNE 2018
		***SET THESE VARS TO ZERO WHEN MISSING, IE WHEN NO MATCH TO THE W2S OR 1099S
		replace wagebill=0 if wagebill==.
		replace comp1099=0 if comp1099==.
		gen wagebill1 = wagebill + comp1099
		***GUARANTEED PAYMENTS TO PARTNRES VAR EXISTS ONLY IN THE PSHIPS FILE
		replace pmtsprts=0 if pmtsprts==.
		gen wagebill2 = pmtsprts + slwgljob + penplded + empbene
		gen valine3 = sales - costsold
		***DUE TO ROUNDING ERROR, A FEW OBS HAVE NEGATIVE VALINE3, SO SET TO ZERO
		replace valine3=0 if valine3<0
		gen wagesfromfirm = 0
		replace wagesfromfirm = wagesfromfirm + wages_max if payer_tin==payer_tin_w2_max & payer_tin!=. & 	payer_tin!=0
		replace wagesfromfirm = wagesfromfirm + wages_smax if payer_tin==payer_tin_w2_smax & payer_tin!=. & payer_tin!=0
		***ADD SOME NEW FIRM-LEVEL VARS
		capture drop ord_inc_totein
		bys payer_tin: egen ord_inc_totein = total(ord_inc)
		by payer_tin: egen wagesfromfirm_totein = total(wagesfromfirm)
		***ADD SOME NEW OWNER-LEVEL VARS
		bys tin: egen numfirms = count(tin)
		***PROCESS NEW OUTCOME VARS
		gen va = wagebill2 + ord_inc_totein
		gen ownerpay = wagesfromfirm + ord_inc
		gen ownerpay_totein = wagesfromfirm_totein + ord_inc_totein
		gen ownshare = ord_inc/ord_inc_totein
        **FLAG FIRMS DEPENDING ON OWNERS' AGI RANKS
        egen agi_max = max(agipctilebin$year), by(ein)
        gen own_top10 = (agi_max>90 & agi_max != .)
        gen own_top1  = (agi_max>99 & agi_max != .)
        gen own_toppt1  = (agi_max>99.9 & agi_max != .)
        gen own_top1_sales5M =(own_top1 ==1 & sales5M==1)
        gen own_toppt1_sales5M =(own_toppt1 ==1 & sales5M==1)
        *CREATE SIZEBIN
        sizebin, binningvar(sales_14dollars) newvar(sizebin)   
        *VALIDATE WITH SIMPLE HOCKEY STICK
        tabstat pm [w=one_tinnumrows] if inrange(pm,-1,1) & sales5M==1, by(agibin) stat(mean)   
        *SAVE
        compress
        format ein tin ord_inc profits sales %15.0g
        save ${dta}/p_firmowner_full_${year}, replace
    }

end



capture program drop build_p_firmowner
program define build_p_firmowner

    forv year = $yrminoverall/$yrmaxoverall {

        global year = `year'
        disp ${year}
        *LOAD DATA, RESTRICTING TO TINS MATCHED TO A 1040 AND DROP UNMATCHED OWNERS B/C OF A 2003 OUTLIER
        use ${dta}/p_firmowner_full_${year} if psinc!=. & profits!=., clear
        set seed 1000
        gen zzrand = uniform()
        gsort tin ein zzrand
        by tin ein: keep if _n==1
        drop zz*
        replace ord_inc=0 if sign(ord_inc)!=sign(profits) & profits!=.
        *CENSOR ord_inc USING profits
        replace ord_inc=profits if ord_inc>profits & ord_inc>0 & ord_inc!=. & profits!=.
        replace ord_inc=profits if ord_inc<profits & ord_inc<0 & ord_inc!=. & profits!=.
        *SET ord_inc_gain AND ord_inc_loss
        gen ord_inc_gain = 0
        gen ord_inc_loss = 0
        replace ord_inc_gain=ord_inc if ord_inc>0 & ord_inc!=.
        replace ord_inc_loss=ord_inc if ord_inc<0 & ord_inc!=.
        *APPORTION PROFITS AND SALES TO INDIVIDUAL OWNERS TO AVOID DOUPLE-COUNTING ACROSS OWNERS
        foreach var in profits sales {
          gen `var'_apportioned = (ord_inc/ord_inc_totein)*`var'
        }
        compress
        save ${dta}/p_firmowner_${year}, replace

    }

end



capture program drop build_sp_firmowner
program define build_sp_firmowner

    forv year = $yrminoverall/$yrmaxoverall {

        global year = `year'
        disp ${year}
        use ${dta}/s_firmowner_${year}, clear
        gen orgform = "s"
        append using ${dta}/p_firmowner_${year}
        replace orgform="p" if orgform==""
        gsort tin payer_tin -orgform
        by tin payer_tin: keep if _n==1
        compress
        save ${dta}/sp_firmowner_${year}, replace
    }

end



capture program drop build_sp_firmpanel
program define build_sp_firmpanel
  *LOAD FIRMS DATA AND MERGE ON W2 DATA
  capture rm ${dump}/sp_firmpanel.dta
  forv t=$yrminoverallplusone/$yrmaxoverall {
    use ein tin tax_prd tot_inc totalded costsold salywage pmtsprts retplan empbene intrded using ${raw}/pship_firms/f1065_`t', clear
	gen orgform = "p"
	rename tot_inc toinclos
	rename salywage slwgljob
	rename pmtsprts compofcr
	rename retplan penplded
    append using ${raw}/f1120s_`t', keep(ein tin tax_prd toinclos totalded costsold slwgljob compofcr penplded empbene intrded) 
	replace orgform="s" if orgform==""
	gsort tin -orgform
	by tin: keep if _n==1
    rename tin payer_tin
    gen tax_yr = `t'
    merge m:1 payer_tin tax_yr using ${raw}/rpi_worker_chars, keep(1 3) keepusing(w2_num wagebill num1099 comp1099) nogen
    rename w2_num numw2`t'
	rename wagebill wagebill`t'
	rename num1099 num1099`t'
	rename comp1099 comp1099`t'
    *CHOOSE AMONG DUPLICATES (PRIORITIZING NON-MISSING ROWS AND LATE-YEAR TAX PERIODS)
    foreach var in toinclos totalded costsold numw2 slwgljob compofcr penplded empbene intrded  {
      replace `var'=0 if `var'==.  
    } 
    foreach var in toinclos totalded costsold slwgljob compofcr penplded empbene intrded {
      replace `var'=0 if `var'<0
    }    
    *MAKE VARS
    gen profits`t' = toinclos - totalded
    gen sales`t' = toinclos + costsold
    gen profits_14dollars`t' = profits`t'
    usd2014, var(profits_14dollars`t') yr(tax_yr)
    gen sales_14dollars`t' = sales`t'
    usd2014, var(sales_14dollars`t') yr(tax_yr)
    keep ein payer_tin orgform profits`t' profits_14dollars`t' sales`t' sales_14dollars`t' numw2`t'
    *MERGE AND SAVE
    capture merge 1:1 payer_tin using ${dump}/sp_firmpanel, nogen
    save ${dump}/sp_firmpanel, replace
  }
  *MERGE ON START AND END YEARS OF THE FIRMS
  rename payer_tin tin
  merge m:1 tin using ${raw}/rpi_pullallfirmyears, keep(1 3) keepusing(tyfirst tylast) nogen 
  rename tin payer_tin
  forv t=$yrminoverallplusone/$yrmaxoverall {
    foreach varroot in profits sales profits_14dollars numw2 {
      replace `varroot'`t'=0 if `varroot'`t'==.
    }
  }
  compress
  save ${dta}/sp_firmpanel, replace
end



*******************************************************************************
* MAIN
*******************************************************************************
capture program drop main
program define main

    ****************************************************************************
    * Init
    ****************************************************************************
    *capture log c
    *log using "${dirdo}/build_cdw_${buildcdwversiondate}.log", replace
    *set trace on
    *set tracedepth 1
    
    ****************************************************************************
    * Builds
    ****************************************************************************
    compress_rawfiles
    build_pikettysaez_thresholds
    build_f1040se_prep
    build_s_firmowner_raw
    build_s_firmowner_full
    build_s_firmowner
    collapse_s_firmowner

    build_p_firmowner_raw
    build_p_firmowner_full
    build_p_firmowner
	
    build_sp_firmowner
    build_sp_firmpanel

    *log c
end

main
