global graphconfig "graphregion(color(white)) bgcolor(white)"

capture program drop load_analysis_data_v1/*%<*/
program define load_analysis_data_v1

    if ("`1'" == "soi") {
        use $dta/newsoi_20170210.dta, clear
        gen nc4 = floor(standard_naics/100)
    }
    if ("`1'" == "c_s_v1") {
        use $dta/ls_nc4.dta, clear
    }
    if ("`1'" == "top14") {
        use $dta/s_firmowner_full_2014.dta, clear
    }
    if ("`1'" == "top01") {
        use $dta/s_firmowner_full_2001.dta, clear
    }
    if ("`yr'" != "" & "`nofull'" != "") {
        use $dta/s_firmowner_20`yr'.dta, clear
    }
    else if ("`yr'" != "") {
        use $dta/s_firmowner_full_20`yr'.dta, clear
    }
    else if ("`1'" == "popswitch") {
        use $dta/c_to_s_switcher_panel.dta, clear
        destring naics_cd, force replace
        gen nc4 = floor(naics_cd/100)
        rename (tin tax_yr) (ein year)
    }

end/*%>*/

capture program drop analyze_soi_switch/*%<*/
program define analyze_soi_switch 

    ***************************************************************************
    * SOI Switchers
    ***************************************************************************
    use `switch', clear
    graph_switch_eventstudies

end/*%>*/

capture program drop make_pop_switchers/*%<*/
program define make_pop_switchers

    load_analysis_data_v1 popswitch

    * Identify switchers (done in KS code)

    * Define event time
    sort ein year
    by ein: gen e_holder = switch * _n
    by ein: egen e_time = max(e_holder)
    by ein: gen event_time = _n - e_time
    drop e_holder e_time

    * Define key outcomes
    rename (ofcrcomp rcpts) (officer_comp sale)
    gen labor_comp = wages + officer_comp
    gen profits = tot_inc - tot_ded
    usd2014, var(officer_comp) yr(year)
    usd2014, var(profits) yr(year)
    usd2014, var(labor_comp) yr(year)
    usd2014, var(sale) yr(year)
    usd2014, var(tot_ded) yr(year)

    gen profit_sale = profits/sale
    gen officer_comp_sale = officer_comp/sale
    gen labor_comp_sale = labor_comp/sale
    gen tototh_ded_sale = (tot_ded - labor_comp)/sale

    foreach v of varlist profit_sale-tototh_ded_sale { 
        trim_tails `v', level(.01)
    }

    * Make simple table
    tabstat officer_comp labor_comp profits, by(event_time) s(mean)
    tabstat officer_comp labor_comp profits if nc4 == 6211, by(event_time) s(mean)

    bys ein: egen mean_sale = mean(sale)
    gen sizebin = cond(mean_sale < 5e6, 1, cond(mean_sale < 50e6, 2, 3))
    gen nc2 = floor(nc4/100)

    egen maxsales=max(sale), by(ein)
    gen active96H = event_time == -4
    gen active97H = event_time == -3
    bys ein: egen active96 = max(active96H)
    bys ein: egen active97 = max(active97H)

    gen tminus1salesH = cond(event_time == -1, sale, .)
    bys ein: egen tminus1sales = max(tminus1salesH)
    drop tminus1salesH

    save $dta/popswitchers_20170705.dta, replace

end/*%>*/


capture program drop analyze_switch_v2/*%<*/
program define analyze_switch_v2
    syntax, spec(string) [groupvar(name)]

    tempfile orig analysis_data
    save `orig'

    foreach var of varlist profit_sale labor_comp_sale tototh_ded_sale {
        
        if ("`groupvar'" != "") {
            reghdfe `var' `groupvar'#(Dn5p-Dn2 D0-D5p), abs(ein year) cluster(ein)
        } 
        else {
            reghdfe `var' Dn5p-Dn2 D0-D5p, abs(ein year) cluster(ein)
        }
        regsave
        cap drop N r2
        export delimited ${out}/ES_switch_firmFX_`var'_`spec'.csv, replace
        use `orig', clear
    }

    use `orig', clear

end/*%>*/

capture program drop graph_switch_eventstudies/*%<*/
program define graph_switch_eventstudies
    syntax , [count(integer 5)]

    * Balanced
    bys ein: gen count = _N
    keep if count == `count'

    xi: areg profit_sale i.year, absorb(ein)
    predict profit_sale_r, resid
    sum profit_sale
    replace profit_sale_r = profit_sale_r + `r(mean)'

    xi: areg labor_comp_sale i.year, absorb(ein)
    predict labor_comp_sale_r, resid
    sum labor_comp_sale
    replace labor_comp_sale_r = labor_comp_sale_r + `r(mean)'

    xi: areg tototh_ded_sale i.year, absorb(ein)
    predict tototh_ded_sale_r, resid
    sum tototh_ded_sale
    replace tototh_ded_sale_r = tototh_ded_sale_r + `r(mean)'

    gen post = event_time >= 0

    tabstat profit_sale_r if nc4 == 6211, by(event_time) s(mean p10 p25 p50 p75 p90)
    tabstat labor_comp_sale_r if nc4 == 6211, by(event_time) s(mean p10 p25 p50 p75 p90)
    tabstat tototh_ded_sale_r if nc4 == 6211, by(event_time) s(mean p10 p25 p50 p75 p90)

    * Graphs.
    tempfile sample
    save `sample'

    * docs
    use `sample', clear
    keep if nc4 == 6211 | nc4 == 6212
    analyze_switch, spec("docs")

    * all
    use `sample', clear
    analyze_switch, spec("all")

    * nc 62
    use `sample', clear
    keep if nc2 == 62
    analyze_switch, spec("nc62")

    * firm size bins (sales < 10M, 10-100M, > 100M)
    use `sample', clear
    keep if sizebin == 1
    analyze_switch, spec("small")

    use `sample', clear
    keep if sizebin == 2
    analyze_switch, spec("med")

    use `sample', clear
    keep if sizebin == 3
    analyze_switch, spec("big")

    * firm size crossed with nc 62
    use `sample', clear
    keep if sizebin == 1 & nc2 == 62
    analyze_switch, spec("smallnc2")

    use `sample', clear
    keep if sizebin != 1 & nc2 == 62
    analyze_switch, spec("medbignc2")

    * high profit share versus labor share
    tempfile profit_share
    insheet using "$csvdir/soi_indy_correlates_20170210.csv", clear
    rename naics_4d nc4
    keep if year > 2002
    usd2014, var(profits_scorp) yr(year)
    usd2014, var(profits_ccorp) yr(year)
    usd2014, var(sale_scorp) yr(year)
    usd2014, var(sale_ccorp) yr(year)
    collapse (sum) profits_scorp profits_ccorp sale_scorp sale_ccorp, by(nc4)
    gen s_profit_share = profits_scorp / (profits_scorp + profits_ccorp)
    gen s_sale_share = sale_scorp / (sale_scorp + sale_ccorp)
    keep if profits_scorp + profits_ccorp > 10*500e3
    gen profit_edge = s_profit_share - s_sale_share
    xtile edgebin=profit_edge, nq(5)
    xtile profitbin = profits_scorp, nq(5)
    keep nc4 profit_edge s_profit_share edgebin profitbin
    list nc4 if edgebin == 5
    save `profit_share'

    use `sample', clear
    merge m:1 nc4 using `profit_share', keep(3) nogen
    keep if edgebin == 5
    analyze_switch, spec("edge5")

    use `sample', clear
    merge m:1 nc4 using `profit_share', keep(3) nogen
    keep if edgebin == 4
    analyze_switch, spec("edge4")

    use `sample', clear
    merge m:1 nc4 using `profit_share', keep(3) nogen
    keep if edgebin == 4 | edgebin == 5
    analyze_switch, spec("edge45")

    use `sample', clear
    merge m:1 nc4 using `profit_share', keep(3) nogen
    keep if edgebin == 3
    analyze_switch, spec("edge3")
    
    use `sample', clear
    merge m:1 nc4 using `profit_share', keep(3) nogen
    keep if edgebin == 2 
    analyze_switch, spec("edge2")

    use `sample', clear
    merge m:1 nc4 using `profit_share', keep(3) nogen
    keep if edgebin == 1
    analyze_switch, spec("edge1")

    * largest S corp profit industries
    use `sample', clear
    merge m:1 nc4 using `profit_share', keep(3) nogen
    keep if profitbin == 5
    analyze_switch, spec("pbin5")

    * Top 10 transformer industries.
    use `sample', clear
    keep if inlist(nc4, 6211, 5511, 2389, 5242, 5411, 2382, 5239, 6212, 5415, 3329)
    analyze_switch, spec("top10tran") 

end/*%>*/

capture program drop graph_switch_eventstudies_v2/*%<*/
program define graph_switch_eventstudies_v2

    keep if tminus1sales > 100e3 & !mi(tminus1sales)

    keep if active96*active97 == 1

    gen D = event_time

    gen Dn5p = D <= -5
    gen Dn4=D == -4
    gen Dn3=D == -3
    gen Dn2=D == -2
    gen D0=D == 0
    gen D1=D == 1
    gen D2=D == 2
    gen D3=D == 3
    gen D4=D == 4
    gen D5p = D >=5 & D!=.
    gen nc3 = floor(nc4/10)

    bys ein: gen rowcount = _N
    bys ein: egen has4 = max(D4)
    bys ein: egen hasn4 = max(Dn4)
    gen balanced = (rowcount >= 9 & rowcount != . & has4 == 1 & hasn4 == 1)

    gen hasDYeventH = (D0 == 1 & year >= 2005 & year <= 2010)
    bys ein: egen hasDYevent = max(hasDYeventH)

    * Graphs.
    tempfile sample
    save `sample'

    * baseline
    use `sample', clear
    keep if balanced == 1
    analyze_switch_v2, spec("all_bal")

    * service industry versus non-service industry
    use `sample', clear
    keep if balanced == 1
    keep if inlist(nc2, 51, 52, 54, 56, 61, 62)
    analyze_switch_v2, spec("service_bal") 

    use `sample', clear
    keep if balanced == 1
    keep if !inlist(nc2, 51, 52, 54, 56, 61, 62)
    analyze_switch_v2, spec("non-service_bal") 

    * high ownership share versus low ownership share
    use $dta/s_ownsharemax_byfirmyr.dta, clear
    duplicates drop ein tax_yr, force
    save $dta/dy_ownersharemax_nodups, replace
    
    tempfile ownshare
    use $dta/dy_ownersharemax_nodups, replace
    save `ownshare'

    use `sample', clear
    rename year tax_yr
    rename ein payer_tin
    merge 1:1 payer_tin tax_yr using `ownshare', keep(1 3)
    rename tax_yr year
    drop ein
    rename payer_tin ein
    gen hmoX = cond(inrange(ownsharemax, 0.5, 1) & D0 == 1, 1, .)
    replace hmoX = cond(inrange(ownsharemax, 0.001, 0.499) & D0 == 1, 0, hmoX)
    bys ein: egen has_majority_owner = max(hmoX)
    drop hmoX
    tempfile sample_own
    save `sample_own'

    use `sample_own', clear
    keep if balanced == 1
    keep if has_majority_owner == 1
    analyze_switch_v2, spec("yesmajority_bal") 

    use `sample_own', clear
    keep if balanced == 1
    keep if has_majority_owner == 0
    analyze_switch_v2, spec("nomajority_bal") 

end/*%>*/

capture program drop xp_labor_capital/*%<*/
program define xp_labor_capital

    ***************************************************************************
    * SOI Switchers
    ***************************************************************************

    ***************************************************************************
    * Pop Switchers
    ***************************************************************************
    make_pop_switchers
    use $dta/popswitchers_20170705, clear
    tempfile popswitch
    save `popswitch'
	
    graph_switch_eventstudies_v2
    pstopdf $out

end/*%>*/

capture program drop make_sty_collapse/*%<*/
program define make_sty_collapse
    syntax, [yr(string)]

    tempfile orig
    * Industry comparisons
    load_analysis_data, yr("`yr'") 
    duplicates drop ein, force
    gen here = 1
    save `orig'
    collapse (sum) ass profits sales numw2 count=here, by(nc4 own_toppt1)
    gen yr = 2000 + `yr'
    usd2014, var(ass) yr(yr)
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    outsheet using "nc4_top_collapse_20`yr'.csv", comma replace
    keep if count >= 10
    outsheet using "nc4_top_collapse_20`yr'_masked.csv", comma replace
    insheet using "nc4_top_collapse_20`yr'.csv", clear
    gen nc1 = floor(nc4/1e3)
    collapse (sum) ass profits sales numw2 count, by(nc1 own_toppt1)
    outsheet using "nc1_top_collapse_20`yr'.csv", comma replace

    * NC4 for top 1 percent.
    use `orig', clear
    collapse (sum) ass profits sales numw2 count=here, by(nc4 own_top1)
    gen yr = 2000 + `yr'
    usd2014, var(ass) yr(yr)
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    outsheet using "nc4_top1_collapse_20`yr'.csv", comma replace
    keep if count >= 10
    outsheet using "nc4_top1_collapse_20`yr'_masked.csv", comma replace
    insheet using "nc4_top1_collapse_20`yr'.csv", clear
    gen nc1 = floor(nc4/1e3)
    collapse (sum) ass profits sales numw2 count, by(nc1 own_top1)
    outsheet using "nc1_top1_collapse_20`yr'.csv", comma replace

    * Top S corporation income by size bin
    use `orig', clear
    collapse (sum) ass profits sales numw2 count=here, by(nc4 sizebin own_toppt1)
    gen yr = 2000 + `yr'
    usd2014, var(ass) yr(yr)
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    outsheet using "nc4size_top_collapse_20`yr'.csv", comma replace
    keep if count >= 10
    outsheet using "nc4size_top_collapse_20`yr'_masked.csv", comma replace
    insheet using "nc4size_top_collapse_20`yr'.csv", clear
    collapse (sum) ass profits sales numw2 count, by(sizebin own_toppt1)
    outsheet using "size_top_collapse_20`yr'.csv", comma replace
    keep if count >= 10
    outsheet using "size_top_collapse_20`yr'_masked.csv", comma replace

end/*%>*/

capture program drop make_sty_collapse_app/*%<*/
program define make_sty_collapse_app
    syntax, [yr(string)]

    tempfile orig
    * Industry comparisons
    load_analysis_data, yr("`yr'") nofull("1")
    gen here = 1
    save `orig'
    gen toppt1 = (inrange(agibin,99.94,99.96))
    collapse (sum) profits=profits_app* sales=sales_app* ownercount=here, by(nc4 toppt1)
    gen yr = 2000 + `yr'
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    format profits sales %15.0g
    outsheet using "nc4_top_collapse_20`yr'_app.csv", comma replace
    keep if ownercount >= 10
    outsheet using "nc4_top_collapse_20`yr'_appmasked.csv", comma replace

    * NC4 for top 1 percent.
    use `orig', clear
    gen top1 = (inrange(agibin,99,100))
    collapse (sum) profits=profits_app* sales=sales_app* ownercount=here, by(nc4 top1)
    gen yr = 2000 + `yr'
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    format profits sales %15.0g
    outsheet using "nc4_top1_collapse_20`yr'_app.csv", comma replace
    keep if ownercount >= 10
    outsheet using "nc4_top1_collapse_20`yr'_appmasked.csv", comma replace

end/*%>*/

capture program drop make_sty_collapse_pship/*%<*/
program define make_sty_collapse_pship
    syntax, [yr(string)]

    tempfile orig
    * Industry comparisons
    load_analysis_data, yr("`yr'") pship(1)
    duplicates drop ein, force
    gen here = 1
    save `orig'
    collapse (sum) ass profits sales numw2 count=here, by(nc4 own_toppt1)
    gen yr = 2000 + `yr'
    usd2014, var(ass) yr(yr)
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    outsheet using "nc4_top_collapse_pship_20`yr'.csv", comma replace
    keep if count >= 10
    outsheet using "nc4_top_collapse_pship_20`yr'_masked.csv", comma replace
    insheet using "nc4_top_collapse_pship_20`yr'.csv", clear
    gen nc1 = floor(nc4/1e3)
    collapse (sum) ass profits sales numw2 count, by(nc1 own_toppt1)
    outsheet using "nc1_top_collapse_pship_20`yr'.csv", comma replace

    * NC4 for top 1 percent.
    use `orig', clear
    collapse (sum) ass profits sales numw2 count=here, by(nc4 own_top1)
    gen yr = 2000 + `yr'
    usd2014, var(ass) yr(yr)
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    outsheet using "nc4_top1_collapse_pship_20`yr'.csv", comma replace
    keep if count >= 10
    outsheet using "nc4_top1_collapse_pship_20`yr'_masked.csv", comma replace
    insheet using "nc4_top1_collapse_pship_20`yr'.csv", clear
    gen nc1 = floor(nc4/1e3)
    collapse (sum) ass profits sales numw2 count, by(nc1 own_top1)
    outsheet using "nc1_top1_collapse_pship_20`yr'.csv", comma replace

end/*%>*/

capture program drop make_sty_collapse_pship_app/*%<*/
program define make_sty_collapse_pship_app
    syntax, [yr(string)]

    tempfile orig
    * Industry comparisons
    load_analysis_data, yr("`yr'") pship(1)
    gen here = 1
    save `orig'
    gen toppt1 = (inrange(agibin,99.94,99.96))
    collapse (sum) profits=profits_app* sales=sales_app* ownercount=here, by(nc4 toppt1)
    gen yr = 2000 + `yr'
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    format profits sales %15.0g
    outsheet using "nc4_top_collapse_pship_20`yr'_app.csv", comma replace
    keep if ownercount >= 10
    outsheet using "nc4_top_collapse_pship_20`yr'_appmasked.csv", comma replace

    * NC4 for top 1 percent.
    use `orig', clear
    gen top1 = (inrange(agibin,99,100))
    collapse (sum) profits=profits_app* sales=sales_app* ownercount=here, by(nc4 top1)
    gen yr = 2000 + `yr'
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    format profits sales %15.0g
    outsheet using "nc4_top1_collapse_pship_20`yr'_app.csv", comma replace
    keep if ownercount >= 10
    outsheet using "nc4_top1_collapse_pship_20`yr'_appmasked.csv", comma replace

end/*%>*/

capture program drop filter_indy/*%<*/
program define filter_indy

    keep if nc4 > 999 & nc4 != .

    gen nc1 = floor(nc4/1e3)

    gen naics_des=""
    replace naics_des="NAICS 1: Agriculture & Forestry" if nc1 == 1
    replace naics_des="NAICS 2: Construction & Mining" if nc1 == 2
    replace naics_des="NAICS 3: Manufacturing" if nc1 == 3
    replace naics_des="NAICS 4: Retail & Wholesale Trade" if nc1 == 4
    replace naics_des="NAICS 5: Information & Professional Services" if nc1 == 5
    replace naics_des="NAICS 6: Health Care" if nc1 == 6
    replace naics_des="NAICS 7: Entertainment, Food, & Hotels" if nc1 == 7
    replace naics_des="NAICS 8: Other Services" if nc1 == 8

    * 9 is an unknown category
    keep if nc1 < 9

end/*%>*/

capture program drop make_markup_collapse/*%<*/
program define make_markup_collapse
    syntax, [yr(string)]

    tempfile orig
    load_analysis_data, yr("`yr'") 
    duplicates drop ein, force
    gen here = 1

    gen yr = 2000 + `yr'
    usd2014, var(ass) yr(yr)
    usd2014, var(profits) yr(yr)
    usd2014, var(sales) yr(yr)
    drop yr
    save `orig'

    * Generate markups and profits per worker
    gen markup = profits/(sales - profits) 
    gen profits_w2 = profits/numw2
    gen margin = profits/sales

    foreach v of varlist markup-margin {
        bys nc4: egen `v'_p94 = pctile(`v'), p(94)
        bys nc4: egen `v'_p95 = pctile(`v'), p(95)
        bys nc4: egen `v'_p96 = pctile(`v'), p(96)

        bys nc4: egen `v'_p49 = pctile(`v'), p(49)
        bys nc4: egen `v'_p50 = pctile(`v'), p(50)
        bys nc4: egen `v'_p51 = pctile(`v'), p(51)
    }
    bys nc4: gen num_firms = _N
    duplicates drop nc4, force
    foreach v of varlist markup-margin {
        gen `v'_p95s = (`v'_p94 + `v'_p95 + `v'_p96)/3
        gen `v'_p50s = (`v'_p49 + `v'_p50 + `v'_p51)/3
    }
    keep *_p50s *_p95s num_firms nc4
    outsheet using "nc4_markup_collapse_20`yr'.csv", comma replace
    keep if num_firms >= 10
    outsheet using "nc4_markup_collapse_20`yr'_masked.csv", comma replace

end/*%>*/

capture program drop xp_stylized_facts/*%<*/
program define xp_stylized_facts

    **************************
    * Build collapsed data
    **************************
    make_sty_collapse_pship_app, yr("00")
    make_sty_collapse_pship_app, yr("01")
    make_sty_collapse_pship_app, yr("02")
    make_sty_collapse_pship_app, yr("03")
    make_sty_collapse_pship_app, yr("04")
    make_sty_collapse_pship_app, yr("05")
    make_sty_collapse_pship_app, yr("06")
    make_sty_collapse_pship_app, yr("07")
    make_sty_collapse_pship_app, yr("08")
    make_sty_collapse_pship_app, yr("09")
    make_sty_collapse_pship_app, yr("10")
    make_sty_collapse_pship_app, yr("11")
    make_sty_collapse_pship_app, yr("12")
    make_sty_collapse_pship_app, yr("13")
    make_sty_collapse_pship_app, yr("14")

end/*%>*/

capture program drop make_risk_collapse/*%<*/
program define make_risk_collapse
    syntax, [yr(string)]

    tempfile orig
    load_analysis_data, yr("`yr'") nofull("1")

    keep if sales_14dollars > 5e6 & agibin > 90
    rename pm pm_firm

    bys tin: egen zz_p = total(profits_apportioned)
    bys tin: egen zz_s = total(sales_apportioned)
    gen pm = zz_p/zz_s
    drop zz*
    foreach var in pm {
        replace `var'=. if !inrange(`var',-1,1)
    }

    gen here = 1
    collapse (sum) count=here (mean) pm_mean=pm (sd) pm_sd=pm [w=one_tinnumrows_allfirms], by(tax_yr agibin)
    outsheet using "hockey_risk_collapse_20`yr'.csv", comma replace

end/*%>*/

capture program drop xp_risk_overtime/*%<*/
program define xp_risk_overtime

    **************************
    * Build collapsed data
    **************************
    make_risk_collapse, yr("00")
    make_risk_collapse, yr("01")
    make_risk_collapse, yr("02")
    make_risk_collapse, yr("03")
    make_risk_collapse, yr("04")
    make_risk_collapse, yr("05")
    make_risk_collapse, yr("06")
    make_risk_collapse, yr("07")
    make_risk_collapse, yr("08")
    make_risk_collapse, yr("09")
    make_risk_collapse, yr("10")
    make_risk_collapse, yr("11")
    make_risk_collapse, yr("12")
    make_risk_collapse, yr("13")
    make_risk_collapse, yr("14")

end/*%>*/

*******************************************************************************
* Main
*******************************************************************************
capture program drop main
program define main

    set trace on

    set tracedepth 2
    xp_labor_capital

    set tracedepth 2
    
    pstopdf ${out}

end

main
