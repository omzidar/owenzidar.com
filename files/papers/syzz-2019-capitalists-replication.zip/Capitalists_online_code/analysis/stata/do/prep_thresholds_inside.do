***************************************************************************
*PREP THRESHOLDS INSIDE
***************************************************************************

  *PREP THRESHOLDS
  use ${raw}/pikettysaez_nomthresholds_imputed_topdecile_forxtile, clear
  keep fractile nocg*
  reshape long nocg_thresholds_, i(fractile) j(y)
  save ${dump}/temp_thresholds, replace
  sum y
  local rmin = r(min)
  local rmax = r(max)
  forv y=`rmin'/`rmax' {
    use ${dump}/temp_thresholds if y==`y', clear
    drop y
    save ${dump}/ps_nocg_thresholds_`y', replace
  }

  *PREP THRESHOLDS (WITH CAPITAL GAINS)
  use ${raw}/pikettysaez_nomthresholds_imputed_topdecile_forxtile, clear
  keep fractile wcg*
  reshape long wcg_thresholds_, i(fractile) j(y)
  save ${dump}/temp_thresholds, replace
  sum y
  local rmin = r(min)
  local rmax = r(max)
  forv y=`rmin'/`rmax' {
    use ${dump}/temp_thresholds if y==`y', clear
    drop y
    save ${dump}/ps_wcg_thresholds_`y', replace
  }

  *PREP TAX SCHEDULES
  insheet using ${raw}/income_tax_schedules.csv, comma clear
  rename tax_yr y
  save ${dump}/temp_thresholds, replace 
  sum y
  local rmin = r(min)
  local rmax = r(max)
  forv y=`rmin'/`rmax' {
    use ${dump}/temp_thresholds if y==`y', clear
    reshape wide itbracket* itmtr*, i(y) j(mars)
    drop y
    save ${dump}/income_tax_schedule_`y', replace
  }
  insheet using ${raw}/payroll_tax_schedules.csv, comma clear
  rename tax_yr y
  save ${dump}/temp_thresholds, replace 
  sum y
  local rmin = r(min)
  local rmax = r(max)
  forv y=`rmin'/`rmax' {
    use ${dump}/temp_thresholds if y==`y', clear
    drop y
    save ${dump}/payroll_tax_schedule_`y', replace
  }
