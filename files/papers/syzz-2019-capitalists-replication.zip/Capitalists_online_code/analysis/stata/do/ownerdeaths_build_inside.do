global firstyear = 2001
global lastyear  = 2014
global odfirstyear = 2005
global odlastyear = 2010
global eventfirstyear = 100 - ($odfirstyear-$firstyear)
global eventlastyear = 100 + ($lastyear-$odlastyear)
global firmvarlist = "profits sales numw2 costsold"
global firmvarlist_ = "profits_ sales_ numw2_ costsold_"
global firmvarlist_dollarvars = "profits sales costsold"
global minsales = 100000


****************************************************
* 1. RUN OWNERDEATHS BUILDS
****************************************************
foreach orgforminput in "s" "p" {
  ownerdeaths_build_prep, orgform("`orgforminput'")
  ownerdeaths_build, ageminimum(0) agemaximum(64) orgform("`orgforminput'")
  ownerdeaths_build, ageminimum(75) agemaximum(100) orgform("`orgforminput'")
}
use $dta/ownerdeaths_build_s_0_64, clear
append using $dta/ownerdeaths_build_p_0_64
drop odid odhsid
egen odid = group(ein_od tin_od)
egen odhsid = group(ein_od tin_od ein_hs tin_hs)
save $dta/ownerdeaths_build_sp_0_64, replace
use $dta/ownerdeaths_build_s_75_100, clear
append using $dta/ownerdeaths_build_p_75_100
drop odid odhsid
egen odid = group(ein_od tin_od)
egen odhsid = group(ein_od tin_od ein_hs tin_hs)
save $dta/ownerdeaths_build_sp_75_100, replace


*******************************************************************************
* 2. SHUTDOWN/REORG PREP: OWNER DEATH SHUTDOWN YEAR
*******************************************************************************
local mainsampagemin=0
local mainsampagemax=64
*GRAB EIN AND SHUTDOWN YEAR
foreach suffix in od hs {
  use ein_`suffix' tin_`suffix' year year_var sales_`suffix' using $dta/ownerdeaths_build_sp_`mainsampagemin'_`mainsampagemax' if year>=year_var, clear
  duplicates drop
  gen zerosalesyear = year if sales_`suffix'==0
  bys ein_`suffix' tin_`suffix': egen shutdownyear = min(zerosalesyear)
  keep if sales_`suffix'==0 & year==year_var+4
  keep ein_`suffix' shutdownyear
  rename ein_`suffix' ein
  duplicates drop
  duplicates report ein
  gsort ein -shutdownyear
  **ZERO OBS DELETED BY CONSTRUCTION FOR ein_od. POSITIVE (ONLY ONE) OBS DELETED FOR ein_hs, SINCE WE ALLOW
  ** THE SAME COUNTERFACTUAL FIRM TO BE MATCHED TO MULTIPLE OWNER DEATH FIRMS.
  by ein: keep if _n==1
  save ${dump}/tempshutdownyear_`suffix', replace
}
*GRAB numw2 FROM THE YEAR BEFORE THE SHUTDOWN AND YEAR OF THE SHUTDOWN
foreach suffix in od hs {
  *MAKE UNIQUE ON ein_`suffix'-year SINCE THE DATA ARE UNIQUE ONLY ON ein_od-tin_od-year (IE A FIRM
  * CAN HAVE MULTIPLE OWNER DEATHS)
  use ein_`suffix' year numw2_`suffix' using $dta/ownerdeaths_build_sp_`mainsampagemin'_`mainsampagemax', clear
  duplicates drop ein_`suffix' year, force
  save ${dump}/temp_od_build, replace
  *MERGE ON numw2 FROM THE YEAR BEFORE THE SHUTDOWN
  use ${dump}/tempshutdownyear_`suffix', clear
  rename ein ein_`suffix'
  rename shutdownyear year
  replace year = year-1
  merge 1:1 ein_`suffix' year using ${dump}/temp_od_build, keepusing(numw2_`suffix') keep(1 3)
  assert _merge==3
  drop _merge
  rename numw2_`suffix' numw2_l1
  *MERGE ON numw2 FROM THE YEAR AFTER THE SHUTDOWN
  replace year = year+1
  merge 1:1 ein_`suffix' year using ${dump}/temp_od_build, keepusing(numw2_`suffix') keep(1 3)
  assert _merge==3
  drop _merge
  rename numw2_`suffix' numw2_f0
  *SAVE
  rename ein_`suffix' ein
  rename year shutdownyear
  save ${dump}/tempshutdownyear_`suffix', replace
}
*OUTSHEET
use ${dump}/tempshutdownyear_od, clear
append using ${dump}/tempshutdownyear_hs
duplicates tag ein, gen(zztag)
assert zztag==0
drop zz*
sort ein
save $dta/ownerdeaths_shutdownyear, replace
tostring ein, replace
replace ein = "0" + ein if length(ein)<9
replace ein = "0" + ein if length(ein)<9
assert length(ein)==9
saveold $dta/ownerdeaths_shutdownyear_einstring, replace v(12)


*******************************************************************************
* 3. SHUTDOWN/REORG PREP: REORG STATS, AFTER HARVESTING SAS OUTPUT
*******************************************************************************
local mainsampagemin=0
local mainsampagemax=64
*COLLECT THE OWNER TIN ASSOCIATED WITH EACH FIRM
use ein_od tin_od year year_var using $dta/ownerdeaths_build_sp_`mainsampagemin'_`mainsampagemax' if year==year_var, clear
drop year*
rename ein_od ein
rename tin_od owner_tin
save ${dump}/temp_od_build, replace
use ein_hs tin_hs year year_var using $dta/ownerdeaths_build_sp_`mainsampagemin'_`mainsampagemax' if year==year_var, clear
drop year*
rename ein_hs ein
rename tin_hs owner_tin
append using ${dump}/temp_od_build
duplicates drop
save ${dump}/temp_ownertins, replace
*ADD FIRMS THAT HAD WORKERS IN T-1 BUT DIDN'T GET MATCHED TO ANY SUBSEQUENT WORKERS
use ein shutdownyear dead_tin worker_tin payer_tin year_nf year_df using $raw/ownerdeaths_shutdownyear_50, clear
keep if year_df==shutdownyear-1
drop year_df
duplicates drop
**CONFIRM THAT THERE'S ONLY EVER TWO COPIES OF EACH DEADFIRM-WORKER-NEXTFIRM PAIR
duplicates tag shutdownyear dead_tin worker_tin payer_tin, gen(zztag)
assert zztag<=1
drop zz*
destring ein, replace
joinby ein using ${dump}/temp_ownertins, _merge(_merge) unmatched(both)
assert _merge!=1
keep if _merge==3
drop _merge
**REMOVE THE OWNER TIN FROM CONSIDERATION AS A WORKER
drop if owner_tin==worker_tin
**REMOVE THE DEAD FIRM FROM CONSIDERATION AS A NEXT FIRM
drop if dead_tin==payer_tin
**COLLAPSE BY DEADFIRM-OWNER-NEXTFIRM-NEXTFIRMYEAR
collapse (count) freq=worker_tin, by(ein shutdownyear owner_tin payer_tin year_nf)
**SAVE ONLY THE LARGEST COUNT FOR EACH DEADFIRM-OWNER-NEXTFIRM-NEXTFIRMYEAR PAIR
replace year_nf=0 if year_nf==shutdownyear-1
replace year_nf=1 if year_nf==shutdownyear
assert inlist(year_nf,0,1)
gsort ein shutdownyear owner_tin year_nf -freq
by ein shutdownyear owner_tin year_nf: keep if _n==1
drop payer_tin
rename freq maxfreq_
reshape wide maxfreq, i(ein shutdownyear owner_tin) j(year_nf)
save ${dump}/temp_firmownernextfirmcounts, replace
*COMPUTE COUNTS OF TOTAL T-1 WORKERS PER FIRM-OWNER PAIR
**START WITH THE _40 MATCHES
use ein shutdownyear dead_tin worker_tin year_df using $raw/ownerdeaths_shutdownyear_40, clear
keep if year_df==shutdownyear-1
drop year_df
destring ein, replace
joinby ein using ${dump}/temp_ownertins, _merge(_merge) unmatched(both)
assert _merge!=1
keep if _merge==3
drop _merge
**REMOVE THE OWNER TIN FROM CONSIDERATION AS A WORKER, BUT SAVE WITH OWNERS IN ORDER TO DO VALIDATION BELOW
save ${dump}/temp_withworkerowners, replace
drop if owner_tin==worker_tin
**COLLAPSE TO GET TOTAL COUNTS OF THE FIRM-OWNER PAIR'S NUMBER OF T-1 WORKERS
collapse (count) totfreq_0=worker_tin, by(ein shutdownyear owner_tin)
*MERGE TOTAL DEAD FIRM COUNT TO NEXT FIRM COUNTS
merge 1:1 ein shutdownyear owner_tin using ${dump}/temp_firmownernextfirmcounts
assert _merge!=2
drop _merge
*COMPUTE NEXT FIRM SHARES
forv t=0/1 {
  replace maxfreq_`t'=0 if maxfreq_`t'==.
  gen maxshare_`t' = maxfreq_`t'/totfreq_0
  sum maxshare_`t'
  assert r(min)>=0
  assert r(max)<=1
}
*SAVE
gen reorg = maxshare_0>.5 | maxshare_1>.5
save $dta/ownerdeaths_reorgs, replace
