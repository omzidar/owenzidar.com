clear
forv t=2001/2014 {
  append using $dta/s_firmowner_`t', keep(ein payer_tin tax_yr ownshare)
}
collapse (max) ownsharemax=ownshare, by(ein payer_tin tax_yr)
save ${dta}/s_ownsharemax_byfirmyr, replace
