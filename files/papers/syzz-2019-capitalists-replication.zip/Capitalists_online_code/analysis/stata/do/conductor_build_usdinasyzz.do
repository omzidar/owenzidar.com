do headers.do
cd ${logs}

********************************************************************************
** Toggles
local onlydraft 0
local onlytop1per 0
********************************************************************************

do ${do}/build_usdinasyzz_${buildusdinasyzzversion}

********************************************************************************
** NUMBER OF SUBSHELL TOGGLES
local p 5 // number of programs running at once
local i 1 // indexes the number of subshells started
********************************************************************************

if `onlydraft' != 1 {
*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
** Run build_usdinasyzz in a combination of parellel and not
** For labor shares 750 and 999: 1962-2014
** For labor shares 500, 600, 700, 800: JUST 2014
*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

foreach ls of numlist $labshare_list_build {
	/*

	PROGRAMS TO RUN:
		merge_vars_def_ranks, labshareofpt000(${labshareofpt000})
		ps_psz_clps, labshareofpt000(${labshareofpt000})
		build_usdinasyzz, labshareofpt000(${labshareofpt000})
		add_tin_parranks, labshareofpt000(${labshareofpt000})
		add_wagess_wagesp, labshareofpt000(${labshareofpt000})
		outsheet_thresholds, labshareofpt000(${labshareofpt000})
		*download_payertinw2maxsmax
		merge_ccorpwages, labshareofpt000(${labshareofpt000})
		*log c
		
	HOW THEY ARE RUN:	
	-Parallel part 1:
		merge_vars_def_ranks, labshareofpt000(${labshareofpt000})
		ps_psz_clps_wide , labshareofpt000(${labshareofpt000})

	-Not in parallel:
		ps_psz_clps, labshareofpt000(${labshareofpt000})
		
	-Not in paralllel:
		clps_top1pt1_append , labshareofpt000(${labshareofpt000})	
		
	-Parallel part 2:
		build_usdinasyzz, labshareofpt000(${labshareofpt000})
		add_tin_parranks, labshareofpt000(${labshareofpt000})
		add_wagess_wagesp, labshareofpt000(${labshareofpt000})
		
	-Not in parallel:
		outsheet_thresholds, labshareofpt000(${labshareofpt000})
		merge_ccorpwages, labshareofpt000(${labshareofpt000})

	*/


	global labshareofpt000 = `ls'

	if `ls' == 750 | `ls' == 999 {
		global yrmin = $yrmin_absol
		global yrmax = $yrmax_absol
	}
	else {
		global yrmin = 2014
		global yrmax = 2014
	}
	

	
	if `onlytop1per' != 1 {

	********************************************************************************
	*** Parallel part 1:
	local part = 1
	di "$yrmin to $yrmax"
	foreach yr of numlist $yrmin/$yrmax  {
		di "year= `yr'"		
		* add command to cmd
		local cmd `cmd' (stata-mp -b do ${do}/master_usdinasyzz_dy_${version}_parallel_full.do `ls' `yr' `part' ${buildusdinasyzzversion} & disown -h);

		if mod(`i', `p') ==0 | (`yr' == ${yrmax}) {
			*  run only on multiples of p or if at end of the loops
			
			di ""
			di ""
			di "running `cmd'"
			!`cmd'
			
			*  reset cmd
			local cmd
		}

		local ++i

	}
	********************************************************************************

	********************************************************************************
	*** Non parallel part
	ps_psz_clps, labshareofpt000(${labshareofpt000})
	********************************************************************************
	}
	
	********************************************************************************
	*** Non parallel part
	clps_top1pt1_append , labshareofpt000(${labshareofpt000})
	********************************************************************************

	********************************************************************************
	*** Parallel part 2:
	local part = 2
	local i 1 // indexes the number of subshells started

	foreach yr of numlist $yrmin/$yrmax  {

		* add command to cmd
		local cmd `cmd' (stata-mp -b do ${do}/master_usdinasyzz_dy_${version}_parallel_full.do `ls' `yr' `part' ${buildusdinasyzzversion} & disown -h);

		if mod(`i', `p') ==0 | (`yr' == ${yrmax}) {
			* run only on multiples of p or if at end of the loops
			di ""
			di ""
			di "running `cmd'"
			!`cmd'
			
			* reset cmd
			local cmd
		}

		local ++i

	}
	********************************************************************************


	********************************************************************************
	*** Non parallel part
	outsheet_thresholds, labshareofpt000(${labshareofpt000})
	
	** added after replication effort was begun!
	download_payertinw2maxsmax
	merge_ccorpwages, labshareofpt000(${labshareofpt000})
	********************************************************************************

}

}

*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
** Run draft_usdinasyzz in a combination of parellel and not
** For labor shares 750: 1962-2014
** For labor shares 500, 600, 700, 800: JUST 2014
*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

local i 1 // indexes the number of subshells started
local part = 3
local yr = 5555
local n_labshares : word count $labshare_list
local last_labshare : word `n_labshares' of $labshare_list
foreach ls of numlist $labshare_list {

	* add command to cmd
	local cmd `cmd' (stata-mp -b do ${do}/master_usdinasyzz_dy_${version}_parallel_full.do `ls' `yr' `part' ${draftusdinasyzzversion} & disown -h);

	if mod(`i', `p') ==0 | (`ls' == `last_labshare') {
		* run only on multiples of p or if at end of the loops
		
		di ""
		di ""
		di "running `cmd'"
		!`cmd'
		
		* reset cmd
		local cmd
		
	}

	local ++i

}



