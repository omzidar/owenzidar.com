args ls yr part version

do ../headers.do

log using ${logs_usdinasyzz}/build_usdinasyzz_`yr'_parallel`part'_`ls' , text replace
di "$S_DATE $S_TIME"


cd ${dump}
display "$S_TIME  $S_DATE"

*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* BUILD_USDINASYZZ - PARALLEL PARTS ONLY
*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
if inrange(`part', 1, 2) {

	*SUBSTANTIVE GLOBALS

	if "`ls'"  == "750" | "`ls'" == "999" {
		global yrmin_absol = 1962
		global yrmax_absol = 2016
	}
	else {
		global yrmin_absol = 2014
		global yrmax_absol = 2014
	}

	global yrmin = `yr'
	global yrmax = `yr'


    global labshareofpt000 = `ls'

    *BUILD
    do ${do}/build_usdinasyzz_${buildusdinasyzzversion}
    
    if `part' == 1 {
        merge_vars_def_ranks, labshareofpt000(${labshareofpt000})
        ps_psz_clps_wide , labshareofpt000(${labshareofpt000})
    }
    
    if `part' == 2 {
        build_usdinasyzz, labshareofpt000(${labshareofpt000})
        add_tin_parranks, labshareofpt000(${labshareofpt000})
        add_wagess_wagesp, labshareofpt000(${labshareofpt000})
    }
    
}


*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
* BUILD_USDINASYZZ - 2014 COLLAPSE FOR ALL LABOR SHARES
*				   - FULL COLLAPSE FOR ONLY LABOR SHARE 750
*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
if `part' == 3 {

	global labshareofpt000 = `ls'

	*ANALYSIS
	do ${do}/draft_usdinasyzz_${draftusdinasyzzversion}
	
	* 2014 COLLAPSE
	global yrmin = 2014
	global yrmax = 2014
	usdinasyzz_2014clps, labshareofpt000(${labshareofpt000})
	
	
	
	if `ls' == 750 {
		global yrmin = 1962
		global yrmax = 2016
		usdinasyzz_mainclps, labshareofpt000(${labshareofpt000})
	
	}
	
}


di "$S_DATE $S_TIME"
