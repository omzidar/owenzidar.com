*******************************************************************************
* 1. Load data
*******************************************************************************
local yr=2014
use $dta/newsoi_20170210.dta, clear
keep if year==`yr'

keep if inlist(return_type,2,8,14,20)
*******************************************************************************
*2. IDENTIFY Ccorp and Scorps
*******************************************************************************
g scorp = inlist(return_type,2) 
g ccorp = inlist(return_type,8,14,20)

*******************************************************************************
*3. Industry Shares 
*******************************************************************************
gen nc4 = floor(standard_naics/100)
gen nc1 = floor(nc4/1000)

g Nfirms=1
tabstat Nfirms  [weight=weight_f], stats(sum) by(nc1)
tabstat Nfirms if scorp [weight=weight_f], stats(sum) by(nc1)
tabstat Nfirms if ccorp [weight=weight_f], stats(sum) by(nc1)

*******************************************************************************
*4. bring to 2014 dollars
*******************************************************************************
*NOTE THAT THIS PROGRAM ONLY GOES BACK TO 93
capture drop year
g year=`yr'
assert year>1993
usd2014, var(sale) yr(year)
usd2014, var(profits) yr(year)
usd2014, var(labor_comp) yr(year)
usd2014, var(officer_comp) yr(year)
usd2014, var(capital) yr(year)
usd2014, var(investment) yr(year)

*******************************************************************************
*5. Sales Size Shares 
*******************************************************************************
*make in USD
rename sale sales
replace sales=sales*1000

g sale500K_1M  = (sales>=500000    &sales<1000000) 
g sale1M_5M    = (sales>=1000000   &sales<5000000) 
g sale5M_10M   = (sales>=5000000   &sales<10000000)
g sale10M_50M  = (sales>=10000000  &sales<500000000)
g sale50M_500M = (sales>=50000000  &sales<5000000000)
g sale500Mplus = (sales>=500000000 &!mi(sales))

g salebin2 = -1
replace salebin2 = 0 if sale500K_1M 
replace salebin2 = 1 if sale1M_5M   
replace salebin2 = 2 if sale5M_10M  
replace salebin2 = 3 if sale10M_50M 
replace salebin2 = 4 if sale50M_500M 
replace salebin2 = 5 if sale500Mplus   


*100K
g salebin3= -1
forv i= 0/501{
local j=`i'+1
replace salebin3 = `i' if (sales>=`i'*100000    &sales<`j'*100000)
}
replace salebin3 = 501 if (sales>=50100000 &!mi(sales))


*MILLIONS
g salebin4= -1
forv i= 0/300{
local j=`i'+1
replace salebin4 = `i' if (sales>=`i'*1000000    &sales<`j'*1000000)
}
replace salebin4 = 300 if (sales>=300*1000000 &!mi(sales))

*10MILLION
g salebin5= -1
forv i= 0/101{
local j=`i'+1
replace salebin5 = `i' if (sales>=`i'*10000000    &sales<`j'*10000000)
}
replace salebin5 = 101 if (sales>=101*10000000 &!mi(sales))

*100MILLION
g salebin6= -1
forv i= 0/25{
local j=`i'+1
replace salebin6 = `i' if (sales>=`i'*100000000    &sales<`j'*100000000)
}
replace salebin6 = 25 if (sales>=25*100000000 &!mi(sales))


*make back K
replace sales=sales/1000
rename sales sale
*******************************************************************************
*6. Export
*******************************************************************************

tempfile data_all
save `data_all'

local varlist "Nfirms sale profits labor_comp officer_comp capital investment"

use `data_all', clear
collapse (sum) `varlist' [iweight=weight_f], by(salebin2)
assert Nfirms>10
export delimited  using $out/sale_bins_soi_`yr'_totals.csv, replace

use `data_all', clear
keep if ccorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin2)
assert Nfirms>10
export delimited  using $out/sale_bins_soi_`yr'_ccorp.csv, replace


use `data_all', clear
keep if scorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin2)
assert Nfirms>10
export delimited  using $out/sale_bins_soi_`yr'_scorp.csv, replace

*******************************************************************************
*6.B Export
*******************************************************************************
use `data_all', clear
collapse (sum) `varlist' [iweight=weight_f], by(salebin3)
keep if Nfirms>10
export delimited  using $out/sale_bins100K_soi_`yr'_totals.csv, replace

use `data_all', clear
keep if ccorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin3)
keep if Nfirms>10
export delimited  using $out/sale_bins100K_soi_`yr'_ccorp.csv, replace


use `data_all', clear
keep if scorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin3)
keep if Nfirms>10
export delimited  using $out/sale_bins100K_soi_`yr'_scorp.csv, replace

*******************************************************************************
*6.C Export
*******************************************************************************
use `data_all', clear
collapse (sum) `varlist' [iweight=weight_f], by(salebin4)
keep if Nfirms>10
export delimited  using $out/sale_binsM_soi_`yr'_totals.csv, replace

use `data_all', clear
keep if ccorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin4)
keep if Nfirms>10
export delimited  using $out/sale_binsM_soi_`yr'_ccorp.csv, replace


use `data_all', clear
keep if scorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin4)
keep if Nfirms>10
export delimited  using $out/sale_binsM_soi_`yr'_scorp.csv, replace

*******************************************************************************
*6.D Export
*******************************************************************************
use `data_all', clear
collapse (sum) `varlist' [iweight=weight_f], by(salebin5)
keep if Nfirms>10
export delimited  using $out/sale_bins10M_soi_`yr'_totals.csv, replace

use `data_all', clear
keep if ccorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin5)
keep if Nfirms>10
export delimited  using $out/sale_bins10M_soi_`yr'_ccorp.csv, replace


use `data_all', clear
keep if scorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin5)
keep if Nfirms>10
export delimited  using $out/sale_bins10M_soi_`yr'_scorp.csv, replace


*******************************************************************************
*6.E Export
*******************************************************************************
use `data_all', clear
collapse (sum) `varlist' [iweight=weight_f], by(salebin6)
keep if Nfirms>10
export delimited  using $out/sale_bins100M_soi_`yr'_totals.csv, replace

use `data_all', clear
keep if ccorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin6)
keep if Nfirms>10
export delimited  using $out/sale_bins100M_soi_`yr'_ccorp.csv, replace


use `data_all', clear
keep if scorp
collapse (sum) `varlist' [iweight=weight_f], by(salebin6)
keep if Nfirms>10
export delimited  using $out/sale_bins100M_soi_`yr'_scorp.csv, replace

