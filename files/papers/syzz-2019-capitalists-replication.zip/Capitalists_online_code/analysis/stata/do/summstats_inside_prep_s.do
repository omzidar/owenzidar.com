*******************************************************************************
* SUMMSTATS_INSIDE
*******************************************************************************

*******************************************************************************
* Assign Firm Locals
*******************************************************************************
local firstyear = 2001
local lastyear  = 2014
local sizethresholdK = 0
local randomsample = 1.10
set seed 1

*******************************************************************************
* 1. PREP SCORP FIRMS DATA
*******************************************************************************

local varlist   = "penplded empbene va sales profits pm roa ass numw2 numw2nz wprofit_w2 Nowners sales_w2 profit_w2 profit_owner totownerpayment ownerpay_owner ownerpay_w2  ownerpay_profit ownerpay_sales ownerpay_va"

forv yr= `firstyear'/`lastyear' {
disp `yr'
use $dta/s_firmowner_`yr'.dta, clear
drop if ein == . 

g fullsample = 1

capture drop year
g year=`yr'

*IDENTIFY FIRMS WITH TOP OWNERS
g firm_own_top1    = own_top1 
g firm_own_toppt1  = own_toppt1 
g firm_own_top1nottoppt1 = (own_top1==1 & own_toppt1!=1)

*COMPUTE NUMBER OF TOP OWNERS
g anyowner = !mi(tin)
gen owner_top1 = inrange(agibin,99,100)
gen owner_toppt1 = inrange(agibin,99.94,100)
gen owner_top1nottoppt1 = (owner_top1==1 & owner_toppt1!=1)
egen Nowners       = total(anyowner), by(ein)
egen Ntop1owners   = total(owner_top1), by(ein)
egen Ntoppt1owners = total(owner_toppt1), by(ein)
egen Ntop1nottoppt1owners = total(owner_top1nottoppt1), by(ein)

g ownerpayment = ord_inc
replace ownerpayment = ord_inc + wages_max  if payer_tin==payer_tin_w2_max
replace ownerpayment = ord_inc + wages_smax if payer_tin==payer_tin_w2_smax

egen totownerpayment = total(ownerpayment), by(ein)

*KEEP ONE OBS PER FIRM
egen tag = tag(ein)
keep if tag == 1
drop tag

g u = runiform()
keep if u<`randomsample'

foreach i in sales costsold profits ass totownerpayment slwgljob compofcr intrded penplded empbene {
	*EXPRESS IN 2014 USD
	usd2014, var(`i') yr(year)

	*EXPRESS IN $K
	replace `i'   = `i'/1000
}

g sales_w2        = sales/numw2
g profit_w2       = profits/numw2
g wprofit_w2        = profits/numw2
g profit_owner    = profits/Nowners
g ownerpay_owner  = totownerpayment/Nowners
g ownerpay_w2	  = totownerpayment/numw2

g numw2nz = numw2
replace numw2nz = . if numw2 == 0
 
g ownerpay_profit = totownerpayment/profits
g ownerpay_sales  = totownerpayment/sales
g ownerpay_va = totownerpayment/(sales-costsold)
cap g va = (sales-costsold)
replace ownerpay_va = . if sales-costsold <= 0 

g ownerpay_psci = totownerpayment/(profits+slwgljob+compofcr+intrded)
g ownerpay_psc = totownerpayment/(profits+slwgljob+compofcr)
g profcomp_psci = (profits+compofcr)/(profits+slwgljob+compofcr+intrded)
g profcomp_psc = (profits+compofcr)/(profits+slwgljob+compofcr)

g b_ownerpay_psci = totownerpayment/(profits+slwgljob+compofcr+intrded)
g b_ownerpay_psc = totownerpayment/(profits+slwgljob+compofcr)
g b_profcomp_psci = (profits+compofcr)/(profits+slwgljob+compofcr+intrded)
g b_profcomp_psc = (profits+compofcr)/(profits+slwgljob+compofcr)


*SIZE RESTRICTION
keep if sales>(`sizethresholdK')

*TRIM
ds ownerpay_profit  b_*
foreach v in `r(varlist)' {
	summ `v', d
	replace `v' = r(p99) if `v' >= r(p99) & `v' != .
	replace `v' = r(p1) if `v' <= r(p1) & `v' != .
}

foreach v in ownerpay_sales ownerpay_va pm {
	replace `v' = 1 if `v' > 1 & `v' != .
	replace `v' = -1 if `v' < -1 & `v' != .
	assert abs(`v') <= 1 | `v' == .
}


replace ass = . if ass > 1000000000000/1000

keep `varlist' fullsample ein firm_own* year ownerpay_* profcomp_* totownerpayment slwgljob compofcr intrded b_*

save $dump/summstats_scorps_`yr'.dta, replace

}

*COMBINE YEARS
clear

forv yr= `firstyear'/`lastyear' {
disp `yr'
append using $dump/summstats_scorps_`yr'.dta
rm $dump/summstats_scorps_`yr'.dta
}


save $dump/summstats_scorps.dta, replace

egen ownerpay_ = total(totownerpayment)
egen profcomp_ = total(profits+compofcr)

egen psci = total( profits+slwgljob+compofcr+intrded )
egen psc = total( profits+slwgljob+compofcr)

g c_ownerpay_psci = ownerpay_/psci
g c_ownerpay_psc = ownerpay_/psc
g c_profcomp_psci = profcomp_/psci
g c_profcomp_psc = profcomp_/psc


save $dump/summstats_scorps.dta, replace


di "*____DONE WITH THE INPUT BUILD____*"
d

*******************************************************************************
* Assign Owners Locals
*******************************************************************************
local firstyear = 2001
local lastyear  = 2014
local sizethreshold = 0
local randomsample = 1.05
set seed 1
local manual    = "Nfirms totalwages own_top1 own_toppt1 onlypassive"
local varlist   = "totalnetcorpinc_psinc psinc age Nfirms totalwages totalord_inc totalnetcorpinc totalownerpayments own_top1 own_toppt1 own_top1nottoppt1 onlypassive ownerpay_psinc  wage_psinc ordinc_ownerpay owner_top1 owner_toppt1 owner_top1nottoppt1"

*******************************************************************************
* 3. PREP SCORP OWNER LEVEL DATA
*******************************************************************************

forv yr= `firstyear'/`lastyear' {
disp `yr'
use $dta/s_firmowner_`yr'.dta, clear

*Drop if ein is missing
drop if ein == .

g fullsample = 1

capture drop year
g year=`yr'

*FIRM SIZE RESTRICTION
usd2014, var(sales) yr(year)
keep if sales>(`sizethreshold')

*IDENTIFY NUMBER OF FIRMS
g anyfirm = !mi(ein)
egen Nfirms   = total(anyfirm), by(tin)
rename numw2 zznumw2
egen numw2 = total(zznumw2), by(tin)
drop zz*

*TOTAL THE INCOME VARIABLES THAT VARY ACROSS ROWS (FIRMS) WITHIN OWNERS
egen totalord_inc 		= total(ord_inc), by(tin)

*DEFINE INCOME VARIABLES
g totalownerpayments = totalord_inc
replace totalownerpayments = totalord_inc + wages_max  if payer_tin==payer_tin_w2_max
replace totalownerpayments = totalord_inc + wages_smax if payer_tin==payer_tin_w2_smax
g totalwages = wages_max
replace totalwages = wages_max + wages_smax if wages_smax!=.
replace totalwages=0 if totalwages==.
g totalnetcorpinc=corpinc -corploss
replace totalnetcorpinc=0 if totalnetcorpinc==.

*DEFINE AGE
gen age =`yr'-ssa_yob
replace age =.  if mi(ssa_yob)
replace age =.  if (ssa_yob==0)
replace age = . if mi(ssa_yob)
replace age=100 if age>100 & age!=.

*AGGREGATE THE FIRM-BASED SAMPLE DEFINITION VARS
rename own_top1 zzown_top1
rename own_toppt1 zzown_toppt1
egen own_top1 = max(zzown_top1), by(tin)
egen own_toppt1 = max(zzown_toppt1), by(tin)
drop zz*

*KEEP ONE OBS PER OWNER
egen tag = tag(tin)
keep if tag == 1
drop tag

*RANDOMLY SAMPLE FOR SPEED
set seed 1000
g u = runiform()
keep if u<`randomsample'

*EXPRESS IN 2014 USD
usd2014, var(totalwages) yr(year)
usd2014, var(totalord_inc) yr(year)
usd2014, var(totalnetcorpinc) yr(year)
usd2014, var(totalownerpayments) yr(year)
usd2014, var(psinc) yr(year)

*EXPRESS IN $K
foreach var in totalwages totalord_inc totalnetcorpinc totalownerpayments psinc{
replace `var'   = `var'/1000
}

*MORE OUTCOME VARS
g ownerpay_psinc  = totalownerpayments/psinc
g wage_psinc      = totalwages/psinc
g ordinc_ownerpay = totalord_inc/totalownerpayments
g totalnetcorpinc_psinc = totalnetcorpinc/psinc

*SET SAMPLE VARS
gen own_top1nottoppt1 = (own_top1==1 & own_toppt1!=1)
gen owner_top1 = inrange(agibin,99,100)
gen owner_toppt1 = inrange(agibin,99.94,100)
gen owner_top1nottoppt1 = (owner_top1==1 & owner_toppt1!=1)

drop if age==.

*TRIM
summ totalnetcorpinc_psinc, d
replace totalnetcorpinc_psinc = r(p99) if totalnetcorpinc_psinc >= r(p99) & totalnetcorpinc_psinc != .
replace totalnetcorpinc_psinc = r(p1) if totalnetcorpinc_psinc <= r(p1) & totalnetcorpinc_psinc != .


keep `varlist' fullsample tin numw2 year

save $dump/summstats_owners_`yr'.dta, replace
}
clear


forv yr= `firstyear'/`lastyear' {
disp `yr'
append using $dump/summstats_owners_`yr'.dta
rm $dump/summstats_owners_`yr'.dta
}
save $dump/summstats_owners_full.dta, replace

