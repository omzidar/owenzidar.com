qui {
capture program drop usdinasyzz_mainclps
program define usdinasyzz_mainclps
  syntax, labshareofpt000(int)
  
  local labshare_suff `labshareofpt000'
  local labshareofpt = `labshareofpt000'/1000

  *DEFINE INFLATORS
  use ${raw}/cpi_annual, clear
  qui sum year
  local cpiyrmin = r(min)
  local cpiyrmax = r(max)
  forv t=`cpiyrmin'/`cpiyrmax' {
   qui sum cpi_u_2015 if year==`t'
   local cpi`t' = r(mean)
  }
  
  *SAVE MANY COLLAPSES AS TEMPORARY DATASETS
  forv t=$yrmin/$yrmax {
    if !inlist(`t',1963,1965) {
	
	di " ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	di "on year `t'"
	di " ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
	
      forv equalsplit=0/1 {
	    foreach incdefn in fi ni {
		 if (`equalsplit'==0 & "`incdefn'"=="fi") | (`equalsplit'==1 & "`incdefn'"=="ni") {
		  use ${dta}/usdina`t'syzz_es`equalsplit'_`labshare_suff' , clear

          *SET WEIGHT, RANK, AND TOTAL INCOME VARS
		  if "`incdefn'"=="fi" {
		    local weightvar="dweghttaxu"
			local rankvar="rankprogtufn"
			gen tot = fninc
			order rank*, last
			replace age=. if !inrange(age,32,34)
			collapse (sum) fiinc-tot (mean) `weightvar' rank* age, by(id)
			duplicates tag id, gen(zztag)
			assert zztag==0
			drop zz*
		  }
		  else if "`incdefn'"=="ni" {
		    local weightvar="dweght"
			local rankvar="rankprogpt"
			gen tot = allinc
		  }
          
		  di "define income groups"
          *DEFINE INCOME GROUPS
          matrix input cumul = (0, .5, .9, .95, .99, .995, .999, .9999)
          **ALL
          g inc_group1 = 1 if `rankvar'>=cumul[1,1]
          **TOP 10%
          g inc_group2 = 1 if `rankvar'>=cumul[1,3]
          **TOP 1%
          g inc_group3 = 1 if `rankvar'>=cumul[1,5]
          **MILLIONAIRES
          g inc_group4 = 1 if tot>=1000000*`cpi`t''/`cpi2014'
          **TOP .1%
          g inc_group5 = 1 if `rankvar'>=cumul[1,7]
          **TOP .01%
          g inc_group6 = 1 if `rankvar'>=cumul[1,8]
          
		  *DEFINE KEY DOLLAR VARS
		  **CREATE WAGES-FROM-FIRM AND PAR RANK VARS IF THEY DON'T EXIST, IE FOR YEARS <2000 and <1990
		  foreach var in wagess wagess_noi wagesp wagesp_noi {
		    capture gen `var'=0
		  }
		  foreach var in rankparcoll rankparige igewgt {
		    capture gen `var'=.
		  }

		  **PROCEED
		  if "`incdefn'"=="fi" {
			gen s = scorinc
			gen p = partinc
			gen miexclsp = fibus - s - p
		    gen pt = fibus
			gen ownerlab = wagess + wagesp
			gen otherlab = fiwag - ownerlab
			gen labnaive = fiwag + .7*(fibus-scorinc)
			gen wag = fiwag
			gen waglpen = fiwag
			gen c = fidiv
			gen othercap = firen + fiint
			gen capnaive = fninc - labnaive
			gen labsoph = labnaive - .7*(fibus-scorinc) + `labshareofpt'*fibus
			gen capsoph = capnaive - `labshareofpt'*fibus
			gen ptlab = `labshareofpt'*fibus
			gen ptcap = (1-`labshareofpt')*fibus
			gen othercap2 = fidiv + firen + fiint
			gen othercap3 = .
			
			
			** make plot variables
			gen wages = waglpen
			gen business = c + pt
			confirm variable othercap
			
			gen wages_pt = waglpen + ptlab
			gen business_adj = c + ptcap
			
		  }
		  else if "`incdefn'"=="ni" {
			gen s = sdiv
			gen p = (partinc!=0)*(lmixinc+kmixinc)
			gen miexclsp = (partinc==0)*(lmixinc+kmixinc)
		    gen pt = sdiv + lmixinc + kmixinc
			gen zz = kmixinc/fkbus
			qui sum zz
			gen ownerlab = r(mean)*(wagess+wagesp+min((wagess+wagesp)/flemp,1)*flprl*(flemp/(flemp+flmil)))
			replace ownerlab = r(mean)*(wagess+wagesp) if ownerlab==.
			drop zz
			gen otherlab = empcomp + lpeninc - ownerlab
			
			di "right before rename to soph"
			
			** get labor and capital from original files
		    rename labinc labsoph
		    rename capinc capsoph
		  
			** labinc and capinc now incorporate "sophisticatedly" distributed 
			** mixed inc and scorp inc
		    ** (get naive versions from original usdina files)
		    merge 1:1 idsyzz using ${dta}/usdina`t'syzz_es`equalsplit'_999 , ///
				nogen keepusing(labinc capinc)
		  
		    rename labinc labnaive
		    rename capinc capnaive
		
			gen wag = empcomp
			gen waglpen = empcomp + lpeninc
			gen c = cdiv + cre
			gen othercap = intrents + kpeninc
			
			** get pass thru labor and capital
			gen ptlab = sdivlab + lmixinc
			gen ptcap = sdivcap + kmixinc
		
			gen othercap2 = capnaive - sdiv - kmixinc
			gen othercap3 = capsoph - sdivcap - kmixinc	
			
			** CHECK TOTAL
			gen tot_check = waglpen + c + pt + othercap
			gen diff = tot - tot_check
	
			summ tot_check, d
			di "`r(sum)'"
			
			summ tot, d
			di "`r(sum)'"
			
			summ diff , d
			
			cap noi assert abs(diff) <= 2

			** make plot variables
			gen wages = waglpen
			gen business = c + pt
			confirm variable othercap
			
			gen wages_pt = waglpen + ptlab
			gen business_adj = c + ptcap
		  }
		  local incvars1 = "tot s p miexclsp pt ownerlab otherlab labnaive wag c othercap capnaive sdivcap sdivlab kmixinc lmixinc"
          local incvars2 = "labsoph capsoph ptlab ptcap othercap2 othercap3 waglpen"
		  *DEFINE PERSON-LEVEL INDICATORS
		  gen hass = (scorinc!=0)
		  gen hasp = (partinc!=0)
		  gen hassp = (scorinc!=0 | partinc!=0)
		  gen hasschc = (schcinc!=0)
		  gen hasspschc = (scorinc!=0 | partinc!=0 | schcinc!=0)
		  gen haspt = (pt!=0)
		  gen hass2 = (scorinc!=0 | wagess_noi!=0)
		  gen hasp2 = (partinc!=0 | wagesp_noi!=0)
		  gen hassp2 = (scorinc!=0 | partinc!=0 | wagess_noi!=0 | wagesp_noi!=0)
		  gen hasspschc2 = (scorinc!=0 | partinc!=0 | schcinc!=0 | wagess_noi!=0 | wagesp_noi!=0)
		  gen haspt2 = (pt!=0 | wagess_noi!=0 | wagesp_noi!=0)
		  gen haspt3 = (abs(pt)>10000)
		  gen gt25pcpt = ((pt+wagess+wagesp)/tot>.25) if tot!=0
		  gen majpt = ((pt+wagess+wagesp)/tot>.5) if tot!=0
		  gen gt25pcptlab = ((pt+labnaive)/tot>.25) if tot!=0
		  gen majptlab = ((pt+labnaive)/tot>.5) if tot!=0
		  gen gt25pcwag = (wag/tot>.25) if tot!=0
		  gen majwag = (wag/tot>.5) if tot!=0
		  gen majwaglpen = (waglpen/tot>.5) if tot!=0
		  gen majptwaglpen = ((pt+waglpen)/tot>.5) if tot!=0		  
		  gen majlab1 = (labnaive>capnaive)
		  gen majlab2 = (labsoph>capsoph)
		  gen majc = (c/tot>.5) if tot!=0
		  gen majothercap = (othercap/tot>.5) if tot!=0
		  gen majothercap2 = (othercap2/tot>.5) if tot!=0
		  gen majlab1sm = (labnaive>capnaive) if rankparcoll!=. & inrange(age,32,34)
		  gen majlab2sm = (labsoph>capsoph) if rankparcoll!=. & inrange(age,32,34)
		  gen sm1 = !(rankparcoll>=.95) if rankparcoll!=. & inrange(age,32,34)
		  gen sm2 = !(rankparcoll>=.99) if rankparcoll!=. & inrange(age,32,34)
		  forv j=1/2 {
		    forv i=1/2 {
			  gen majlab`i'sm`j' = (majlab`i'==1 | sm`j'==1) if rankparcoll!=. & inrange(age,32,34)
            }
            gen sm`j'ptowners1 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majpt==1
            gen sm`j'ptowners2 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & haspt==1
            gen sm`j'ptowners3 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & (hass==1 | hasp==1)
            gen sm`j'workers1 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majwaglpen==1
            gen sm`j'workers2 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & waglpen!=0
            gen sm`j'majc = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majc==1
            gen sm`j'majothercap = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majothercap==1
            gen sm`j'majothercap2 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majothercap2==1
          }
		  
		  *COLLAPSE AND SAVE
          tempfile data_all
          save `data_all'
		  forv i=1/6 {
		    use `data_all' if inc_group`i'==1, clear
		    collapse (mean) has* maj* sm* gt* (sum) `incvars1' `incvars2' [fw=`weightvar']
			foreach var in `incvars1' `incvars2' {
			  replace `var' = `var'/100000
			}
			gen year = `t'
			gen equalsplit = `equalsplit'
			gen incdefn = "`incdefn'"
			gen groupnum = `i'
          	tempfile clps_`t'_`equalsplit'_`incdefn'_`i'
          	save `clps_`t'_`equalsplit'_`incdefn'_`i''
		  }
		 }
		}
      }
    }
  }
  
  *CONSOLIDATE COLLAPSES AND SAVE
  clear
  forv t=$yrmin/$yrmax {
    if !inlist(`t',1963,1965) {
      forv equalsplit=0/1 {
	    foreach incdefn in fi ni {
		 if (`equalsplit'==0 & "`incdefn'"=="fi") | (`equalsplit'==1 & "`incdefn'"=="ni") {
          forv i=1/6 {
          	append using `clps_`t'_`equalsplit'_`incdefn'_`i''
          }
		 }
		}
      }
    }
  }
  g group = "All"
  replace group = "Top 10"       if groupnum==2
  replace group = "Top 1"        if groupnum==3
  replace group = "Millionaires" if groupnum==4
  replace group = "Top .1"       if groupnum==5
  replace group = "Top .01"      if groupnum==6
  order year equalsplit incdefn group groupnum
  sort year equalsplit incdefn groupnum
  format %30.0g `incvars1' `incvars2'
  outsheet using "${out}/usdinasyzz_mainclps_resub_`labshareofpt000'.csv", comma replace
end
}



qui {
capture program drop usdinasyzz_2014clps
program define usdinasyzz_2014clps
  syntax, labshareofpt000(int)
  
  local labshare_suff `labshareofpt000'
  local labshareofpt = `labshareofpt000'/1000

  *DEFINE INFLATORS
  use ${raw}/cpi_annual, clear
  qui sum year
  local cpiyrmin = r(min)
  local cpiyrmax = r(max)
  forv t=`cpiyrmin'/`cpiyrmax' {
    qui sum cpi_u_2015 if year==`t'
    local cpi`t' = r(mean)
  }
  
  *SAVE MANY COLLAPSES AS TEMPORARY DATASETS
  forv t=$yrmax/$yrmax {
    if !inlist(`t',1963,1965) {
      forv equalsplit=0/1 {
	    foreach incdefn in fi ni {
		 if (`equalsplit'==0 & "`incdefn'"=="fi") | (`equalsplit'==1 & "`incdefn'"=="ni") {
		  use ${dta}/usdina`t'syzz_es`equalsplit'_cwag_`labshare_suff', clear
		  
		  di "`t' `equalsplit' `incdefn'"
		  desc
          
		 *SET WEIGHT, RANK, AND TOTAL INCOME VARS
		  if "`incdefn'"=="fi" {
		    local weightvar="dweghttaxu"
			local rankvar="rankprogtufn"
			gen privcwag = 0
			replace privcwag=fiwag if privcpayeract==1 | privcpayerimp==1
			gen privcwaglpen = 0
			gen privcwagkpen = 0
			gen tot = fninc
			order rank*, last
			replace age=. if !inrange(age,32,34)
			collapse (sum) fiinc-tot (mean) `weightvar' rank* age, by(id)
			duplicates tag id, gen(zztag)
			assert zztag==0
			drop zz*
		  }
		  else if "`incdefn'"=="ni" {
		    local weightvar="dweght"
			local rankvar="rankprogpt"
			gen privcwag = 0
			replace privcwag=empcomp if privcpayeract==1 | privcpayerimp==1
			gen privcwaglpen = 0
			replace privcwaglpen=lpeninc if privcpayeract==1 | privcpayerimp==1
			gen privcwagkpen = 0
			replace privcwagkpen=kpeninc if privcpayeract==1 | privcpayerimp==1
			gen tot = allinc
		  }
          di "define income groups"
          *DEFINE INCOME GROUPS
          matrix input cumul = (0, .5, .9, .95, .99, .995, .999, .9999)
         		  
			g inc_group1 = 1 if `rankvar'>=0
			g inc_group2 = 1 if `rankvar'>=0 & `rankvar'<.1
			g inc_group3 = 1 if `rankvar'>=.1 & `rankvar'<.2
			g inc_group4 = 1 if `rankvar'>=.2 & `rankvar'<.3
			g inc_group5 = 1 if `rankvar'>=.3 & `rankvar'<.4
			g inc_group6 = 1 if `rankvar'>=.4 & `rankvar'<.5
			g inc_group7 = 1 if `rankvar'>=.5 & `rankvar'<.6
			g inc_group8 = 1 if `rankvar'>=.6 & `rankvar'<.7
			g inc_group9 = 1 if `rankvar'>=.7 & `rankvar'<.8
			g inc_group10 = 1 if `rankvar'>=.8 & `rankvar'<.9
			g inc_group11 = 1 if `rankvar'>=.9 
			g inc_group12 = 1 if `rankvar'>=.9 & `rankvar'<.91
			g inc_group13 = 1 if `rankvar'>=.91 & `rankvar'<.92
			g inc_group14 = 1 if `rankvar'>=.92 & `rankvar'<.93
			g inc_group15 = 1 if `rankvar'>=.93 & `rankvar'<.94
			g inc_group16 = 1 if `rankvar'>=.94 & `rankvar'<.95
			g inc_group17 = 1 if `rankvar'>=.95 & `rankvar'<.96
			g inc_group18 = 1 if `rankvar'>=.96 & `rankvar'<.97
			g inc_group19 = 1 if `rankvar'>=.97 & `rankvar'<.98
			g inc_group20 = 1 if `rankvar'>=.98 & `rankvar'<.99
			g inc_group21 = 1 if `rankvar'>=.99 
			g inc_group22 = 1 if `rankvar'>=.99 & `rankvar'<.999
			g inc_group23 = 1 if `rankvar'>=.999 
			g inc_group24 = 1 if `rankvar'>=.999 & `rankvar'<.9999
			g inc_group25 = 1 if `rankvar'>=.9999
			
			** millionaires
			g inc_group26 = 1 if tot>=1000000*`cpi`t''/`cpi2014'
		  
		  
		  *DEFINE KEY DOLLAR VARS
		  **CREATE WAGES-FROM-FIRM AND PAR RANK VARS IF THEY DON'T EXIST, IE FOR YEARS <2000 and <1990
		  foreach var in wagess wagess_noi wagesp wagesp_noi {
		    capture gen `var'=0
		  }
		  foreach var in rankparcoll rankparige igewgt {
		    capture gen `var'=.
		  }
		  di "PROCEED"
		  desc

		  **PROCEED
		  if "`incdefn'"=="fi" {
			di "in fi loop"
		    gen s = scorinc
			gen p = partinc
			gen miexclsp = fibus - s - p
		    gen pt = fibus
			gen ownerlab = wagess + wagesp
			gen otherlab = fiwag - ownerlab
			gen labnaive = fiwag + .7*(fibus-scorinc)
			gen wag = fiwag
			gen waglpen = fiwag
			gen c = fidiv
			gen othercap = firen + fiint
			gen capnaive = fninc - labnaive
			gen labsoph = labnaive - .7*(fibus-scorinc) + `labshareofpt'*fibus
			gen capsoph = capnaive - `labshareofpt'*fibus
			gen ptlab = `labshareofpt'*fibus
			gen ptcap = (1-`labshareofpt')*fibus
			gen othercap2 = fidiv + firen + fiint
			gen othercap3 = .
			
			** make plot variables
			gen wages = waglpen
			gen business = c + pt
			confirm variable othercap
			
			gen wages_pt = waglpen + ptlab
			gen business_adj = c + ptcap
			
		  }
		  else if "`incdefn'"=="ni" {
			di "in ni loop"
		    gen s = sdiv
			gen p = (partinc!=0)*(lmixinc+kmixinc)
			gen miexclsp = (partinc==0)*(lmixinc+kmixinc)
		    gen pt = sdiv + lmixinc + kmixinc
			gen zz = kmixinc/fkbus
			qui sum zz
			gen ownerlab = r(mean)*(wagess+wagesp+min((wagess+wagesp)/flemp,1)*flprl*(flemp/(flemp+flmil)))
			replace ownerlab = r(mean)*(wagess+wagesp) if ownerlab==.
			drop zz
			gen otherlab = empcomp + lpeninc - ownerlab
			di "right before rename to soph"
			
			
			** get labor and capital from original files
		    rename labinc labsoph
		    rename capinc capsoph
		  
			** labinc and capinc now incorporate "sophisticatedly" distributed 
			** mixed inc and scorp inc
		    ** (get naive versions from original usdina files)
		    merge 1:1 idsyzz using ${dta}/usdina`t'syzz_es`equalsplit'_cwag_999, ///
				nogen keepusing(labinc capinc)
		  
		    rename labinc labnaive
		    rename capinc capnaive
			
			/*
			** missing for now
			gen labnaive = .
			gen capnaive = .
			*/
			** formerly:
			*gen labnaive = labinc
			*gen capnaive = capinc

			*gen labsoph = labnaive - lmixinc + `labshareofpt'*(sdiv+lmixinc+kmixinc)
			*gen capsoph = capnaive - sdiv - kmixinc + (1-`labshareofpt')*(sdiv+lmixinc+kmixinc)
			
			gen wag = empcomp
			gen waglpen = empcomp + lpeninc
			gen c = cdiv + cre
			gen othercap = intrents + kpeninc
			
			** get pass thru labor and capital
			gen ptlab = sdivlab + lmixinc
			gen ptcap = sdivcap + kmixinc
			
			** formerly
			*gen ptlab = `labshareofpt' * (sdiv + lmixinc + kmixinc)
			*gen ptcap = (1 - `labshareofpt') * (sdiv + lmixinc + kmixinc)
			
			** should not include lmixinc bc it was never in capinc
			gen othercap2 = capnaive - sdiv - kmixinc
			gen othercap3 = capsoph - sdivcap - kmixinc	
			** formerly:
			*gen othercap2 = capinc - sdiv - kmixinc
			
			** CHECK TOTAL
			gen tot_check = waglpen + c + pt + othercap
			gen diff = tot - tot_check
	
			summ tot_check, d
			di "`r(sum)'"
			
			summ tot, d
			di "`r(sum)'"
			
			summ diff , d
			
			cap noi assert abs(diff) <= 2
			
			** make plot variables
			gen wages = waglpen
			gen business = c + pt
			confirm variable othercap
			
			gen wages_pt = waglpen + ptlab
			gen business_adj = c + ptcap
			
		  }
		  
		  
		  ** make majority variables 
		  	gen majlinc = (wages / tot >= 0.5)
			gen majbinc = (business / tot >= 0.5)
			gen majkinc = (othercap / tot >= 0.5)
		  
			gen majhcinc = (wages_pt / tot >= 0.5)
			gen majbinc_adj = (business_adj / tot >= 0.5)
		  
		  
		  *MAKE VERSIONS THAT ADJUST FOR PRIVATE C-CORP WAGES
          gen otherlab5 = otherlab - privcwag - privcwaglpen
          gen labnaive5 = labnaive - privcwag - privcwaglpen
          gen wag5 = wag - privcwag
          gen waglpen5 = waglpen - privcwag - privcwaglpen
          gen c5 = c + privcwag + privcwaglpen + privcwagkpen
          gen capnaive5 = capnaive + privcwag + privcwaglpen
          gen labsoph5 = labsoph - privcwag - privcwaglpen
          gen capsoph5 = capsoph + privcwag + privcwaglpen
          gen othercap5 = othercap + privcwag + privcwaglpen + privcwagkpen
          gen othercap25 = othercap2 + privcwag + privcwaglpen + privcwagkpen

		  gen othercap35 = othercap3 + privcwag + privcwaglpen
		  
		  local incvars1 = "tot s p miexclsp pt ownerlab otherlab labnaive wag c othercap capnaive sdivcap sdivlab kmixinc lmixinc"
          local incvars2 = "labsoph capsoph ptlab ptcap othercap2 othercap3 waglpen otherlab5 labnaive5 wag5"
		  local incvars3 = "waglpen5 c5 capnaive5 labsoph5 capsoph5 othercap25 othercap35"
		  
		  *DEFINE PERSON-LEVEL INDICATORS
		  gen hass = (scorinc!=0)
		  gen hasp = (partinc!=0)
		  gen hassp = (scorinc!=0 | partinc!=0)
		  gen hasschc = (schcinc!=0)
		  gen hasspschc = (scorinc!=0 | partinc!=0 | schcinc!=0)
		  gen haspt = (pt!=0)
		  gen hass2 = (scorinc!=0 | wagess_noi!=0)
		  gen hasp2 = (partinc!=0 | wagesp_noi!=0)
		  gen hassp2 = (scorinc!=0 | partinc!=0 | wagess_noi!=0 | wagesp_noi!=0)
		  gen hasspschc2 = (scorinc!=0 | partinc!=0 | schcinc!=0 | wagess_noi!=0 | wagesp_noi!=0)
		  gen haspt2 = (pt!=0 | wagess_noi!=0 | wagesp_noi!=0)
		  gen haspt3 = (abs(pt)>10000)
		  gen gt25pcpt = ((pt+wagess+wagesp)/tot>.25) if tot!=0
		  gen majpt = ((pt+wagess+wagesp)/tot>.5) if tot!=0
		  gen gt25pcptlab = ((pt+labnaive)/tot>.25) if tot!=0
		  gen majptlab = ((pt+labnaive)/tot>.5) if tot!=0
		  gen gt25pcwag = (wag/tot>.25) if tot!=0
		  gen majwag = (wag/tot>.5) if tot!=0
		  gen majwaglpen = (waglpen/tot>.5) if tot!=0
		  gen majptwaglpen = ((pt+waglpen)/tot>.5) if tot!=0		  
		  gen majlab1 = (labnaive>capnaive)
		  gen majlab2 = (labsoph>capsoph)
		  gen majc = (c/tot>.5) if tot!=0
		  gen majothercap = (othercap/tot>.5) if tot!=0
		  gen majothercap2 = (othercap2/tot>.5) if tot!=0
		  gen majothercap3 = (othercap3/tot>.5) if tot!=0
		  gen majlab1sm = (labnaive>capnaive) if rankparcoll!=. & inrange(age,32,34)
		  gen majlab2sm = (labsoph>capsoph) if rankparcoll!=. & inrange(age,32,34)
		  gen sm1 = !(rankparcoll>=.95) if rankparcoll!=. & inrange(age,32,34)
		  gen sm2 = !(rankparcoll>=.99) if rankparcoll!=. & inrange(age,32,34)
		  forv j=1/2 {
		    forv i=1/2 {
			  gen majlab`i'sm`j' = (majlab`i'==1 | sm`j'==1) if rankparcoll!=. & inrange(age,32,34)
            }
            gen sm`j'ptowners1 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majpt==1
            gen sm`j'ptowners2 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & haspt==1
            gen sm`j'ptowners3 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & (hass==1 | hasp==1)
            gen sm`j'workers1 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majwaglpen==1
            gen sm`j'workers2 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & waglpen!=0
            gen sm`j'majc = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majc==1
            gen sm`j'majothercap = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majothercap==1
            gen sm`j'majothercap2 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majothercap2==1
          }
		  *MAKE VERSIONS THAT ADJUST FOR C-CORP WAGES
		  gen gt25pcptlab5 = ((pt+labnaive5)/tot>.25) if tot!=0
		  gen majptlab5 = ((pt+labnaive5)/tot>.5) if tot!=0
		  gen gt25pcwag5 = (wag5/tot>.25) if tot!=0
		  gen majwag5 = (wag5/tot>.5) if tot!=0
		  gen majwaglpen5 = (waglpen5/tot>.5) if tot!=0
		  gen majptwaglpen5 = ((pt+waglpen5)/tot>.5) if tot!=0		  
		  gen majlab15 = (labnaive5>capnaive5)
		  gen majlab25 = (labsoph5>capsoph5)
		  gen majc5 = (c5/tot>.5) if tot!=0
		  gen majothercap5 = (othercap5/tot>.5) if tot!=0
		  gen majothercap25 = (othercap25/tot>.5) if tot!=0
		  gen majothercap35 = (othercap35/tot>.5) if tot!=0
		  gen majlab1sm5 = (labnaive5>capnaive5) if rankparcoll!=. & inrange(age,32,34)
		  gen majlab2sm5 = (labsoph5>capsoph5) if rankparcoll!=. & inrange(age,32,34)
		  forv j=1/2 {
		    forv i=1/2 {
			  gen majlab`i'sm`j'5 = (majlab`i'5==1 | sm`j'==1) if rankparcoll!=. & inrange(age,32,34)
            }
			gen sm`j'workers15 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majwaglpen5==1
            gen sm`j'workers25 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & waglpen5!=0
            gen sm`j'majc5 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majc5==1
            gen sm`j'majothercap5 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majothercap5==1
            gen sm`j'majothercap25 = (sm`j'==1) if rankparcoll!=. & inrange(age,32,34) & majothercap25==1
          }
		  
		  *COLLAPSE AND SAVE
          tempfile data_all
          save `data_all'

		  local max_group 26

		  forv i=1/`max_group' {
		    use `data_all' if inc_group`i'==1, clear
		    collapse (mean) has* maj* sm* gt* (sum) `incvars1' `incvars2' `incvars3' [fw=`weightvar']
			foreach var in `incvars1' `incvars2' `incvars3' {
			  replace `var' = `var'/100000
			}
			gen year = `t'
			gen equalsplit = `equalsplit'
			gen incdefn = "`incdefn'"
			gen incgroup = `i'
          	tempfile clps_`t'_`equalsplit'_`incdefn'_`i'
          	save `clps_`t'_`equalsplit'_`incdefn'_`i''
		  }
		 }
		}
      }
    }
  }
  
  *CONSOLIDATE COLLAPSES AND SAVE
  clear
  forv t=$yrmax/$yrmax {
    if !inlist(`t',1963,1965) {
      forv equalsplit=0/1 {
	    foreach incdefn in fi ni {
		 if (`equalsplit'==0 & "`incdefn'"=="fi") | (`equalsplit'==1 & "`incdefn'"=="ni") {
          forv i=1/`max_group' {
          	append using `clps_`t'_`equalsplit'_`incdefn'_`i''
          }
		 }
		}
      }
    }
  }
  
  	g group = "All"
	replace group = "P0-10"          if incgroup==2
	replace group = "P10-20"         if incgroup==3
	replace group = "P20-30"         if incgroup==4
	replace group = "P30-40"         if incgroup==5
	replace group = "P40-50"         if incgroup==6
	replace group = "P50-60"         if incgroup==7
	replace group = "P60-70"         if incgroup==8
	replace group = "P70-80"         if incgroup==9	
	replace group = "P80-90"         if incgroup==10
	replace group = "P90-100"        if incgroup==11
	replace group = "P90-91"         if incgroup==12
	replace group = "P91-92"         if incgroup==13
	replace group = "P92-93"         if incgroup==14
	replace group = "P93-94"         if incgroup==15
	replace group = "P94-95"         if incgroup==16
	replace group = "P95-96"         if incgroup==17
	replace group = "P96-97"         if incgroup==18
	replace group = "P97-98"         if incgroup==19
	replace group = "P98-99"         if incgroup==20
	replace group = "P99-100"        if incgroup==21
	replace group = "P99-99.9"       if incgroup==22
	replace group = "P99.9-100"      if incgroup==23
	replace group = "P99.9-99.99"    if incgroup==24
	replace group = "P99.99-100"     if incgroup==25			
	replace group = "Millionaires"   if incgroup==26
  
  order year equalsplit incdefn incgroup group
  sort year equalsplit incdefn incgroup
  format %30.0g `incvars1' `incvars2' `incvars3'
  
  
  outsheet using "${out}/usdinasyzz_2014clps_resub_`labshareofpt000'.csv", comma replace
end
}


qui {
capture program drop usdinasyzz_oneoffstats
program define usdinasyzz_oneoffstats
  *FI AND INI TOP 1% AND TOP 0.1% THRESHOLDS IN 2014
  use id fninc rankprogtufn using ${dta}/usdina2014syzz_es0, clear
  collapse (sum) fninc (mean) rankprogtufn, by(id)
  tabstat fninc if rankprogtufn>=.99, stat(min)
  tabstat fninc if rankprogtufn>=.999, stat(min)
  use ptinc rankprogpt using ${dta}/usdina2014syzz_es1, clear
  tabstat ptinc if rankprogpt>=.99, stat(min)
  tabstat ptinc if rankprogpt>=.999, stat(min)
  
  *SHARE OF 32-34-YEAR-OLDS MATCHED TO A PARENT IN THE TOP 1%
  use ${dta}/usdina2014syzz_es1 if inrange(age,32,34), clear
  gen matched = rankparcoll!=.
  sum matched [w=dweght] if rankprogpt>.99
  
  *SHARE OF TOP EARNERS IN 2014 WHO HAVE DIRECTLY OBSERVED C-CORP WAGES AND HAVE IMPUTED C-CORP WAGES
  use ${dta}/usdina2014syzz_es1_cwag, clear
  sum privcpayer* [w=dweght] if rankprogpt>.99
end
}


*******************************************************************************
* MAIN
*******************************************************************************
capture program drop main
program define main

    ****************************************************************************
    * Init
    ****************************************************************************
    capture log c
    *log using "${dirdo}/draft_usdinasyzz_${draftusdinasyzzversion}.log", replace
    *set trace on
    *set tracedepth 1
    
    ****************************************************************************
    * Builds
    ****************************************************************************
    *reproduce_tb2f
	
	*usdinasyzz_2014clps, labshareofpt000(${labshareofpt000})
	*usdinasyzz_mainclps, labshareofpt000(${labshareofpt000})

    *log c
end


