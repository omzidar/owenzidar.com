*******************************************************************************
* NEW 1. S-P-SP Hockeys, apportioned and nonapportioned
*******************************************************************************
foreach orgform in sp {
  foreach apportion in yesapportion {
    if "`apportion'"=="yesapportion" {
	  local apportionoption = "apportioned"
	}
    if "`apportion'"=="noapportion" {
	  local apportionoption = ""
	}
  
    hockey_prep_cdwfirms, orgform("`orgform'") ifcon("if agibin>90") specname("standard") `apportionoption'
    
    global yvarenglish = "Value added (000s) per worker"
    use ${dta}/hockeys_vapw, clear
	save ${dta}/hockeys_vapw_`orgform'_`apportionoption', replace 
	keep if tax_yr==2014
	outsheet using "${out}/G_hockey_`orgform'_allsizes_vapw_2014_`apportion'_data.csv", comma replace
    
    global yvarenglish = "Profits (000s) per worker"
    use ${dta}/hockeys_ppw, clear
	save ${dta}/hockeys_ppw_`orgform'_`apportionoption', replace 
	keep if tax_yr==2014
	outsheet using "${out}/G_hockey_`orgform'_allsizes_ppw_2014_`apportion'_data.csv", comma replace
    
    global yvarenglish = "Owner-pay share of value added"
    use ${dta}/hockeys_sos, clear
	save ${dta}/hockeys_sos_`orgform'_`apportionoption', replace 
	keep if tax_yr==2014
	outsheet using "${out}/G_hockey_`orgform'_allsizes_sos_2014_`apportion'_data.csv", comma replace
  }
}







