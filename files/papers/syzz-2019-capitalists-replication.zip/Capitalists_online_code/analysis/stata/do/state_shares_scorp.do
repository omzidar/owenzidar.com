local yr=2014
************************************************
* 0. PREP GEO OF FIRMS
************************************************
set seed 1234
use $dump/scorp_geo.dta, clear
keep if year==`yr'
drop ein year zip
rename tin payer_tin
duplicates drop

g u=runiform()
sort u
egen tag=tag(payer_tin)
keep if tag==1
drop tag u
sort payer_tin 
tempfile firmgeodta_`yr'
save `firmgeodta_`yr''

*******************************************************************************
* 1. Load data
*******************************************************************************
use $dta/s_firmowner_`yr'.dta, clear

*******************************************************************************
*2. IDENTIFY FIRMS WITH TOP OWNERS
*******************************************************************************
g anyowner = !mi(tin)
egen Nowners       = total(anyowner), by(ein)
egen Ntop1owners   = total(own_top1), by(ein)
egen Ntoppt1owners = total(own_toppt1), by(ein)

	*Millionaires in 2014
	g psinc2014=psinc
	capture drop year
	g year=`yr'
	usd2014, var(psinc2014) yr(year)	

	g millionaire = psinc2014>=1000000 & !mi(psinc2014)
egen NMowners   = total(millionaire), by(ein)

g firm_own_top1    = (Ntop1owners>0 & !mi(Ntop1owners))
g firm_own_M       = (NMowners >0 & !mi(NMowners))
g firm_own_toppt1  = (Ntoppt1owners>0 & !mi(Ntoppt1owners))

*******************************************************************************
*3. Keep one observation per firm
*******************************************************************************
egen tag=tag(ein)
keep if tag==1
drop tag


*MERGE ON FIRM GEO DATA
merge m:1 payer_tin using  `firmgeodta_`yr''
tab _merge
drop if _merge==2
replace state="NA" if _merge==2
drop _merge

*******************************************************************************
*4. Industry Shares 
*******************************************************************************
gen nc1 = floor(nc4/1000)
tab nc1
tab nc1 if (Nowners>=1 & !mi(Nowners))
tab nc1 if firm_own_top1
tab nc1 if firm_own_toppt1

*******************************************************************************
*5. bring to 2014 dollars
*******************************************************************************
*NOTE THAT THIS PROGRAM ONLY GOES BACK TO 93
capture drop year
g year=`yr'
assert year>1993
usd2014, var(sales) yr(year)
usd2014, var(profits) yr(year)
usd2014, var(ass) yr(year)

*******************************************************************************
*6. Export
*******************************************************************************
g Nfirms=!mi(ein)

tempfile data_all
save `data_all'

use `data_all', clear
collapse (sum) Nfirms sales profits numw2 ass, by(state)
keep if Nfirms>10
export delimited  using $out/state_shares_scorp_`yr'_all.csv, replace

use `data_all', clear
keep if (Nowners>=1 & !mi(Nowners))
collapse (sum) Nfirms sales profits numw2 ass, by(state)
keep if Nfirms>10
export delimited  using $out/state_shares_scorp_`yr'_anyowner.csv, replace
	
	
use `data_all', clear
keep if firm_own_top1
collapse (sum) Nfirms sales profits numw2 ass, by(state)
keep if Nfirms>10
export delimited  using $out/state_shares_scorp_`yr'_top1.csv, replace

use `data_all', clear	
keep if firm_own_M
collapse (sum) Nfirms sales profits numw2 ass, by(state)
keep if Nfirms>10
export delimited  using $out/state_shares_scorp_`yr'_millionaire.csv, replace
		
	
use `data_all', clear	
keep if firm_own_toppt1
collapse (sum) Nfirms sales profits numw2 ass, by(state)
keep if Nfirms>10
export delimited  using $out/state_shares_scorp_`yr'_toppt1.csv, replace
			
