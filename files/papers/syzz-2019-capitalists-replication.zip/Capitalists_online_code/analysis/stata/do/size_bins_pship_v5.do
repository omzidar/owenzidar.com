
*******************************************************************************
* 1. Load data
*******************************************************************************
local yr=2014
use $dta/p_firmowner_`yr'.dta, clear

*******************************************************************************
*2. IDENTIFY FIRMS WITH TOP OWNERS
*******************************************************************************
g anyowner = !mi(tin)
egen Nowners       = total(anyowner), by(ein)
egen Ntop1owners   = total(own_top1), by(ein)
egen Ntoppt1owners = total(own_toppt1), by(ein)

	*Millionaires in 2014
	g psinc2014=psinc
	capture drop year
	g year=`yr'
	usd2014, var(psinc2014) yr(year)	

	g millionaire = psinc2014>=1000000 & !mi(psinc2014)
egen NMowners   = total(millionaire), by(ein)

g firm_own_top1    = (Ntop1owners>0 & !mi(Ntop1owners))
g firm_own_M       = (NMowners >0 & !mi(NMowners))
g firm_own_toppt1  = (Ntoppt1owners>0 & !mi(Ntoppt1owners))

*******************************************************************************
*3. Keep one observation per firm
*******************************************************************************
egen tag=tag(ein)
keep if tag==1
drop tag

*******************************************************************************
*4. bring to 2014 dollars
*******************************************************************************
*NOTE THAT THIS PROGRAM ONLY GOES BACK TO 93
capture drop year
g year=`yr'
assert year>1993
usd2014, var(sales) yr(year)
usd2014, var(profits) yr(year)
usd2014, var(ass) yr(year)

*******************************************************************************
*5. Sales Size Shares 
*******************************************************************************

g sale500K_1M  = (sales>=500000    &sales<1000000) 
g sale1M_5M    = (sales>=1000000   &sales<5000000) 
g sale5M_10M   = (sales>=5000000   &sales<10000000)
g sale10M_50M  = (sales>=10000000  &sales<500000000)
g sale50M_100M = (sales>=50000000  &sales<1000000000)
g sale100M_500M = (sales>=100000000  &sales<5000000000)
g sale500Mplus = (sales>=500000000 &!mi(sales))

g salebin2 = -1
replace salebin2 = 0 if sale500K_1M 
replace salebin2 = 1 if sale1M_5M   
replace salebin2 = 2 if sale5M_10M  
replace salebin2 = 3 if sale10M_50M 
replace salebin2 = 4 if sale50M_100M 
replace salebin2 = 5 if sale100M_500M 
replace salebin2 = 6 if sale500Mplus 

g salebin3 = -1
replace salebin3 = 0 if (sales>=500000    &sales<1e6)
replace salebin3 = 1 if (sales>=1e6       &sales<5e6)  
replace salebin3 = 2 if (sales>=5e6       &sales<10e6)  
replace salebin3 = 3 if (sales>=10e6      &sales<25e6)  
replace salebin3 = 4 if (sales>=25e6      &sales<50e6)  
replace salebin3 = 5 if (sales>=50e6      &sales<100e6) 
replace salebin3 = 6 if (sales>=100e6     &sales<250e6)  
replace salebin3 = 7 if (sales>=250e6     &sales<500e6)
replace salebin3 = 8 if (sales>=500e6     &!mi(sales))

*******************************************************************************
*6. Export
*******************************************************************************
g Nfirms=!mi(ein)

tempfile data_all
save `data_all'

use `data_all', clear
collapse (sum) Nfirms sales profits numw2 ass, by(salebin2)
assert Nfirms>10
export delimited  using $out/sales_bins_pship_`yr'_all.csv, replace

use `data_all', clear
keep if firm_own_top1
collapse (sum) Nfirms sales profits numw2 ass, by(salebin2)
assert Nfirms>10
export delimited  using $out/sales_bins_pship_`yr'_top1.csv, replace

use `data_all', clear
keep if firm_own_M
collapse (sum) Nfirms sales profits numw2 ass, by(salebin2)
assert Nfirms>10
export delimited  using $out/sales_bins_pship_`yr'_millionaire.csv, replace

use `data_all', clear
keep if firm_own_toppt1
collapse (sum) Nfirms sales profits numw2 ass, by(salebin2)
assert Nfirms>10
export delimited  using $out/sales_bins_pship_`yr'_toppt1.csv, replace

*******************************************************************************
*6.A Export
*******************************************************************************

use `data_all', clear
collapse (sum) Nfirms sales profits numw2 ass, by(salebin3)
keep if Nfirms>10
export delimited  using $out/sales_bins100K_pship_`yr'_all.csv, replace

use `data_all', clear
keep if firm_own_top1
collapse (sum) Nfirms sales profits numw2 ass, by(salebin3)
keep if Nfirms>10
export delimited  using $out/sales_bins100K_pship_`yr'_top1.csv, replace

use `data_all', clear
keep if firm_own_M
collapse (sum) Nfirms sales profits numw2 ass, by(salebin3)
keep if Nfirms>10
export delimited  using $out/sales_bins100K_pship_`yr'_millionaire.csv, replace

use `data_all', clear
keep if firm_own_toppt1
collapse (sum) Nfirms sales profits numw2 ass, by(salebin3)
keep if Nfirms>10
export delimited  using $out/sales_bins100K_pship_`yr'_toppt1.csv, replace

