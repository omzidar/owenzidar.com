global firstyear = 2001
global lastyear  = 2014
global odfirstyear = 2005
global odlastyear = 2010
global eventfirstyear = 100 - ($odfirstyear-$firstyear)
global eventlastyear = 100 + ($lastyear-$odlastyear)
global firmvarlist = "profits sales numw2 costsold"
global firmvarlist_ = "profits_ sales_ numw2_ costsold_"
global firmvarlist_dollarvars = "profits sales costsold"
global minsales = 100000


************************************************************************
* 4. OWNERDEATHS ANALYSIS FILES AND GRAPHS
************************************************************************
foreach orgforminput in "s" "p" "sp" {
  foreach sampleinput in "millionaire" "top1" "toppt1" {
    ownerdeaths_analysis, orgform("`orgforminput'") sample("`sampleinput'") ageminimum(0) agemaximum(64)
    ownerdeaths_analysis, orgform("`orgforminput'") sample("`sampleinput'") ageminimum(75) agemaximum(100)
  }
}


************************************************************************
* 5. OWNERDEATHS REORGSTATS
************************************************************************
foreach orgforminput in "s" "p" "sp" {
  foreach sampleinput in "millionaire" "top1" "toppt1" {
    ownerdeaths_reorgstats, orgform("`orgforminput'") sample("`sampleinput'") ageminimum(0) agemaximum(64)
    ownerdeaths_reorgstats, orgform("`orgforminput'") sample("`sampleinput'") ageminimum(75) agemaximum(100)
  }
}


************************************************************************
* 6. OWNERDEATHS TABLE
************************************************************************
clear
global col = 0

local outfile "${dump}/temprow_od.dta"
capture rm "`outfile'"

foreach orgform in s p sp {
  global orgform = "`orgform'"
  
  *TOP 1%
  global sample = "top1"
  use ${dta}/ownerdeaths_analysis_`orgform'_0_64_${sample} if agipctilebin_var>99, clear 
  t4reg, varroot("salesgt0") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre_int") ifcon("profits_numw2pre_int_dif != .") ofile("`outfile'") append 
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,0,.5)") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,.50000001,1)") ofile("`outfile'") append
  use ${dta}/ownerdeaths_analysis_`orgform'_75_100_${sample} if agipctilebin_var>99, clear
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
  
  *TOP 0.1%
  global sample = "toppt1"
  use ${dta}/ownerdeaths_analysis_`orgform'_0_64_${sample} if agipctilebin_var>99.9, clear
  t4reg, varroot("salesgt0") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre_int") ifcon("profits_numw2pre_int_dif != .") ofile("`outfile'") append 
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,0,.5)") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,.50000001,1)") ofile("`outfile'") append
  use ${dta}/ownerdeaths_analysis_`orgform'_75_100_${sample} if agipctilebin_var>99.9, clear
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
  
  *MILLIONAIRES
  global sample = "millionaire"
  use ${dta}/ownerdeaths_analysis_`orgform'_0_64_${sample} if psinc_14dollars_l1>=1000000 & psinc_14dollars_l1!=., clear
  t4reg, varroot("salesgt0") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre_int") ifcon("profits_numw2pre_int_dif != .") ofile("`outfile'") append 
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,0,.5)") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,.50000001,1)") ofile("`outfile'") append
  use ${dta}/ownerdeaths_analysis_`orgform'_75_100_${sample} if psinc_14dollars_l1>=1000000 & psinc_14dollars_l1!=., clear
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
}

use "`outfile'", clear
sort orgform sample col
order orgform sample col
export delimited $out/ownerdeaths_table_output.csv, replace
list


************************************************************************
* 7. WATERFALL COUNTS
************************************************************************
*WATERFALL COUNT 1: Distinct firms 2005-2010
use ${dump}/temp_odbuild_prep_s, clear
append using ${dump}/temp_odbuild_prep_p
gen nc_var = floor(nc4/10)
gen age = year-ssa_yob
gen age_var = 5*floor(age/5)
gen agipctilebin_var=.
forv yr=$odfirstyear/$odlastyear {
 local yrM1 = `yr'-1
 replace agipctilebin_var=agipctilebin`yrM1' if year==`yr'
}
drop if nc_var<=0 | nc_var>=999
drop if nc_var==. | age_var==. | agipctilebin_var==.
disp "WATERFALL COUNT 1: Distinct firms 2005-2010"
distinct ein

*WATERFALL COUNT 2: Restrict to firms with one owner death
keep if death==1
disp "WATERFALL COUNT 2: Restrict to firms with one owner death"
distinct ein

*WATERFALL COUNT 3: Restrict to dying owners in the top 1%
keep if agipctilebin_var>99
disp "WATERFALL COUNT 3: Restrict to dying owners in the top 1%"
distinct ein

*WATERFALL COUNT 4: Restrict to dying owners under age 65
***RESTRICT TO AGE RANGE
drop if !inrange(age,0,64)
disp "WATERFALL COUNT 4: Restrict to dying owners under age 65"
distinct ein

*WATERFALL COUNT 5: Restrict to firms with >$100K in t-1 sales and positive sales [t-4,t-1]
keep if keepinsample_l4l1==1
disp "WATERFALL COUNT 5: Restrict to firms with >$100K in t-1 sales and positive sales [t-4,t-1]"
distinct ein

*WATERFALL COUNT 6: Restrict to firms with at least one pre-period worker
keep if posnumw2_l4l1==1
disp "WATERFALL COUNT 6: Restrict to firms with at least one pre-period worker"
distinct ein

*WATERFALL COUNT 7: Restrict to firms with dying owner's ownership share >=20%
drop if ownshare<.2
disp "WATERFALL COUNT 7: Restrict to firms with dying owner's ownership share >=20%"
distinct ein

*WATERFALL COUNT 8: Match to at least one counterfactual firm
use ein_od ownshare using $dta/ownerdeaths_build_sp_0_64, clear
drop if ownshare<.2
disp "WATERFALL COUNT 8: Match to at least one counterfactual firm"
distinct ein_od


************************************************************************
* 8. ONE-OFF STATS ON EXITS AND REORGS
************************************************************************
use $dta/ownerdeaths_analysis_sp_0_64_millionaire if eventtime==104, clear
foreach suffix in od hs {
  gen exit_`suffix' = (lnsales_`suffix'==.)
}
foreach suffix in od hs {
  qui sum exit_`suffix' [w=odidwgt]
  local exit_`suffix'_mean = r(mean)
  disp "Exit rate for `suffix' firms: " `exit_`suffix'_mean'
}
foreach suffix in od hs {
  qui sum salesgt0_`suffix' [w=odidwgt]
  local salesgt0_`suffix'_mean = r(mean)
  local reorg_share_`suffix' = (`exit_`suffix'_mean' - (1 - `salesgt0_`suffix'_mean'))/`exit_`suffix'_mean'
  disp "Share of `suffix' exits that were reorgs: " `reorg_share_`suffix''
}

*MEAN AND MEDIAN NUMBER OF EMPLOYEES AT OWNER DEATH FIRMS
use eventtime numw2pre_od odidwgt using $dta/ownerdeaths_analysis_sp_0_64_millionaire, clear
sum numw2pre_od [w=odidwgt], d
