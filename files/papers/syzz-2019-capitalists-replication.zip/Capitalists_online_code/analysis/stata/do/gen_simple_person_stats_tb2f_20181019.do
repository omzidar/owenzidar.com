*******************************************************************************
*MAIN DINA DATASET
*******************************************************************************
forv yr = 2014/2014 {
use $dta/usdina`yr'syzz_es1_999.dta, clear

*set weight
g w=dweght

*******************************************************************************
*Define Income Groups of interest
*******************************************************************************

*All
g inc_group1 = 1 if rankprogpt>=0
g inc_group2 = 1 if rankprogpt>=0 & rankprogpt<.1
g inc_group3 = 1 if rankprogpt>=.1 & rankprogpt<.2
g inc_group4 = 1 if rankprogpt>=.2 & rankprogpt<.3
g inc_group5 = 1 if rankprogpt>=.3 & rankprogpt<.4
g inc_group6 = 1 if rankprogpt>=.4 & rankprogpt<.5
g inc_group7 = 1 if rankprogpt>=.5 & rankprogpt<.6
g inc_group8 = 1 if rankprogpt>=.6 & rankprogpt<.7
g inc_group9 = 1 if rankprogpt>=.7 & rankprogpt<.8
g inc_group10 = 1 if rankprogpt>=.8 & rankprogpt<.9
g inc_group11 = 1 if rankprogpt>=.9 
g inc_group12 = 1 if rankprogpt>=.9 & rankprogpt<.91
g inc_group13 = 1 if rankprogpt>=.91 & rankprogpt<.92
g inc_group14 = 1 if rankprogpt>=.92 & rankprogpt<.93
g inc_group15 = 1 if rankprogpt>=.93 & rankprogpt<.94
g inc_group16 = 1 if rankprogpt>=.94 & rankprogpt<.95
g inc_group17 = 1 if rankprogpt>=.95 & rankprogpt<.96
g inc_group18 = 1 if rankprogpt>=.96 & rankprogpt<.97
g inc_group19 = 1 if rankprogpt>=.97 & rankprogpt<.98
g inc_group20 = 1 if rankprogpt>=.98 & rankprogpt<.99
g inc_group21 = 1 if rankprogpt>=.99 
g inc_group22 = 1 if rankprogpt>=.99 & rankprogpt<.999
g inc_group23 = 1 if rankprogpt>=.999 
g inc_group24 = 1 if rankprogpt>=.999 & rankprogpt<.9999
g inc_group25 = 1 if rankprogpt>=.9999 
*Millionaries
g inc_group26 = 1 if ptinc>=1000000

g age_group1 = 1 if 		  age<20 & !mi(age)
g age_group2 = 1 if age>=20 & age<30 & !mi(age)
g age_group3 = 1 if age>=30 & age<40 & !mi(age)
g age_group4 = 1 if age>=40 & age<50 & !mi(age)
g age_group5 = 1 if age>=50 & age<60 & !mi(age)
g age_group6 = 1 if age>=60 & age<70 & !mi(age)
g age_group7 = 1 if age>=70 & age<80 & !mi(age)
g age_group8 = 1 if age>=80 & age<90 & !mi(age)
g age_group9 = 1 if age>=90 		 & !mi(age)

*******************************************************************************
*Define Person-level indicators
*******************************************************************************

g Kinc			   = capinc - (sdiv + cdiv + cre +kmixinc)
g Linc			   = labinc - lmixinc
g Binc			   = (sdiv + cdiv + cre +kmixinc + lmixinc)
g inc			   = Kinc + Linc + Binc

g owner                  = (Binc!=0) 
g posKinc                = (Kinc>0)  
g posLinc                = (Linc>0)  
g posBinc                = (Binc>0)  
g majKinc 				 = (Kinc/inc>=.5)
g majBinc 				 = (Binc/inc>=.5)
g majLinc 				 = (Linc/inc>=.5)

*adding pass through by type
****************************
g Sinc			   = (scorinc!=0)*sdiv
g Pinc			   = (partinc!=0)*(kmixinc + lmixinc)
g posSinc	  			 = (Sinc >0) 
g posPinc	  			 = (Pinc >0) 
g Sowner                 = (Sinc!=0)
g Powner                 = (Pinc!=0)
g posSorPinc 			 = (Sinc>0 | Pinc>0)
g SorPowner				 = (Sinc!=0 | Pinc!=0)
g schcowner			     = (schcinc!=0)
g ptowner			     = (Sinc!=0 | Pinc!=0 | schcinc!=0)

g PTinc = fkbus +lmixinc
g posPTinc = (PTinc>0)
g posCinc  = (fkequ>0)

g majSinc 				 = (Sinc/inc>=.5)
g majCinc 				 = (fkequ/inc>=.5)
g majPTinc 				 = (PTinc/inc>=.5)

g BLinc			   = Binc + Linc*Sowner
g posBLinc         = (BLinc>0)

foreach var in Sinc Pinc schcinc Binc Linc BLinc Kinc {
g `var'_ltm10K  = (`var'<-10000)
g `var'_gt10K   = (`var'>10000)
g `var'_gt100K  = (`var'>100000)
g `var'_gt500K  = (`var'>500000)
g `var'_gt1M    = (`var'>1000000)
}

*******************************************************************************
*PREP DATA FOR COLLAPSES
*******************************************************************************
g N=1

	local sumlist "N posKinc posBinc posLinc posBLinc majKinc majBinc majLinc posSinc posPinc owner Powner Sowner SorPowner posSorPinc schcowner ptowner majSinc majPTinc majCinc posPTinc posCinc "
	local sumlist2 "Sinc_ltm10K Pinc_ltm10K schcinc_ltm10K Binc_ltm10K Linc_ltm10K BLinc_ltm10K Kinc_ltm10K"
	local sumlist3 "Sinc_gt10K Pinc_gt10K schcinc_gt10K Binc_gt10K Linc_gt10K BLinc_gt10K Kinc_gt10K"
	local sumlist4 "Sinc_gt100K Pinc_gt100K schcinc_gt100K Binc_gt100K Linc_gt100K BLinc_gt100K Kinc_gt100K"
	local sumlist5 "Sinc_gt500K Pinc_gt500K schcinc_gt500K Binc_gt500K Linc_gt500K BLinc_gt500K Kinc_gt500K"
	local sumlist6 "Sinc_gt1M Pinc_gt1M schcinc_gt1M Binc_gt1M Linc_gt1M BLinc_gt1M Kinc_gt1M"
	
	local meanlist "Binc Linc Kinc BLinc inc scorinc partinc Sinc Pinc PTinc fiwag fninc schcinc firen  fiint fidiv scorpinc2 ptinc divinc divest kginc kgest"
	local meanlist2 "allinc peinc capinc cdiv cre sdiv empcomp labinc lmixinc lpeninc kmixinc  kpeninc flemp flmil flprl fkbus fkequ intrents"

	tempfile data_all
	save `data_all'

	*******************************************************************************
	*1. OVERALL STATS: COLLAPSES BY INCOME GROUP
	*******************************************************************************
	forv i=1/26{
	use `data_all', clear
	keep if inc_group`i'==1
	collapse (sum) `sumlist'  `sumlist2' `sumlist3' `sumlist4' `sumlist5' `sumlist6' (mean) `meanlist' `meanlist2' [fw=w]

	g incgroup=`i'

	tempfile dina_group`i'
	save `dina_group`i''
	}

	***********************************
	*CONSOLIDATE COLLAPSES
	***********************************
	clear
	forv i=1/26{
	append using `dina_group`i''
	}

	g group = "All"
	replace group = "P0-10"          if incgroup==2
	replace group = "P10-20"         if incgroup==3
	replace group = "P20-30"         if incgroup==4
	replace group = "P30-40"         if incgroup==5
	replace group = "P40-50"         if incgroup==6
	replace group = "P50-60"         if incgroup==7
	replace group = "P60-70"         if incgroup==8
	replace group = "P70-80"         if incgroup==9	
	replace group = "P80-90"         if incgroup==10
	replace group = "P90-100"        if incgroup==11
	replace group = "P90-91"         if incgroup==12
	replace group = "P91-92"         if incgroup==13
	replace group = "P92-93"         if incgroup==14
	replace group = "P93-94"         if incgroup==15
	replace group = "P94-95"         if incgroup==16
	replace group = "P95-96"         if incgroup==17
	replace group = "P96-97"         if incgroup==18
	replace group = "P97-98"         if incgroup==19
	replace group = "P98-99"         if incgroup==20
	replace group = "P99-100"        if incgroup==21
	replace group = "P99-99.9"       if incgroup==22
	replace group = "P99.9-100"      if incgroup==23
	replace group = "P99.9-99.99"    if incgroup==24
	replace group = "P99.99-100"     if incgroup==25			
	replace group = "Millionaires"   if incgroup==26

	*weights are 100K too big
	foreach var in `sumlist'  `sumlist2' `sumlist3' `sumlist4' `sumlist5' `sumlist6' {
	replace `var' = `var'/100000
	}

	capture drop wagesfromfirm poswage if `yr'=="2014"
	order group N inc 
	export delimited using "$out/person_stats_tb2f_simple/all_`yr'.csv", replace


	*******************************************************************************
	*2. OVERALL STATS: COLLAPSES BY INCOME GROUP AND AGE
	*******************************************************************************
	forv a=1/9{
	
	forv i=1/26{
	use `data_all', clear
	keep if inc_group`i'==1
	capture keep if age_group`a'==1
	capture collapse (sum) `sumlist' `sumlist2' `sumlist3' `sumlist4' `sumlist5' `sumlist6' (mean) `meanlist' `meanlist2' [fw=w]

	g incgroup=`i'
	g agegroup=`a'

	tempfile dina_group`i'
	save `dina_group`i''
	}
	
	
	***********************************
	*CONSOLIDATE COLLAPSES
	***********************************
	clear
	forv i=1/26{
	append using `dina_group`i''
	}

	g group = "All"
	replace group = "P0-10"          if incgroup==2
	replace group = "P10-20"         if incgroup==3
	replace group = "P20-30"         if incgroup==4
	replace group = "P30-40"         if incgroup==5
	replace group = "P40-50"         if incgroup==6
	replace group = "P50-60"         if incgroup==7
	replace group = "P60-70"         if incgroup==8
	replace group = "P70-80"         if incgroup==9	
	replace group = "P80-90"         if incgroup==10
	replace group = "P90-100"        if incgroup==11
	replace group = "P90-91"         if incgroup==12
	replace group = "P91-92"         if incgroup==13
	replace group = "P92-93"         if incgroup==14
	replace group = "P93-94"         if incgroup==15
	replace group = "P94-95"         if incgroup==16
	replace group = "P95-96"         if incgroup==17
	replace group = "P96-97"         if incgroup==18
	replace group = "P97-98"         if incgroup==19
	replace group = "P98-99"         if incgroup==20
	replace group = "P99-100"        if incgroup==21
	replace group = "P99-99.9"       if incgroup==22
	replace group = "P99.9-100"      if incgroup==23
	replace group = "P99.9-99.99"    if incgroup==24
	replace group = "P99.99-100"     if incgroup==25			
	replace group = "Millionaires"   if incgroup==26

	*weights are 100K too big
	foreach var in `sumlist' `sumlist2' `sumlist3' `sumlist4' `sumlist5' `sumlist6' {
	replace `var' = `var'/100000
	}

	capture g agebin = "Age<20"
	replace agebin = "Age<20"             if agegroup==1
	replace agebin = "20=<Age<30"         if agegroup==2
	replace agebin = "30=<Age<40"         if agegroup==3
	replace agebin = "40=<Age<50"         if agegroup==4
	replace agebin = "50=<Age<60"         if agegroup==5
	replace agebin = "60=<Age<70"         if agegroup==6
	replace agebin = "70=<Age<80"         if agegroup==7
	replace agebin = "80=<Age<90"         if agegroup==8
	replace agebin = "90=<Age"            if agegroup==9	
	
	drop if N<50
	
	capture drop wagesfromfirm poswage if `yr'=="2014"
	order group N inc 
	export delimited using "$out/person_stats_tb2f_simple/all_`yr'_age`a'.csv", replace
	}
	
	
	
}

