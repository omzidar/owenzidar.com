*load panel 
import delimited "$raw/c_to_s_switcher_panel.csv", clear 

*keep one observation for each tin-year
bysort tin tax_yr: keep if _n == 1 

*keep a continuous period of years around each switch event 
g continuous = 1 if tax_yr == tax_yr_switch 
bysort tin (tax_yr): replace continuous = 1 if tax_yr>tax_yr_switch & tax_yr - tax_yr[_n-1] == 1 & continuous[_n-1] == 1 
g inv_tax_yr = tax_yr * -1 
bysort tin (inv_tax_yr): replace continuous = 1 if tax_yr<tax_yr_switch & tax_yr - tax_yr[_n-1] == -1 & continuous[_n-1] == 1 
replace continuous = 0 if continuous == . 
tab continuous 
drop if continuous == 0
drop continuous inv_tax_yr 

*cleaning
replace rcpts = rcpts2011on if rcpts == . & tax_yr >= 2011 & form == "scorp" 
g switch = (tax_yr == tax_yr_switch) 
drop tin_switch rcpts2011on

save "$dta/c_to_s_switcher_panel.dta", replace 
