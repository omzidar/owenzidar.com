********************************************************************************
** USD2014
********************************************************************************
capture program drop usd2014
program usd2014
    syntax, var(varname) yr(varname)
    replace `var'= `var'*1.503062988  if `yr'==1993 & `var'!=.
    replace `var'= `var'*1.47180133   if `yr'==1994 & `var'!=.
    replace `var'= `var'*1.441698831  if `yr'==1995 & `var'!=.
    replace `var'= `var'*1.415894851  if `yr'==1996 & `var'!=.
    replace `var'= `var'*1.391942424  if `yr'==1997 & `var'!=.
    replace `var'= `var'*1.377006398  if `yr'==1998 & `var'!=.
    replace `var'= `var'*1.357571973  if `yr'==1999 & `var'!=.
    replace `var'= `var'*1.327317133  if `yr'==2000 & `var'!=.
    replace `var'= `var'*1.297761328  if `yr'==2001 & `var'!=.
    replace `var'= `var'*1.278151458  if `yr'==2002 & `var'!=.
    replace `var'= `var'*1.253173459  if `yr'==2003 & `var'!=.
    replace `var'= `var'*1.219663817  if `yr'==2004 & `var'!=.
    replace `var'= `var'*1.181649182  if `yr'==2005 & `var'!=.
    replace `var'= `var'*1.146416065  if `yr'==2006 & `var'!=.
    replace `var'= `var'*1.116642696  if `yr'==2007 & `var'!=.
    replace `var'= `var'*1.095506864  if `yr'==2008 & `var'!=.
    replace `var'= `var'*1.08694      if `yr'==2009 & `var'!=.
    replace `var'= `var'*1.073775512  if `yr'==2010 & `var'!=.
    replace `var'= `var'*1.052064076  if `yr'==2011 & `var'!=.
    replace `var'= `var'*1.033016537  if `yr'==2012 & `var'!=.
    replace `var'= `var'*1.016449245  if `yr'==2013 & `var'!=.
    replace `var'= `var'*1            if `yr'==2014 & `var'!=.
end

*******************************************************************************
* Command line helpers.
*******************************************************************************
capture program drop pstopdf
program define pstopdf
    args path
	!${root}/bin/pstopdf `path'
end

*******************************************************************************
* Simple data commands.
*******************************************************************************
capture program drop trim_tails
program define trim_tails, byable(recall, noheader)
    syntax varname, level(real) [keep(real 0)]
	marksample touse
    winsor `varlist' if `touse', generate(`varlist'_w) p(`level')
	replace `varlist' = cond(`touse', ///
						     cond(`varlist'_w == `varlist', `varlist', .), ///
							 `varlist')
	if `keep' == 0 {
		drop `varlist'_w
	}
end

capture program drop impose_bounds
program define impose_bounds
    syntax varname, [upper(real 9999) lower(real 9999)]
    rename `varlist' `varlist'_ub
    quietly gen `varlist' = `varlist'_ub
    if `upper' != 9999 {
        quietly replace `varlist' = . if `varlist' > `upper'
    }
    if `lower' != 9999 {
        quietly replace `varlist' = . if `varlist' < `lower'
    }
end


capture program drop make_cpi
program define make_cpi

    gen deflater = 144.475/229.5963 if year == 1993
    replace deflater = 148.225/229.5963 if year == 1994
    replace deflater = 152.38333/229.5963 if year == 1995
    replace deflater = 156.85833/229.5963 if year == 1996
    replace deflater = 160.525/229.5963 if year == 1997
    replace deflater = 163.00833/229.5963 if year == 1998
    replace deflater = 166.58333/229.5963 if year == 1999
    replace deflater = 172.19167/229.5963 if year == 2000 
    replace deflater = 177.04167/229.5963 if year == 2001
    replace deflater = 179.86667/229.5963 if year == 2002 
    replace deflater = 184/229.5963 if year == 2003 
    replace deflater = 188.90833/229.5963 if year == 2004
    replace deflater = 195.26667/229.5963 if year == 2005
    replace deflater = 201.55833/229.5963 if year == 2006
    replace deflater = 207.34417/229.5963 if year == 2007
    replace deflater = 215.25425/229.5963 if year == 2008
    replace deflater = 214.56467/229.5963 if year == 2009
    replace deflater = 218.07617/229.5963 if year == 2010
    replace deflater = 224.923/229.5963 if year == 2011
    replace deflater = 229.59633/229.5963 if year == 2012

end

capture program drop residualize
program define residualize
	syntax newvarname=/exp, CONTROLs(varlist)	
	reg `exp' `controls'
	predict `varlist' if e(sample), residuals
	qui sum `exp' if e(sample)
	replace `varlist'=`varlist'+r(mean)
end

capture program drop ddplot_yagan
program define ddplot_yagan
    syntax varlist(fv) [if/] [aweight], fname(string) over(name) ///
    xlabel(string) ylabel(string) ///
    [absorb(name) raj(integer 0) ///
     diag(integer 0) start(integer 2000) end(integer 2010) trim(real 0) ///
     treatlab(string) contlab(string) xline(numlist)]

    * Save original data.
    tempfile orig
    save `orig'

    * Modify data.
    if "`if'" != "" {
        keep if `if'
    }

    if `trim' != 0 {
        trim_tails `1', level(`trim')
    }

    * For each period, figure out treatment coefficient for the groups.
    gen treatment_coeff = .
    forvalues i = `start'/`end' {
        display `i'
        if "`absorb'" != "" {
            areg `varlist' if `over' == `i' [`weight' `exp'], absorb(`absorb')
        }
        else {
            reg `varlist' if `over' == `i' [`weight' `exp']
        }
        matrix B = e(b)
        replace treatment_coeff = B[1,1] if `over' == `i'
    }

    * Grab group stats for collapse and gross up.
    bys `over': egen mean_y = mean(`1')
    bys `over': egen count_total = count(`over')

    * Collapse by group.
    gen count = 1
    collapse (sum) count [`weight' `exp'], by(`over' `2' mean_y treatment_coeff count_total)
    count
    gen y_group = (count_total*mean_y - count*treatment_coeff)/count_total + treatment_coeff if `2' == 1
    replace y_group = (count_total*mean_y - (count_total - count)*treatment_coeff)/count_total if `2' == 0
    list in 1

    * Vertical shift a la Chetty Friedman Saez (2013).
    * Subtract group mean and add year mean for the initial year or years.
    if `raj' != 0 {
        gen mean_holder = cond(`over' < `start' + `raj', y_group, .)
        bys `2': egen mean_yg = mean(mean_holder)
        egen mean_overall = mean(mean_yg)
        replace y_group = y_group - mean_yg + mean_overall
        sort `over'
    }

    * Make main plot.
    #delimit ;
    twoway 
        (connect y_group `over' if `2' == 1, 
            mcolor(red*1.6) lpattern(dash) lcolor(red*.8) msymbol(O)) 
        (connect y_group `over' if `2' == 0, 
            msymbol(s) lpattern(dash) mcolor(blue*1.6) lcolor(blue*.8))
        if `over' >= `start' & `over' <= `end', 
        xscale(r(`start' `end')) 
        xtitle("`xlabel'") ytitle("`ylabel'") 
        xline(`xline', lcolor(gs9))
        legend(label(1 "`treatlab'") 
               label(2 "`contlab'")) xsize(6);

    graph export "`fname'", replace;
    #delimit cr

    use `orig', clear
end
 
capture program drop binsum
program define binsum
    syntax varlist(fv) [if/], [Nquantile(integer 20) savegraph(string)]

    * Save original data.
    tempfile orig
    save `orig'

    * Modify data.
    if "`if'" != "" {
        keep if `if'
    }

    * Make bins
    xtile `2'_tile = `2', n(`nquantile')

    * Make bar chart.
    graph bar (mean) `1', over(`2'_tile)

    if "`savegraph'" != "" {
        graph export "`savegraph'", replace
    }

    use `orig', clear   
end

capture program drop post_scatter
program define post_scatter
                syntax, name(str)
                
				*graph export "`name'.png", replace
                graph export "${out}/`name'.pdf", replace
				
                outsheet using "${out}/`name'.csv", comma replace
end


*******************************************************************************
* Tax programs.
*******************************************************************************

capture program drop corp_tax
program define corp_tax
    syntax varlist(max=1), gen(string)
	gen 	`gen' = 0 									if `varlist' <= 0		& `varlist' != .
	replace `gen' = 0.15*`varlist' 						if `varlist' > 0 		& `varlist' <= 50000	& `varlist' != .
	replace `gen' = 7500 + 0.25*(`varlist'-50000) 		if `varlist' > 50000 	& `varlist' <= 75000	& `varlist' != .
	replace `gen' = 13750 + 0.34*(`varlist'-75000) 		if `varlist' > 75000 	& `varlist' <= 100000	& `varlist' != .
	replace `gen' = 22250 + 0.39*(`varlist'-100000) 	if `varlist' > 100000 	& `varlist' <= 335000	& `varlist' != .
	replace `gen' = 113900 + 0.34*(`varlist'-335000) 	if `varlist' > 335000 	& `varlist' <= 10^7		& `varlist' != .
	replace `gen' = 3400000 + 0.35*(`varlist'-10^7) 	if `varlist' > 10^7 	& `varlist' <= 15^7		& `varlist' != .
	replace `gen' = 5150000 + 0.38*(`varlist'-15^7) 	if `varlist' > 15^7 	& `varlist' <= 18333333	& `varlist' != .
	replace `gen' = 0.35*`varlist' 						if `varlist' > 18333333	& `varlist' != .
end

capture program drop tax_brkt
program define tax_brkt
    syntax varlist(max=1), gen(string)
	gen 	`gen' = 0 									if `varlist' <= 0	 	& `varlist' != .
	replace `gen' = 0.15		 						if `varlist' > 0 		& `varlist' <= 50000	& `varlist' != .
	replace `gen' = 0.25						 		if `varlist' > 50000 	& `varlist' <= 75000	& `varlist' != .
	replace `gen' = 0.34						 		if `varlist' > 75000 	& `varlist' <= 100000	& `varlist' != .
	replace `gen' = 0.39								if `varlist' > 100000 	& `varlist' <= 335000	& `varlist' != .
	replace `gen' = 0.34								if `varlist' > 335000 	& `varlist' <= 10^7		& `varlist' != .
	replace `gen' = 0.35								if `varlist' > 10^7 	& `varlist' <= 15^7		& `varlist' != .
	replace `gen' = 0.38								if `varlist' > 15^7 	& `varlist' <= 18333333	& `varlist' != .
	replace `gen' = 0.35 								if `varlist' > 18333333	& `varlist' != .
end


*******************************************************************************
* plot_reg: Plots conditional means and linear fit of a weighted regression on means
*******************************************************************************

capture program drop plot_reg
program define plot_reg
    syntax varlist, by(string) [title(string) subtitle(string) ytitle(string) xtitle(string) xformat(string) xlabel(string asis) ylabel(string asis) linearfit(string) legend(string) min(integer 5) xmin(real 0) xmax(real 0) xstep(real 0) notrim scale(string) coeff(string)]
    preserve
    
    * determin range of x-axis
    if "`trim'" != "notrim" {
        qui sum `by', det
        local xmin = `r(p1)'
        local xmax = `r(p99)'
        local xstep = ( `xmax' -  `xmin') / 6
        local xlabel = "`xmin'(`xstep')`xmax', format( `xformat' )"
    }
    
    * compure conditional means of y-value
    gen count = 1
    collapse (mean) `varlist' (sum) count, by( `by' )
    
    * convert y vars to logs
    if "`scale'" == "log" {
        foreach V of varlist `varlist' {
            replace `V' = ln( `V' )
        }
    }
    
    * linear fit
    if "`linearfit'" == "on" {
	
		* linear fit local
		local linearfits ""
		foreach V in `varlist' {
			* determine range of y-axis
			qui sum `V' if `by' > `xmin' & `by' < `xmax'
			local ymin = `r(min)'
			local ymax = `r(max)'
			local ystep = ( `ymax' -  `ymin') / 4
			
			* weighted regression on means
			qui reg `V' `by' [fweight = count]
			matrix define betas = e(b)
			matrix define ses = e(V)
			local b`V' = string(round(betas[1,1], 0.0001), "%9.4f")
			local se`V' = string(round(sqrt(ses[1,1]), 0.0001), "%9.4f")
			
			* save graph commands into a local
			local linearfits "`linearfits' ( lfit `V' `by' [fweight = count], range( `xmin' `xmax'))"
		}
	}

	* coefficients
	if "`coeff'" == "on" {
		local labelcoeff "text( `ymax' `xmax'  "Beta: `b', S.E.: `se'", place(sw) box fcolor(white) margin(vsmall))"
	}
		
    * produce graph
    graph twoway ( scatter `varlist' `by' if `by' >= `xmin' & `by' <= `xmax' & count > `min') `linearfits', title( "`title'") subtitle( "`subtitle'") ytitle( "`ytitle'") xtitle( "`xtitle'") xlabel( `xlabel' ) ylabel( `ylabel') `labelcoeff' scheme( s1mono) legend( `legend')    
    
    restore
end

capture program drop plot_means
program define plot_means
    syntax varlist, by(string) [logscale(string) min(integer 5)]
	   
    * compure conditional means of y-value
    gen count = 1
    collapse (mean) `varlist' (sum) count, by( `by' )
	
    * convert y vars to logs
    if "`logscale'" == "on" {
        foreach V of varlist `varlist' {
            replace `V' = ln( `V' )
        }
    }
	
	* drop cells with too few observations
	drop if count < `min' 
end

capture program drop _residualize
program define _residualize

	syntax newvarname=/exp, CONTROLs(varlist)
	
	reg `exp' `controls' [w=zip3_weights]
	predict `varlist' if e(sample), residuals
	qui sum `exp' if e(sample) [w=zip3_weights]
	replace `varlist'=`varlist'+r(mean)

end

*********************************
*Distinct
*********************************
capture program drop distinct
program define distinct
                syntax varlist

tempvar group max
                
qui egen `group' = group(`varlist')
qui summ `group' 
local obs = r(N)

display ""
display "*______`varlist'______*"


*Note that if any variable in varlist is missing, the value is non-populated
display "Distinct populated obs: " %-15.4gc r(max)

if(r(N) == r(max)){
    display "No duplicates"
}

if(r(N) > r(max)){
    qui bys `varlist': gen `max' = _N
    qui replace `max' = . if `group' == .
    
    qui count if `max' == 1
    display "% Singletons: " round(r(N)/`obs',.0001)*100

    qui sum `max'
    display "Min obs: " %-15.4gc r(min)
    display "Mean obs: " %-15.2fc round(r(mean), .01)
    display "Max obs: " %-15.4gc r(max)

    drop `max'
    
}

display "% of obs with missing values: " round((_N -`obs')/_N, 0.0001)*100
drop `group'
display ""
                
end



********************************************************************************
** HOCKEY PREP STARTUPS 5TH YEAR
********************************************************************************
capture program drop hockey_prep_startups5thyr
program define hockey_prep_startups5thyr
  use ${dta}/sp_firmpanel if inrange(tyfirst,${yrminoverallplusone},${yrmaxoverall}-5), clear
  local yrmaxoverallminus5 = ${yrmaxoverall}-5
  foreach varroot in profits sales profits_14dollars sales_14dollars numw2 {
    gen `varroot' = .
    forv t=$yrminoverallplusone/`yrmaxoverallminus5' {
      local tplus1 = `t'+1
      local tplus2 = `t'+2
      local tplus3 = `t'+3
      local tplus4 = `t'+4
      replace `varroot' = `varroot'`tplus4' if tyfirst==`t'
    }
  }
  gen eversalesgt5m = .
  forv t=$yrminoverallplusone/`yrmaxoverallminus5' {
    local tplus1 = `t'+1
    local tplus2 = `t'+2
    local tplus3 = `t'+3
    local tplus4 = `t'+4
    replace eversalesgt5m = (sales_14dollars`t'>5000000 | sales_14dollars`tplus1'>5000000 | sales_14dollars`tplus2'>5000000 | sales_14dollars`tplus3'>5000000 | sales_14dollars`tplus4'>5000000) if tyfirst==`t'
  }
  xtile salebin = sales_14dollars, n(20)
  keep payer_tin ein tyfirst profits sales profits_14dollars numw2 eversalesgt5m salebin
  save ${dta}/startups5yr, replace
end

********************************************************************************
** HOCKEY PREP STARTUPS 5 YEAR
********************************************************************************
capture program drop hockey_prep_startups5yr
program define hockey_prep_startups5yr
  use ${dta}/sp_firmpanel if inrange(tyfirst,${yrminoverallplusone},${yrmaxoverall}-5), clear
  local yrmaxoverallminus5 = ${yrmaxoverall}-5
  foreach varroot in profits sales profits_14dollars sales_14dollars numw2 {
    gen `varroot' = .
    forv t=$yrminoverallplusone/`yrmaxoverallminus5' {
      local tplus1 = `t'+1
      local tplus2 = `t'+2
      local tplus3 = `t'+3
      local tplus4 = `t'+4
      replace `varroot' = `varroot'`t' + `varroot'`tplus1' + `varroot'`tplus2' + `varroot'`tplus3' + `varroot'`tplus4' if tyfirst==`t'
    }
  }
  gen eversalesgt5m = .
  forv t=$yrminoverallplusone/`yrmaxoverallminus5' {
    local tplus1 = `t'+1
    local tplus2 = `t'+2
    local tplus3 = `t'+3
    local tplus4 = `t'+4
    replace eversalesgt5m = (sales_14dollars`t'>5000000 | sales_14dollars`tplus1'>5000000 | sales_14dollars`tplus2'>5000000 | sales_14dollars`tplus3'>5000000 | sales_14dollars`tplus4'>5000000) if tyfirst==`t'
  }
  xtile salebin = sales_14dollars, n(20)
  keep payer_tin ein tyfirst profits sales profits_14dollars numw2 eversalesgt5m salebin
  save ${dta}/startups5yr, replace
end


********************************************************************************
** HOCKEYS PREP CDWFIRMS
********************************************************************************
capture program drop hockey_prep_cdwfirms
program define hockey_prep_cdwfirms
  syntax, orgform(string) [ifcon(string)] [ifvars(string)] [personweight] [insert(string)] [specname(str)] [append] [startups] [apportioned] [soi]
  
  if("`append'" == ""){
	di "Deleting hockeys_cdwfirmsdata"
    capture rm ${dta}/hockeys_cdwfirmdata.dta
  }
  
  if("`apportioned'" == "apportioned"){
	local apportioned = "_apportioned"
  }
  
  di "Past the options"
  
  *CREATE THREE HOCKEY STICKS (RAW, WITHIN-INDUSTRY, WITHIN-INDUSTRY-SIZE) FOR EACH YEAR
  if "`startups'"!="" {
    local yrmax = ${yrmaxoverall} - 5
  }
  else {
    local yrmax = ${yrmaxoverall}
  }
  forv year = $yrminoverallplusone/`yrmax' {
	di "In the important loop"
    if "`startups'"!="" {
	  di "Now running startups"
      local yearminus1 = `year'-1
      use tin payer_tin tax_yr nc4 ord_inc ord_inc_totein ownshare agipctilebin`yearminus1' `ifvars' using ${dta}/`orgform'_firmowner_`year', clear
	  keep if inrange(ownshare,0,1)
      rename agipctilebin`yearminus1' agibin
      keep if agibin!=.
      capture keep `ifcon'
      rename tax_yr tyfirst
      merge m:1 payer_tin tyfirst using ${dta}/startups5yr, keep(3) nogen
      rename tyfirst tax_yr
      bys tin: egen zztinnumrows = count(tin)
      gen one_tinnumrows_allfirms = 1/zztinnumrows
      drop zz*
      gen costs = sales - profits
	  
	  if("`apportioned'" != ""){
		foreach varroot in profits sales profits_14dollars costs numw2 {
			di "`varoot'"
			gen `varroot'`apportioned' = ownshare*`varroot'
		}
	  }
      gen nc4salebin = 100*nc4 + salebin
    }
	
	else if "`soi'"!="" {
		di "***Building the SOI Based data***"
	
		use tin ein tax_yr profits`apportioned' sales`apportioned' numw2 nc4 nc4salebin one_tinnumrows_allfirms agibin ord_inc ord_inc_totein ownshare `ifvars' using ${dta}/`orgform'_firmowner_`year' `ifcon', clear
	  keep if inrange(ownshare,0,1)
	   
	    rename tax_yr year
		merge m:1 ein year using $dta/newsoi_cap, keep(3) keepusing(capital weight_f) nogen
		rename year tax_yr
		
		*MAKE SOI VARS INTO DOLLARS
		foreach var in capital {
			replace `var' = 1000*`var'
		}

		*COARSEN agibin
		replace agibin = 92.5 if inrange(agibin,90,95)
		replace agibin = 97 if inrange(agibin,95,99)
		replace agibin = 99.45 if inrange(agibin,99,99.9)
	
		*APPORTION CAPITAL AND NUMW2 SINCE NOT ALREADY APPORTIONED
		if("`apportioned'" != ""){
			foreach var in capital numw2 {
				*gen `var'`apportioned' = (ord_inc/ord_inc_totein)*`var'
				gen `var'`apportioned' = ownshare*`var'
			}
		}

        *CREATE COSTS AND COUNTS OF NON MISSING W2S
        gen costs`apportioned' = max(sales`apportioned'-profits`apportioned',0)
        gen cnt = numw2 != .

	}
	
    else {
      use tin tax_yr profits`apportioned' sales`apportioned' numw2 nc4 nc4salebin one_tinnumrows_allfirms agibin ord_inc ord_inc_totein ownerpay_totein wagebill2 numfirms wagebill ownshare `ifvars' using ${dta}/`orgform'_firmowner_`year' `ifcon', clear
	  keep if inrange(ownshare,0,1)
      
	  *APPORTION numw2 SINCE NOT ALREADY APPORTIONED
      if("`apportioned'" != ""){
		foreach var in numw2 ord_inc ord_inc_totein ownerpay_totein wagebill2 numfirms wagebill {
			di "GEN: `var'`apportioned'"
			gen `var'`apportioned' = ownshare*`var'
		} 
	  }
	  di "In else (nonstartups), out of the numw2 loop"
    }
	
	di "________________LOOP FOR: `year'____________"
	*CREATE profits_14dollars_apportioned SINCE NOT ALREADY CREATED
    capture gen profits_14dollars`apportioned' = profits`apportioned'
    usd2014, var(profits_14dollars`apportioned') yr(tax_yr)
    capture gen costs`apportioned' = max(sales`apportioned'-profits`apportioned',0)
	
    *PROCEED
    gen ppw = profits_14dollars`apportioned'/numw2`apportioned'/1000
	if "`startups'"=="" {
      gen pm = profits`apportioned'/sales`apportioned'
      gen mu = profits`apportioned'/costs`apportioned'
	  gen wpf = numw2`apportioned'
	  gen oppw = ownerpay_totein`apportioned'/numw2`apportioned'/1000
      gen va = wagebill`apportioned' + ord_inc_totein`apportioned'
	  gen vapw = va/numw2`apportioned'/1000
	  gen sos = ownerpay_totein`apportioned'/va
	  gen numf = numfirms`apportioned'
	}
	else {
	  gen pm = ppw
	  gen mu = ppw
	  gen sos = ppw
	  gen oppw = ppw
	  gen vapw = ppw
	  gen va = ppw
	  gen numf = ppw
	  gen wpf = ppw
	}
    foreach var in pm mu {
      replace `var'=. if !inrange(`var',-1,1)
    }
    foreach var in sos {
      replace `var'=. if !inrange(`var',0,1)
    }
    foreach var in ppw oppw vapw va {
      sum `var', d
      replace `var'=r(p1) if `var'<r(p1) & `var'!=.
      replace `var'=r(p99) if `var'>r(p99) & `var'!=.
    }
	
	
    foreach yvar in pm mu ppw wpf oppw va vapw sos numf {
      foreach absorbvar in none nc4 nc4salebin {
	  
		di "ABS LOOP: `yvar', `absorbvar'"
        
		if "`yvar'"=="pm" {
          local scalevar "sales`apportioned'"
        }
        else if "`yvar'"=="mu" {
          local scalevar "costs`apportioned'"
        }
        else if inlist("`yvar'","ppw","oppw","vapw","sos","numf") {
          local scalevar "numw2`apportioned'"
        }
		else if "`yvar'"=="wpf" {
		  capture gen cnt = numw2 != .
          local scalevar "cnt"
        }
		
        if "`absorbvar'"=="none" {
          gen `yvar'_`absorbvar' = `yvar'
          gen `yvar'_`absorbvar'_numer = `yvar'_`absorbvar'*`scalevar'
        }
        else {
          if "`personweight'"!="" {
			di "Person weighted"
            qui areg `yvar' [w=one_tinnumrows_allfirms], absorb(`absorbvar')
            predict `yvar'_`absorbvar', r
            qui sum `yvar' [w=one_tinnumrows_allfirms]
            replace `yvar'_`absorbvar' = `yvar'_`absorbvar' + r(mean)            
          }
          else {
			di "NOT person weighted"
            qui areg `yvar' [w=`scalevar'], absorb(`absorbvar')
            predict `yvar'_`absorbvar', r
            qui sum `scalevar' if `yvar'!=. & `scalevar'!=. & `absorbvar'!=.
            local scalevarsum = r(sum)
            gen zzprofits = `yvar'*`scalevar'
            qui sum zzprofits if `yvar'!=. & `scalevar'!=. & `absorbvar'!=.
            local profitssum = r(sum)
            gen zzprofitshat = `yvar'_`absorbvar'*`scalevar'
            qui sum zzprofitshat if `yvar'!=. & `scalevar'!=. & `absorbvar'!=.
            local profitshatsum = r(sum)
            qui sum `yvar' [w=`scalevar'] if `yvar'!=. & `scalevar'!=. & `absorbvar'!=.
            replace `yvar'_`absorbvar' = `yvar'_`absorbvar' + (`profitssum'-`profitshatsum')/`scalevarsum'
            drop zz*
            gen `yvar'_`absorbvar'_numer = `yvar'_`absorbvar'*`scalevar'
            qui sum `yvar'_`absorbvar'_numer
            disp r(sum)
            disp `profitssum'
            assert abs((`profitssum'-r(sum))/r(sum))<.0001
          }
        }
      }
    }
	
	*Add extra control vars related to SOI
	if("`soi'" != "" ){
		di "Add K controls"

        foreach var in mu {
			replace `var'=. if !inrange(`var',-1,1)
		}
	    
		di "CHECK: `scalevar'"
		
		foreach yvar in pm mu ppw wpf oppw va vapw sos numf {
		  if "`yvar'"=="pm" {
			local scalevar "sales`apportioned'"
          }
          else if "`yvar'"=="mu" {
            local scalevar "costs`apportioned'"
          }
          else if inlist("`yvar'","ppw","oppw","vapw","sos","numf") {
            local scalevar "numw2`apportioned'"
          }
		  else if "`yvar'"=="wpf" {
            local scalevar "cnt"
          }
		  
		  gen k_s = capital`apportioned'/sales`apportioned'
		  
		  foreach var in k_s {
			   sum `var' [w=`scalevar'], d
			   replace `var'=r(p1) if `var'<r(p1) & `var'!=.
			   replace `var'=r(p99) if `var'>r(p99) & `var'!=.
			   forv i=1/4 {
				 gen `var'_`i' = `var'^`i'
				}
			}
		    di "CHECK: `scalevar'"
			areg `yvar' k_s_* [w=`scalevar'], absorb(nc4)
			predict `yvar'_nc4kintens, r
			sum `yvar' [w=`scalevar']
			replace `yvar'_nc4kintens = `yvar'_nc4kintens + r(mean)
			gen `yvar'_nc4kintens_numer = `yvar'_nc4kintens*`scalevar'
			drop k_s*
		}
	
	}
	
	di "Into the collapsing section..."
	
    if "`personweight'"!="" {
      collapse (mean) pm* mu* ppw* wpf* oppw* va* vapw* sos* numw* numf* [w=one_tinnumrows_allfirms], by(tax_yr agibin)
    }
    else {

	  gen wpf_numer = numw2
	  gen count = numw2
		
      if "`soi'"!="" {
        collapse (sum) *numer sales`apportioned' costs`apportioned' numw2`apportioned' (count) count, by(tax_yr agibin)
      }
      else {
        collapse (sum) *numer sales`apportioned' costs`apportioned' numw2`apportioned' (count) count, by(tax_yr agibin)
      }

      foreach yvar in pm mu ppw wpf oppw va vapw sos numf {
        foreach absorbvar in none nc4 nc4salebin nc4kintens {
          if "`yvar'"=="pm" {
            local scalevar "sales`apportioned'"
          }
          else if "`yvar'"=="mu" {
            local scalevar "costs`apportioned'"
          }
          else if inlist("`yvar'","ppw","oppw","vapw","sos","numf") {
            local scalevar "numw2`apportioned'"
          }
		  else if "`yvar'"=="wpf" {
            local scalevar "count"
          }
          
		  capture gen `yvar'_`absorbvar' = `yvar'_`absorbvar'_numer/`scalevar'
        }
      }
      drop *numer sales`apportioned' costs`apportioned' numw2`apportioned' count
    }
	
	`insert'
    capture append using ${dta}/hockeys_cdwfirmdata
	di "Saving hockeys_cdwfirmsdata"
    save ${dta}/hockeys_cdwfirmdata, replace
	saveold ${dta}/hockeys_cdwfirmdata_`specname', v(12) replace
  }

  foreach yvar in pm mu ppw wpf oppw va vapw sos numf {
	
	di "Saving hockeys dtas"
	
	if("`soi'" != ""){
		local yname = "`yvar'_soi"
	}
	else{
		local yname "`yvar'"
	}
	
    use tax_yr agibin `yvar'* using ${dta}/hockeys_cdwfirmdata, clear
    rename `yvar'_none yvar_none
    rename `yvar'_nc4 yvar_nc4
    rename `yvar'_nc4salebin yvar_nc4salebin
    save ${dta}/hockeys_`yname', replace
  }
 
end

********************************************************************************
** HOCKEYS REMAKE
********************************************************************************
capture program drop hockeys_remake
program hockeys_remake
   syntax, using(str)
 
 noi di "Changing main data name"
 capture rm hockeys_cdwfirmdata.dta
 cp `using' hockeys_cdwfirmdata.dta
 
 noi di "Saving hockeys dtas using `using'"  
 foreach yvar in pm mu ppw wpf {
    use tax_yr agibin `yvar'* using `using', clear
    rename `yvar'_none yvar_none
    rename `yvar'_nc4 yvar_nc4
    rename `yvar'_nc4salebin yvar_nc4salebin
    save hockeys_`yvar', replace
  }

end

********************************************************************************
** HOCKEY GRAPHER TWO INDS
********************************************************************************
capture program drop hockey_grapher_twoinds
program define hockey_grapher_twoinds
  syntax, yvar(string) yvarenglish(string) ind1(int) ind1english(string) ind2(int) ind2english(string) specname(string)
  
  use hockeys_cdwfirmdata.dta, clear
  keep if inlist(tax_yr, 2013,2014)
  collapse (mean) pm* mu* ppw* wpf*, by(agibin nc4)
  
  twoway (scatter `yvar' agibin if nc4==`ind1', c(l) m(O) lc(navy) mc(navy)) || (scatter `yvar' agibin if nc4==`ind2', c(l) m(S) lc(cranberry) mc(cranberry) msize(medsmall)),  ${gpr} ytitle("`yvarenglish'") xtitle("Personal income rank") xlab(90(1)100) legend(label(1 "`ind1english' (NAICS `ind1')") label(2 "`ind2english' (NAICS `ind2')") row(3) region(lc(white)))	   
  graph export "${out}/G_hockey_`yvar'_ind`ind1'ind`ind2'_`specname'.pdf", replace

end

********************************************************************************
** HOCKEY GRAPHER SOI CAPITAL INTENSE
********************************************************************************
capture program drop hockey_graphersoicapintens
program define hockey_graphersoicapintens
  syntax, yvar(name) yvarenglish(string)
  global yvar = "`yvar'"
  global yvarenglish = "`yvarenglish'"


  di "*HOCKEYS IN 2001 and 2014"
  foreach year in 2001 2014 {
    use hockeys_cdwfirmdata_soi if tax_yr==`year', clear
	rename `yvar'* yvar*
	
    foreach suffix in alltop tpt1 {
      twoway (scatter yvar_nc4_`suffix' agibin, c(l) m(O) lc(navy) mc(navy)) || (scatter yvar_nc4kintens_`suffix' agibin, c(l) m(S) lc(cranberry) mc(cranberry) msize(medsmall)),  $gpr ytitle("${yvarenglish}") xtitle("Personal income rank") xlab(90(1)100) legend(label(1 "Net of 4-digit industry FEs") label(2 "Net of 4-digit industry FEs and a quartic in capital intensity") row(3) region(lc(white)))
      graph export "${out}/G_hockey`year'soicapintens_${yvar}_`suffix'.pdf", replace
    }
  }

  di "*TIME SERIES OF TOP 0.1%"
  use hockeys_cdwfirmdata_soi if inrange(agibin,99.9,99.99), clear
  
  rename `yvar'* yvar*
  
  twoway (scatter yvar_nc4_tpt1 tax_yr, c(l) m(O) lc(navy) mc(navy)) || (scatter yvar_nc4kintens_tpt1 tax_yr, c(l) m(S) lc(cranberry) mc(cranberry) msize(medsmall)),  $gpr ytitle("${yvarenglish}") xtitle("") xlab($yrminoverallplusone(1)$yrmaxoverall, angle(vertical)) legend(label(1 "Net of 4-digit industry FEs") label(2 "Net of 4-digit industry FEs and a quartic in capital intensity") row(5) region(lc(white)))
  graph export "${out}/G_hockeyheightsoicapintensfull2_${yvar}.pdf", replace
end

********************************************************************************
** ES GRAPH
********************************************************************************
capture program drop ES_graph
program define ES_graph
    syntax, ci(real) [ xti(string) yti(string) lab1(string) outname(string) regnumobs(string) regnumeins(string) pcteffectsize(string) ownshare(string)]
    preserve
    qui gen fig_upper=b+`ci'*se
    qui gen fig_lower=b-`ci'*se
    qui gen fig_t = t
    qui rename b* fig_b*
    twoway (scatter fig_b fig_t if  fig_t<6 & fig_t>-5, c(l) xline(-0.0, lc(gs11) lp(shortdash)) yline(0, lc(gs11) lp(shortdash))) (rcap fig_upper fig_lower fig_t  if fig_t<6 & fig_t>-5 , lpattern(solid) lcolor(dknavy) c(l) m(i) ), $gpr xtitle("`xti'") ytitle("`yti'") xlab(-4(1)4) legend(on order(- "`regnumobs' obs, `regnumeins' eins, `pcteffectsize'% effect,  `ownshare'% ownshare") pos(7) ring(0))
    
	** outname is passed absolute path
	graph export "`outname'.pdf", replace
    restore
end


********************************************************************************
** OWNERDEATHS BUILD PREP
********************************************************************************
capture program drop ownerdeaths_build_prep
program define ownerdeaths_build_prep
     syntax, orgform(str)
  *******************************************************************************
  * 1. PREP FOR OWNERDEATHS BUILDS: PREP ALL FIRM OBS BY YEAR
  *******************************************************************************
  forv yr=$firstyear/$lastyear {
    use ein tax_yr $firmvarlist using $dta/`orgform'_firmowner_`yr' if ein!=., clear
    rename tax_yr year
    duplicates drop
    duplicates drop ein, force
    foreach var in $firmvarlist_dollarvars {
      usd2014, var(`var') yr(year)
    }
    save ${dump}/temp_firms_`yr'_`orgform', replace
  }
  
  *******************************************************************************
  * 2. PREP FOR OWNERDEATHS BUILDS: CREATE MINIMUM EIN-YEAR FILE NECESSARY TO MATCH OWNER-DEATH FIRMS AND COUNTERFACTUAL FIRMS
  *******************************************************************************
  *GET FULL LIST OF EINS OF POTENTIAL OWNER DEATH FIRMS
  clear
  forv yr=$odfirstyear/$odlastyear {
    append using ${dump}/temp_firms_`yr'_`orgform', keep(ein)
  }
  duplicates drop
  save ${dump}/temp_eins_`orgform', replace
  *MAKE INTO A BALANCED PANEL WITH SALES AND NUMW2
  forv yr=$firstyear/$lastyear {
    use ${dump}/temp_eins_`orgform', clear
    merge m:1 ein using ${dump}/temp_firms_`yr'_`orgform', keep(1 3) nogen keepusing(sales numw2)
    gen year=`yr'
    save ${dump}/temp_eins_vars_`yr'_`orgform', replace
  }
  clear
  forv yr=$firstyear/$lastyear {
    append using ${dump}/temp_eins_vars_`yr'_`orgform'
  }
  order ein year
  save ${dump}/temp_eins_vars_`orgform', replace
  *CREATE SAMPLE RESTRICTION FLAGS
  tsset ein year

  ** both deaths and retirements use this definition!
  gen keepinsample_l4l1 = (l1.sales>0 & l2.sales>0 & l3.sales>0 & l4.sales>0 & l1.sales!=. & l2.sales!=. & l3.sales!=. & l4.sales!=. & max(l1.sales,l2.sales,l3.sales,l4.sales)>=$minsales)

  gen posnumw2_l4l1 = (l1.numw2>0 & l2.numw2>0 & l3.numw2>0 & l4.numw2>0 & l1.numw2!=. & l2.numw2!=. & l3.numw2!=. & l4.numw2!=.)
  gen sales_l1 = l1.sales
  *SAVE
  compress
  keep ein year keepinsample_l4l1 posnumw2_l4l1 sales_l1
  * OWNEDEATH WATERFALL CHECK (1)
  distinct ein
  disp _N
  save ${dump}/temp_candidate_firms_`orgform', replace
  
  *******************************************************************************
  * 3. PREP FOR OWNERDEATHS BUILDS: STACK ALL POTENTIAL OWNER DEATH OBS AND COUNTERFACTUAL OWNERS, AND RESTRICT TO CANDIDATES
  *******************************************************************************
  clear
  forv yr=$firstyear/$lastyear {
    append using $dta/`orgform'_firmowner_`yr', keep(tin ein tax_yr ssa_yob ssa_yod agipctilebin* nc4 ord_inc ord_inc_totein psinc)
  }
  count
  drop if ein==.
  count
  *SAVE LAST YEAR'S psinc_14dollars
  gen psinc_14dollars = psinc
  usd2014, var(psinc_14dollars) yr(tax_yr)
  count
  sort ein tin tax_yr
  by ein tin: gen psinc_14dollars_l1 = psinc_14dollars[_n-1]
  drop psinc psinc_14dollars
  count
  *PROCEED
  rename tax_yr year
  egen double zzeintin = group(ein tin)
  count
  tsset zzeintin year
  count
  gen ownshare = l.ord_inc/l.ord_inc_totein
  drop ord_inc ord_inc_totein zz*
  merge m:1 ein year using ${dump}/temp_candidate_firms_`orgform', nogen keep(3)
  compress
  save ${dump}/temp_candidate_owners_`orgform', replace
  
  *******************************************************************************
  * 4. PREP FOR OWNERDEATHS BUILDS: PREP MATCH OF OWNER DEATHS TO COUNTERFACTUAL OWNER DEATHS
  *******************************************************************************
  use ${dump}/temp_candidate_owners_`orgform', clear
  gen deathever = ((ssa_yod==year | ssa_yod==year+1) & !mi(ssa_yod))
  gen death = ((ssa_yod==year | ssa_yod==year+1) & !mi(ssa_yod)) & inrange(year,$odfirstyear,$odlastyear)
  gen death_f0 = (death==1 & ssa_yod==year)
  bys ein tin: egen zzeintindeath = max(death)
  by ein tin: egen zzeintindeath_f0 = max(death_f0)
  drop if zzeintindeath_f0==1 & death==1 & death_f0==0
  drop zz*
  by ein: egen zznumdeaths = total(death)
  drop if zznumdeaths>1
  drop if zznumdeaths!=0 & death!=1
  by ein: egen zznumeverdeaths = total(deathever)
  tab zznumeverdeaths
  drop if zznumdeaths==0 & zznumeverdeaths!=0
  drop zz*
  by ein: egen zzeindeath = max(death)
  assert zzeindeath<=1
  drop zz*
  assert death==deathever
  drop deathever
  distinct ein
  disp _N
  save ${dump}/temp_odbuild_prep_`orgform', replace
  keep if death == 1
  distinct ein
  disp _N
  
end


********************************************************************************
** OWNERDEATHS BUILD
********************************************************************************
capture program drop ownerdeaths_build
program define ownerdeaths_build
     syntax, ageminimum(int) agemaximum(int) orgform(str)

  *******************************************************************************
  * 1. RESTRICT THE SAMPLE
  *******************************************************************************
  use ${dump}/temp_odbuild_prep_`orgform', clear
  gen nc_var = floor(nc4/10)
  gen age = year-ssa_yob
  gen age_var = 5*floor(age/5)
  gen agipctilebin_var=.
  forv yr=$odfirstyear/$odlastyear {
   local yrM1 = `yr'-1
   replace agipctilebin_var=agipctilebin`yrM1' if year==`yr'
  }
  compress
  tempfile samplewhittling
  save `samplewhittling', replace
  keep if death==1
  distinct ein
  use `samplewhittling', clear
  keep if agipctilebin_var>99
  save `samplewhittling', replace
  keep if death==1
  distinct ein
  use `samplewhittling', clear
  drop if !inrange(age,`ageminimum',`agemaximum')
  save `samplewhittling', replace
  keep if death==1
  distinct ein
  use `samplewhittling', clear
  keep if keepinsample_l4l1==1
  keep if posnumw2_l4l1==1
  save `samplewhittling', replace
  keep if death==1
  distinct ein
  use `samplewhittling', clear
  drop if nc_var<=0 | nc_var>=999
  drop if nc_var==. | age_var==. | agipctilebin_var==.
  drop agipctilebin2* nc4 ssa_yob
  save `samplewhittling', replace
  keep if death==1
  distinct ein
  use `samplewhittling', clear
  gen salesbin_var=.
  forv yr=$odfirstyear/$odlastyear {
    xtile zzsalesbin = sales_l1 if year==`yr', n(10)
    replace salesbin_var=zzsalesbin if year==`yr'
    drop zz*
  }
  keep ein year tin death* *_var ownshare psinc_14dollars_l1
  compress
  save ${dump}/temp_prematch_slim_`orgform'_`ageminimum'_`agemaximum', replace
  use ${dump}/temp_prematch_slim_`orgform'_`ageminimum'_`agemaximum', clear
  keep if death == 1
  distinct ein
  disp _N

  *******************************************************************************
  * 2. MATCH OWNER DEATHS TO COUNTERFACTUAL OWNER DEATHS
  *******************************************************************************
  *MATCH
  use ${dump}/temp_prematch_slim_`orgform'_`ageminimum'_`agemaximum', clear
  tempfile orig needle
  egen zzcell = group(nc_var age_var agipctilebin_var salesbin_var year)
  save `orig', replace
  keep if death==1
  save `needle', replace
  use death zzcell ein tin using `orig' if death==0, clear
  drop death
  rename * *_hs
  rename zzcell_hs zzcell
  joinby zzcell using `needle', unmatched(none)
  drop zz*
  distinct ein
  disp _N
  save ${dump}/temp_odmatch_spine_`orgform'_`ageminimum'_`agemaximum', replace
  use ein agipctile using ${dump}/temp_odmatch_spine_`orgform'_`ageminimum'_`agemaximum', clear
  keep if agipctile > 99.9
  distinct ein
  disp _N

  **QUICK DIAGNOSTIC: HOW MANY OWNER DEATHS?
  use ein using ${dump}/temp_odmatch_spine_`orgform'_`ageminimum'_`agemaximum', clear
  count
  duplicates drop
  count

  *******************************************************************************
  * 3. MERGE ON sales87,...,profits13 AND CREATE numw2pre, AND RESHAPE WIDE
  *******************************************************************************
  *STACK ALL RELEVANT EINS
  use ein_hs using ${dump}/temp_odmatch_spine_`orgform'_`ageminimum'_`agemaximum', clear
  rename ein_hs ein
  append using ${dump}/temp_odmatch_spine_`orgform'_`ageminimum'_`agemaximum', keep(ein)
  duplicates drop
  sort ein
  save ${dump}/temp_odhseins_`orgform'_`ageminimum'_`agemaximum', replace

  *GET AS MANY YEARS OF DATA AS POSSIBLE FOR THESE EINS 
  forv yr=$firstyear/$lastyear {
    use ${dump}/temp_odhseins_`orgform'_`ageminimum'_`agemaximum', clear
    merge 1:1 ein using ${dump}/temp_firms_`yr'_`orgform', keep(3) nogen keepusing($firmvarlist)
    gen year=`yr'
    save ${dump}/temp_odhseins_vars_`yr'_`orgform'_`ageminimum'_`agemaximum', replace
  }
  clear
  forv yr=$firstyear/$lastyear {
    append using ${dump}/temp_odhseins_vars_`yr'_`orgform'_`ageminimum'_`agemaximum'
  }
  order ein year
  save ${dump}/temp_odhseins_vars_`orgform'_`ageminimum'_`agemaximum', replace

  *PREP OWNER DEATH DATA FOR MERGES
  use ${dump}/temp_odmatch_spine_`orgform'_`ageminimum'_`agemaximum', clear
  foreach var in ein tin {
    rename `var' `var'_od
  }
  rename year year_var
  order *_od *_hs
  **MAKE BALANCED PANEL BY EVENT YEAR AND THEN RESTRICT TO VALID CALENDAR YEARS
  save ${dump}/temp_od_`orgform'_`ageminimum'_`agemaximum', replace
  gen eventtime=.
  forv yr=$eventfirstyear/$eventlastyear {
    replace eventtime=`yr' if eventtime==.
    append using ${dump}/temp_od_`orgform'_`ageminimum'_`agemaximum'
  }
  drop if eventtime==.
  gen year = year_var + (eventtime-100)
  keep if inrange(year,$firstyear,$lastyear)
  *MERGE ON OWNER-DEATH AND HAYSTACK TIME-VARYING VALUES
  foreach suffix in od hs {
    rename ein_`suffix' ein
    merge m:1 ein year using ${dump}/temp_odhseins_vars_`orgform'_`ageminimum'_`agemaximum', nogen keep(1 3)
    foreach var in $firmvarlist {
      rename `var' `var'_`suffix'
     }
    rename ein ein_`suffix'
  }
  *SET VARIABLES TO ZERO IF MISSING
  foreach suffix in od hs {
    foreach var in $firmvarlist {
      replace `var'_`suffix'=0 if `var'_`suffix'==.
     }
  }
  *CREATE ID VARIABLES
  egen odid = group(ein_od tin_od)
  egen odhsid = group(ein_od tin_od ein_hs tin_hs)
  *VALIDATE THAT THE DATA ARE UNIQUE ON odshid-eventtime
  gen zzodhsidet100 = odhsid if eventtime==100
  duplicates tag zzodhsidet100, gen(zztag)
  sum zztag if zzodhsidet100!=.
  assert r(max)==0
  drop zz*
  *MAKE WEIGHT EQUAL TO 1/NUMBEROFINSTANCES
  gen zzet100 = 1 if eventtime==100
  bys odid: egen totalodmatches = total(zzet100)
  sum totalodmatches
  drop zz*
  gen odidwgt = 1/totalodmatches
  *SAVE
  compress
  save $dta/ownerdeaths_build_`orgform'_`ageminimum'_`agemaximum', replace

  *******************************************************************************
  *DIAGNOSTICS
  *******************************************************************************
  use ein_od tin_od using $dta/ownerdeaths_build_`orgform'_`ageminimum'_`agemaximum', clear
  duplicates drop
  count
  keep ein_od
  duplicates drop
  count

  *******************************************************************************
  *VALIDATION: RESHAPE LONG AND CONFIRM ALL FIRMS HAVE [t-4,t-1] ROWS AND THAT numw2_ IS ALWAYS THERE
  *******************************************************************************
  use $dta/ownerdeaths_build_`orgform'_`ageminimum'_`agemaximum', clear
  drop totalodmatches odidwgt
  reshape long ein_ tin_ $firmvarlist_, i(odhsid *var eventtime odid year) j(treatment) string
  egen odhsidt = group(odhsid treatment)
  tsset odhsidt year
  list ein_ tin_ year year_var eventtime sales_ if _n<40
  gen zzkeepinsample_l4l1 = (l1.sales_>0 & l2.sales_>0 & l3.sales_>0 & l4.sales_>0 & l1.sales_!=. & l2.sales_!=. & l3.sales_!=. & l4.sales_!=. & max(l1.sales_,l2.sales_,l3.sales_,l4.sales_)>=$minsales) if year==year_var
  list ein_ tin_ year year_var eventtime sales_ zz* if _n<40
  gen zzposnumw2_l4l1 = (l1.numw2_>0 & l2.numw2_>0 & l3.numw2_>0 & l4.numw2_>0 & l1.numw2_!=. & l2.numw2_!=. & l3.numw2_!=. & l4.numw2_!=.) if year==year_var
  list ein_ tin_ year year_var eventtime numw2_ zzpos* if _n<40
  collapse (max) keepinsample_l4l1=zzkeepinsample_l4l1 posnumw2_l4l1=zzposnumw2_l4l1, by(odhsid treatment)
  assert keepinsample_l4l1==1 if treatment=="od"
  assert keepinsample_l4l1==1 if treatment=="hs"
  assert posnumw2_l4l1==1 if treatment=="od"
  assert posnumw2_l4l1==1 if treatment=="hs"
end


********************************************************************************
** OWNERDEATHS ANALYSIS
********************************************************************************
capture program drop ownerdeaths_analysis
program define ownerdeaths_analysis
     syntax, orgform(str) sample(str) ageminimum(int) agemaximum(int)

  *******************************************************************************
  * 1. PREP ANALYSIS DATASET
  *******************************************************************************
  di "`orgform'"
  di "`sample'"
  di "`ageminimum'"
  di "`agemaximum'"
  *RESTRICT OWNERS
  if "`sample'"=="top1" {
    use $dta/ownerdeaths_build_`orgform'_`ageminimum'_`agemaximum' if inrange(eventtime,96,104) & agipctilebin_var>99, clear
  }
  else if "`sample'"=="toppt1" {
    use $dta/ownerdeaths_build_`orgform'_`ageminimum'_`agemaximum' if inrange(eventtime,96,104) & agipctilebin_var>99.9, clear
  }
  else if "`sample'"=="millionaire" {
    use $dta/ownerdeaths_build_`orgform'_`ageminimum'_`agemaximum' if inrange(eventtime,96,104) & psinc_14dollars_l1>=1000000 & psinc_14dollars_l1!=., clear
  }
  *DROP THOSE WITH LOW OWNSHARE
  drop if ownshare<.2
  *IMPUTE OWNSHARE IF MISSING OR ZERO
  sum ownshare [aw=odidwgt] if ownshare!=0 & ownshare!=.
  replace ownshare=r(mean) if ownshare==. | ownshare==0

  *ADD VA
  g va_od = (sales_od-costsold_od)
  replace va_od = . if va_od <= 0
  g va_hs = (sales_hs-costsold_hs)
  replace va_hs = . if va_hs <= 0

  *TSSET THE DATA
  tsset odhsid year
  *CREATE PRE-PERIOD NUMBER OF WORKERS AND OTHER PRE-PERIOD MEASURES
  foreach suffix in od hs {
    gen zznumw2pre_`suffix' = (l1.numw2_`suffix'+l2.numw2_`suffix'+l3.numw2_`suffix'+l4.numw2_`suffix')/4 if year==year_var
    by odhsid: egen numw2pre_`suffix' = mean(zznumw2pre_`suffix')
    drop zz*
    gen zzsalespre_`suffix' = (l1.sales_`suffix'+l2.sales_`suffix'+l3.sales_`suffix'+l4.sales_`suffix')/4 if year==year_var
    by odhsid: egen salespre_`suffix' = mean(zzsalespre_`suffix')
    drop zz*
    gen zzvapre_`suffix' = (l1.va_`suffix'+l2.va_`suffix'+l3.va_`suffix'+l4.va_`suffix')/4 if year==year_var
    by odhsid: egen vapre_`suffix' = mean(zzvapre_`suffix')
    drop zz*
  }
  *CREATE OUTCOMES
  foreach suffix in od hs {
    gen salesgt0_`suffix' = (sales_`suffix'>0)
    gen profits_numw2pre_`suffix' = profits_`suffix'/numw2pre_`suffix'
    gen lnsales_`suffix' = ln(sales_`suffix')
    gen sales_salespre_`suffix' = sales_`suffix'/salespre_`suffix'
    gen lnsales_salespre_`suffix' = ln(sales_`suffix'/salespre_`suffix')
    gen lnva_`suffix' = ln(va_`suffix')
    gen va_vapre_`suffix' = va_`suffix'/vapre_`suffix'
    gen lnva_vapre_`suffix' = ln(va_`suffix'/vapre_`suffix')
    gen lnnumw2_`suffix' = ln(numw2_`suffix')
    gen numw2_numw2pre_`suffix' = numw2_`suffix'/numw2pre_`suffix'
    gen lnnumw2_numw2pre_`suffix' = ln(numw2_`suffix'/numw2pre_`suffix')
  }
  *TRIM BASED ON THE OWNER-DEATH FIRMS' PRE-PERIOD VALUES
  foreach varroot in profits_numw2pre sales_salespre numw2_numw2pre va_vapre {
    sum `varroot'_od [aw=odidwgt] if inrange(eventtime,96,99), d
    foreach suffix in od hs {
      replace `varroot'_`suffix'=r(p1)  if `varroot'_`suffix'<r(p1)  & `varroot'_`suffix'!=.
      replace `varroot'_`suffix'=r(p99) if `varroot'_`suffix'>r(p99) & `varroot'_`suffix'!=.
    }
  }
  *INTENSIVE MARGIN ONLY
  foreach varroot in profits_numw2pre lnsales sales_salespre lnsales_salespre lnva va_vapre lnva_vapre lnnumw2 numw2_numw2pre lnnumw2_numw2pre {
    foreach suffix in od hs {
      gen zzdies=.
      forv eventtime=96/104 {
        replace zzdies = sales_`suffix'==0 if eventtime==`eventtime'
	  }
	  bys ein_od tin_od ein_hs tin_hs: egen zzdiesever = max(zzdies)
      gen `varroot'_int_`suffix' = `varroot'_`suffix'
      replace `varroot'_int_`suffix'=. if zzdiesever==1
	  drop zz*
    }
  }
  *CREATE DIFFERENCE OUTCOMES
  foreach varroot in salesgt0 profits_numw2pre lnsales sales_salespre lnsales_salespre lnva va_vapre lnva_vapre lnnumw2 numw2_numw2pre lnnumw2_numw2pre profits_numw2pre_int sales_salespre_int lnsales_int lnsales_salespre_int numw2_numw2pre_int lnva_int va_vapre_int lnva_vapre_int {
    gen `varroot'_dif = `varroot'_od - `varroot'_hs
  }
  *CREATE DUMMIES FOR REGRESSION
  gen D = year-year_var
  gen Dn5p=D<=-5
  gen Dn4=D==-4
  gen Dn3=D==-3
  gen Dn2=D==-2
  gen D0=D==0
  gen D1=D==1
  gen D2=D==2
  gen D3=D==3
  gen D4=D==4
  gen D5p=D>=5&D!=.
  *CREATE CLUSTER VAR: OWNERDEATHPAIR-YEAR
  egen odidyr=group(odid year)
  *SAVE
  save $dta/ownerdeaths_analysis_`orgform'_`ageminimum'_`agemaximum'_`sample', replace
  *ADJUST ZEROS FOR REORGANIZATIONS
  use ein owner_tin shutdownyear reorg using $dta/ownerdeaths_reorgs if reorg==1, clear
  drop reorg
  tempfile shutdowns
  save `shutdowns', replace
  use $dta/ownerdeaths_analysis_`orgform'_`ageminimum'_`agemaximum'_`sample', clear
  foreach suffix in od hs {
    rename ein_`suffix' ein
    rename tin_`suffix' owner_tin
    merge m:1 ein owner_tin using `shutdowns', keep(1 3) nogen
	gen zz1 = profits_numw2pre_`suffix' if year==shutdownyear-1
    rename ein ein_`suffix'
    rename owner_tin tin_`suffix'
	bys ein_od tin_od ein_hs tin_hs: egen zz2 = mean(zz1)
	replace profits_numw2pre_`suffix' = zz2 if year>=shutdownyear & shutdownyear!=. & sales_`suffix'==0
	replace salesgt0_`suffix' = 1 if year>=shutdownyear & shutdownyear!=. & sales_`suffix'==0
	drop zz* shutdownyear
  }
  foreach varroot in salesgt0 profits_numw2pre {
    replace `varroot'_dif = `varroot'_od - `varroot'_hs
  }
  save $dta/ownerdeaths_analysis_`orgform'_`ageminimum'_`agemaximum'_`sample', replace
  

  *******************************************************************************/
  * 2. ANALYZE SYSTEMATICALLY
  *******************************************************************************
  foreach varroot in salesgt0 profits_numw2pre {
    local var "`varroot'_dif" 
    use $dta/ownerdeaths_analysis_`orgform'_`ageminimum'_`agemaximum'_`sample', clear
    reg `var' Dn5p Dn4 Dn3 Dn2  D0 D1 D2 D3 D4 D5p [aw=odidwgt], cluster(odid)
    local regnumobs = e(N)
    local regnumeins = e(N_clust)
    sum `varroot'_hs [aw=odidwgt] if eventtime==104
    local hsD4mean = r(mean)
    sum ownshare [aw=odidwgt] if eventtime==100
    local ownshare = r(mean)
    regsave 
    cap drop N r2
    cap export delimited $out/ES_`orgform'_`ageminimum'_`agemaximum'_`sample'_`var'.csv, replace
    insheet using $out/ES_`orgform'_`ageminimum'_`agemaximum'_`sample'_`var'.csv, comma clear
    drop if strpos(var, "5") != 0 | var=="_cons"
    local new_obs = _N + 1
    set obs `new_obs'
    qui g t = _n - 5 if _n < 4
    qui replace t = _n - 4 if missing(t)
    qui replace t = -1 in `new_obs'
    sort t
    sum coef if var=="D4"
    local pcteffectsize = round(100*r(mean)/`hsD4mean'/`ownshare',1)
    local ownshare = round(100*`ownshare',1)
    qui replace coef = 0 if missing(coef)
    qui replace stderr = 0 if missing(stderr)
    qui rename (coef stderr) (b se)
    ES_graph, ci(1.96) xti(Years Since Owner Death) yti("`var'") outname("$out/ES_`orgform'_`ageminimum'_`agemaximum'_`sample'_`var'") lab1("Impact") regnumobs(`regnumobs') regnumeins(`regnumeins') pcteffectsize(`pcteffectsize') ownshare(`ownshare')
  }
end


********************************************************************************
** OWNERDEATHS REORGSTATS
********************************************************************************
capture program drop ownerdeaths_reorgstats
program define ownerdeaths_reorgstats
     syntax, orgform(str) sample(str) ageminimum(int) agemaximum(int)

  *MERGE ON REORG AND SHUTDOWNYEAR
  use $dta/ownerdeaths_analysis_`orgform'_`ageminimum'_`agemaximum'_`sample', clear
  foreach suffix in od hs {
    rename ein_`suffix' ein
    rename tin_`suffix' owner_tin
    merge m:1 ein owner_tin using $dta/ownerdeaths_reorgs, keep(1 3) keepusing(reorg totfreq_0) nogen
    replace reorg=0 if reorg==.
    rename reorg reorg_`suffix'
    rename totfreq_0 reorgtotfreq_`suffix'
    merge m:1 ein using $dta/ownerdeaths_shutdownyear, keep(1 3) keepusing(shutdownyear) nogen
    rename shutdownyear shutdownyear_`suffix'
    rename ein ein_`suffix'
    rename owner_tin tin_`suffix'
  }
  *IDENTIFY FIRMS THAT EXIT IN EVENTTIME [100,104]
  foreach suffix in od hs {
    gen firmexit_`suffix' = inrange(shutdownyear_`suffix'-year_var,0,4)
    gen lastfullyear_`suffix' = shutdownyear_`suffix'-2 if firmexit_`suffix'==1
  }
  sum firmexit* if eventtime==100
  sum reorg_od if eventtime==100 & firmexit_od==1 & reorgtotfreq_od!=. & reorgtotfreq_od>1
  disp "Orgform: `orgform'. Sample: `sample'. Ages [`ageminimum',`agemaximum']. OD reorg share: r(mean)."
  sum reorg_hs if eventtime==100 & firmexit_hs==1 & reorgtotfreq_hs!=. & reorgtotfreq_hs>1
  disp "Orgform: `orgform'. Sample: `sample'. Ages [`ageminimum',`agemaximum']. HS reorg share: r(mean)."
end


*******************************************************************************
*T4REG
*******************************************************************************
capture program drop t4reg
program define t4reg
    syntax, varroot(string) ofile(string) [ifcon(string) append save]
	global col = $col + 1
	if ("`ifcon'" == ""){
		local ifcon = "1==1"
	}	
	preserve 	
	keep if `ifcon'	
	local var "`varroot'_dif" 
	reg `var' Dn5p Dn4 Dn3 Dn2  D0 D1 D2 D3 D4 D5p [aw=odidwgt], cluster(odid)
	local regnumobs = e(N)
	local regnumeins = e(N_clust)
	sum `varroot'_hs [aw=odidwgt] if eventtime==104
	local hsD4mean = r(mean)
	sum ownshare [aw=odidwgt] if eventtime==100
	local ownshare = r(mean)	
	regsave 
	replace r2 = round(r2,0.001)
	keep if var == "D4"
	gen outmeancf = round(`hsD4mean',.001)
	summ coef
	gen est_out = round(100*r(mean)/`hsD4mean',0.001)
	di "*OWNSHARE"
	gen ownshare = 100*`ownshare'
	gen est_out_out_own = round(100*r(mean)/`hsD4mean'/`ownshare',.001)	
	gen cluster = `regnumeins'
	gen col = $col
	gen sample = "${sample}"
	gen orgform = "${orgform}"
	replace var = "`varroot'" if var == "D4"
	if ("`append'" != ""){
		di in red "append"
		capture append using "`ofile'"
		save "`ofile'", replace
	}	
	else if ("`save'" != ""){
		di in red "save"
		append using "`ofile'"
		save ${dump}/temppanel, replace
	}	
	else{
		di in red "new panel"
		save "`ofile'", replace
	}	
	restore	
end


*******************************************************************************
*SUMM IRS FIRMS
*******************************************************************************
capture program drop summ_IRS_firms
program define summ_IRS_firms
	set more off
	syntax, samplevar(varname) name(string) varlist(string) wgt(string) orgform(string) [ minobs(integer 10) ]
	 
	foreach x of varlist `varlist'{
	preserve
	di "******* `x' *************"
	local wgt = "one"
    gen one=1
    keep if `samplevar'==1
    keep ein `x' `wgt' year numw2
    keep if !mi(`x') 
    assert _N>`minobs'
    if ("`wgt'"=="one") {
      sort `x'
      gen `x'_group = int(100*(_n-1)/_N) 
    }
	
    else {
	
	  if("`x'" == "Nowners"){
			di "In the Nowners conditinoal" 
			drop if numw2 == 0 
			expand numw2
			sort `x' numw2
			gen `x'_group = int(100*(_n-1)/_N)
			egen tag = tag(ein year)
			keep if tag == 1
			drop tag
		}
	  
	  else {
			xtile `x'_group = `x' [w=`wgt'], n(100)
			replace `x'_group = `x'_group - 1
		}
	}
	
	di "Through the weighting"
	
	*Exemption for the one weighted var (profits-per-worker)
	if("`x'" == "wprofit_w2"){
			di "We're here!!!"
			drop `x'_group
			xtile `x'_group = `x' [w=numw2], n(100)
			replace `x'_group = `x'_group - 1
			local wgt = "numw2"
	}
	
    egen `x'_p10h = mean(`x') if abs(`x'_group - 10) <= 1
    egen `x'_p10 = max(`x'_p10h)
    egen `x'_p50h = mean(`x') if abs(`x'_group - 50) <= 1 
    egen `x'_p50 = max(`x'_p50h)
    egen `x'_p90h = mean(`x') if abs(`x'_group - 90) <= 1
    egen `x'_p90 = max(`x'_p90h)
    egen `x'_count = count(`x') 
    
    estpost tabstat `x' [w=`wgt'], listwise statistics(mean)
    eststo Mean
    rename `x' `x'_orig
    rename `x'_p10 `x'  
    estpost tabstat `x', listwise statistics(mean)
    eststo P10
    rename `x' `x'_p10
    rename `x'_p50 `x' 
    estpost tabstat `x', listwise statistics(mean)
    eststo P50
    rename `x' `x'_p50
    rename `x'_p90 `x' 
    estpost tabstat `x', listwise statistics(mean)
    eststo P90
    rename `x' `x'_p90
    rename `x'_count `x' 
    estpost tabstat `x', listwise statistics(mean)
    eststo N	   
    rename `x' `x'_count
    rename `x'_orig `x'
    esttab Mean P10 P50 P90 N using ${dump}/`orgform'summ_`x'.csv, ///
    cells(mean(fmt(3)))  replace label unstack nodepvar noobs  nonumber
    
    
    restore
    }   


	preserve 
	clear
	foreach var in `varlist'{
	insheet using ${dump}/`orgform'summ_`var'.csv, clear names 
	drop if _n==1
	tempfile `orgform'data_`var'
	save ``orgform'data_`var''
	}

	clear
	foreach var in `varlist'{
	append using ``orgform'data_`var''

	}
	rename v1 varname
	export delimited ${out}/`orgform'stats_`name'.csv, replace
	
	foreach var in `varlist'{
	rm ${dump}/`orgform'summ_`var'.csv
	}
	restore
	d
end


*******************************************************************************
*SUMM IRS OWNERS
*******************************************************************************
capture program drop summ_IRS_owners
program define summ_IRS_owners
	set more off
	syntax, samplevar(varname) name(string) varlist(string) orgform(string) [weight(varname)] [ minobs(integer 10) ]
	
	foreach x of varlist `varlist'{
	preserve

	keep if `samplevar'==1
	keep `x' tin numw2 age year
	keep if !mi(`x') 
	assert _N>`minobs'
	
	if "`weight'"!="numw2" {
	   replace numw2 = 1
	   sort `x'
	   gen `x'_group = int(100*(_n-1)/_N) 
	}
	else if "`x'" == "Nfirms" |  "`x'" == "totalwages" | "`x'" == "own_top1" | "`x'" == "own_toppt1" | "`x'" == "onlypassive" | "`x'" == "wage_psinc" | "`x'" == "ordinc_ownerpay" {
	   drop if numw2 == 0 
	   expand numw2
	   sort `x' numw2
       gen `x'_group = int(100*(_n-1)/_N)
	   egen tag = tag(tin year)
	   keep if tag == 1
	   drop tag
	}
	else {
	   xtile `x'_group = `x' [w=numw2], n(100)
       replace `x'_group = `x'_group - 1
	}   
		
			   egen `x'_p10h = mean(`x') if abs(`x'_group - 10) <= 1 
			   egen `x'_p10 = max(`x'_p10h)
			   egen `x'_p50h = mean(`x') if abs(`x'_group - 50) <= 1 
			   egen `x'_p50 = max(`x'_p50h)
			   egen `x'_p90h = mean(`x') if abs(`x'_group - 90) <= 1
			   egen `x'_p90 = max(`x'_p90h)
			   egen `x'_count = count(`x') 

			   estpost tabstat `x' [w=numw2], listwise statistics(mean)
			   eststo Mean
			   rename `x' `x'_orig
			   rename `x'_p10 `x'  
			   estpost tabstat `x', listwise statistics(mean)
			   eststo P10
			   rename `x' `x'_p10
			   rename `x'_p50 `x' 
			   estpost tabstat `x', listwise statistics(mean)
			   eststo P50
			   rename `x' `x'_p50
			   rename `x'_p90 `x' 
			   estpost tabstat `x', listwise statistics(mean)
			   eststo P90
			   rename `x' `x'_p90
			   rename `x'_count `x' 
			   estpost tabstat `x', listwise statistics(mean)
			   eststo N	   
			   rename `x' `x'_count
			   rename `x'_orig `x'
			   esttab Mean P10 P50 P90 N using ${dump}/`orgform'own_summ_`x'.csv, cells(mean(fmt(3)))  replace label unstack nodepvar noobs  nonumber
			   *drop `x'_*
			   restore
	}   
	di "Finished with the loop: `samplevar' `name' `orgform'"
	
	preserve 
	clear
	foreach var in `varlist'{
	insheet using ${dump}/`orgform'own_summ_`var'.csv, clear names 
	drop if _n==1
	tempfile own_`orgform'dat_`var'
	save `own_`orgform'dat_`var''
	}

	clear
	foreach var in `varlist'{
	append using `own_`orgform'dat_`var''

	}
	rename v1 varname
	export delimited "${out}/`orgform'ownerstats_`name'_`weight'.csv", replace
	
	foreach var in `varlist'{
	rm ${dump}/`orgform'own_summ_`var'.csv
	}
	restore
end

*******************************************************************************
*LOAD SOI
*******************************************************************************
capture program drop load_soi
program define load_soi
    syntax , year(string)

    if (strlen("`year'") == 0) {
        local year = "00"
    }
    else if (strlen("`year'") == 1) {
        local year = "0`year'"
    }
    else {
        local year = "`year'"
    }

    use $raw/corp`year'.dta, clear

end

*******************************************************************************
*GEN COLUMNS
*******************************************************************************
capture program drop gen_columns
program define gen_columns 

    capture {
    #delimit;
    gen standard_naics = cond(industry_soi < 1000, industry_soi*1000, 
                          cond(industry_soi < 10000, industry_soi*100, 
                           cond(industry_soi < 100000, industry_soi*10, industry_soi)));
    #delimit cr
    }
    recode tot_income tot_ded intrst_pd net_dpr cst_of_gds (.=0)
    recode slrs_wgs pnsn_prft_shrng_plns emp_bnft_prg officer_comp (.=0) 
    #delimit ;
    recode   y_3yr_prpty_basis  
             y_5yr_prpty_basis 
             y_7yr_prpty_basis 
             y_10yr_prpty_basis 
             y_15yr_prpty_basis 
             y_20yr_prpty_basis 
             y_25yr_prpty_basis 
             y_50yr_prpty_basis 
             y_res_rntl_prpty_basis  
             y_nonres_rl_prpty_basis  
             y_ads_class_prpty_basis  
             y_ads_12yr_prpty_basis  
             y_ads_40yr_prpty_basis  
             y_spcl_dpr_allw 
             y_sec_179_tot_cst (.=0);
    #delimit cr

    gen va = rev - cst_of_gds
    gen sale = tot_income + cst_of_gds
    gen profits = tot_income - tot_ded
    gen ebitd = profits + intrst_pd + net_dpr

    gen labor_comp = slrs_wgs + pnsn_prft_shrng_plns + emp_bnft_prg + ///
        cst_of_lbr + officer_comp

    gen capital = dprcbl_assts - accum_dpr
    #delimit ;
    gen investment = y_3yr_prpty_basis + 
                     y_5yr_prpty_basis +
                     y_7yr_prpty_basis +
                     y_10yr_prpty_basis +
                     y_15yr_prpty_basis +
                     y_20yr_prpty_basis +
                     y_25yr_prpty_basis +
                     y_50yr_prpty_basis +
                     y_res_rntl_prpty_basis + 
                     y_nonres_rl_prpty_basis + 
                     y_ads_class_prpty_basis + 
                     y_ads_12yr_prpty_basis + 
                     y_ads_40yr_prpty_basis + 
                     y_spcl_dpr_allw +
                     y_sec_179_tot_cst;
    #delimit cr

    gen profits_margin = profits/sale
    gen ebitd_margin = ebitd/sale

    g age = year - date_inc
    replace age = . if date_inc == 9999
    replace age = . if age < 0

    * Merge on compustat for pub company flag.
    merge m:1 ein using $raw/cstat_eins, keep(1 3)
    gen public_co = cond(_merge == 3, 1, 0)
    drop _merge
    merge m:1 ein using $raw/eins_042715_destring, keep(1 3)
    replace public_co = cond(_merge == 3, 1, public_co)
    drop _merge

end

*******************************************************************************
*ANALYZE SWITCHERS
*******************************************************************************
capture program drop analyze_switch_v2/*%<*/
program define analyze_switch_v2
    syntax, spec(string)

    tempfile orig analysis_data
    save `orig'

    foreach var of varlist profit_sale labor_comp_sale tototh_ded_sale {
        reghdfe `var' Dn5p-Dn2 D0-D5p, abs(ein year) cluster(ein)
        regsave
        cap drop N r2
        outsheet using "$out/popswitch/ES_switch_firmFX_`var'_`spec'.csv", replace
        use `orig', clear
    }

    use `orig', clear

end/*%>*/

********************************************************************************
** OWNERDEATHS BUILD
********************************************************************************
capture program drop oe_build
program define oe_build
     syntax, orgform(str)

  *LOAD ALL FIRM-OWNER ROWS
  clear
  gen agipctilebin = .
  forv t=2001/2014 {
    append using $dta/`orgform'_firmowner_`t', keep(ein tin tax_yr ownshare sales numw2 ssa_yob wagesfromfirm onlypassive nc4 agipctilebin`t' psinc sizebin)
    replace agipctilebin=agipctilebin`t' if agipctilebin==.
    drop agipctilebin`t'
  }
  drop if ein==.
  save ${dta}/savetemp0_`orgform', replace
  
  *CREATE INDICATORS FOR ACTIVITY AT THE FIRM LEVEL
  foreach var in sales wagesfromfirm psinc {
    usd2014, var(`var') yr(tax_yr)
  }
  gen hasactive = 1-onlypassive
  gen haspassive = onlypassive
  gen haswagesfromfirm = wagesfromfirm>0
  gen hashighwagesfromfirm = wagesfromfirm>100000
  gen hasmajowner1 = ownshare>.5
  gen hasmajowner2 = ownshare>=.5
  gen hasage6075 = inrange(tax_yr-ssa_yob,60,75)
  gen ownsharehaswages = ownshare if haswagesfromfirm==1
  gen ownsharehashighwages = ownshare if hashighwagesfromfirm==1
  drop ownshare
  gen hasmill = psinc>=1000000 & haswagesfromfirm==1
  gen hastop1 = agipctilebin>99 & haswagesfromfirm==1
  gen hastoppt1 = agipctilebin>99.9 & haswagesfromfirm==1
  collapse (max) has* ownshare* (min) hasonlyage6075=hasage6075, by(ein tax_yr sales numw2 nc4 sizebin)
  compress
  duplicates drop ein tax_yr, force
  save ${dta}/savetemp1_`orgform', replace
  
  *RESTRICT TO SUFFICIENT-LENGTH SPELLS AND STACK
  use ein tax_yr haswagesfromfirm hastop1 sales numw2 ownsharehaswages using ${dta}/savetemp1_`orgform', clear
  reshape wide has* ownsharehaswages sales numw2, i(ein) j(tax_yr)
  save ${dta}/savetemp2_`orgform', replace
  use ${dta}/savetemp2_`orgform', clear
  forv t=$odfirstyear/$odlastyear {
    forv s=1/4 {
      local tminus`s' = `t' - `s'
    }
    local tplus1 = `t' + 1
    gen oe`t'=1 if haswagesfromfirm`tminus4'==1 & haswagesfromfirm`tminus3'==1 & haswagesfromfirm`tminus2'==1 & haswagesfromfirm`tminus1'==1 & haswagesfromfirm`t'==0 & haswagesfromfirm`tplus1'==0
    replace oe`t'=0 if haswagesfromfirm`tminus4'==1 & haswagesfromfirm`tminus3'==1 & haswagesfromfirm`tminus2'==1 & haswagesfromfirm`tminus1'==1 & haswagesfromfirm`t'==1 & haswagesfromfirm`tplus1'==1
    gen hastop1l1`t' = hastop1`tminus1'==1 if hastop1`tminus1'!=.
    gen hassales100kl1`t' = sales`tminus1'>100000 if sales`tminus1'!=.
    gen ownsharel1`t' = ownsharehaswages`tminus1' if ownsharehaswages`tminus1'!=.
    gen posnumw2pre`t' = (numw2`tminus4' + numw2`tminus3' + numw2`tminus2' + numw2`tminus1' > 0)
    gen possalesl4f1`t' = (sales`tminus4'>0 & sales`tminus3'>0 & sales`tminus2'>0 & sales`tminus1'>0 & sales`t'>0)
  }
  keep ein oe* hastop1l1* hassales100kl1* pos* ownsharel1*
  reshape long oe hastop1l1 hassales100kl1 posnumw2pre possalesl4f1 ownsharel1, i(ein) j(tax_yr)
  save ${dta}/savetemp3_`orgform', replace
  **RESTRICT TO ROWS IN WHICH THE FIRM EXISTED IN TAX_YR-1 (AND THUS IS A CANDIDATE FIRM)
  drop if hastop1l1==.
  **WATERFALL
  count
  keep if hastop1l1==1
  count
  keep if hassales100kl1==1
  count
  keep if possalesl4f1==1
  count
  keep if posnumw2pre==1
  count
  keep if inrange(ownsharel1,.2,1.00000000001)
  count
  keep if oe!=.
  count
  tab oe
  keep ein tax_yr oe
  rename tax_yr year_var
  save ${dta}/savetemp4_`orgform', replace
  
  *MAKE INTO A PANEL AND MERGE ON TIME-INVARIANT VARIABLES
  use ${dta}/savetemp4_`orgform', clear
  gen tax_yr = year_var-1
  merge 1:m ein tax_yr using ${dta}/savetemp1_`orgform', keepusing(nc4 sizebin hasmill hastop1 hastoppt1 ownsharehaswages) keep(1 3)
  assert _merge!=1
  assert hastop1==1
  rename ownsharehaswages ownshare
  assert inrange(ownshare,.2,1.00000000001)
  drop _merge tax_yr hastop1
  drop if nc4==.
  rename nc4 nc_var
  gen agipctilebin_var = 99.25
  replace agipctilebin_var=99.95 if hastoppt1==1
  gen psinc_14dollars_l1 = 0
  replace psinc_14dollars_l1=1000001 if hasmill==1
  drop has*
  rename sizebin salesbin_var
  egen einyrid = group(ein year_var)
  save ${dta}/savetemp5_`orgform', replace
  
  *MATCH OWNER DEATHS TO COUNTERFACTUAL OWNER DEATHS
  use oe einyrid nc_var agipctilebin_var salesbin_var year_var ownshare using ${dta}/savetemp5_`orgform', clear
  tempfile orig needle
  egen zzcell = group(nc_var agipctilebin_var salesbin_var year_var)
  save `orig', replace
  keep if oe==1
  drop oe
  save `needle', replace
  use oe zzcell einyrid using `orig' if oe==0, clear
  drop oe
  rename * *_hs
  rename zzcell_hs zzcell
  joinby zzcell using `needle', unmatched(none)
  drop zz*
  *RANDOMLY CHOOSE UP TO 10 ROWS PER oe==1
  set seed 1234
  gen zzrand = uniform()
  sort einyrid zzrand
  by einyrid: keep if _n<=10
  drop zz*
  save ${dta}/savetemp6_`orgform', replace
  
  *MERGE BACK ON psinc_14dollars_l1
  use ${dta}/savetemp6_`orgform', clear
  merge m:1 einyrid using ${dta}/savetemp5_`orgform', keepusing(ein psinc_14dollars_l1) keep(1 3)
  assert _merge==3
  drop _merge
  rename ein ein_od
  drop einyrid
  rename einyrid_hs einyrid
  merge m:1 einyrid using ${dta}/savetemp5_`orgform', keepusing(ein) keep(1 3)
  assert _merge==3
  drop _merge
  rename ein ein_hs
  rename ein_od ein
  drop einyrid
  order ein ein_hs year_var nc_var salesbin_var agipctilebin_var
  save ${dta}/savetemp7_`orgform', replace
  keep ein
  duplicates drop
  count
  
  *******************************************************************************
  * 3. MERGE ON sales87,...,profits13 AND CREATE numw2pre, AND RESHAPE WIDE
  *******************************************************************************
  *STACK ALL RELEVANT EINS
  use ein_hs using ${dta}/savetemp7_`orgform', clear
  rename ein_hs ein
  append using ${dta}/savetemp7_`orgform', keep(ein)
  duplicates drop
  sort ein
  save ${dta}/savetemp8_`orgform', replace
  
  forv yr=$firstyear/$lastyear {
	cap use ${dump}/temp_firms_`yr'_`orgform', clear

	** file doesn't exist, build it
	if _rc {
		use ein tax_yr $firmvarlist using $dta/`orgform'_firmowner_`yr' if ein!=., clear
		rename tax_yr year
		duplicates drop
		duplicates drop ein, force
		foreach var in $firmvarlist_dollarvars {
		  usd2014, var(`var') yr(year)
		}
		save ${dump}/temp_firms_`yr'_`orgform', replace
	}
  }

  *GET AS MANY YEARS OF DATA AS POSSIBLE FOR THESE EINS 
    forv yr=$firstyear/$lastyear {
      use ${dta}/savetemp8_`orgform', clear
      merge 1:1 ein using ${dump}/temp_firms_`yr'_`orgform', keep(3) nogen keepusing($firmvarlist)
      gen year=`yr'
      save ${dta}/savetemp9_`yr'_`orgform', replace
    }
  
  clear
  *APPEND
  forv yr=$firstyear/$lastyear {
    append using ${dta}/savetemp9_`yr'_`orgform'
  }
  order ein year
  save ${dta}/savetemp10_`orgform', replace
  
  *PREP OWNER DEATH DATA FOR MERGES, INCLUDING BUILDING OUT A BALANCED PANEL
  clear
  gen eventtime=.
  forv t=96/104 {
    append using ${dta}/savetemp7_`orgform'
    replace eventtime=`t' if eventtime==.
  }
  gen year = year_var + eventtime - 100
  order ein ein_hs eventtime year
  rename ein ein_od
  foreach suffix in od hs {
    rename ein_`suffix' ein
    merge m:1 ein year using ${dta}/savetemp10_`orgform', nogen keep(1 3)
    foreach var in $firmvarlist {
      rename `var' `var'_`suffix'
     }
    rename ein ein_`suffix'
  }
  *SET VARIABLES TO ZERO IF MISSING
  foreach suffix in od hs {
    foreach var in $firmvarlist {
      replace `var'_`suffix'=0 if `var'_`suffix'==.
     }
  }
  *CREATE ID VARIABLES
  egen odid = group(ein_od)
  egen odhsid = group(ein_od ein_hs)
  *VALIDATE THAT THE DATA ARE UNIQUE ON odshid-eventtime
  gen zzodhsidet100 = odhsid if eventtime==100
  duplicates tag zzodhsidet100 if zzodhsidet100!=., gen(zztag)
  sum zztag
  bys odhsid: egen zztagmax = max(zztag)
  drop if zztagmax!=0
  drop zz*
  *MAKE WEIGHT EQUAL TO 1/NUMBEROFINSTANCES
  gen zzet100 = 1 if eventtime==100
  bys odid: egen totalodmatches = total(zzet100)
  sum totalodmatches
  drop zz*
  gen odidwgt = 1/totalodmatches
  compress
  save ${dta}/savetemp11_`orgform', replace
  save $dta/oe_build_`orgform', replace
end


********************************************************************************
** ORDERLYEXITS ANALYSIS
********************************************************************************
capture program drop orderlyexits_analysis
program define orderlyexits_analysis
     syntax, orgform(str) sample(str) 

  *******************************************************************************
  * 1. PREP ANALYSIS DATASET
  *******************************************************************************
  di "`orgform'"
  di "`sample'"
  *RESTRICT OWNERS
  if "`sample'"=="top1" {
    use $dta/oe_build_`orgform' if inrange(eventtime,96,104) & agipctilebin_var>99, clear
  }
  else if "`sample'"=="toppt1" {
    use $dta/oe_build_`orgform' if inrange(eventtime,96,104) & agipctilebin_var>99.9, clear
  }
  else if "`sample'"=="millionaire" {
    use $dta/oe_build_`orgform' if inrange(eventtime,96,104) & psinc_14dollars_l1>=1000000 & psinc_14dollars_l1!=., clear
  }

  *IMPUTE OWNSHARE IF MISSING OR ZERO
  sum ownshare [aw=odidwgt] if ownshare!=0 & ownshare!=.
  replace ownshare=r(mean) if ownshare==. | ownshare==0

  *ADD VA
  g va_od = (sales_od-costsold_od)
  replace va_od = . if va_od <= 0
  g va_hs = (sales_hs-costsold_hs)
  replace va_hs = . if va_hs <= 0

  *TSSET THE DATA
  tsset odhsid year
  *CREATE PRE-PERIOD NUMBER OF WORKERS AND OTHER PRE-PERIOD MEASURES
  foreach suffix in od hs {
    gen zznumw2pre_`suffix' = (l1.numw2_`suffix'+l2.numw2_`suffix'+l3.numw2_`suffix'+l4.numw2_`suffix')/4 if year==year_var
    by odhsid: egen numw2pre_`suffix' = mean(zznumw2pre_`suffix')
    drop zz*
    gen zzsalespre_`suffix' = (l1.sales_`suffix'+l2.sales_`suffix'+l3.sales_`suffix'+l4.sales_`suffix')/4 if year==year_var
    by odhsid: egen salespre_`suffix' = mean(zzsalespre_`suffix')
    drop zz*
    gen zzvapre_`suffix' = (l1.va_`suffix'+l2.va_`suffix'+l3.va_`suffix'+l4.va_`suffix')/4 if year==year_var
    by odhsid: egen vapre_`suffix' = mean(zzvapre_`suffix')
    drop zz*
  }
  *CREATE OUTCOMES
  foreach suffix in od hs {
    gen salesgt0_`suffix' = (sales_`suffix'>0)
    gen profits_numw2pre_`suffix' = profits_`suffix'/numw2pre_`suffix'
    gen lnsales_`suffix' = ln(sales_`suffix')
    gen sales_salespre_`suffix' = sales_`suffix'/salespre_`suffix'
    gen lnsales_salespre_`suffix' = ln(sales_`suffix'/salespre_`suffix')
    gen lnva_`suffix' = ln(va_`suffix')
    gen va_vapre_`suffix' = va_`suffix'/vapre_`suffix'
    gen lnva_vapre_`suffix' = ln(va_`suffix'/vapre_`suffix')
    gen lnnumw2_`suffix' = ln(numw2_`suffix')
    gen numw2_numw2pre_`suffix' = numw2_`suffix'/numw2pre_`suffix'
    gen lnnumw2_numw2pre_`suffix' = ln(numw2_`suffix'/numw2pre_`suffix')
  }
  *TRIM BASED ON THE OWNER-DEATH FIRMS' PRE-PERIOD VALUES
  foreach varroot in profits_numw2pre {
    sum `varroot'_od [aw=odidwgt] if inrange(eventtime,96,99), d
    foreach suffix in od hs {
      replace `varroot'_`suffix'=r(p1)  if `varroot'_`suffix'<r(p1)  & `varroot'_`suffix'!=.
      replace `varroot'_`suffix'=r(p99) if `varroot'_`suffix'>r(p99) & `varroot'_`suffix'!=.
    }
  }
  *INTENSIVE MARGIN ONLY
  foreach varroot in profits_numw2pre {
    foreach suffix in od hs {
      gen zzdies=.
      forv eventtime=96/104 {
        replace zzdies = sales_`suffix'==0 if eventtime==`eventtime'
	  }
	  bys ein_od ein_hs: egen zzdiesever = max(zzdies)
      gen `varroot'_int_`suffix' = `varroot'_`suffix'
      replace `varroot'_int_`suffix'=. if zzdiesever==1
	  drop zz*
    }
  }
  *CREATE DIFFERENCE OUTCOMES
  foreach varroot in salesgt0 profits_numw2pre profits_numw2pre_int {
    gen `varroot'_dif = `varroot'_od - `varroot'_hs
  }
  *CREATE DUMMIES FOR REGRESSION
  gen D = year-year_var
  gen Dn5p=D<=-5
  gen Dn4=D==-4
  gen Dn3=D==-3
  gen Dn2=D==-2
  *gen Dn1=D==-1
  gen D0=D==0
  gen D1=D==1
  gen D2=D==2
  gen D3=D==3
  gen D4=D==4
  gen D5p=D>=5&D!=.
  *CREATE CLUSTER VAR: OWNERDEATHPAIR-YEAR
  egen odidyr=group(odid year)
  *SAVE
  save $dta/oe_analysis_`orgform'_`sample', replace
  *ADJUST ZEROS FOR REORGANIZATIONS
  use ein shutdownyear reorg using $dta/oe_reorgs if reorg==1, clear
  drop reorg
  tempfile shutdowns
  save `shutdowns', replace
  use $dta/oe_analysis_`orgform'_`sample', clear
  foreach suffix in od hs {
    rename ein_`suffix' ein
    merge m:1 ein using `shutdowns', keep(1 3) nogen
	gen zz1 = profits_numw2pre_`suffix' if year==shutdownyear-1
    rename ein ein_`suffix'
	bys ein_od ein_hs: egen zz2 = mean(zz1)
	replace profits_numw2pre_`suffix' = zz2 if year>=shutdownyear & shutdownyear!=. & sales_`suffix'==0
	replace salesgt0_`suffix' = 1 if year>=shutdownyear & shutdownyear!=. & sales_`suffix'==0
	drop zz* shutdownyear
  }
  foreach varroot in salesgt0 profits_numw2pre {
    replace `varroot'_dif = `varroot'_od - `varroot'_hs
  }
  save $dta/oe_analysis_`orgform'_`sample', replace
  *ADD SALES WEIGHT

  *******************************************************************************
  * 2. ANALYZE SYSTEMATICALLY
  *******************************************************************************
  foreach varroot in salesgt0 profits_numw2pre {
    local var "`varroot'_dif" 
	use $dta/oe_analysis_`orgform'_`sample', clear
    reg `var' Dn5p Dn4 Dn3 Dn2  D0 D1 D2 D3 D4 D5p [aw=odidwgt], cluster(odid)
    local regnumobs = e(N)
    local regnumeins = e(N_clust)
    sum `varroot'_hs [aw=odidwgt] if eventtime==104
    local hsD4mean = r(mean)
    sum ownshare [aw=odidwgt] if eventtime==100
    local ownshare = r(mean)
    regsave 
    cap drop N r2
    cap export delimited $out/ES_`orgform'_`sample'_`var'.csv, replace
    insheet using $out/ES_`orgform'_`sample'_`var'.csv, comma clear
    drop if strpos(var, "5") != 0 | var=="_cons"
    local new_obs = _N + 1
    set obs `new_obs'
    qui g t = _n - 5 if _n < 4
    qui replace t = _n - 4 if missing(t)
    qui replace t = -1 in `new_obs'
    sort t
    sum coef if var=="D4"
    local pcteffectsize = round(100*r(mean)/`hsD4mean'/`ownshare',1)
    local ownshare = round(100*`ownshare',1)
    qui replace coef = 0 if missing(coef)
    qui replace stderr = 0 if missing(stderr)
    qui rename (coef stderr) (b se)
    ES_graph, ci(1.96) xti(Years Since Owner Death) yti("`var'") outname("$out/ES_`orgform'_`sample'_`var'") lab1("Impact") regnumobs(`regnumobs') regnumeins(`regnumeins') pcteffectsize(`pcteffectsize') ownshare(`ownshare')
  }
end


********************************************************************************
** ORDERLYEXITS ANALYSIS 2
********************************************************************************
capture program drop orderlyexits_analysis2
program define orderlyexits_analysis2
     syntax, orgform(str) sample(str) 

  *REDO SALES WEIGHT
  use $dta/oe_analysis_`orgform'_`sample', clear
  gen odidwgtorig = odidwgt/salesodl1
  replace odidwgt = odidwgtorig*ln(salesodl1)
  save $dta/oe_analysis2_`orgform'_`sample', replace
  

  *******************************************************************************
  * 2. ANALYZE SYSTEMATICALLY
  *******************************************************************************
  foreach varroot in salesgt0 profits_numw2pre {
    local var "`varroot'_dif" 
	use $dta/oe_analysis2_`orgform'_`sample', clear
    reg `var' Dn5p Dn4 Dn3 Dn2  D0 D1 D2 D3 D4 D5p [aw=odidwgt], cluster(odid)
    local regnumobs = e(N)
    local regnumeins = e(N_clust)
    sum `varroot'_hs [aw=odidwgt] if eventtime==104
    local hsD4mean = r(mean)
    sum ownshare [aw=odidwgt] if eventtime==100
    local ownshare = r(mean)
    regsave 
    cap drop N r2
    cap export delimited $out/ES_`orgform'_`sample'_`var'.csv, replace
    insheet using $out/ES_`orgform'_`sample'_`var'.csv, comma clear
    drop if strpos(var, "5") != 0 | var=="_cons"
    local new_obs = _N + 1
    set obs `new_obs'
    qui g t = _n - 5 if _n < 4
    qui replace t = _n - 4 if missing(t)
    qui replace t = -1 in `new_obs'
    sort t
    sum coef if var=="D4"
    local pcteffectsize = round(100*r(mean)/`hsD4mean'/`ownshare',1)
    local ownshare = round(100*`ownshare',1)
    qui replace coef = 0 if missing(coef)
    qui replace stderr = 0 if missing(stderr)
    qui rename (coef stderr) (b se)
    ES_graph, ci(1.96) xti(Years Since Owner Death) yti("`var'") outname("$out/ES_`orgform'_`sample'_`var'") lab1("Impact") regnumobs(`regnumobs') regnumeins(`regnumeins') pcteffectsize(`pcteffectsize') ownshare(`ownshare')
  }
end

