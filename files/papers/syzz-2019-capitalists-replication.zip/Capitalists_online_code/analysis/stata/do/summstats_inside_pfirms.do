**************************
* EXECUTE PARTNERSHIP FIRMS
**************************
use $dump/summstats_pships.dta, clear
local set = "Nowners ownerpay_va numw2nz wprofit_w2 sales profits pm roa ass numw2 sales_w2 profit_w2 profit_owner totownerpayment ownerpay_owner ownerpay_w2  ownerpay_profit ownerpay_sales"
summ_IRS_firms, samplevar(fullsample) name(fullsample) wgt("one") orgform("p") varlist("`set'")
summ_IRS_firms, samplevar(firm_own_toppt1) name(toppt1own) wgt("one") orgform("p") varlist("`set'")
summ_IRS_firms, samplevar(firm_own_top1nottoppt1) name(top1nottoppt1own) wgt("one") orgform("p") varlist("`set'")

