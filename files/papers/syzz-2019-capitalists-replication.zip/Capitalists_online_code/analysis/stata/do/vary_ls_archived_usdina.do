global psz_archive ${raw}/usdina_archive_xp
global parameters ${raw}
global dump_syzz ${dump}


********************************************************************************
* Consolidate the tt- parameters that we need varied by labor share
use "${parameters}/psz_mixedincome_notes_20190407 - dy_2016extrap" , clear
rename Dollarsofcorporateandbusines corp_tax
destring ttfkbus ttfllbu , force replace

foreach labor_share_000 in 700 750 596 717 816 600 800 500 000 1000 100 200 300 400 900 {

	local labor_share = `labor_share_000' / 1000
	local labor_share_suffix = "`labor_share_000'"

	gen ttfkbus`labor_share_suffix' = (1-`labor_share') * (ttfkbus + ttfllbu - corp_tax) + corp_tax
	gen ttfllbu`labor_share_suffix' = (ttfkbus + ttfllbu) - ttfkbus`labor_share_suffix'

	gen labor_check`labor_share_suffix' = (ttfllbu`labor_share_suffix') / (ttfllbu`labor_share_suffix' + ttfkbus`labor_share_suffix')
}

foreach var in ttfkbus ttfllbu {
	replace `var'700 = `var'
}

rename (ttfkbus ttfllbu) (ttfkbus_og ttfllbu_og)

drop corp_tax labor_check*


tempfile parameters_varied
save `parameters_varied' , replace
********************************************************************************


********************************************************************************
** Take the archived usdina_$yr files and reconstruct fkbus and flmil varied by year

foreach labor_share_000 in 700 750 596 717 816 600 800 500 000 1000 100 200 300 400 900 {

	local labor_share = `labor_share_000' / 1000
	global capital_share = 1 - `labor_share'
	
	global labor_share_suffix = "`labor_share_000'"
	local labor_share_suffix ${labor_share_suffix}
	
	
	if `labor_share_000' == 750 {
		global years "1962 1964 1966/2016"
		numlist "$years"
	}
	else {
		global years "2014"
		numlist "$years"
	}

	foreach yr of numlist $years {
	
		global yr `yr'

		use $psz_archive/usdina${yr} , clear
		
		gen yr = $yr
		
		merge m:1 yr using `parameters_varied' , ///
			keep(3) nogen keepusing(ttfkbus_og ttfllbu_og ttfkbus`labor_share_suffix' ttfllbu`labor_share_suffix')
		
		
		*** Untie flmil
		replace flmil = flmil / ttfllbu_og
		
		*** Retie flmil
		replace flmil = flmil * ttfllbu`labor_share_suffix'
		
		
		*** Untie fkbus
		foreach var in fkhoumain fkhourent fkequ fkfix fkbus fkpen fkmor fknmo {
			qui gen sh`var' = `var' / (fkhoumain + fkhourent + fkequ + fkfix + fkbus + fkpen + fkmor + fknmo)
			qui replace sh`var' = 0 if sh`var' == . 
		}
		foreach var in fkhoumain fkhourent fkequ fkfix fkbus fkpen fkmor fknmo {
			qui replace `var' = `var' - fkprk * sh`var' 
			qui replace `var' = 0 if `var' == .
		}	
		
		replace fkbus = fkbus / ttfkbus_og
		
		** Drop shares so can remake
		drop sh*
		
		*** Retie fkbus
		replace fkbus = fkbus * ttfkbus`labor_share_suffix'
		
		foreach var in fkhoumain fkhourent fkequ fkfix fkbus fkpen fkmor fknmo {
			qui gen sh`var' = `var' / (fkhoumain + fkhourent + fkequ + fkfix + fkbus + fkpen + fkmor + fknmo)
			qui replace sh`var' = 0 if sh`var' == . 
		}
		foreach var in fkhoumain fkhourent fkequ fkfix fkbus fkpen fkmor fknmo {
			qui replace `var' = `var' + fkprk * sh`var' 
			qui replace `var' = 0 if `var' == .
		}	

		
		** Drop variables made in this process
		drop yr ttfkbus_og ttfllbu_og ttfkbus`labor_share_suffix' ttfllbu`labor_share_suffix'
		
		** Actually need to keep very few variables 
		keep flmil fkbus id second
		
		tempfile usdina${yr}_${labor_share_suffix}
		save `usdina${yr}_${labor_share_suffix}' , replace
	}
}
********************************************************************************


********************************************************************************
** Take the archived usdina$yr files that are broken out by labor share and aggregate them
** This is then the input for build_usdinasyzz


global years "1962 1964 1966/2016"
numlist "$years"


** Make tempfile spines by year
foreach yr of numlist $years {
	global yr `yr'

	use $psz_archive/usdina${yr} , clear

	keep id second
	
	tempfile agg_psz_vary_labor${yr}
	save `agg_psz_vary_labor${yr}' , replace
}

foreach yr of numlist $years {
	global yr `yr'
	
	
	if `yr' == 2014 {
		local lab_list 750 700 596 717 816 600 800 500 000 1000 100 200 300 400 900
	}
	else {
		local lab_list 750
	}

	foreach labor_share_000 in `lab_list' {
	
		local labor_share = `labor_share_000' / 1000
		
		global labor_share `labor_share'
		global capital_share = 1 - `labor_share'
		
		global labor_share_suffix = "`labor_share_000'"
		local labor_share_suffix ${labor_share_suffix}
		global labor_share_000 `labor_share_000'
		
		
		* Load file made in build_usdina
		use `usdina${yr}_${labor_share_suffix}' , clear
		
		* Trim
		keep flmil fkbus id second
		
		* Rename flmil and fkbus
		rename flmil flmil${labor_share_000}
		rename fkbus fkbus${labor_share_000}
		
		
		merge 1:1 id second using `agg_psz_vary_labor${yr}'
		drop _m
		save `agg_psz_vary_labor${yr}' , replace
		
	}
	
	use `agg_psz_vary_labor${yr}' , clear
	save ${dump_syzz}/archived_vary_labor_share_dina_values${yr} , replace
}


