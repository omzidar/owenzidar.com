set seed 1
*******************************************************************************
* 1. Load data
*******************************************************************************
local firstyr = ${yrminoverall}
local lastyr  = ${yrmaxoverall} 

forv yr = `firstyr'/`lastyr'{
*local yr=2013
disp "Year"
disp `yr'

****************
* 1099s and w2s
****************
use $raw/rpi_worker_chars.dta, clear
keep if tax_yr==`yr'
drop tax_yr

tempfile dta_`yr'
save `dta_`yr''

****************
* GEO
****************
use $dump/scorp_geo.dta
keep if year==`yr'
drop ein year zip
rename tin payer_tin
duplicates drop

g u=runiform()
sort u
egen tag=tag(payer_tin)
keep if tag==1
drop tag u

tempfile geodta_`yr'
save `geodta_`yr''


use $dta/s_firmowner_`yr'.dta, clear

*MERGE ON WORKER DATA
merge m:1 payer_tin using  `dta_`yr''
tab _merge
keep if _merge==3
drop _merge

*MERGE ON GEO DATA
merge m:1 payer_tin using  `geodta_`yr''
tab _merge
drop if _merge==2
replace state="NA" if _merge==2
drop _merge


*******************************************************************************
*2. IDENTIFY FIRMS WITH TOP OWNERS
*******************************************************************************
g anyowner = !mi(tin)
egen Nowners       = total(anyowner), by(ein)
egen Ntop1owners   = total(own_top1), by(ein)
egen Ntoppt1owners = total(own_toppt1), by(ein)

g firm_own_top1    = (Ntop1owners>0 & !mi(Ntop1owners))
g firm_own_toppt1  = (Ntoppt1owners>0 & !mi(Ntoppt1owners))

g ownerpayment = ord_inc
replace ownerpayment = ord_inc + wages_max  if payer_tin==payer_tin_w2_max
replace ownerpayment = ord_inc + wages_smax if payer_tin==payer_tin_w2_smax

egen totownerpayment = total(ownerpayment), by(ein)
egen totordinc		 = total(ord_inc), by(ein)

*******************************************************************************
*3. Keep one observation per firm
*******************************************************************************
egen tag=tag(ein)
keep if tag==1
drop tag

*******************************************************************************
*4. BRING TO 2014 USD
*******************************************************************************
*NOTE THAT THIS PROGRAM ONLY GOES BACK TO 93
capture drop year
g year=`yr'
usd2014, var(sales) yr(year)
usd2014, var(profits) yr(year)
usd2014, var(ass) yr(year)
usd2014, var(totownerpayment) yr(year)
usd2014, var(wagebill) yr(year)
usd2014, var(comp1099) yr(year)

keep sales profits numw2 ass state Nowners Ntop* ein totownerpayment totordinc wagebill w2_num num1099 comp1099 
duplicates drop

local varlist "sales profits numw2 ass Nfirms Nowners Ntop1owners Ntoppt1owners totownerpayment totordinc wagebill w2_num num1099 comp1099 "

*******************************************************************************
*5. Export collapses by state and top owner indicator
*******************************************************************************
g Nfirms=!mi(ein)
recode num1099 w2_num (.=0)
g emp_broad=num1099+ w2_num

g numw2gt10=(emp_broad>10 & !mi(emp_broad))
g numw2gt50=(emp_broad>50 & !mi(emp_broad))
g numw2gt100=(emp_broad>100 & !mi(emp_broad))

tempfile data_all
save `data_all'

********************************************
*ALL BY OWNER INCOME AND state
********************************************
use `data_all', clear
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_decomp_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_decomp_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0 
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_decomp_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_decomp_top1_`yr'.csv", replace

*Top 0.1%
use `data_all', clear
keep if Ntoppt1owners>0 
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_decomp_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_decomp_top01_`yr'.csv", replace

********************************************
*10+ Emps BY OWNER INCOME AND INDUSTRY
********************************************
use `data_all', clear
keep if numw2gt10==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt10_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt10_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0 
keep if numw2gt10==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt10_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt10_top1_`yr'.csv", replace

*Top 0.1%
use `data_all', clear
keep if Ntoppt1owners>0 
keep if numw2gt10==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt10_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt10_top01_`yr'.csv", replace

********************************************
*50+ Emps BY OWNER INCOME AND state
********************************************
use `data_all', clear
keep if numw2gt50==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt50_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt50_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0 
keep if numw2gt50==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt50_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt50_top1_`yr'.csv", replace

*Top 0.1%
use `data_all', clear
keep if Ntoppt1owners>0 
keep if numw2gt50==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt50_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt50_top01_`yr'.csv", replace

********************************************
*100+ Emps BY OWNER INCOME AND state
********************************************
use `data_all', clear
keep if numw2gt100==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt100_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt100_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0 
keep if numw2gt100==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt100_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt100_top1_`yr'.csv", replace

*Top 0.1%
use `data_all', clear
keep if Ntoppt1owners>0 
keep if numw2gt100==1
collapse (sum) `varlist', by(state)
export delimited using "$out/decomp/unmasked_state_w2gt100_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decomp/masked_state_w2gt100_top01_`yr'.csv", replace
}

*******************************************************************************
* CONSOLIDATE DECOMP AND TOTAL FILES: state
*******************************************************************************

foreach dataset in "all" "top1" "top01"{
forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'
insheet using "$out/decomp/masked_state_decomp_`dataset'_`yr'.csv", clear
assert nfirms>10

g year=`yr'
tempfile data_decomp_`yr'
save `data_decomp_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `data_decomp_`yr''
}
sort state year
export delimited using "$out/decomp/masked_state_decomp_`dataset'.csv", replace

}


*******************************************************************************
* CONSOLIDATE DECOMP AND TOTAL FILES: scorp4d by size
*******************************************************************************
foreach size in "w2gt10" "w2gt50" "w2gt100" {
foreach dataset in "all" "top1" "top01"{
forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'
insheet using "$out/decomp/masked_state_`size'_`dataset'_`yr'.csv", clear
assert nfirms>10

g year=`yr'
tempfile data_decomp_`yr'
save `data_decomp_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `data_decomp_`yr''
}
sort state year
export delimited using "$out/decomp/masked_state_`size'_`dataset'.csv", replace

}
}
