*******************************************************************************
* 1. Load data
*******************************************************************************
local firstyr = 2000
local lastyr  = 2014 

forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'

use $dta/s_firmowner_`yr'.dta, clear

*******************************************************************************
*2. IDENTIFY FIRMS WITH TOP OWNERS
*******************************************************************************
g anyowner = !mi(tin)
egen Nowners       = total(anyowner), by(ein)
egen Ntop1owners   = total(own_top1), by(ein)
egen Ntoppt1owners = total(own_toppt1), by(ein)

	*Millionaires in 2014
	g psinc2014=psinc
	capture drop year
	g year=`yr'
	usd2014, var(psinc2014) yr(year)	

	g millionaire = psinc2014>=1000000 & !mi(psinc2014)

egen NMowners   = total(millionaire), by(ein)	
	
g firm_own_top1    = (Ntop1owners>0 & !mi(Ntop1owners))
g firm_own_M       = (NMowners >0 & !mi(NMowners))
g firm_own_toppt1  = (Ntoppt1owners>0 & !mi(Ntoppt1owners))

gen totownerpayment = ownerpay_totein
gen totordinc		= ord_inc_totein
gen totownerwage    = wagesfromfirm_totein

g poswagesfromfirm   = (wagesfromfirm >0)
egen Nowners_poswage = total(poswagesfromfirm), by(ein)
g posordinc   = (ord_inc>0)
egen Nowners_posordinc   = total(posordinc), by(ein)
egen Nowners_onlypassive = total(onlypassive), by(ein)

rename wagebill wb_p1099
rename wagebill2 wagebill
*******************************************************************************
*3. Keep one observation per firm
*******************************************************************************
egen tag=tag(ein)

keep if tag==1
drop tag

*******************************************************************************
*4. BRING TO 2014 USD
*******************************************************************************
*NOTE THAT THIS PROGRAM ONLY GOES BACK TO 93
capture drop year
g year=`yr'
usd2014, var(sales) yr(year)
usd2014, var(profits) yr(year)
usd2014, var(ass) yr(year)
usd2014, var(totownerpayment) yr(year)
usd2014, var(totordinc) yr(year)
usd2014, var(wb_p1099) yr(year)
usd2014, var(wagebill) yr(year)
usd2014, var(comp1099) yr(year)
usd2014, var(va) yr(year)
usd2014, var(totownerwage) yr(year)
usd2014, var(valine3) yr(year)


keep sales profits numw2 ass nc4 Nowners Ntop* NMowners ein totownerpayment totordinc totownerwage wagebill num1099 comp1099 wb_p1099 va  valine3 Nowners_poswage Nowners_posordinc Nowners_onlypassive
duplicates drop

local varlist "sales profits numw2 ass Nfirms Nowners Ntop1owners Ntoppt1owners totownerpayment totordinc totownerwage wagebill num1099 comp1099 wb_p1099 va valine3 Nowners_poswage Nowners_posordinc Nowners_onlypassive"

*******************************************************************************
*5. Export collapses by 4D industry and top owner indicator
*******************************************************************************
g Nfirms=!mi(ein)
recode num1099 numw2 (.=0)
g emp_broad=num1099+ numw2

g numw2gt10=(emp_broad>10 & !mi(emp_broad))
g numw2gt50=(emp_broad>50 & !mi(emp_broad))
g numw2gt100=(emp_broad>100 & !mi(emp_broad))

tempfile data_all
save `data_all'

********************************************
*ALL BY OWNER INCOME AND INDUSTRY
********************************************
use `data_all', clear
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_decomp_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_decomp_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0 
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_decomp_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_decomp_top1_`yr'.csv", replace

*Millionaires
use `data_all', clear
keep if NMowners>0 
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_decomp_M_`yr'.csv", replace
disp "Millionarie owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_decomp_M_`yr'.csv", replace


*Top 0.1%
use `data_all', clear
keep if Ntoppt1owners>0 
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_decomp_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_decomp_top01_`yr'.csv", replace

********************************************
*10+ Emps BY OWNER INCOME AND INDUSTRY
********************************************
use `data_all', clear
keep if numw2gt10==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt10_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt10_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0 
keep if numw2gt10==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt10_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt10_top1_`yr'.csv", replace

*Millionaires
use `data_all', clear
keep if NMowners>0 
keep if numw2gt10==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt10_M_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt10_M_`yr'.csv", replace


*Top 0.1%
use `data_all', clear
keep if Ntoppt1owners>0 
keep if numw2gt10==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt10_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt10_top01_`yr'.csv", replace

********************************************
*50+ Emps BY OWNER INCOME AND INDUSTRY
********************************************
use `data_all', clear
keep if numw2gt50==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt50_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt50_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0 
keep if numw2gt50==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt50_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt50_top1_`yr'.csv", replace

*Millionaires
use `data_all', clear
keep if NMowners>0 
keep if numw2gt50==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt50_M_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt50_M_`yr'.csv", replace


*Top 0.1%
use `data_all', clear
keep if Ntoppt1owners>0 
keep if numw2gt50==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt50_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt50_top01_`yr'.csv", replace

********************************************
*100+ Emps BY OWNER INCOME AND INDUSTRY
********************************************
use `data_all', clear
keep if numw2gt100==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt100_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt100_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0 
keep if numw2gt100==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt100_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt100_top1_`yr'.csv", replace

*Millionaires
use `data_all', clear
keep if NMowners>0 
keep if numw2gt100==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt100_M_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt100_M_`yr'.csv", replace

*Top 0.1%
use `data_all', clear
keep if Ntoppt1owners>0 
keep if numw2gt100==1
collapse (sum) `varlist', by(nc4)
export delimited using "$out/decompS/unmasked_s4d_w2gt100_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nfirms>10
export delimited using "$out/decompS/masked_s4d_w2gt100_top01_`yr'.csv", replace

********************************************
********************************************
*TOTALS BY OWNER TYPE
********************************************
********************************************
*ALL
use `data_all', clear
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_totals_all_`yr'.csv", replace
*Top 1%
use `data_all', clear
keep if Ntop1owners>0
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_totals_top1_`yr'.csv", replace
*Millionaires
use `data_all', clear
keep if NMowners>0
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_totals_M_`yr'.csv", replace
*Top 01%
use `data_all', clear
keep if Ntoppt1owners>0
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_totals_top01_`yr'.csv", replace

********************************************
*10+ Emps BY OWNER INCOME 
********************************************
*ALL
use `data_all', clear
keep if numw2gt10==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt10_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0
keep if numw2gt10==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt10_top1_`yr'.csv", replace

*Millionaires
use `data_all', clear
keep if NMowners>0
keep if numw2gt10==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt10_M_`yr'.csv", replace

*Top 01%
use `data_all', clear
keep if Ntoppt1owners>0
keep if numw2gt10==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt10_top01_`yr'.csv", replace

********************************************
*50+ Emps BY OWNER INCOME 
********************************************
*ALL
use `data_all', clear
keep if numw2gt50==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt50_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0
keep if numw2gt50==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt50_top1_`yr'.csv", replace

*Millionaires
use `data_all', clear
keep if NMowners>0
keep if numw2gt50==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt50_M_`yr'.csv", replace

*Top 01%
use `data_all', clear
keep if Ntoppt1owners>0
keep if numw2gt50==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt50_top01_`yr'.csv", replace

********************************************
*100+ Emps BY OWNER INCOME 
********************************************
*ALL
use `data_all', clear
keep if numw2gt100==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt100_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if Ntop1owners>0
keep if numw2gt100==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt100_top1_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if NMowners>0
keep if numw2gt100==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt100_M_`yr'.csv", replace

*Top 01%
use `data_all', clear
keep if Ntoppt1owners>0
keep if numw2gt100==1
collapse (sum) `varlist'
assert Nfirms>10
export delimited using "$out/decompS/masked_s_w2gt100_top01_`yr'.csv", replace


}

*******************************************************************************
* CONSOLIDATE DECOMP AND TOTAL FILES: s4d
*******************************************************************************

foreach dataset in "all" "top1" "M" "top01"{
forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'
insheet using "$out/decompS/masked_s4d_decomp_`dataset'_`yr'.csv", clear
assert nfirms>10

g year=`yr'
tempfile data_decomp_`yr'
save `data_decomp_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `data_decomp_`yr''
}
sort nc4 year
export delimited using "$out/decomp_outS/masked_s4d_decomp_`dataset'.csv", replace

}


*******************************************************************************
* CONSOLIDATE DECOMP AND TOTAL FILES: s4d by size
*******************************************************************************
foreach size in "w2gt10" "w2gt50" "w2gt100" {
foreach dataset in "all" "top1" "M" "top01"{
forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'
insheet using "$out/decompS/masked_s4d_`size'_`dataset'_`yr'.csv", clear
assert nfirms>10

g year=`yr'
tempfile data_decomp_`yr'
save `data_decomp_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `data_decomp_`yr''
}
sort nc4 year
export delimited using "$out/decomp_outS/masked_s4d_`size'_`dataset'.csv", replace

}
}


*******************************************************************************
*CONSOLIDATE DECOMP AND TOTAL FILES: sp total
*******************************************************************************
foreach dataset in "all" "top1" "M" "top01"{
forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'
insheet using "$out/decompS/masked_s_totals_`dataset'_`yr'.csv", clear
assert nfirms>10
g year=`yr'
tempfile data_totals_`yr'
save `data_totals_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `data_totals_`yr''
}
sort year
export delimited using "$out/decomp_outS/masked_s_totals_`dataset'.csv", replace

}

*******************************************************************************
*CONSOLIDATE DECOMP AND TOTAL FILES: sp total by size
*******************************************************************************
foreach size in "w2gt10" "w2gt50" "w2gt100" {
foreach dataset in "all" "top1" "M" "top01"{
forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'
insheet using "$out/decompS/masked_s_`size'_`dataset'_`yr'.csv", clear
assert nfirms>10
g year=`yr'
tempfile data_totals_`yr'
save `data_totals_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `data_totals_`yr''
}
sort year
export delimited using "$out/decomp_outS/masked_s_`size'_`dataset'.csv", replace

}
}

