*******************************************************************************
* External datasets and loads
*******************************************************************************
capture program drop load_soi
program define load_soi
    syntax , year(string)

    if (strlen("`year'") == 0) {
        local year = "00"
    }
    else if (strlen("`year'") == 1) {
        local year = "0`year'"
    }
    else {
        local year = "`year'"
    }

    use $raw/corp`year'.dta, clear

end

capture program drop fix_eins
program define fix_eins

	cap drop _merge
	merge m:1 ein using $raw/fix_eins
	replace ein = ein_replacement if _merge == 3
	drop _merge ein_replacement

end

capture program drop gen_columns
program define gen_columns 

    capture {
    #delimit;
    gen standard_naics = cond(industry_soi < 1000, industry_soi*1000, 
                          cond(industry_soi < 10000, industry_soi*100, 
                           cond(industry_soi < 100000, industry_soi*10, industry_soi)));
    #delimit cr
    }
    recode tot_income tot_ded intrst_pd net_dpr cst_of_gds (.=0)
    recode slrs_wgs pnsn_prft_shrng_plns emp_bnft_prg officer_comp (.=0) 
    #delimit ;
    recode   y_3yr_prpty_basis  
             y_5yr_prpty_basis 
             y_7yr_prpty_basis 
             y_10yr_prpty_basis 
             y_15yr_prpty_basis 
             y_20yr_prpty_basis 
             y_25yr_prpty_basis 
             y_50yr_prpty_basis 
             y_res_rntl_prpty_basis  
             y_nonres_rl_prpty_basis  
             y_ads_class_prpty_basis  
             y_ads_12yr_prpty_basis  
             y_ads_40yr_prpty_basis  
             y_spcl_dpr_allw 
             y_sec_179_tot_cst (.=0);
    #delimit cr

    gen va = rev - cst_of_gds
    gen sale = tot_income + cst_of_gds
    gen profits = tot_income - tot_ded
    gen ebitd = profits + intrst_pd + net_dpr

    gen labor_comp = slrs_wgs + pnsn_prft_shrng_plns + emp_bnft_prg + ///
        cst_of_lbr + officer_comp

    gen capital = dprcbl_assts - accum_dpr
    #delimit ;
    gen investment = y_3yr_prpty_basis + 
                     y_5yr_prpty_basis +
                     y_7yr_prpty_basis +
                     y_10yr_prpty_basis +
                     y_15yr_prpty_basis +
                     y_20yr_prpty_basis +
                     y_25yr_prpty_basis +
                     y_50yr_prpty_basis +
                     y_res_rntl_prpty_basis + 
                     y_nonres_rl_prpty_basis + 
                     y_ads_class_prpty_basis + 
                     y_ads_12yr_prpty_basis + 
                     y_ads_40yr_prpty_basis + 
                     y_spcl_dpr_allw +
                     y_sec_179_tot_cst;
    #delimit cr

    gen profits_margin = profits/sale
    gen ebitd_margin = ebitd/sale

    g age = year - date_inc
    replace age = . if date_inc == 9999
    replace age = . if age < 0

    * Merge on compustat for pub company flag.
    * Custom fixes for ein matching 
    fix_eins

    merge m:1 ein using $raw/cstat_eins, keep(1 3)
    gen public_co = cond(_merge == 3, 1, 0)
    drop _merge
    merge m:1 ein using $raw/eins_042715_destring, keep(1 3)
    replace public_co = cond(_merge == 3, 1, public_co)
    drop _merge

end

*******************************************************************************
* Selecting rows
*******************************************************************************
capture program drop filter_rows
program define filter_rows 

    * Duplicates
    gsort year - sale
    duplicates drop ein year, force

end

*******************************************************************************
* Adding columns and building main analysis datasets
*******************************************************************************
capture program drop build_newsoi
program define build_newsoi
	
	display "BUILD newsoi"
    tempfile newsoi

	load_soi, year("14")
    save `newsoi'

    forv i = 93/113 {
        if (`i' < 100) {
            load_soi, year("`i'")
        } 
        else {
            local j = `i'-100
            load_soi, year("`j'")
        }
        append using `newsoi'
        save `newsoi', replace
    }
    gen_columns
    filter_rows
	
	save $dta/newsoi_20170210.dta, replace
	
end

*******************************************************************************
* Main
*******************************************************************************
capture program drop main
program define main

    *log_start, f("make-20170210")
    set trace on

	**********************
	* External datasets
	**********************
	**********************
	* Main analysis dataset
	**********************
    set tracedepth 2
	build_newsoi 

	**********************
	* Derived analysis dataset
	**********************
    set tracedepth 1
	*build_indy_correlates
	
	*log close
end

main
