*******************************************************************************
* 1. Load data
*******************************************************************************
local yr=2014
use $dta/newsoi_20170210.dta, clear
keep if year==`yr'

keep if inlist(return_type,2,8,14,20)
*******************************************************************************
*2. IDENTIFY Ccorp and Scorps
*******************************************************************************
g scorp = inlist(return_type,2) 
g ccorp = inlist(return_type,8,14,20)

*******************************************************************************
*3. Industry Shares 
*******************************************************************************
gen nc4 = floor(standard_naics/100)
gen nc1 = floor(nc4/1000)

g Nfirms=1
tabstat Nfirms  [weight=weight_f], stats(sum) by(state)
tabstat Nfirms if scorp [weight=weight_f], stats(sum) by(state)
tabstat Nfirms if ccorp [weight=weight_f], stats(sum) by(state)

*******************************************************************************
*4. bring to 2014 dollars
*******************************************************************************
*NOTE THAT THIS PROGRAM ONLY GOES BACK TO 93
capture drop year
g year=`yr'
assert year>1993
usd2014, var(sale) yr(year)
usd2014, var(profits) yr(year)
usd2014, var(labor_comp) yr(year)
usd2014, var(officer_comp) yr(year)
usd2014, var(capital) yr(year)
usd2014, var(investment) yr(year)

*******************************************************************************
*5. Export
*******************************************************************************

tempfile data_all
save `data_all'

local varlist "Nfirms sale profits labor_comp officer_comp capital investment"

use `data_all', clear
collapse (sum) `varlist' [iweight=weight_f], by(state)
keep if Nfirms>10
export delimited  using $out/state_shares_soi_`yr'_all.csv, replace

use `data_all', clear
keep if ccorp
collapse (sum) `varlist' [iweight=weight_f], by(state)
keep if Nfirms>10
export delimited  using $out/state_shares_soi_`yr'_ccorp.csv, replace


use `data_all', clear
keep if scorp
collapse (sum) `varlist' [iweight=weight_f], by(state)
keep if Nfirms>10
export delimited  using $out/state_shares_soi_`yr'_scorp.csv, replace

