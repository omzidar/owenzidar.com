*******************************************************************************
* MAKESOI INSIDE
*******************************************************************************

*******************************************************************************
* NEWSOI - CAPITALISTS
*******************************************************************************
	display "BUILD newsoi"
    tempfile newsoi

	load_soi, year("15")
    save `newsoi'

    forv i = 93/114 {
        if (`i' < 100) {
            load_soi, year("`i'")
        } 
        else {
            local j = `i'-100
            load_soi, year("`j'")
        }
        append using `newsoi'
        save `newsoi', replace
    }
    
	gen_columns
	gsort year - sale
    duplicates drop ein year, force

	save $dta/newsoi_cap.dta, replace
	
*******************************************************************************
* NEWSOI - LABOR SHARE
*******************************************************************************
	display "BUILD newsoi 20171204"
    tempfile newsoi

	load_soi, year("15")
    save `newsoi'

    forv i = 93/114 {
        if (`i' < 100) {
            load_soi, year("`i'")
        } 
        else {
            local j = `i'-100
            load_soi, year("`j'")
        }
        append using `newsoi'
        save `newsoi', replace
    }
	gen_columns
	recode cash gvt_oblgns tx_exmt_sec (.=0)
    gen liquid_assets = cash + gvt_oblgns + tx_exmt_sec
	gsort year - sale
    duplicates drop ein year, force
	save $dta/newsoi_ls.dta, replace
