*******************************************************************************
* 1. Load data
*******************************************************************************
local firstyr = ${yrminoverall}
local lastyr  = ${yrmaxoverall}

forv yr = `firstyr'/`lastyr'{
*local yr=2013
disp "Year"
disp `yr'


use $dta/s_firmowner_`yr'.dta, clear

*******************************************************************************
*2. IDENTIFY FIRMS WITH TOP OWNERS
*******************************************************************************

g anyfirm  = !mi(ein)
egen Nfirmsowned   = total(anyfirm), by(tin)

g ownerpayment = ord_inc
replace ownerpayment = ord_inc + wages_max  if payer_tin==payer_tin_w2_max
replace ownerpayment = ord_inc + wages_smax if payer_tin==payer_tin_w2_smax

egen totownerpayment = total(ownerpayment), by(tin)
egen totordinc		 = total(ord_inc), by(tin)

g firmnumw2gt50=(numw2>50 & !mi(numw2))

gen age =`yr'-ssa_yob
replace age =.  if (ssa_yob==0)
replace age = ssa_yod-ssa_yob if !mi(ssa_yod)
replace age =.  if age<0
replace age =.  if age>130
replace age = . if mi(ssa_yob)

g top1   = (agipctilebin`yr'>99 & !mi(agipctilebin`yr'))
g toppt1 = (agipctilebin`yr'>99.9 & !mi(agipctilebin`yr'))


*******************************************************************************
*3. Keep one observation per owner
*******************************************************************************
egen tag=tag(tin)
keep if tag==1
drop tag
g Nowner = !mi(tin)


*******************************************************************************
*4. BRING TO 2014 USD
*******************************************************************************
*NOTE THAT THIS PROGRAM ONLY GOES BACK TO 93
capture drop year
g year=`yr'
usd2014, var(totownerpayment) yr(year)
usd2014, var(totordinc) yr(year)
usd2014, var(wages_max) yr(year)

keep tin  Nowner top1 toppt1 Nfirmsowned  totownerpayment totordinc wages_max firmnumw2gt50 age hasw2 onlypassive
duplicates drop
local varlist "Nowner top1 toppt1 Nfirmsowned  totownerpayment totordinc wages_max"
local meanlist "firmnumw2gt50 hasw2 onlypassive"

*******************************************************************************
*5. Export collapses by 4D industry and top owner indicator
*******************************************************************************
tempfile data_all
save `data_all'

tempfile data_all
save `data_all'

*ALL
use `data_all', clear
collapse (sum) `varlist' (mean) `meanlist', by(age)
export delimited using "$out/decomp/unmasked_scorp_ownerage_all_`yr'.csv", replace
disp "All firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nowner>10
export delimited using "$out/decomp/masked_scorp_ownerage_all_`yr'.csv", replace

*Top 1%
use `data_all', clear
keep if top1>0 
collapse (sum) `varlist' (mean) `meanlist', by(age)
export delimited using "$out/decomp/unmasked_scorp_ownerage_top1_`yr'.csv", replace
disp "Top 1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nowner>10
export delimited using "$out/decomp/masked_scorp_ownerage_top1_`yr'.csv", replace

*Top 0.1%
use `data_all', clear
keep if toppt1>0 
collapse (sum) `varlist' (mean) `meanlist', by(age)
export delimited using "$out/decomp/unmasked_scorp_ownerage_top01_`yr'.csv", replace
disp "Top 0.1% owned firms"
disp "`yr'"
tabstat `varlist', s(sum)
keep if Nowner>10
export delimited using "$out/decomp/masked_scorp_ownerage_top01_`yr'.csv", replace

*TOTALS
*ALL
use `data_all', clear
collapse (sum) `varlist' (mean) `meanlist' age
assert Nowner>10
export delimited using "$out/decomp/masked_scorp_owner_totals_all_`yr'.csv", replace
*Top 1%
use `data_all', clear
keep if top1>0
collapse (sum) `varlist' (mean) `meanlist' age
assert Nowner>10
export delimited using "$out/decomp/masked_scorp_owner_totals_top1_`yr'.csv", replace
*Top 01%
use `data_all', clear
keep if toppt1>0
collapse (sum) `varlist' (mean) `meanlist' age
assert Nowner>10
export delimited using "$out/decomp/masked_scorp_owner_totals_top01_`yr'.csv", replace

}

*******************************************************************************
* CONSOLIDATE DECOMP AND TOTAL FILES: scorp4d
*******************************************************************************
foreach dataset in "all" "top1" "top01"{
forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'
insheet using "$out/decomp/masked_scorp_ownerage_`dataset'_`yr'.csv", clear
assert nowner>10

g year=`yr'
tempfile data_decomp_`yr'
save `data_decomp_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `data_decomp_`yr''
}
sort year age
export delimited using "$out/decomp/masked_scorp_ownerage_`dataset'.csv", replace

}


*******************************************************************************
*CONSOLIDATE DECOMP AND TOTAL FILES: scorp total
*******************************************************************************
foreach dataset in "all" "top1" "top01"{
forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'
insheet using "$out/decomp/masked_scorp_owner_totals_`dataset'_`yr'.csv", clear
assert nowner>10
g year=`yr'
tempfile data_totals_`yr'
save `data_totals_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `data_totals_`yr''
}
sort year
export delimited using "$out/decomp/masked_scorp_owner_totals_`dataset'.csv", replace

}
