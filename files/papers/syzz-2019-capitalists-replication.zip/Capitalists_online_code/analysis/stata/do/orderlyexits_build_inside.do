global firstyear = 2001
global lastyear  = 2014
global odfirstyear = 2005
global odlastyear = 2010
global eventfirstyear = 100 - ($odfirstyear-$firstyear)
global eventlastyear = 100 + ($lastyear-$odlastyear)
global firmvarlist = "profits sales numw2 costsold"
global firmvarlist_ = "profits_ sales_ numw2_ costsold_"
global firmvarlist_dollarvars = "profits sales costsold"
global minsales = 100000


****************************************************
* 1. RUN ORDERLYEXITS BUILDS
****************************************************
foreach orgforminput in "s" "p" {
  oe_build, orgform("`orgforminput'")
}
*APPEND S AND P
foreach orgform in s p {
  use ein_od using $dta/oe_build_`orgform', clear
  duplicates drop
  tempfile eins_`orgform'
  save `eins_`orgform'', replace
}
use `eins_s', clear
merge 1:1 ein_od using `eins_p', keep(3) nogen
tempfile eins_todrop
save `eins_todrop', replace
use $dta/oe_build_s, clear
append using $dta/oe_build_p
merge m:1 ein_od using `eins_todrop'
assert _merge!=2
drop if _merge==3
drop _merge
drop odid odhsid
egen odid = group(ein_od)
egen odhsid = group(ein_od ein_hs)
save $dta/oe_build_sp, replace


*******************************************************************************
* 2. SHUTDOWN/REORG PREP: ORDERLYEXITS SHUTDOWN YEAR
*******************************************************************************
*GRAB EIN AND SHUTDOWN YEAR
foreach suffix in od hs {
  use ein_`suffix' year year_var sales_`suffix' using $dta/oe_build_sp if year>=year_var, clear
  duplicates drop
  gen zerosalesyear = year if sales_`suffix'==0
  bys ein_`suffix': egen shutdownyear = min(zerosalesyear)
  keep if sales_`suffix'==0 & year==year_var+4
  keep ein_`suffix' shutdownyear
  rename ein_`suffix' ein
  duplicates drop
  duplicates report ein
  gsort ein -shutdownyear
  **ZERO OBS DELETED BY CONSTRUCTION FOR ein_od. POSITIVE (ONLY ONE) OBS DELETED FOR ein_hs, SINCE WE ALLOW
  ** THE SAME COUNTERFACTUAL FIRM TO BE MATCHED TO MULTIPLE OWNER DEATH FIRMS.
  by ein: keep if _n==1
  save ${dump}/tempshutdownyear_oe_`suffix', replace
}
*GRAB numw2 FROM THE YEAR BEFORE THE SHUTDOWN AND YEAR OF THE SHUTDOWN
foreach suffix in od hs {
  *MAKE UNIQUE ON ein_`suffix'-year SINCE THE DATA ARE UNIQUE ONLY ON ein_od-tin_od-year (IE A FIRM
  * CAN HAVE MULTIPLE OWNER DEATHS)
  use ein_`suffix' year numw2_`suffix' using $dta/oe_build_sp, clear
  duplicates drop ein_`suffix' year, force
  save ${dump}/temp_oe_build, replace
  *MERGE ON numw2 FROM THE YEAR BEFORE THE SHUTDOWN
  use ${dump}/tempshutdownyear_oe_`suffix', clear
  rename ein ein_`suffix'
  rename shutdownyear year
  replace year = year-1
  merge 1:1 ein_`suffix' year using ${dump}/temp_oe_build, keepusing(numw2_`suffix') keep(1 3)
  assert _merge==3
  drop _merge
  rename numw2_`suffix' numw2_l1
  *MERGE ON numw2 FROM THE YEAR AFTER THE SHUTDOWN
  replace year = year+1
  merge 1:1 ein_`suffix' year using ${dump}/temp_oe_build, keepusing(numw2_`suffix') keep(1 3)
  assert _merge==3
  drop _merge
  rename numw2_`suffix' numw2_f0
  *SAVE
  rename ein_`suffix' ein
  rename year shutdownyear
  save ${dump}/tempshutdownyear_oe_`suffix', replace
}


*OUTSHEET
use ${dump}/tempshutdownyear_oe_od, clear
append using ${dump}/tempshutdownyear_oe_hs
duplicates tag ein, gen(zztag)
drop zz*
sort ein
save ${dta}/oe_shutdownyear, replace
tostring ein, replace
replace ein = "0" + ein if length(ein)<9
replace ein = "0" + ein if length(ein)<9
assert length(ein)==9
saveold ${dta}/oe_shutdownyear_einstring, replace v(12)



*******************************************************************************
* 3. SHUTDOWN/REORG PREP: REORG STATS, AFTER HARVESTING SAS OUTPUT
*******************************************************************************
*ADD FIRMS THAT HAD WORKERS IN T-1 BUT DIDN'T GET MATCHED TO ANY SUBSEQUENT WORKERS
use ein shutdownyear dead_tin worker_tin payer_tin year_nf year_df using $raw/oe_shutdownyear_50, clear
keep if year_df==shutdownyear-1
drop year_df
**PROCEED
duplicates drop
**CONFIRM THAT THERE'S ONLY EVER TWO COPIES OF EACH DEADFIRM-WORKER-NEXTFIRM PAIR
duplicates tag shutdownyear dead_tin worker_tin payer_tin, gen(zztag)
assert zztag<=1
drop zz*
destring ein, replace

**REMOVE THE DEAD FIRM FROM CONSIDERATION AS A NEXT FIRM
drop if dead_tin==payer_tin
**COLLAPSE BY DEADFIRM-OWNER-NEXTFIRM-NEXTFIRMYEAR
collapse (count) freq=worker_tin, by(ein shutdownyear payer_tin year_nf)
**SAVE ONLY THE LARGEST COUNT FOR EACH DEADFIRM-OWNER-NEXTFIRM-NEXTFIRMYEAR PAIR
replace year_nf=0 if year_nf==shutdownyear-1
replace year_nf=1 if year_nf==shutdownyear
assert inlist(year_nf,0,1)
gsort ein shutdownyear year_nf -freq
by ein shutdownyear year_nf: keep if _n==1
drop payer_tin
rename freq maxfreq_
reshape wide maxfreq, i(ein shutdownyear) j(year_nf)
save ${dump}/temp_firmownernextfirmcounts, replace
*COMPUTE COUNTS OF TOTAL T-1 WORKERS PER FIRM-OWNER PAIR
**START WITH THE _40 MATCHES
use ein shutdownyear dead_tin worker_tin year_df using $raw/oe_shutdownyear_40, clear
keep if year_df==shutdownyear-1
drop year_df
destring ein, replace

**COLLAPSE TO GET TOTAL COUNTS OF THE FIRM-OWNER PAIR'S NUMBER OF T-1 WORKERS
collapse (count) totfreq_0=worker_tin, by(ein shutdownyear)
*MERGE TOTAL DEAD FIRM COUNT TO NEXT FIRM COUNTS
merge 1:1 ein shutdownyear using ${dump}/temp_firmownernextfirmcounts
assert _merge!=2
drop _merge
*COMPUTE NEXT FIRM SHARES
forv t=0/1 {
  replace maxfreq_`t'=0 if maxfreq_`t'==.
  gen maxshare_`t' = maxfreq_`t'/totfreq_0
  sum maxshare_`t'
  assert r(min)>=0
  assert r(max)<=1
}
*SAVE
gen reorg = maxshare_0>.5 | maxshare_1>.5
save $dta/oe_reorgs, replace
