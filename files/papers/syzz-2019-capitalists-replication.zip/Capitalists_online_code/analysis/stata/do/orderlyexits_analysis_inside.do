global firstyear = 2001
global lastyear  = 2014
global odfirstyear = 2005
global odlastyear = 2010
global eventfirstyear = 100 - ($odfirstyear-$firstyear)
global eventlastyear = 100 + ($lastyear-$odlastyear)
global firmvarlist = "profits sales numw2 costsold"
global firmvarlist_ = "profits_ sales_ numw2_ costsold_"
global firmvarlist_dollarvars = "profits sales costsold"
global minsales = 100000

************************************************************************
* 4. ORDERLYEXITS ANALYSIS FILES AND GRAPHS
************************************************************************
foreach orgforminput in "sp" "s" "p" {
  foreach sampleinput in "millionaire" "toppt1" "top1" {
    orderlyexits_analysis, orgform("`orgforminput'") sample("`sampleinput'")
  }
}


************************************************************************
* 5. ORDERLYEXITS TABLE
************************************************************************
clear
global col = 0

local outfile "${dump}/temprow_oe.dta"
capture rm "`outfile'"

foreach orgform in s p sp {
  global orgform = "`orgform'"
  
  *TOP 1%
  global sample = "top1"
  use ${dta}/oe_analysis_`orgform'_${sample} if agipctilebin_var>99, clear 
  t4reg, varroot("salesgt0") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre_int") ifcon("profits_numw2pre_int_dif != .") ofile("`outfile'") append 
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,0,.5)") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,.50000001,1)") ofile("`outfile'") append
  
  *TOP 0.1%
  global sample = "toppt1"
  use ${dta}/oe_analysis_`orgform'_${sample} if agipctilebin_var>99.9, clear
  t4reg, varroot("salesgt0") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre_int") ifcon("profits_numw2pre_int_dif != .") ofile("`outfile'") append 
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,0,.5)") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,.50000001,1)") ofile("`outfile'") append
  
  *MILLIONAIRES
  global sample = "millionaire"
  use ${dta}/oe_analysis_`orgform'_${sample} if psinc_14dollars_l1>=1000000 & psinc_14dollars_l1!=., clear
  t4reg, varroot("salesgt0") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre_int") ifcon("profits_numw2pre_int_dif != .") ofile("`outfile'") append 
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,0,.5)") ofile("`outfile'") append
  t4reg, varroot("profits_numw2pre") ifcon("inrange(ownshare,.50000001,1)") ofile("`outfile'") append
}

use "`outfile'", clear
sort orgform sample col
order orgform sample col
export delimited $out/orderlyexits_table_output.csv, replace
list


************************************************************************
* 7. WATERFALL COUNTS
************************************************************************
*WATERFALL COUNT 1: Distinct firms 2005-2010
use ${dta}/savetemp3_s, clear
append using ${dta}/savetemp3_p
drop if hastop1l1==.
disp "WATERFALL COUNT 1: Distinct firms 2005-2010"
distinct ein

*WATERFALL COUNT 2: Restrict to firms with an orderly exit
keep if oe==1
disp "WATERFALL COUNT 2: Has orderly exit"
distinct ein

*WATERFALL COUNT 3: Restrict to firms with a top 1% owner in t-1
keep if hastop1l1==1
disp "WATERFALL COUNT 3: Restrict to firms with a top 1% owner in t-1"
distinct ein

*WATERFALL COUNT 4: Restrict to firms with >$100K sales
keep if hassales100kl1==1
disp "WATERFALL COUNT 4: Restrict to firms with >$100K sales"
distinct ein

*WATERFALL COUNT 5: Restrict to firms with positive sales [t-4,t-1]
keep if possalesl4f1==1
disp "WATERFALL COUNT 5: Restrict to firms with positive sales [t-4,t-1]"
distinct ein

*WATERFALL COUNT 6: Restrict to firms with at least one pre-period worker
keep if posnumw2pre==1
disp "WATERFALL COUNT 6: Restrict to firms with at least one pre-period worker"
distinct ein

*WATERFALL COUNT 7: Restrict to firms with t-1 owner share >=.2
keep if inrange(ownsharel1,.2,1.00000000001)
disp "WATERFALL COUNT 7: Restrict to firms with t-1 owner share >=.2"
distinct ein

*WATERFALL COUNT 8: Match to at least one counterfactual firm
use $dta/oe_build_s, clear
append using $dta/oe_build_p
keep ein_od
disp "WATERFALL COUNT 8: Match to at least one counterfactual firm"
distinct ein_od


****************************************************
* 8. ACTIVE SHARE OF INFERRED RETIREMENTS (SEE ALSO STEP 10 BELOW)
****************************************************
use ein_od eventtime year using $dta/oe_analysis_sp_millionaire if eventtime==104, clear
drop eventtime
duplicates drop
tempfile temp
save `temp', replace

use ein tax_yr onlypassive using ${dta}/savetemp0_s, clear
append using ${dta}/savetemp0_p, keep(ein tax_yr onlypassive)
collapse (min) onlypassive, by(ein tax_yr)
rename tax_yr year
rename ein ein_od
merge 1:1 ein_od year using `temp', keep(2 3) 
sum onlypassive
replace onlypassive=1 if onlypassive==.
sum onlypassive


************************************************************************
* 9. ONE-OFF STATS ON EXITS AND REORGS
************************************************************************
use $dta/oe_analysis_sp_millionaire if eventtime==104, clear
foreach suffix in od hs {
  gen exit_`suffix' = (lnsales_`suffix'==.)
}
foreach suffix in od hs {
  qui sum exit_`suffix' [w=odidwgt]
  local exit_`suffix'_mean = r(mean)
  disp "Exit rate for `suffix' firms: " `exit_`suffix'_mean'
}
foreach suffix in od hs {
  qui sum salesgt0_`suffix' [w=odidwgt]
  local salesgt0_`suffix'_mean = r(mean)
  local reorg_share_`suffix' = (`exit_`suffix'_mean' - (1 - `salesgt0_`suffix'_mean'))/`exit_`suffix'_mean'
  disp "Share of `suffix' exits that were reorgs: " `reorg_share_`suffix''
}


****************************************************
* 10. W-2 SHARE OF INFERRED RETIREMENTS (SEE ALSO STEP 8 BELOW)
****************************************************
use ein_od eventtime year using $dta/oe_analysis_sp_millionaire if eventtime==104, clear
drop eventtime
duplicates drop
tempfile temp
save `temp', replace

use ein tax_yr wagesfromfirm using ${dta}/savetemp0_s, clear
append using ${dta}/savetemp0_p, keep(ein tax_yr wagesfromfirm)
gen haswagesfromfirm = wagesfromfirm>0
collapse (max) haswagesfromfirm, by(ein tax_yr)
rename tax_yr year
rename ein ein_od
merge 1:1 ein_od year using `temp', keep(2 3) 
sum haswagesfromfirm
replace haswagesfromfirm=0 if haswagesfromfirm==.
sum haswagesfromfirm
