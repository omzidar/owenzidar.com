clear 
clear matrix

*******************************************************************************
* 5. COLLAPSE ALL YEARS 
*******************************************************************************
*MAKE COLLAPSES
forv t=1962/2014 {
  if !inlist(`t',1963,1965) {
    *CREATE RANKS
    use ${dinafiles_ext}/usdina`t', clear
	
    ** PSZ: USE PRE_TAX NATIONAL INCOME (MATCHING MACRO NI)
    xtile rankpsz = peinc [w=dweght], n(1000)
    replace rankpsz=rankpsz-1

    **USE fninc WHICH IS EXCLUSIVE OF CAP GAINS, IN ORDER TO MATCH CAPITALISTS.
    xtile rankps = fninc [w=dweghttaxu], n(1000)
    replace rankps=rankps-1
    **BIN INTO THREE GROUPS
    foreach type in ps psz {
      gen bin`type' = 0
      replace bin`type'=1 if inrange(rank`type',990,998)
      replace bin`type'=2 if inrange(rank`type',999,999)
      if "`type'"=="ps" {
    	label variable bin`type' "PS income bin"
      }
      else if "`type'"=="psz" {
    	label variable bin`type' "PSZ income bin"
      }
    }
    label define binlabels 0 "0 (Bottom 99%)" 1 "1 (Top 1-0.1%)" 2 "2 (Top 0.1%)"
    label values binps binpsz binlabels
    **DIVIDE WEIGHT BY 100000
    foreach wgt in dweght dweghttaxu {
      replace `wgt' = `wgt'/100000
    }
    *PS COLLAPSE
    preserve
      collapse (sum) fiinc-vethealth [iw=dweghttaxu], by(binps)
      save ${dump}/usdina`t'clps_ps.dta, replace
      outsheet using ${dump}/usdina`t'clps_ps.csv, comma replace
    restore
    *PSZ COLLAPSE
    preserve
      collapse (sum) fiinc-vethealth [iw=dweght], by(binpsz)
      save ${dump}/usdina`t'clps_psz.dta, replace
      outsheet using ${dump}/usdina`t'clps_psz.csv, comma replace
    restore
  }
}

*COMPILE INTO A SINGLE FILE AND SAVE
use ${dump}/usdina1962clps_psz, clear
gen year = 9999
gen defn = "psz"
rename bin bininc
drop if _n>=0
save ${dump}/usdinaclps19622014, replace
forv t=1962/2014 {
  if !inlist(`t',1963,1965) {
    foreach defn in "ps" "psz" {
      use ${dump}/usdina`t'clps_`defn', clear
	  gen year = `t'
	  gen defn = "`defn'"
	  rename bin bininc
	  append using ${dump}/usdinaclps19622014
	  save ${dump}/usdinaclps19622014, replace
	}
  }
}
order year defn bininc
sort year defn bininc
save ${out}/usdinaclps19622014, replace
outsheet using ${out}/usdinaclps19622014.csv, comma replace
