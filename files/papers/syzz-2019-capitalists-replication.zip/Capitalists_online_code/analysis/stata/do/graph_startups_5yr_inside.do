*********************************
*** RUN PROGRAMS ****************
*********************************

hockey_prep_startups5thyr
hockey_prep_cdwfirms, orgform("sp") ifcon("if agibin>90") specname("asize_5thyr") startups apportioned
hockey_prep_startups5yr
hockey_prep_cdwfirms, orgform("sp") ifcon("if agibin>90") specname("suallsizes") startups apportioned

*******************************
*** MAKE GRAPHS ***************
*******************************

use ${dta}/hockeys_cdwfirmdata_asize_5thyr, clear
gen fifth_yr = 1
append using ${dta}/hockeys_cdwfirmdata_suallsizes
replace fifth_yr = 0 if fifth_yr == .
collapse (mean) ppw*, by(agibin fifth_yr)

outsheet using ${out}/fig_4b_input.csv, comma replace
