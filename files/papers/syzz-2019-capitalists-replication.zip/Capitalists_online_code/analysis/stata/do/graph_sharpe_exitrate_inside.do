forv x = 2001/2014 { 
   use ownshare tax_yr profits sales numw2 agibin using $dta/sp_firmowner_`x' if inrange(ownshare,0,1), clear
   gen sales_apportioned = ownshare*sales
   gen profits_14dollars = profits
   usd2014, var(profits_14dollars) yr(tax_yr)
   gen ppw = profits_14dollars/numw2
   foreach var in ppw {
   sum `var', d
   replace `var'=r(p1) if `var'<r(p1) & `var'!=.
   replace `var'=r(p99) if `var'>r(p99) & `var'!=.
   }
   collapse (mean) ppw_mean=ppw (sd) ppw_sd=ppw [w=sales_apportioned], by(agibin)
   gen sr = ppw_mean/ppw_sd
   gen tax_yr = `x'
   save $dump/sharpe_data_`x', replace
}

use $dump/sharpe_data_2001, clear
forv x = 2002/2014 {
  append using $dump/sharpe_data_`x'
}
save $dump/sharpe_data_panel,replace
use $dump/sharpe_data_panel, clear
gen bin = 1 
replace bin = 2 if inrange(tax_yr,2005,2010)
replace bin = 3 if inrange(tax_yr,2011,2014)
drop if bin == 2

collapse (mean) sr, by(bin agibin)
reshape wide sr, i(agibin) j(bin)
saveold $dump/sharpe_data_clspe, v(12) replace

use tylast sales ownshare agibin using $dta/sp_firmowner_2001 if inrange(ownshare,0,1), clear
gen sales_apportioned = ownshare*sales
gen exited = (tylast < 2014)
collapse (mean) exited [w=sales_apportioned], by(agibin)
merge 1:1 agibin using $dump/sharpe_data_clspe
saveold $dump/rpi_fig5b, v(12) replace

use $dump/rpi_fig5b, clear
outsheet using $out/fig_i13_input.csv, comma replace
