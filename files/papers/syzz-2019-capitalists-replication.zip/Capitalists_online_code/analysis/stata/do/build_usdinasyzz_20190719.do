/*******************************************************************************
    Title: build_usdinasyzz_YYYYMMDD.do
  Purpose: Build the usdinasyzz analysis files 
   Author: DY, EZ, OZ
     Date: 2018-06-20
*******************************************************************************/


qui {
capture program drop merge_vars_def_ranks
program define merge_vars_def_ranks

  syntax, labshareofpt000(int)
  
  local labshare_suff `labshareofpt000'

  *CREATE INTERMEDIATE DATASETS ${dump}/usdinasyzz`t'_tempmerged1_es0 and _es1 TO BE USED HERE AND
  * IN -build_usdinasyzz-
  forv t=$yrmin/$yrmax {
    if !inlist(`t',1963,1965) {
      *LOAD RAW DINA FILE
      use ${dinafiles_ext}/usdina`t' if dweght!=0 & dweght!=. & dweghttaxu!=0 & dweghttaxu!=., clear

	di " "
	di "`labshare_suff'"

 
		if "`labshare_suff'" != "999" {
		  ** replace flmil / fkbus with vary labor share versions
		  drop flmil fkbus
		  merge 1:1 id second using ${dump}/archived_vary_labor_share_dina_values`t' , keep(1 3) keepusing(flmil* fkbus*) nogen
		
		  rename flmil`labshare_suff' zflmil
		  rename fkbus`labshare_suff' zfkbus
		  
		 cap drop flmil*
		 cap drop fkbus*
		  
		  rename zflmil flmil
		  rename zfkbus fkbus
		}
	  
	  cap confirm variable year
	  if _rc {
		  gen year = `t'
	  } 
	  else {
		  replace year = `t' if year == .
	  }

   	  foreach var of varlist divinc scorpinc2 kginc divest kgest {
   	    *replace `var' = 0 if `var' == . & _merge == 1
   	    replace `var' = 0 if `var' == .
   	  }

   	  *CREATE NEW VARS FOLLOWING PSZ, WHICH HAVE TO BE CREATED AT THE INDIVIDUAL LEVEL
   	  **COMPUTE EACH INDIVIDUAL'S RATIO shemp OF EMPLOYEE COMP TO TOTAL LABOR COMP
      ** (= EMPLOYEE COMP + LABOR COMPONENT OF NET MIXED INCOME LIKE SCHED C AND PSHIP)
      gen shemp = flemp / (flemp + flmil)
      replace shemp = 0 if shemp == .
      **ALLOCATE shemp SHARE OF THE INDIVIDUAL'S SALES AND EXCISE TAXES FALLING ON
      ** LABOR TO EMPLOYEE COMP
      gen flempwtax = flemp + flprl * shemp
      label var flempwtax "Compensation of employees + allocated sales+excise taxes"
      **ALLOCATE (1-shemp) SHARE OF THE INDIVIDUAL'S SALES AND EXCISE TAXES FALLING ON
      ** LABOR TO THE LABOR COMPONENT OF NET MIXED INCOME
      gen flmilwtax = flmil + flprl * (1-shemp)
      label var flmilwtax "Labor share of mixed income + allocated sales+excise taxes"
      drop shemp
   	  *CREATE NON-EQUAL-SPLIT RANKING BASED ON EMMANUELS SHCOMP ADO FILE
      matrix input cumul = (0, .5, .9, .95, .99, .995, .999, .9999)
      local nbgroup = colsof(cumul)
      cumul ptinc [w=dweght] , gen(rankprogpt)
      cumul peinc [w=dweght] , gen(rankprogpe)
      cumul fiinc [w=dweght] , gen(rankprogfi)
      cumul fninc [w=dweght] , gen(rankprogfn)
	  **PS RANKS: AGGREGATE RANKING VARS WITHIN TAX UNITS, SET ONE ROW TO MISSING, CREATE RANKS, THEN SPREAD WITHIN UNIT
      foreach var in ptinc peinc fiinc fninc {
        bys id: egen `var'taxu = total(`var')
        replace `var'taxu=. if second==1
      }
	  replace dweghttaxu=. if second==1
      cumul ptinctaxu [w=dweghttaxu] , gen(zzrankprogtupt)
      cumul peinctaxu [w=dweghttaxu] , gen(zzrankprogtupe)
      cumul fiinctaxu [w=dweghttaxu] , gen(zzrankprogtufi)
      cumul fninctaxu [w=dweghttaxu] , gen(zzrankprogtufn)
	  foreach prefix in pt pe fi fn {
	    by id: egen rankprogtu`prefix' = max(zzrankprogtu`prefix')
		rename `prefix'inctaxu zz`prefix'inctaxu
		by id: egen `prefix'inctaxu = max(zz`prefix'inctaxu)
	  }
	  rename dweghttaxu zzdweghttaxu
	  by id: egen dweghttaxu = max(zzdweghttaxu)
	  drop zz* ptinctaxu peinctaxu fiinctaxu fninctaxu
      label var dweghttaxu "Population weight to recover Piketty-Saez total tax units"
      label var rankprogpt "PSZ CDF rank by ptinc, (0,1]. Used for TB2f."
      label var rankprogpe "PSZ CDF rank by peinc, (0,1]"
      label var rankprogfi "PSZ CDF rank by fiinc, (0,1]"
      label var rankprogfn "PSZ CDF rank by fninc, (0,1]"
      label var rankprogtupt "PS CDF rank by ptinc, (0,1]"
      label var rankprogtupe "PS CDF rank by peinc, (0,1]"
      label var rankprogtufi "PS CDF rank by fiinc, (0,1]"
      label var rankprogtufn "PS CDF rank by fninc, (0,1]"
	  *SAVE ALL VAR LABELS (MAINLY TO REAPPLY AFTER THE COLLAPSE)
	  foreach v of var * {
        local l`v' : variable label `v'
        if `"`l`v''"' == "" {
	      local l`v' "`v'"
        }
      }
	  *REAPPLY ALL VAR LABELS, WHICH HERE JUST LABELS UNLABELED VARS WITH THE VAR NAME
      foreach v of var * {
	    capture label var `v' "`l`v''"
      }
	  *SAVE NON-EQUAL-SPLIT INDIVIDUAL-LEVEL INTERMEDIATE FILE
	  order id second dweght dweghttaxu
	  save ${dump}/usdinasyzz`t'_tempmerged1_es0_`labshare_suff', replace
   	  *SPLIT ALL INCOME COMPONENTS EQUALLY WITHIN MARRIED COUPLES
      collapse (first) married (mean) fiinc-flmilwtax, by(id)
      qui gen second=1
      qui replace second=2 if married==1
      expand second
	  bys id: replace second=0 if _n==1
	  by id: replace second=1 if _n==2
	  *REAPPLY ALL VAR LABELS, WHICH IS NECESSARY AFTER COLLAPSE
      foreach v of var * {
	    capture label var `v' "`l`v''"
      }
	  *MERGE THESE EQUAL-SPLIT INCOME VARS ONTO THE "SPINE" OF NON-INCOME VARS
	  drop married
	  merge 1:1 id second using ${dump}/usdinasyzz`t'_tempmerged1_es0_`labshare_suff', keepusing(id-xkidspop)
	  assert _merge==3
	  drop _merge
	  order id second dweght-xkidspop
   	  *CREATE EQUAL-SPLIT RANKING BASED ON EMMANUELS SHCOMP ADO FILE
      matrix input cumul = (0, .5, .9, .95, .99, .995, .999, .9999)
      local nbgroup = colsof(cumul)
      cumul ptinc [w=dweght] , gen(rankprogpt)
      cumul peinc [w=dweght] , gen(rankprogpe)
      cumul fiinc [w=dweght] , gen(rankprogfi)
      cumul fninc [w=dweght] , gen(rankprogfn)
	  **PS RANKS: AGGREGATE RANKING VARS WITHIN TAX UNITS, SET ONE ROW TO MISSING, CREATE RANKS, THEN SPREAD WITHIN UNIT
      foreach var in ptinc peinc fiinc fninc {
        bys id: egen `var'taxu = total(`var')
        replace `var'taxu=. if second==1
      }
	  replace dweghttaxu=. if second==1
      cumul ptinctaxu [w=dweghttaxu] , gen(zzrankprogtupt)
      cumul peinctaxu [w=dweghttaxu] , gen(zzrankprogtupe)
      cumul fiinctaxu [w=dweghttaxu] , gen(zzrankprogtufi)
      cumul fninctaxu [w=dweghttaxu] , gen(zzrankprogtufn)
	  foreach prefix in pt pe fi fn {
	    by id: egen rankprogtu`prefix' = max(zzrankprogtu`prefix')
		rename `prefix'inctaxu zz`prefix'inctaxu
		by id: egen `prefix'inctaxu = max(zz`prefix'inctaxu)
	  }
	  rename dweghttaxu zzdweghttaxu
	  by id: egen dweghttaxu = max(zzdweghttaxu)
	  drop zz* ptinctaxu peinctaxu fiinctaxu fninctaxu
      label var dweghttaxu "Population weight to recover Piketty-Saez total tax units"
      label var rankprogpt "PSZ CDF rank by ptinc, (0,1]. Used for TB2f."
      label var rankprogpe "PSZ CDF rank by peinc, (0,1]"
      label var rankprogfi "PSZ CDF rank by fiinc, (0,1]"
      label var rankprogfn "PSZ CDF rank by fninc, (0,1]"
      label var rankprogtupt "PS CDF rank by ptinc, (0,1]"
      label var rankprogtupe "PS CDF rank by peinc, (0,1]"
      label var rankprogtufi "PS CDF rank by fiinc, (0,1]"
      label var rankprogtufn "PS CDF rank by fninc, (0,1]"
	  *SAVE EQUAL-SPLIT INDIVIDUAL-LEVEL INTERMEDIATE FILE
	  order id second dweght dweghttaxu
	  save ${dump}/usdinasyzz`t'_tempmerged1_es1_`labshare_suff', replace
	}
  }
end
}

qui {
capture program drop ps_psz_clps
program define ps_psz_clps

  syntax, labshareofpt000(int)
  
  local labshare_suff `labshareofpt000'

  *PSZRANKED COLLAPSES (ALL, TOP 1%, AND TOP .1%. GROUPS ARE NOT MUTUALLY EXCLUSIVE.)
  forv t=$yrmin/$yrmax {
    forv equalsplit=0/1 {
      if !inlist(`t',1963,1965) {
	    foreach ranktype in pt pe {
  	      foreach threshold in 0 99 999 {	
    	    use ${dump}/usdinasyzz`t'_tempmerged1_es`equalsplit'_`labshare_suff' if rankprog`ranktype'>=.`threshold', clear
			order year, last
			replace dweght=dweght/100000
  		    collapse (sum) fiinc-flmilwtax [pw=dweght], by(year)
			gen defn = "psz"
			gen equalsplit = `equalsplit'
			gen ranktype = "`ranktype'"
  		    gen threshold = `threshold'
  		    save ${dump}/usdina`t'clps_psz_es`equalsplit'_`ranktype'_`threshold'_`labshare_suff', replace
		  }
  		}
      }
    }
  }
  *PS-RANKED COLLAPSES (ALL, TOP 1%, AND TOP .1%. GROUPS ARE NOT MUTUALLY EXCLUSIVE.)
  forv t=$yrmin/$yrmax {
    **NO NEED TO DO BOTH EQUAL SPLITS SINCE THEY'RE THE SAME FOR PS (SINCE THE RANKINGS ARE TAX-UNIT LEVEL)
    forv equalsplit=0/0 {
      if !inlist(`t',1963,1965) {
	    foreach ranktype in tufn tufi {
  	      foreach threshold in 0 99 999 {	
    	    use ${dump}/usdinasyzz`t'_tempmerged1_es`equalsplit'_`labshare_suff' if rankprog`ranktype'>=.`threshold', clear
			order year, last
			replace dweghttaxu=dweghttaxu/100000
  		    collapse (sum) fiinc-flmilwtax [pw=dweghttaxu], by(year)
			gen defn = "ps"
			gen equalsplit = `equalsplit'
			gen ranktype = "`ranktype'"
  		    gen threshold = `threshold'
  		    save ${dump}/usdina`t'clps_ps_es`equalsplit'_`ranktype'_`threshold'_`labshare_suff', replace
		  }
  		}
      }
    }
  }
  *COMPILE THE MANY COLLAPSES INTO A SINGLE FILE TO OUTSHEET
  clear
  forv t=$yrmin/$yrmax {
    forv equalsplit=0/1 {
      if !inlist(`t',1963,1965) {
	    foreach ranktype in pt pe {
  	      foreach threshold in 0 99 999 {
  		    append using ${dump}/usdina`t'clps_psz_es`equalsplit'_`ranktype'_`threshold'_`labshare_suff'
		  }
  		}
      }
    }
  }
  forv t=$yrmin/$yrmax {
    **NO NEED TO DO BOTH EQUAL SPLITS SINCE THEY'RE THE SAME FOR PS (SINCE THE RANKINGS ARE TAX-UNIT LEVEL)
    forv equalsplit=0/0 {
      if !inlist(`t',1963,1965) {
	    foreach ranktype in tufn tufi {
  	      foreach threshold in 0 99 999 {
  		    append using ${dump}/usdina`t'clps_ps_es`equalsplit'_`ranktype'_`threshold'_`labshare_suff'
		  }
  		}
      }
    }
  }
  order year defn equalsplit ranktype threshold
  sort year defn equalsplit ranktype threshold
  ds year defn equalsplit ranktype threshold, not
  format `r(varlist)' %30.0g
  saveold ${dta}/usdina${yrmin}${yrmax}clps_`labshare_suff'.dta, v(12) replace
  outsheet using ${out}/usdina${yrmin}${yrmax}clps_`labshare_suff'.csv, comma replace
  outsheet using ${out}/usdina${yrmin}${yrmax}clps_`labshare_suff'.csv, comma replace
end
}

qui {
capture program drop ps_psz_clps_wide
program define ps_psz_clps_wide

  syntax, labshareofpt000(int)
  
  local labshare_suff `labshareofpt000'

  *PSZ-RANKED COLLAPSES (EQUAL-SPLIT AND NON-EQUAL-SPLIT) BY BOTTOM 99%, TOP 1-0.1%, AND TOP 1%
  forv t=$yrmin/$yrmax {
    forv equalsplit=0/1 {
      if !inlist(`t',1963,1965) {
	    *LOAD DATA
		use ${dump}/usdinasyzz`t'_tempmerged1_es`equalsplit'_`labshare_suff', clear
        matrix input cumul = (0, .5, .9, .95, .99, .995, .999, .9999)
        foreach var of varlist fiinc-flmilwtax {
          *FIRST USING PT RANKS
          quietly sum `var' [w=dweght] if rankprogpt<cumul[1,5]
          gen double `var'bot99pt = r(sum) / 100000
          format `var'bot99pt %25.0g
          quietly sum `var' [w=dweght] if rankprogpt>=cumul[1,5] & rankprogpt<cumul[1,7]
          gen double `var'top1pt = r(sum) / 100000
          format `var'top1pt %25.0g
          quietly sum `var' [w=dweght] if rankprogpt>=cumul[1,7]
          gen double `var'toppt1pt = r(sum) / 100000
          format `var'toppt1pt %25.0g
          *THEN USING PE RANKS
          quietly sum `var' [w=dweght] if rankprogpe<cumul[1,5]
          gen double `var'bot99pe = r(sum) / 100000
          format `var'bot99pe %25.0g
          quietly sum `var' [w=dweght] if rankprogpe>=cumul[1,5] & rankprogpe<cumul[1,7]
          gen double `var'top1pe = r(sum) / 100000
          format `var'top1pe %25.0g
          quietly sum `var' [w=dweght] if rankprogpe>=cumul[1,7]
          gen double `var'toppt1pe = r(sum) / 100000
          format `var'toppt1pe %25.0g
        }
        keep *bot99* *top1* *toppt1*
        keep if _n == 1
        gen year = `t'
        rename taxbond* bondtax*
        #delimit ;
        reshape long fiinc fninc fainc flinc fkinc ptinc plinc pkinc diinc princ	peinc poinc	hweal fiwag	fibus firen ///
        fiint fidiv fikgi fnps peninc schcinc scorinc	partinc	rentinc	estinc	rylinc othinc flemp flmil flprl ///
        fkhou	fkequ fkfix	fkbus fkpen	fkdeb plcon	plbel pkpen	pkbek hwequ	hwfix hwhou	hwbus ///
        hwpen	hwdeb flwag	flsup waghealth	wagpen fkhoumain fkhourent fkmor fknmo fkprk proprestax ///
        propbustax rental	rentalhome	rentalmort ownerhome ownermort housing partw soleprop	scorw equity ///
        bondtax muni currency	nonmort	hwealnokg hwfin	hwnfa plpco	ploco plpbe	plobe plben	plpbl ///
        plnin	pkpbk pknin ptnin dicsh inkindinc	colexp govin npinc prisupen	invpen prisupenprivate prisupgov ///
        educ	colexp2	poinc2 tax	ditax ditaf	ditas salestax corptax estatetax govcontrib	ssuicontrib	othercontrib ///
        ssinc_oa ssinc_di	uiinc ben dicab	dicred difoo disup divet diwco	dicao tanfinc othben medicare ///
        medicaid otherkin	pell vethealth	divinc scorpinc2 kginc divest kgest flempwtax flmilwtax, i(year) j(group) string
        ;
        #delimit cr
        rename bondtax taxbond
        save ${dump}/usdina`t'clps_es`equalsplit'_`labshare_suff', replace
      }
    }
  }

  *PS-RANKED COLLAPSES (EQUAL-SPLIT AND NON-EQUAL-SPLIT) BY BOTTOM 99%, TOP 1-0.1%, AND TOP 1%
  forv t=$yrmin/$yrmax {
    forv equalsplit=0/1 {
      if !inlist(`t',1963,1965) {
	    *LOAD DATA
		use ${dump}/usdinasyzz`t'_tempmerged1_es`equalsplit'_`labshare_suff', clear
		order year, last
		*COLLAPSE BY TAX ID FOR PS-BASED COLLAPSES
		collapse (sum) fiinc-flmilwtax (mean) dweghttaxu rank*, by(id year)
        matrix input cumul = (0, .5, .9, .95, .99, .995, .999, .9999)
        foreach var of varlist fiinc-flmilwtax {
          *FIRST USING PT RANKS
          quietly sum `var' [w=dweghttaxu] if rankprogtufi<cumul[1,5]
          gen double `var'bot99fi = r(sum) / 100000
          format `var'bot99fi %25.0g
          quietly sum `var' [w=dweghttaxu] if rankprogtufi>=cumul[1,5] & rankprogtufi<cumul[1,7]
          gen double `var'top1fi = r(sum) / 100000
          format `var'top1fi %25.0g
          quietly sum `var' [w=dweghttaxu] if rankprogtufi>=cumul[1,7]
          gen double `var'toppt1fi = r(sum) / 100000
          format `var'toppt1fi %25.0g
          *THEN USING PE RANKS
          quietly sum `var' [w=dweghttaxu] if rankprogtufn<cumul[1,5]
          gen double `var'bot99fn = r(sum) / 100000
          format `var'bot99fn %25.0g
          quietly sum `var' [w=dweghttaxu] if rankprogtufn>=cumul[1,5] & rankprogtufn<cumul[1,7]
          gen double `var'top1fn = r(sum) / 100000
          format `var'top1fn %25.0g
          quietly sum `var' [w=dweghttaxu] if rankprogtufn>=cumul[1,7]
          gen double `var'toppt1fn = r(sum) / 100000
          format `var'toppt1fn %25.0g
        }
        keep *bot99* *top1* *toppt1*
        keep if _n == 1
        gen year = `t'
        rename taxbond* bondtax*
        #delimit ;
        reshape long fiinc fninc fainc flinc fkinc ptinc plinc pkinc diinc princ	peinc poinc	hweal fiwag	fibus firen ///
        fiint fidiv fikgi fnps peninc schcinc scorinc	partinc	rentinc	estinc	rylinc othinc flemp flmil flprl ///
        fkhou	fkequ fkfix	fkbus fkpen	fkdeb plcon	plbel pkpen	pkbek hwequ	hwfix hwhou	hwbus ///
        hwpen	hwdeb flwag	flsup waghealth	wagpen fkhoumain fkhourent fkmor fknmo fkprk proprestax ///
        propbustax rental	rentalhome	rentalmort ownerhome ownermort housing partw soleprop	scorw equity ///
        bondtax muni currency	nonmort	hwealnokg hwfin	hwnfa plpco	ploco plpbe	plobe plben	plpbl ///
        plnin	pkpbk pknin ptnin dicsh inkindinc	colexp govin npinc prisupen	invpen prisupenprivate prisupgov ///
        educ	colexp2	poinc2 tax	ditax ditaf	ditas salestax corptax estatetax govcontrib	ssuicontrib	othercontrib ///
        ssinc_oa ssinc_di	uiinc ben dicab	dicred difoo disup divet diwco	dicao tanfinc othben medicare ///
        medicaid otherkin	pell vethealth	divinc scorpinc2 kginc divest kgest flempwtax flmilwtax, i(year) j(group) string
        ;
        #delimit cr
        rename bondtax taxbond
        save ${dump}/usdina`t'clps_ps_es`equalsplit'_`labshare_suff', replace
      }
    }
  }
end
}

qui {
capture program drop clps_top1pt1_append
program define clps_top1pt1_append

  syntax, labshareofpt000(int)
  
  local labshare_suff `labshareofpt000'

  *APPEND MAIN COLLAPSE (PSZ-RANKED)
  forv equalsplit=0/1 {
    clear
    forv t=$yrmin/$yrmax {
      if !inlist(`t',1963,1965) {
        append using ${dump}/usdina`t'clps_es`equalsplit'_`labshare_suff'
      }
    }
    ds year group, not
    format `r(varlist)' %30.0g
    sort year group
    saveold ${dta}/usdina${yrmin}${yrmax}clps_es`equalsplit'_`labshare_suff'.dta, v(12) replace
    outsheet using ${out}/usdina${yrmin}${yrmax}clps_es`equalsplit'_`labshare_suff'.csv, comma replace
    outsheet using ${out}/usdina${yrmin}${yrmax}clps_psz_es`equalsplit'_`labshare_suff'.csv, comma replace
  }

  *APPEND MAIN COLLAPSE (PS-RANKED)
  forv equalsplit=0/1 {
    clear
    forv t=$yrmin/$yrmax {
      if !inlist(`t',1963,1965) {
        append using ${dump}/usdina`t'clps_ps_es`equalsplit'_`labshare_suff'
      }
    }
    ds year group, not
    format `r(varlist)' %30.0g
    sort year group
    saveold ${dta}/usdina${yrmin}${yrmax}clps_ps_es`equalsplit'_`labshare_suff'.dta, v(12) replace
    outsheet using ${out}/usdina${yrmin}${yrmax}clps_ps_es`equalsplit'_`labshare_suff'.csv, comma replace
  }
 
  *SPLIT COLLAPSES INTO PE-BASED TOP 1% AND PT-BASED TOP 1% COLLAPSES 
  forv equalsplit=0/1 {
    foreach type in pt pe {
      use ${dta}/usdina${yrmin}${yrmax}clps_es`equalsplit'_`labshare_suff', clear
      keep if inlist(group,"bot99`type'","top1`type'","toppt1`type'")
      gen top1=1
      replace top1=0 if group=="bot99`type'"
      collapse (sum) fiinc-flmilwtax, by(year top1)
      ds year top1, not
      local rootvarlist = "`r(varlist)'"
      reshape wide fiinc-flmilwtax, i(year) j(top1)
      foreach var in `rootvarlist' {
        gen tt`var' = `var'0 + `var'1
        rename `var'1 `var'
        drop `var'0
      }
      ds year, not
      format `r(varlist)' %30.0g
  	  saveold ${dta}/usdina${yrmin}${yrmax}clps_es`equalsplit'_`type'based_top1totals_`labshare_suff'.dta, v(12) replace
      outsheet using ${out}/usdina${yrmin}${yrmax}clps_es`equalsplit'_`type'based_top1totals_`labshare_suff'.csv, comma replace
    }
  }
  
  *COMBINE THE PE AND PT VERSIONS OF EACH EQUAL-SPLIT TYPE
  forv equalsplit=0/1 {
    use ${dta}/usdina${yrmin}${yrmax}clps_es`equalsplit'_pebased_top1totals_`labshare_suff', clear
	drop tt*
    ds year, not
	foreach var in `r(varlist)' {
	  rename `var' pe`var'
	}
	tempfile temppe
	save `temppe'
	use ${dta}/usdina${yrmin}${yrmax}clps_es`equalsplit'_ptbased_top1totals_`labshare_suff', clear
    ds year tt*, not
	foreach var in `r(varlist)' {
	  rename `var' pt`var'
	}
	merge 1:1 year using `temppe', nogen
	saveold ${dta}/usdina${yrmin}${yrmax}clps_es`equalsplit'_all_top1totals_`labshare_suff', v(12) replace
  }

end
}

qui {
capture program drop build_usdinasyzz
program define build_usdinasyzz

  syntax, labshareofpt000(int)
 

 set type double

 
  local labshare_suff `labshareofpt000'
  local laborshareinput = `labshareofpt000' / 1000

  forv t=$yrmin/$yrmax {
    if !inlist(`t',1963,1965) {
      forv equalsplit=0/1 {
        *LIST OF VARS TO KEEP FROM DINA TOP1TOTALS AND THEN DROP
        local keepvars = "ttptinc ttpeinc ttscorpinc2 ttdivinc ttdivest ttkginc ttkgest ptptinc ptfkbus ptflmilwtax ptplcon ptflempwtax ptplben ptprisupen ptinvpen ptscorpinc2 ptdivinc ptdivest ptkginc ptkgest peptinc peprisupen peinvpen"
  
        *LOAD INPUTS FROM PSZ'S AGGREG APPENDIX TABLE
        insheet using ${raw}/build_usdina_pszappx_agg_inputs.csv, comma clear
    	keep if year==`t'

		** Load the one updated to 2016 if needed
		if inrange(`t', 2015, 2016) {
			count
			cap noi assert `r(N)' == 0
	
			insheet using ${raw}/build_usdina_pszappx_agg_inputs_update1516.csv, comma clear
			keep if year ==`t'
		}
  
        *MERGE ON EQUAL-SPLIT VARS
        merge 1:1 year using ${dta}/usdina${yrmin_absol}${yrmax_absol}clps_es1_all_top1totals_`labshare_suff', keepusing(`keepvars') keep(3) nogen
        
    	  *ADD PREFIX FOR EASY DROPPING LATER
        ds year, not
    	  foreach var in `r(varlist)' {
    	    rename `var' z_`var'
    	  }
    	
      *MERGE TO MERGED DINA FILE FROM -merge_clps_top1pt1-
      merge 1:m year using ${dump}/usdinasyzz`t'_tempmerged1_es`equalsplit'_`labshare_suff'
  	  assert _merge==3
  	  drop _merge
        
        *MAKE TB2f VARS
  	  **MAKE SURE NONE OF THE INPUTS ARE MISSING (prisupen IS SOMETIMES MISSING)
  	  foreach var in flemp flprl flmil plcon plben prisupen invpen fkbus divinc scorpinc2 kginc divest kgest {
  	    replace `var'=0 if `var'==.
  	  }
  	  **CAPITAL COMPONENT OF MIXED INCOME
  	  gen kmixinc = fkbus*(z_peptinc/z_ptptinc)

	** replace missing components with 0s
	foreach var of varlist flmil flprl flemp plcon z_ptflmil z_ptflemp z_ptflmil {
            replace `var' = 0 if `var' == .
        }

	**LABOR COMPONENT OF MIXED INCOME
	gen double lmixinc = flmil + flprl*(flmil/(flemp+flmil))
	replace lmixinc = 0 if lmixinc == .

	gen double plcon_component = plcon*(z_ptflmil/(z_ptflemp+z_ptflmil))
    replace plcon_component = 0 if plcon_component == .

    replace lmixinc = lmixinc + plcon_component
    replace lmixinc = lmixinc*(z_peptinc/z_ptptinc)


	**COMPENSATION OF EMPLOYEES
    gen double empcomp = flemp + flprl*(flemp/(flemp+flmil))
    replace empcomp = 0 if empcomp == .

    drop plcon_component
    gen double plcon_component = plcon*(z_ptflemp/(z_ptflemp+z_ptflmil))
    replace plcon_component = 0 if plcon_component == .

    replace empcomp = empcomp + plcon_component
    replace empcomp = empcomp*(z_peptinc/z_ptptinc)
	drop plcon_component

	  **CAPITAL COMPONENT OF PENSION INCOME AND LABOR COMPONENT OF PENSION INCOME
  	  gen kpeninc = plben*(z_peptinc/z_ptptinc) + prisupen*(z_peprisupen/z_ptprisupen) + invpen*(z_peinvpen/z_ptinvpen)
  	  gen lpeninc = kpeninc
  	  replace kpeninc = kpeninc*(z_socins_capshare/(z_socins_capshare+z_socins_labshare))
  	  replace lpeninc = lpeninc*(z_socins_labshare/(z_socins_capshare+z_socins_labshare))
  	  **S-CORPORATION DIVIDENDS
  	  ***MAKE ALL THREE PRIME VARS: zz_sdivsprime, zz_cdivsprime, and zz_cresprime
  	  gen zz_sdivsprime = scorpinc2*(z_nipa_sdivs/z_ttscorpinc2)
	  ****IN OLD YEARS, z_ttscorpinc2 IS ZERO, SO SET TO ZERO IN THAT CASE
	  replace zz_sdivsprime=0 if z_ttscorpinc2==0
  	  gen zz_cdivsprime_component1 = (divinc+divest+kginc+kgest)/(z_ttdivinc+z_ttdivest+z_ttkginc+z_ttkgest)
  	  gen zz_cdivsprime_component2 = z_ttdivw/(z_equ_wealth+z_pens_wealth-z_ttscorw)
  	  gen zz_cdivsprime_component3 = z_net_corp_divs - z_nipa_sdivs + z_net_forgn_divs
  	  gen zz_cdivsprime = zz_cdivsprime_component1 * zz_cdivsprime_component2 * zz_cdivsprime_component3
  	  gen zz_cresprime = zz_cdivsprime_component1 * zz_cdivsprime_component2 * z_corp_re
  	  ***SAVE TOP 1% SUMS
  	  foreach type in sdivs cdivs cres {
  	    qui sum zz_`type'prime [w=dweght/100000] if rankprogpt>=.99
  		local `type'primetop1sum = r(sum)
  	  }
  	  ***FINISH sdiv
  	  gen double zz_finalcomponent1 = 1/(`sdivsprimetop1sum'+`cdivsprimetop1sum'+`cresprimetop1sum')
	  gen zz_finalcomponent2 = ((z_ptdivinc+z_ptdivest+z_ptkginc+z_ptkgest)/(z_ttdivinc+z_ttdivest+z_ttkginc+z_ttkgest))*(z_ttdivw/(z_ttscorw+z_ttdivw))
	  ****IN OLD YEARS, z_ttscorpinc2 IS ZERO, SO ADD THAT TERM ONLY WHEN IT WON'T BE MISSING
	  qui sum z_ttscorpinc2
	  if r(mean)!=0 {
	    replace zz_finalcomponent2 = zz_finalcomponent2 +  (z_ptscorpinc2/z_ttscorpinc2)*(z_ttscorw/(z_ttscorw+z_ttdivw))
	  } 
  	  gen zz_finalcomponent3 = (z_ttdivw+z_ttscorw)/(z_ttdivw+z_ttscorw+z_pens_wealth)
  	  gen zz_finalcomponent4 = (z_div_share_pfi+z_re_share_pfi+z_cptax_share_pfi)*z_pers_fac_inc
	  
	  
	  if "`labshare_suff'" != "999" {
		  *<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		  
		  
		  gen zz_finalcomponent4_raw     = (z_div_share_pfi + z_re_share_pfi) * z_pers_fac_inc
		  gen zz_finalcomponent4_corptax = (z_cptax_share_pfi) * z_pers_fac_inc
		  
		  ** get raw component (without allocated corp tax)
		  foreach corpinc in sdiv cdiv cre {
			  gen `corpinc'_pretax = zz_`corpinc'sprime * zz_finalcomponent1 * zz_finalcomponent2 * zz_finalcomponent3 * zz_finalcomponent4_raw
		  }
		  
		  ** get tax component
		  gen zz_finalcomponent1_taxes = 1/( (1 - `laborshareinput') * `sdivsprimetop1sum' + `cdivsprimetop1sum' + `cresprimetop1sum')
		
		  gen  sdiv_taxalloc = (1 - `laborshareinput') * zz_sdivsprime * zz_finalcomponent1_taxes * zz_finalcomponent2 * zz_finalcomponent3 * zz_finalcomponent4_corptax
		  gen cdiv_taxalloc = zz_cdivsprime * zz_finalcomponent1_taxes * zz_finalcomponent2 * zz_finalcomponent3 * zz_finalcomponent4_corptax
		  gen cre_taxalloc  = zz_cresprime * zz_finalcomponent1_taxes * zz_finalcomponent2 * zz_finalcomponent3 * zz_finalcomponent4_corptax
		
		  ** get s-corp labor and capital components
		  gen sdivlab = `laborshareinput' * sdiv_pretax
		  gen sdivcap = (1 - `laborshareinput') * sdiv_pretax + sdiv_taxalloc
		  
		  ** get c-corp income incorporating scaled sdivsprime
		  gen sdiv = sdivlab + sdivcap
		  gen cdiv = cdiv_pretax + cdiv_taxalloc
		  gen cre = cre_pretax + cre_taxalloc
		  
		  drop zz_finalcomponent1_taxes
		  drop *_taxalloc
		  	  
		  *>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	  }
	  else {
		  gen sdiv = zz_sdivsprime * zz_finalcomponent1 * zz_finalcomponent2 * zz_finalcomponent3 * zz_finalcomponent4

		  **C-CORPORATION DIVIDENDS
		  gen cdiv = zz_cdivsprime * zz_finalcomponent1 * zz_finalcomponent2 * zz_finalcomponent3 * zz_finalcomponent4	  
		  **C-CORPORATION RETAINED EARNINGS
		  gen cre = zz_cresprime * zz_finalcomponent1 * zz_finalcomponent2 * zz_finalcomponent3 * zz_finalcomponent4
		  
		  ** For ease in the rest of the laborshare varied code
		  gen sdivcap = sdiv
		  gen sdivlab = 0
	  }
	  
	*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	** Add sales taxes to labor component of S-CORPS
	*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    save ${dump}/debug_salestax_`t'_es`equalsplit'_`labshare_suff', replace

	if "`labshare_suff'" != "999" {
		** Remake lmixinc and empcomp
		rename (lmixinc empcomp) (lmixinc_old empcomp_old)
		rename sdivlab sdivlab_pretax
		
		** replace missing components with 0s
		foreach var of varlist flmil flprl flemp sdivlab_pretax plcon z_ptflmil z_ptflemp z_ptflmil {
			replace `var' = 0 if `var' == .
		}
	  
		**LABOR COMPONENT OF MIXED INCOME
		gen lmixinc = flmil + flprl*(flmil/(flemp+flmil+sdivlab_pretax)) 
		replace lmixinc = 0 if lmixinc == .

		gen plcon_component = plcon*(z_ptflmil/(z_ptflemp+z_ptflmil))
		replace plcon_component = 0 if plcon_component == .

		replace lmixinc = lmixinc + plcon_component
		replace lmixinc = lmixinc*(z_peptinc/z_ptptinc)

		**COMPENSATION OF EMPLOYEES
		gen empcomp = flemp + flprl*(flemp/(flemp+flmil+sdivlab_pretax))
		replace empcomp = 0 if empcomp == .

		drop plcon_component
		gen plcon_component = plcon*(z_ptflemp/(z_ptflemp+z_ptflmil))
		replace plcon_component = 0 if plcon_component == .

		replace empcomp = empcomp + plcon_component
		replace empcomp = empcomp*(z_peptinc/z_ptptinc)
		
		**LABOR COMPONENT OF S-CORPS
		gen sdivlab = sdivlab_pretax + (z_peptinc / z_ptptinc) * flprl*(sdivlab_pretax/(flemp+flmil+sdivlab_pretax))
		replace sdivlab = 0 if sdivlab == .
		
		foreach var of varlist lmixinc empcomp sdivlab {
			*replace `var' = 0 if `var' == .
			assert `var' != .
		}

		**Recalculate total SDIV
		drop sdiv
		gen sdiv = sdivlab + sdivcap

	}
	  
	  **SET MISSINGS TO ZERO (which happens only for empcomp and lmixinc and only when flemp==flmil==0)
  	  di "assert number 1"
	  foreach var in lmixinc empcomp sdiv sdivlab {
  	    cap noi assert `var'!=. | (`var'==. & flemp==0 & flmil==0)
  	    replace `var'=0 if `var'==.
  	  }
	  di "assert number 2"
  	  foreach var of varlist kmixinc lmixinc empcomp kpeninc lpeninc sdiv* cdiv cre {
  	    cap noi assert `var'!=.
		if _rc == 9 {
			di "`var' failed assert"
		}
  	  }
	  di "all done with these asserts"

	

	** COMPARE UPDATED LMIXINC, EMPCOMP, AND SDIVLAB WITH (FIXED) OLD METHOD
	  if "`labshare_suff'" != "999" {
		foreach var in lmixinc_old empcomp_old sdivlab_pretax lmixinc empcomp sdivlab {
			replace `var' = 0 if `var' == .
		}


		** Compare totals of the old way and the new way
		gen double lab_tot_old = lmixinc_old + empcomp_old + sdivlab_pretax
		gen double lab_tot_new = lmixinc + empcomp + sdivlab
		
		sum lab_tot_old
		local tot_old = `r(sum)'
		sum lab_tot_new 
		local tot_new = `r(sum)'


		di " CHECK HOW TAX IS ALLOCATED TO SDIVS"
		cap noi assert `tot_old' == `tot_new'
		cap noi assert lab_tot_old == lab_tot_new if (flemp != 0 | flmil != 0)
		cap noi assert lab_tot_old == lab_tot_new if (flemp == 0 & flmil == 0)

	
		cap noi assert lab_tot_old == lab_tot_new if (flemp == 0 & flmil == 0 & sdivlab == 0)
		cap noi assert lab_tot_old == lab_tot_new if (flemp == 0 & flmil == 0 & sdivlab != 0)


		gen double diff = lab_tot_new - lab_tot_old

		sum diff if diff != 0, d
		sum diff if (flemp !=0 | flemp !=0) & sdivlab == 0, d
		sum diff if (flemp !=0 | flemp !=0) & sdivlab != 0, d


		count if (flemp == 0 & flmil == 0 & sdivlab == 0)
		count if (flemp == 0 & flmil == 0 & sdivlab != 0)
	
		**Drop temp intermediate variable
		drop sdivlab_pretax
		drop lmixinc_old empcomp_old
		drop lab_tot_old lab_tot_new

		drop diff
	  }

	  *log close debug_salestax

  	  **ALL INCOME (= peinc x the ratio of the peinc- and ptinc-defined top 1% peinc = 1.005*peinc IN 2010) 
      capture drop allinc
  	  qui sum peinc [w=dweght] if rankprogpt>=.99
  	  local top1peinc_pt = r(sum)
  	  qui sum peinc [w=dweght] if rankprogpe>=.99
  	  gen allinc = peinc * r(sum)/`top1peinc_pt'
  	  ***ADJUST BOTTOM-99% allinc SO THAT IT SUMS TO NATIONAL INCOME (BETTER THAN NOT ADJUSTING AT ALL)
  	  qui sum peinc [w=dweght]
  	  local totalpeinc = r(sum)
  	  qui sum allinc [w=dweght] if rankprogpt>=.99
  	  local top1allinc = r(sum)
  	  qui sum allinc [w=dweght] if rankprogpt<.99
  	  replace allinc = allinc * (`totalpeinc'-`top1allinc')/r(sum) if rankprogpt<.99
  	  **INTEREST AND RENTS
  	  gen intrents = allinc - kmixinc - lmixinc - empcomp - kpeninc - lpeninc - sdiv - cdiv - cre
  	  **SUMMARY VARS
  	  gen capinc = kmixinc + kpeninc + sdivcap + cdiv + cre + intrents
  	  gen labinc = lmixinc + empcomp + lpeninc + sdivlab
  	  **LABEL AND DROP
      label var allinc "TB2f Total income. Sums to NI and basically equals peinc."
      label var capinc "TB2f Capital income"
      label var intrents "TB2f Interest + rents"
      label var cdiv "TB2f C-corporation dividends"
      label var cre "TB2f C-corporation retained earnings"
      label var sdiv "TB2f S-corporation dividends"
	  label var sdivlab "TB2f Labor component of S-corporation dividends"
      label var sdivcap "TB2f Capital component of S-corporation dividends"
	  label var kmixinc "TB2f Capital component of mixed income"
      label var kpeninc "TB2f Capital component of pension income"
      label var labinc "TB2f Labor income"
      label var empcomp "TB2f Compensation of employees"
      label var lmixinc "TB2f Labor component of mixed income"
      label var lpeninc "TB2f Labor component of pension income"
  	  drop z_* zz*
  	  
  	  *VET TB2f VARS
  	  **PRINT DOLLAR TOTALS TO THE SCREEN
  	  tabstat kmixinc lmixin empcomp kpeninc lpeninc sdiv* cdiv cre intrents [w=dweght/100000/1000000000] if rankprogpt>=.99, stat(sum)
  	  **REPLICATE TB2f
  	  local compo "allinc capinc intrents cdiv cre sdiv sdivlab sdivcap kmixinc kpeninc labinc empcomp lmixinc lpeninc"
	  
      su peinc [w=dweght]
      local total = r(sum)
      foreach var of varlist `compo' {
        quietly sum `var' [w=dweght] if rankprogpt>=.99
        local `var'_total = r(sum)/`total'
        disp "`var'_total equals " ``var'_total'
      }
  
  	  *CREATE NEW ID VAR AND SAVE	  
  	  gen idsyzz = 10*id + second
      label var idsyzz "Unique individual identifier, equal to 10*id + second"
  	  save ${dta}/usdina`t'syzz_es`equalsplit'_`labshare_suff', replace
      }
	}
  }
end
}

qui {
capture program drop add_tin_parranks
program define add_tin_parranks

  syntax, labshareofpt000(int)

  local labshare_suff `labshareofpt000'

  *PREP IGE RANKS 
  **COMPILE AVAILABLE RANKS AT EACH AGE 12-16 
  forvalues age = 12/16 {
    insheet using ${raw}/SOI_IGEtreated_t`age'_131231print.csv, clear
    local tx `age'
    local firstyear=1987-`tx'
    drop dataset
    g dataset = `age'
    keep if !missing(dataset)
    keep if cohort>=`firstyear' & cohort<=1982
    gen kid_yod = floor(kid_dod/10000)
    keep if kid_yod==0 | kid_yod-cohort>30     
    drop if missing(kid_tin)
    bys cohort: cumul soi_matchyr_inc [w=s006_matchyr], gen(par_soi_rank), if soi_matchyr_inc>0
	keep if kid_tin!=. & par_soi_rank!=.
    tempfile igeranks`age'
    save `igeranks`age'', replace
  }	
  **COMPILE ACROSS AGES AND COLLAPSE BY KID 
  use `igeranks12', clear
  forvalues age = 13/16 {
    append using `igeranks`age''
  }
  collapse (mean) rankparige=par_soi_rank igewgt=s006_matchyr, by(kid_tin kid_gnd)
  tempfile igeranks
  save `igeranks', replace  

  *TIN INFO IN PSZ "small" FILES DOESN'T GO BACK TO 1962, AND NEVER USEFUL ANYWAY BEFORE 1990
  local yrmin1990 = max(1990,${yrmin})
  
  ** ADDED TO RUN IN PARALLEL
  if ${yrmax} >= `yrmin1990' {
	  *MERGE ON COLL AND IGE PARENT RANKS BY TIN
	  forv t=`yrmin1990'/$yrmax {
		if !inlist(`t',1963,1965) {
		  forv equalsplit=0/1 {
			*LOAD FILE MAPPING ID TO TIN
			use id tin tinsec female femalesec using ${raw}/usdina/output/small/small`t', clear
			rename tin tin0
			rename tinsec tin1
			rename female femalesmall0
			rename femalesec femalesmall1
			reshape long tin femalesmall, i(id) j(second)
			drop if tin==0 | tin==.
			*MERGE TO DINA FILE
			merge 1:1 id second using ${dta}/usdina`t'syzz_es`equalsplit'_`labshare_suff', nogen keep(2 3)
			label var tin "Masked TIN from DINA smallYYYY.dta files"
			**VALIDATE USING GENDER (100% CORRECT IN 2010)
			gen zzsamegender = female==femalesmall if tin!=.
			qui sum zzsamegender
			assert inrange(r(mean),.99,1.0001)
			drop zz* femalesmall
			*MERGE ON PARENT RANK FROM THE COLLEGE FILES
			rename tin kid_tin
			merge m:1 kid_tin using ${raw}/coll_expl_tiny_k22_parrankonly, keepusing(par_agi_pctile gnd_ind) keep(1 3) nogen
			rename kid_tin tin
			**VALIDATE USING GENDER (99.99% CORRECT IN 2010)
			gen zzfemale = gnd_ind=="F" if gnd_ind!=""
			gen zzsamegender = female==zzfemale if gnd_ind!=""
			qui sum zzsamegender
			capture assert inrange(r(mean),.99,1.0001)
			drop zz* gnd_ind
			**RENAME PARENT RANK, ADD A LITTLE NOISE IN CASE EVER RELEVANT, AND CONFORM TO (0,1]
			rename par_agi_pctile rankparcoll
			replace rankparcoll = (rankparcoll+uniform()/10000)/100
			label var rankparcoll "College paper's CDF rank of parent AGI"
			*MERGE ON PARENT RANK FROM THE IGE FILES
			rename tin kid_tin
			merge m:1 kid_tin using `igeranks', nogen keep(1 3)
			rename kid_tin tin
			**VALIDATE USING GENDER (100% in 2010)
			gen zzfemale = kid_gnd=="F" if kid_gnd!=""
			gen zzsamegender = female==zzfemale if kid_gnd!=""
			qui sum zzsamegender
			capture assert inrange(r(mean),.99,1.0001)
			drop zz* kid_gnd
			**LABEL
			label var rankparige "Intergenerational Mobility Trends paper's CDF rank of parent AGI"
			label var igewgt "Intergenerational Mobility Trends paper's SOI INSOLE weight"
			*SAVE
			save ${dta}/usdina`t'syzz_es`equalsplit'_`labshare_suff', replace
		  }
		}
	  }
  }
end
}

qui {
capture program drop add_wagess_wagesp
program define add_wagess_wagesp

  syntax, labshareofpt000(int)

  local labshare_suff `labshareofpt000'

  *FIRMOWNER FILES START IN 2000
  local yrmin2000 = max(2000,${yrmin})
 
  *FIRMOWNER FILES END IN 2014
  local yrmax2014 = min(2014,${yrmax})
 
  ** ADDED TO RUN IN PARALLEL
  if (${yrmax} >= `yrmin2000') & ($yrmin <= `yrmax2014') {
	  *MERGE ON COLL AND IGE PARENT RANKS BY TIN
	  forv t=`yrmin2000'/`yrmax2014' {
		if !inlist(`t',1963,1965) {
		  
		  *PREP wagess AND wagesp INCLUDING BY IMPUTING
		  foreach type in s p {
			*LOAD DATA
			if "`type'"=="s" {
			  use tin numw2 wages_max wages_smax wagesfromfirm onlypassive payer_tin sales_14dollars slwgljob compofcr using ${dta}/`type'_firmowner_`t', clear
			}
			else if "`type'"=="p" {
			  use tin numw2 wages_max wages_smax wagesfromfirm onlypassive payer_tin sales_14dollars slwgljob pmtsprts using ${dta}/`type'_firmowner_`t', clear
			  rename pmtsprts compofcr
			}
			*IDENTIFY NUMBER OF OWNERS
			bys payer_tin: egen numowners = count(tin)
			drop payer_tin
			*FLAG FOR A ROW THAT NEEDS TO BE IMPUTED (numw2 is never missing but is often zero)
			gen imputeme = (numw2==0 | numw2==.) & (slwgljob+compofcr>0)
			drop numw2 slwgljob compofcr
			*SET wagesfromfirm TO ZERO FOR ALL TO-BE-IMPUTED ROWS
			replace wagesfromfirm=0 if imputeme==1
			*GROUP OBSERVATIONS INTO FIVE GROUPS
			gen group=1 if onlypassive==1
			replace group=2 if group==. & numowners==1
			replace group=3 if group==. & numowners==2
			replace group=4 if group==. & inrange(numowners,3,4)
			replace group=5 if group==. & numowners>=5
			assert group!=.
			gen adhocsizebin=1 if sales_14dollars==0
			replace adhocsizebin=2 if adhocsizebin==. & inrange(sales_14dollars,0,100000)
			replace adhocsizebin=3 if adhocsizebin==. & inrange(sales_14dollars,100000,500000)
			replace adhocsizebin=4 if adhocsizebin==. & inrange(sales_14dollars,500000,1000000)
			replace adhocsizebin=5 if adhocsizebin==. & inrange(sales_14dollars,1000000,5000000)
			replace adhocsizebin=6 if adhocsizebin==. & inrange(sales_14dollars,5000000,50000000)
			replace adhocsizebin=7 if adhocsizebin==. & inrange(sales_14dollars,50000000,999999999999999999999)
			assert adhocsizebin!=.
			replace group = 10*group + adhocsizebin
			drop onlypassive numowners adhocsizebin
			*COMPUTE WAGESFROMFIRM RATIO
			replace wages_max=0 if wages_max==.
			replace wages_smax=0 if wages_smax==.
			gen wages = wages_max + wages_smax + uniform()
			gen ratio = wagesfromfirm/wages
			**UNNECESSARY PRECAUTIONS. NO ACTUAL CHANGES MADE IN THESE TWO LINES.
			replace ratio=1 if ratio>1 & ratio!=.
			replace ratio=0 if wages==0
			replace ratio=. if imputeme==1
			*IMPUTE
			set seed 1234
			sort group wages
			gen ratiotoimpute=ratio if imputeme==0
			**PUT ZERO IN THE FIRST ROW OF EACH GROUP, IF THAT ROW HAS NO ratiotoimpute
			by group: replace ratiotoimpute=0 if _n==1 & ratiotoimpute==.
			replace ratiotoimpute=ratiotoimpute[_n-1] if ratiotoimpute==.
			gen wages`type' = wagesfromfirm
			replace wages`type' = ratiotoimpute*wages if imputeme==1
			*COLLAPSE BY OWNER
			collapse (sum) wages`type' wages`type'_noi=wagesfromfirm, by(tin)
			*SAVE FOR MERGING TO usdinaYYYYsyzz FILES
			label var tin "Masked TIN from DINA smallYYYY.dta files"
			label var wages`type' "Wages from all `type'-firms, including imputed firm wages"
			label var wages`type'_noi "Wages from all `type'-firms, excluding imputed firm wages"
			tempfile wages`type'`t'
			save `wages`type'`t'', replace
		  }	  
			
		  *MERGE TO usdinaYYYYsyzz FILE, EQUAL-SPLIT IF NECESSARY, AND SAVE
		  forv equalsplit=0/1 {
			use ${dta}/usdina`t'syzz_es`equalsplit'_`labshare_suff', clear
			foreach type in s p {
			  merge m:1 tin using `wages`type'`t'', nogen keep(1 3)
			  replace wages`type'=0 if wages`type'==.
			  replace wages`type'_noi=0 if wages`type'_noi==.
			}
			*EQUAL-SPLIT IF NECESSARY
			if `equalsplit'==1 {
			  foreach type in s p {
				bys id: egen zzwages`type' = mean(wages`type')
				replace wages`type'=zzwages`type'
				bys id: egen zzwages`type'_noi = mean(wages`type'_noi)
				replace wages`type'_noi=zzwages`type'_noi
				drop zz*
			  }
			}
			*SAVE
			save ${dta}/usdina`t'syzz_es`equalsplit'_`labshare_suff', replace
		  }
		}
	  }

	}
end
}

qui {
capture program drop outsheet_thresholds
program define outsheet_thresholds

  syntax, labshareofpt000(int)

  local labshare_suff `labshareofpt000'

  *THRESHOLDS IN USDINASYZZ FILES
  foreach prefix in fn fi {
    forv t=$yrmin/$yrmax {
      if !inlist(`t',1963,1965) {
        use id `prefix'inc rankprogtu`prefix' using ${dta}/usdina`t'syzz_es0_`labshare_suff', clear
    	  collapse (sum) `prefix'inctaxu=`prefix'inc (mean) rankprogtu`prefix', by(id)
    	  qui sum `prefix'inctaxu if rankprogtu`prefix'>.99
    	  local `prefix'threshold`t' = r(min)
      }
    }
  }
  foreach prefix in pt pe {
    forv t=$yrmin/$yrmax {
      if !inlist(`t',1963,1965) {
        use `prefix'inc rankprog`prefix' using ${dta}/usdina`t'syzz_es1_`labshare_suff', clear
    	  qui sum `prefix'inc if rankprog`prefix'>.99
    	  local `prefix'threshold`t' = r(min)
      }
    }
  }
  clear
  local rows = ${yrmax} - ${yrmin} + 1
  set obs `rows'
  gen year = ${yrmin} + _n - 1
  foreach prefix in fn fi pt pe {
    gen `prefix'threshold=.
    forv t=$yrmin/$yrmax {
      if !inlist(`t',1963,1965) {
        replace `prefix'threshold=round(``prefix'threshold`t'') if year==`t'
      }
    }
  }
  outsheet using ${out}/ps_psz_thresholds_usdinasyzz_pses0_pszes1_`labshare_suff'.csv, comma replace
  
  *THRESHOLDS IN RAW FILES
  foreach prefix in fn fi {
    forv t=$yrmin/$yrmax {
      if !inlist(`t',1963,1965) {
        use `prefix'inc dweght dweghttaxu id using ${dinafiles_ext}/usdina`t' if dweght!=0 & dweght!=. & dweghttaxu!=0 & dweghttaxu!=., clear
    	  collapse (sum) `prefix'inctaxu=`prefix'inc (mean) dweghttaxu, by(id)
    	  cumul `prefix'inctaxu [w=dweghttaxu] , gen(rankprogtu`prefix')
    	  qui sum `prefix'inctaxu if rankprogtu`prefix'>.99
    	  local `prefix'threshold`t' = r(min)
      }
    }
  }
  foreach prefix in pt pe {
    forv t=$yrmin/$yrmax {
      if !inlist(`t',1963,1965) {
        use `prefix'inc dweght dweghttaxu using ${dinafiles_ext}/usdina`t' if dweght!=0 & dweght!=. & dweghttaxu!=0 & dweghttaxu!=., clear
    	  cumul `prefix'inc [w=dweght] , gen(rankprog`prefix')
    	  qui sum `prefix'inc if rankprog`prefix'>.99
    	  local `prefix'threshold`t' = r(min)
      }
    }
  }
  clear
  local rows = ${yrmax} - ${yrmin} + 1
  set obs `rows'
  gen year = ${yrmin} + _n - 1
  foreach prefix in fn fi pt pe {
    gen `prefix'threshold=.
    forv t=$yrmin/$yrmax {
      if !inlist(`t',1963,1965) {
        replace `prefix'threshold=round(``prefix'threshold`t'') if year==`t'
      }
    }
  }
  outsheet using ${out}/ps_psz_thresholds_raw_pses0_pses0_`labshare_suff'.csv, comma replace
end
}

qui {
capture program drop download_payertinw2maxsmax
program define download_payertinw2maxsmax

  set odbcmgr unixodbc
  odbc list 
  clear
  odbc load, exec("select tin, payer_tin_w2_max, payer_tin_w2_smax from databank_masked where tax_yr = 2014") dsn("prod_cdw") u($cdw_user) p($cdw_pass)  
  drop if payer_tin_w2_max==0 | payer_tin_w2_max==.
  compress
  save ${dta}/databank_payertinw2maxsmax, replace
end
}

qui {
capture program drop merge_ccorpwages
program define merge_ccorpwages

  syntax, labshareofpt000(int)

  local labshare_suff `labshareofpt000'

  *PREP CCORP WAGES FILE
  use ${raw}/ccorpwages_30, clear
  **MERGE ON PUBLIC FLAG
  destring ein, replace
  merge 1:1 ein using ${raw}/cstat_eins, keepusing(ein) keep(1 3)
  gen public = _merge==3
  drop _merge
  **AMEND THE FORM VARIABLE TO ACCOUNT FOR PUBLIC/PRIVATE
  replace form="1120_0" if form=="1120" & public==0
  replace form="1120_1" if form=="1120" & public==1
  **PROCESS AND BIN SALYWAGE
  replace salywage = salywage+compofcr
  drop compofcr
  replace salywage=0 if salywage<1 & salywage!=.
  gen salywagebin=0 if salywage==.
  replace salywagebin=1 if salywage==0
  replace salywagebin=2 if inrange(salywage,1,100000)
  replace salywagebin=3 if inrange(salywage,100000.01,1000000)
  replace salywagebin=4 if inrange(salywage,1000000.01,10000000.01)
  replace salywagebin=5 if inrange(salywage,10000000.01,99999999999)
  **MERGE ON w2_num
  gen tax_yr=2014
  merge 1:1 payer_tin tax_yr using ${raw}/rpi_worker_chars, keep(1 3) keepusing(w2_num) nogen
  drop tax_yr
  save ${dta}/prep_ccorpwages_flags_`labshare_suff', replace
  
  *MERGE CCORPWAGES
  use id second tin dweght rankprogpt ptinc using ${dta}/usdina2014syzz_es1_`labshare_suff', clear

  merge m:1 tin using ${dta}/databank_payertinw2maxsmax, keepusing(payer_tin_w2_max) keep(1 3) nogen
  **MERGE ON RAW CCORP WAGES
  rename payer_tin_w2_max payer_tin
  merge m:1 payer_tin using ${dta}/prep_ccorpwages_flags_`labshare_suff', keepusing(form formtype public salywagebin) keep(1 3) nogen
  rename payer_tin payer_tin_w2_max 
  *BIN TOP INDIVIDUALS
  gen pctilebin=0
  replace pctilebin=1 if rankprogpt>.9
  replace pctilebin=2 if rankprogpt>.99
  replace pctilebin=3 if ptinc>1000000
  replace pctilebin=4 if rankprogpt>.999
  tempfile temp
  save `temp', replace
  
  *RELEVANT COUNTS FROM THE MERGED FILE
  use `temp', clear
  gen match = form=="1120_0"
  keep if match==1
  collapse (sum) match [fw=dweght], by(pctilebin salywagebin)
  tempfile matchcounts
  save `matchcounts', replace

  *RELEVANT COUNTS FROM THE CCORPWAGES FILE
  use ${dta}/prep_ccorpwages_flags_`labshare_suff' if form=="1120_0", clear
  gen ghost = w2_num==.
  gen nonghost = w2_num!=.
  collapse (sum) ghost nonghost, by(salywagebin)
  tempfile firmcounts
  save `firmcounts', replace
  
  *DETERMINE TOTAL WEIGHT THAT NEEDS TO BE IMPUTED TO A PRIVATE C-CORP, BY PCTILEBIN
  use `matchcounts', clear
  merge m:1 salywagebin using `firmcounts'
  assert _merge==3
  drop _merge 
  sort pctilebin salywagebin
  order pctilebin
  qui sum salywagebin
  local minbin=r(min)
  local maxbin=r(max)
  gen wgttoimpute=.
  forv sb=`minbin'/`maxbin' {
    replace wgttoimpute = ghost/nonghost * match  if salywagebin==`sb'
  }
  collapse (sum) wgttoimpute, by(pctilebin)
  tempfile wgttoimpute
  save `wgttoimpute', replace
  
  *IMPUTE
  use `temp', clear
  merge m:1 pctilebin using `wgttoimpute'
  assert _merge==3
  drop _merge
  keep if form=="" & payer_tin_w2_max!=.
  keep id second dweght pctilebin wgttoimpute
  set seed 1234
  gen unif=uniform()
  sort pctilebin unif 
  by pctilebin: gen wgtrunsum = sum(dweght)
  keep if wgtrunsum<wgttoimpute
  keep id second
  merge 1:m id second using `temp'
  assert _merge!=1
  gen privcpayeract = formtype=="c" & public==0
  gen privcpayerimp = _merge==3
  keep id second privcpayer*
  label var privcpayeract "Indicator for highest-W2-payer being an actual private C-corp"
  label var privcpayerimp "Indicator for highest-W2-payer being an imputed private C-corp"
  tempfile privcpayer
  save `privcpayer', replace

  *MERGE TO THE TWO 2014 USDINASYZZ FILES
  forv equalsplit=0/1 {  
    use ${dta}/usdina2014syzz_es`equalsplit'_`labshare_suff', clear
	merge 1:1 id second using `privcpayer'
	assert _merge==3
	drop _merge
    save ${dta}/usdina2014syzz_es`equalsplit'_cwag_`labshare_suff', replace
  }
end
}


*******************************************************************************
* MAIN
*******************************************************************************
capture program drop main
program define main

    ****************************************************************************
    * Init
    ****************************************************************************
    capture log c
    *log using "${dirdo}/build_usdinasyzz_${buildusdinasyzzversion}.log", replace
    *set trace on
    *set tracedepth 1
    
    ****************************************************************************
    * Builds
    ****************************************************************************
    merge_vars_def_ranks, labshareofpt000(${labshareofpt000})
	ps_psz_clps, labshareofpt000(${labshareofpt000})
	build_usdinasyzz, labshareofpt000(${labshareofpt000})
	add_tin_parranks, labshareofpt000(${labshareofpt000})
	add_wagess_wagesp, labshareofpt000(${labshareofpt000})
	outsheet_thresholds, labshareofpt000(${labshareofpt000})
	download_payertinw2maxsmax
    merge_ccorpwages, labshareofpt000(${labshareofpt000})
    *log c
end
