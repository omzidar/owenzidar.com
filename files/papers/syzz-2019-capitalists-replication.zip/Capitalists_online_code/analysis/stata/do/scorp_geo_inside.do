*******************************************************************************
* SCORP GEO INSIDE
*******************************************************************************

*******************************************************************************
* 1. FIRMS
*******************************************************************************
local firstyr = ${yrminoverall}
local lastyr  = ${yrmaxoverall} 

forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'

use ${raw}/f1120s_`yr'.dta, clear
keep if tax_yr==`yr'
drop tax_yr
keep tin ein state zipcode
g year=`yr'
duplicates drop


tempfile dta_`yr'
save `dta_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `dta_`yr''
}

sort tin year 
save ${dump}/scorp_geo.dta, replace


*******************************************************************************
* 2. owners
*******************************************************************************
local firstyr = 2000
local lastyr  = 2014 

forv yr = `firstyr'/`lastyr'{
disp "Year"
disp `yr'

use ${raw}/f1120s_k1_`yr'.dta, clear
keep if tax_yr==`yr'
drop tax_yr
keep tin payer_tin state 
g year=`yr'
duplicates drop


tempfile dta_`yr'
save `dta_`yr''
}

clear
forv yr = `firstyr'/`lastyr'{
append using `dta_`yr''
}

sort tin year 
save ${dump}/scorp_owner_geo.dta, replace
