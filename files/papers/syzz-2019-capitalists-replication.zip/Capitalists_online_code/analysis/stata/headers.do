clear
set more off


********************************************************************************
** General
********************************************************************************

** define project folder structure
global root /bod/OTA13/h0lnb/rpi/mock_rpi/post_submission_final
global do ${root}/do
global logs ${root}/logs
global logs_usdinasyzz ${logs}/usdinasyzz
global raw ${root}/raw
global dinafiles_ext ${raw}/dinafiles
global dump ${root}/dump
global dta ${root}/dta
global out ${root}/out

** set up project folders
local dirs_to_mk logs logs_usdinasyzz dump dta out
foreach d of local dirs_to_mk {
    cap mkdir $`d'
}

** define sample years
global yrminoverall = 2000
global yrmaxoverall = 2014
global yrminoverallplusone = ${yrminoverall} + 1

** graphing shortcuts
global xg = "pstopdf $dirout"
global gpr = "plotregion(fcolor(white) lcolor(white)) graphregion(fcolor(white) lcolor(white))"

** define programs
do $do/programs_inside.do


********************************************************************************
** USDINA
********************************************************************************

** version 
global version = "190719"
global buildusdinasyzzversion = "20${version}"
global draftusdinasyzzversion = "20${version}"

** years
global yrmin_absol = 1962
global yrmax_absol = 2016

** lab share list
global labshare_list  750 596 717 816
numlist "$labshare_list"

** only build with 999
global labshare_list_build ${labshare_list} 999
