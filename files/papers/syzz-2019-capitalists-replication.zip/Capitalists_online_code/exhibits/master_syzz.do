***********************************************************
* Environment
***********************************************************
clear all
set more off

capture log close

*---- REPLICATION PATHS -----*
global localroot "`c(pwd)'" /* Change as necessary */

* Build input paths
global run_syzz  "$localroot/exhibits/1_run_syzz"

* Analysis paths
global analysis  "$localroot/exhibits/2_process_output"
global figdo  "$analysis/code/figures"
global tabdo  "$analysis/code/tables"

* Input directories
global rawdir "$analysis/input/raw" 
global dtadir "$analysis/input/dta" 

* Output directories
global graphdir "$analysis/output/figures" 
global tabdir "$analysis/output/tables" 

* Add packages
cap net install grc1leg, from( http://www.stata.com/users/vwiggins/)
cap ssc install listtex


*Formatting
global gpr = "plotregion(fcolor(white) lcolor(white) m(tiny)) graphregion(fcolor(white) lcolor(white))"


****************************************************************************
* CALL PROGRAMS USED MULTIPLE TIMES
****************************************************************************
do $analysis/code/programs.do

****************************************************************************
* FIGURES
****************************************************************************
* Code
do $figdo/figure1.do
do $figdo/figure2.do
do $figdo/figure3.do
do $figdo/figure4.do
do $figdo/figure5.do
do $figdo/figure5.do
do $figdo/figure6.do
do $figdo/figure7.do
do $figdo/figure8.do
do $figdo/figure9.do
do $figdo/figure10.do

* Call programs
figure1
figure2
figure3
figure4
figure5
figure5
figure6
figure7
figure8
figure9
figure10
	
****************************************************************************
* APPENDIX FIGURES
****************************************************************************
*Code
do $figdo/appx_figure1.do
do $figdo/appx_figure2.do
do $figdo/appx_figure3.do
do $figdo/appx_figure4.do
do $figdo/appx_figure5.do
do $figdo/appx_figure6.do
do $figdo/appx_figure7.do
do $figdo/appx_figure8.do
do $figdo/appx_figure9.do
do $figdo/appx_figure10.do
do $figdo/appx_figure11.do
do $figdo/appx_figure12.do
do $figdo/appx_figure13.do
do $figdo/appx_figure14.do
do $figdo/appx_figure15.do
do $figdo/appx_figure16.do
do $figdo/appx_figure17.do
do $figdo/appx_figure18.do
do $figdo/appx_figure19.do
do $figdo/appx_figure20.do
do $figdo/appx_figure21.do

* Call programs	
appx_figure1
appx_figure2
appx_figure3
appx_figure4
appx_figure5
appx_figure6
appx_figure7
appx_figure8
appx_figure9
appx_figure10
appx_figure11
appx_figure12
appx_figure13
appx_figure14
appx_figure15
appx_figure16
appx_figure17
appx_figure18
appx_figure19
appx_figure20
appx_figure21 

****************************************************************************
* TABLES
****************************************************************************
*Code
do $tabdo/table1.do
do $tabdo/table2_3.do
do $tabdo/table4.do

* Call programs
table1
table2_3
table4

****************************************************************************
* APPENDIX TABLES
****************************************************************************
* Code
do $tabdo/appx_table1.do
do $tabdo/appx_table2.do
do $tabdo/appx_table3.do
do $tabdo/appx_table4.do
do $tabdo/appx_table5.do
do $tabdo/appx_table6.do
do $tabdo/appx_table7.do
do $tabdo/appx_table8.do
do $tabdo/appx_table9.do
do $tabdo/appx_table10.do
do $tabdo/appx_table11.do


* Call programs
appx_table1
appx_table2
appx_table3
appx_table4 
appx_table5
appx_table6
appx_table7
appx_table8
appx_table9
appx_table10
appx_table11 
