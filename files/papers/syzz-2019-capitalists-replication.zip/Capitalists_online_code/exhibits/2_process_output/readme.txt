The files in this folder create the figures and tables in our paper. The folder is organized as follows:

1. code/ contains the .do files that produce our main figures and tables.

2. input/ contains pre-processed .dta and .csv files, which are used in our analysis.
The code used to produce these input files is in exhibits/1_run_syzz/ 

3. output/ contains all figures and tables in our paper.