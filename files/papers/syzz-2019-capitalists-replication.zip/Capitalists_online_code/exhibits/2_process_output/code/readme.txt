The files in this folder create the figures and tables in our paper. The folder is organized as follows:

1. ../master_syzz.do sets paths to the input, output and .do files, and calls the .do files used to create all figures and tables in our paper.

2. figures/ contains .do files that create each of the figures in our paper. For example, figure1.do recreates Figure 1 in the paper. All figures are saved under their figure number in ../figures/ (e.g., Figure 1 is saved as figure1.pdf).

3. tables/ contains .do files that create each of the tables in our paper. For example, table1.do recreates Table 1 in the paper. All tables are saved under their table number in ../tables/ (e.g., Table 1 is saved as table1.tex).