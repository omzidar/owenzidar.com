
*******************************************************************************
* Data setup/*%<*/
*******************************************************************************
capture program drop load_ps/*%<*/
program define load_ps

    * Code from do/PSgraphs_tc.do

    * Going to work directly from the Piketty-Saez Excel spreadsheet downloadable
    * on the website. Don't spam this line!
    *copy http://eml.berkeley.edu/~saez/TabFig2015prel.xls TabFig2015prel.xls
    * Extract relevant data from two tables
    tempfile A1 A3
    foreach tab in A1 A3 {
    import excel using $outputdir/xpez_20160427/TabFig2015prel.xls, ///
        sheet("Table `tab'") cellrange(A4:M108) first clear
        drop in 1
        destring *, ignore(" ") replace
        keep A P99100 P999100 P9999100
        rename A year
        save ``tab''
    }
    * Merge. Table A1 has no capital gains, A3 has them
    use `A1', clear
    rename (P*) (nocap99 nocap99p9 nocap99p99)
    merge 1:1 year using `A3'
    rename (P*) (cap99 cap99p9 cap99p99)

    * Extra vars
    gen nocap99to99p9 = nocap99 - nocap99p9
    gen nocap99p9to99p99 = nocap99p9 - nocap99p99
    
end/*%>*/

capture program drop load_ps_soi/*%<*/
program define load_ps_soi

    *SET UP VARS FOR GRAPHS
    use $dboxstatadir/raw/income_shares_101716G.dta if year!=., clear
    sort year
    
    foreach type in all t1 tpt1 {
        g `type'inc = `type'_totalincome - `type'_capgains + `type'_caplosses ///
                      - `type'_othercapgains - `type'_othergains
    }
    
    * Labor
    gen tpt1sal = 100*tpt1_wages/allinc
    gen t1sal = 100*t1_wages/allinc
    gen t1pt1sal = t1sal - tpt1sal

    * Business 
    gen tpt1part = 100*(tpt1_partpassivegain-tpt1_partpassiveloss+tpt1_partactivegain ///
        -tpt1_partactiveloss-tpt1_part179)/allinc
    gen tpt1scorp = 100*(tpt1_scorppassivegain-tpt1_scorppassiveloss+tpt1_scorpactivegain ///
        -tpt1_scorpactiveloss-tpt1_scorp179)/allinc
    gen tpt1div = 100*tpt1_dividends/allinc
    gen t1part = 100*(t1_partpassivegain-t1_partpassiveloss+t1_partactivegain ///
        -t1_partactiveloss-t1_part179)/allinc
    gen t1scorp = 100*(t1_scorppassivegain-t1_scorppassiveloss+t1_scorpactivegain ///
        -t1_scorpactiveloss-t1_scorp179)/allinc
    gen t1div = 100*t1_dividends/allinc

    gen tpt1bizall = tpt1scorp + tpt1part + tpt1div
    gen t1bizall = t1scorp + t1part + t1div
    gen t1pt1bizall = t1bizall - tpt1bizall

    gen t1pt1scorp = t1scorp - tpt1scorp
    gen t1pt1part = t1part - tpt1part
    gen t1pt1div = t1div - tpt1div

    * Other capital
    gen tpt1othcap = 100*(tpt1_RR_pos-tpt1_RR_neg ///
        +tpt1_schCincome-tpt1_schCloss+tpt1_farmincome-tpt1_farmloss+tpt1_taxableinterest ///
        +tpt1_ETpassivegain+tpt1_ETactivegain-tpt1_ETpassiveloss-tpt1_ETactiveloss)/allinc
    gen t1othcap = 100*(t1_RR_pos-t1_RR_neg ///
        +t1_schCincome-t1_schCloss+t1_farmincome-t1_farmloss+t1_taxableinterest ///
        +t1_ETpassivegain+t1_ETactivegain-t1_ETpassiveloss-t1_ETactiveloss)/allinc
    gen t1pt1othcap = t1othcap - tpt1othcap

    gen tpt1nonsal = 100*(tpt1inc-tpt1_wages)/allinc

    * capital gains comparison
    gen allcapgains = all_capgains - all_caplosses + all_othercapgains + all_othergains
    gen t1capgains = t1_capgains - t1_caplosses + t1_othercapgains + t1_othergains
    gen tpt1capgains = tpt1_capgains - tpt1_caplosses + tpt1_othercapgains + tpt1_othergains

    gen t1cg = 100*t1capgains/allinc
    gen tpt1cg = 100*tpt1capgains/allinc

    gen t1interest = 100*(t1_taxableinterest + t1_nontaxableinterest)/allinc
    gen allinterest = 100*(all_taxableinterest + all_nontaxableinterest)/allinc

    gen t1rentsroys = 100*(t1_RR_pos-t1_RR_neg)/allinc
    gen t1schC = 100*(t1_schCincome-t1_schCloss+t1_farmincome-t1_farmloss)/allinc

    gen top1_div_share = t1_dividends/all_dividends
    gen top1_divPcg_share = (t1_dividends + t1capgains)/(all_dividends + allcapgains)
    gen tpt1_div_share = tpt1_dividends/all_dividends
    gen tpt1_divPcg_share = (tpt1_dividends + tpt1capgains)/(all_dividends + allcapgains)

    * retained earnings
    tempfile orig fr
    save `orig'

    *Draw raw data
    import excel "$frraw/psz_replication_fr.xlsx", firstrow sheet("Data") clear

    rename Variable year
    drop if year==""

    *Drop duplicate variables
    drop AP divwlth

    *Drop variables with missing values
    foreach var of varlist _all {
        capture assert mi(`var')
        if !_rc {
            drop `var'
        }
    }

    *Label variables
    ds year, not
    foreach v in `r(varlist)' {
        local newlabel = `v'[1] + " (" + `v'[2] + "): " + `v'[4]
        label var `v' "`newlabel'"
    }
    label var year  "Year"

    *Drop string variables
    drop if string(real(year))!=year

    *Destring all variables
    destring _all, replace

    * Variable adjustments
    gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth

    *Pension, Life Insurance, and IRA Equities & Mutual Funds
    gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ + lifeinsmutfund*equmutfund/liabmutfund + iraequ

    * Change format to numeric variables
    format %5.4f t1_cdiv_natinc-t1_cwlth_hhwlth div_persfactinc-tax_persfactinc cdiv_dom_natinc cdiv_for_natinc
    format %10.1fc natinc hhwlth persfactinc t1_div_dy-psinc_dy divwlth pens_lifeins_ira

    keep year hhequwlth cequwlth swlth cret divwlth pens_lifeins_ira
    save `fr'

    use `orig', clear
    merge 1:1 year using `fr', keep(1 3) nogen

    gen t1_re_div = top1_div_share * divwlth / (divwlth + pens_lifeins_ira) * 1e3 * cret
    gen t1_re_divPcg = top1_divPcg_share * divwlth / (divwlth + pens_lifeins_ira) * 1e3 * cret

    gen t1re_div = 100*t1_re_div/allinc
    gen t1re_divPcg = 100*t1_re_divPcg/allinc

end/*%>*/

capture program drop load_ps_dy/*%<*/
program define load_ps_dy

    *************************************
    * Tempfile 1: For comparison to old PS series from Matt
    *************************************
    tempfile ps_soi

    #delimit ;
    local psvars 
            t1sal 
            t1bizall
            t1othcap
            t1scorp t1part t1div
            t1interest t1rentsroys t1schC
            allinc;
    #delimit cr

    load_ps_soi
    gen top1_ps_soi = t1sal + t1bizall + t1othcap
    keep top1_ps_soi `psvars' year
    save `ps_soi'

    *************************************
    * Tempfile 2: For CRE allocation
    *************************************
    tempfile psz_replication_cre

    * Draw raw data
    insheet using "$dumpdir/psz_replication_cre_apportion.csv", clear

    drop if year == .

    * Variable adjustments
    gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth

    * Pension, Life Insurance, and IRA Equities & Mutual Funds
    gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ + lifeinsmutfund*equmutfund/liabmutfund + iraequ
    save `psz_replication_cre'

    *************************************
    * Tempfile 3: Main build
    *************************************
 
    insheet using "$dboxdir/out/rpiout181018_usdinaclps/usdina19622014clps.csv", clear
    keep if ranktype == "tufn" & defn == "ps"

    tempfile orig dyall dytop1
    save `orig'

    keep if threshold == 0
    collapse (sum) allnokg_dy=fninc allinc_dy=fiinc allkg_dy=fikgi all_fidiv=fidiv, by(year)
    save `dyall'

    use `orig', clear
    *keep if group != "bot99fn"
    keep if threshold == 99 

    collapse (sum) fiinc fninc fikgi fiwag peninc-othinc fidiv, by(year)
    merge 1:1 year using `dyall', keep(3) nogen
    * Merge Pension, Life Insurance, and IRA Equities & Mutual Funds
    * 1960, 1961, 1963, 1965 are missing
    merge 1:1 year using `psz_replication_cre', nogen keep(1 3)

    * Calculate household wealth apportionment of CRE
    gen cre_app = divwlth / (divwlth + pens_lifeins_ira) * 1e9 * cret 

    * Calculate top 1 share of total dividends
    gen top1_div_share = fidiv/all_fidiv

    * Apportion retained earnings based on 1% share of dividends
    gen t1_re_div = top1_div_share * cre_app

    * Generate main variables for plotting 
    gen t1sal_dy = 100*fiwag/allnokg_dy // - 1.2
    gen t1bizall_dy = 100*(scorinc + partinc + fidiv + schcinc)/allnokg_dy
    gen t1othcap2_dy = 100*(fninc - fiwag - scorinc - partinc - fidiv - schcinc)/allnokg_dy

    gen t1passthru_dy = 100*(scorinc + partinc + schcinc)/allnokg_dy
    gen t1cdiv_dy = 100*(fidiv)/allnokg_dy
    gen t1cdiv_re_dy = 100*(fidiv + t1_re_div)/allnokg_dy

    merge 1:1 year using `ps_soi', keep(1 3) nogen

end/*%>*/

capture program drop load_psz_fr/*%<*/
program define load_psz_fr
    * Code drawn from xpfr-20180608.do.

    *Draw raw data
    import excel "$frraw/psz_replication_fr.xlsx", firstrow sheet("Data") clear

    rename Variable year
    drop if year==""

    *Drop duplicate variables
    drop AP divwlth

    *Drop variables with missing values
    foreach var of varlist _all {
        capture assert mi(`var')
        if !_rc {
            drop `var'
        }
    }

    *Label variables
    ds year, not
    foreach v in `r(varlist)' {
        local newlabel = `v'[1] + " (" + `v'[2] + "): " + `v'[4]
        label var `v' "`newlabel'"
    }
    label var year  "Year"

    *Drop string variables
    drop if string(real(year))!=year

    *Destring all variables
    destring _all, replace

    * Variable adjustments
    gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth

    *Pension, Life Insurance, and IRA Equities & Mutual Funds
    gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ + lifeinsmutfund*equmutfund/liabmutfund + iraequ

    * Change format to numeric variables
    format %5.4f t1_cdiv_natinc-t1_cwlth_hhwlth div_persfactinc-tax_persfactinc cdiv_dom_natinc cdiv_for_natinc
    format %10.1fc natinc hhwlth persfactinc t1_div_dy-psinc_dy divwlth pens_lifeins_ira

    tempfile psz_replication_fr_data
    save `psz_replication_fr_data'

end/*%>*/


capture program drop make_psz_components/*%<*/
program define make_psz_components

    tempfile orig dyaddon
    save `orig'

    insheet using "$dboxdir/out/rpiout181018_usdinaclps/usdina19622014clps.csv", clear
    keep if ranktype == "pt" & defn == "psz" & equalsplit == 1

    tempfile pszdy
    save `pszdy'

    keep if threshold == 0
    bys year: egen ttscorinc = total(scorinc)
    bys year: egen ttpartinc = total(partinc)
    bys year: egen ttscorpinc2 = total(scorpinc2)
    bys year: egen ttdivinc = total(divinc)
    bys year: egen ttdivest = total(divest)
    bys year: egen ttkginc = total(kginc)
    bys year: egen ttkgest = total(kgest)
    gen ttdivallinc = ttdivinc + ttdivest
    gen ttkgallinc = ttkginc + ttkgest
    drop ttdivinc-ttkgest
    bys year: egen ttptinc = total(ptinc)
    bys year: egen ttpeinc = total(peinc)
    keep year ttscorinc-ttpeinc
    merge 1:m year using `pszdy', keep(3) nogen

    *keep if group != "bot99pt"
    keep if threshold == 99
    gen divallinc = divinc + cond(divest != ., divest, 0)
    gen kgallinc = kginc + cond(kgest != ., kgest, 0)
    collapse (sum) scorinc scorpinc2 partinc divallinc kgallinc, by(year ttpartinc ttscorinc ttscorpinc2 ttdivallinc ttkgallinc ttptinc ttpeinc)

    keep year scorinc ttscorinc scorpinc2 partinc divallinc kgallinc ttscorpinc2 ///
        ttpartinc ttptinc ttpeinc ttdivallinc ttkgallinc
    rename (scorinc ttscorinc scorpinc2 partinc ttscorpinc2 ttpartinc ttptinc ttpeinc divallinc kgallinc ttdivallinc ttkgallinc) ///
        (scorinc_dy ttscorinc_dy scorpinc2_dy partinc_dy ttscorpinc2_dy ///
        ttpartinc_dy ttptinc_dy ttpeinc_dy divallinc_dy kgallinc_dy ttdivallinc_dy ttkgallinc_dy)
    save `dyaddon'

    use `orig', clear
    merge 1:1 year using `dyaddon', keep(1 3) nogen

    **************************************************************************** 
    * Replication: PSZ parts, build allocation variables in dollars for equity components
    **************************************************************************** 
    foreach v in "cdiv" "cret" "sdiv" {

        if "`v'"=="cdiv" {
            local lab = "C-Corp Dividends"
        }
        else if "`v'"=="cret" {
            local lab = "C-Corp Retained Earnings"
        }
        else {
            local lab = "S-Corp Dividends"  
        }
        
        * Top 1% Variable = National Income * (Top 1% Variable / National Income)
        *gen t1_`v'_psz_baseline = natinc * t1_`v'_natinc
        gen t1_`v'_psz_baseline = natinc * t1_`v'_natinc
        *replace t1_`v'_psz_baseline = 1e-9 * ttptinc_dy * t1_`v'_natinc if year >= 2000
        replace t1_`v'_psz_baseline = 1e-9 * ttptinc_dy * t1_`v'_natinc 

        * Change format to new numeric variables
        format %10.1fc t1_`v'_psz_baseline
        
        * Label variables
        label var t1_`v'_psz_baseline "Top 1% `lab': PSZ Baseline"
    }

    * Top 1% Equity Income = Top 1% S-Corp Wealth * S-Corp Dividend Yield + 
    *                        Top 1% C-Corp Wealth * C-Corp Dividend Yield + 
    *                        Top 1% C-Corp Wealth * C-Corp Retained Earning Yield
    gen t1_equinc = hhwlth * (t1_swlth_hhwlth * sdiv_swlth + ///
                              t1_cwlth_hhwlth * (cdiv_cwlth + cret_cwlth) )
    format %10.1fc t1_equinc

    foreach v in "cdiv" "cret" "sdiv" {

        if "`v'"=="cdiv" {
            local lab = "C-Corp Dividends"
        }
        else if "`v'"=="cret" {
            local lab = "C-Corp Retained Earnings"
        }
        else {
            local lab = "S-Corp Dividends"  
        }
        
        * Top 1% Var = Top 1% Equity Income * (Top 1% Var / Top 1% Equity Income)
        gen t1_`v'_prime_psz_alloc = t1_equinc * t1_`v'_equinc
        
        * Change format to new numeric variables
        format %10.1fc t1_`v'_prime_psz_alloc
        
        * Label variables
        label var t1_`v'_prime_psz_alloc "Top 1% `lab': PSZ Allocation Component"
    }

    ****************************************************************************
    * Replication: EZ version 
    ****************************************************************************
    * Top 1% Dividends and Capital Gains as a share of total Dividends and Capital Gains
    gen t1_divkg = (t1_div_dy + t1_kgi_dy)/(div_dy + kgi_dy)
    replace t1_divkg = (divallinc_dy + kgallinc_dy)/(ttdivallinc_dy + ttkgallinc_dy)

    * Total Dividend Wealth (ttdivw) = Household Equities 
    *                                  + Money Market Fund Shares (not invested in Munis) 
    *                                  - Non-Profit Corporate Equities 
    *                                  - Non-Profit Money Market Fund Shares 
    *                                  - IRA Equities - S-Corp Wealth
    capture gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth

    * Pension, Life Insurance, and IRA Equities & Mutual Funds
    capture gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ ///
                           + lifeinsmutfund*equmutfund/liabmutfund + iraequ

    gen t1_swlth = t1_snetprof_dy / snetprof_dy * swlth
    *replace t1_swlth = scorpinc2 / ttscorpinc2 * swlth if year >= 2000
    replace t1_swlth = scorpinc2 / ttscorpinc2 * swlth 
    gen t1_divwlth = t1_divkg * divwlth

    gen t1_swlth_extrap = t1_swlth_hhwlth * hhwlth
    gen t1_divwlth_extrap = t1_cwlth_hhwlth * hhwlth

    * C-Corp Dividends (NIPA) 
    *   = Net Dividends (NIPA) - S-Corp Dividends (NIPA) + Foreign Net Dividends (NIPA)
    gen cdiv_nipa = netdiv - sdiv_nipa + netdiv_foreign

    * Top 1% C-Corp Dividends 
    *   = Top 1% Share of Dividends and Capital Gains * Share of Dividend Wealth * C-Corp Dividends (NIPA)
    gen t1_cdiv_prime_ez_allocation = t1_divkg * divwlth / (divwlth + pens_lifeins_ira) * cdiv_nipa
    replace t1_cdiv_prime_ez_allocation = t1_divwlth_extrap / (divwlth + pens_lifeins_ira) * cdiv_nipa if year > 2010

    * Top 1% C-Corp Dividends 
    *   = Top 1% Share of Dividends and Capital Gains * Share of Dividend Wealth * Retained Earnings (NIPA)
    gen t1_cret_prime_ez_allocation = t1_divkg * divwlth / (divwlth + pens_lifeins_ira) * cret
    replace t1_cret_prime_ez_allocation = t1_divwlth_extrap / (divwlth + pens_lifeins_ira) * cret if year > 2010

    * Top 1% S-Corp Dividends 
    *   = S-Corp Dividends (NIPA) * Top 1% S-Corp Net Profits (IRS) / S-Corp Net Profits (IRS)
    gen t1_sdiv_prime_ez_allocation = sdiv_nipa * t1_snetprof_dy / snetprof_dy
    *replace t1_sdiv_prime_ez_allocation = sdiv_nipa * scorpinc2 / ttscorpinc2 if year >= 2000
    replace t1_sdiv_prime_ez_allocation = sdiv_nipa * scorpinc2 / ttscorpinc2 
    replace t1_sdiv_prime_ez_allocation = sdiv_nipa * t1_swlth_extrap / swlth if year > 2010

    * Change format to new numeric variables
    format %5.4f t1_divkg
    format %10.1fc divwlth-t1_sdiv_prime_ez_allocation

    * Label variables
    label var t1_cdiv_prime_ez_allocation   "Top 1% C-Corp Dividends: EZ Replication of PSZ Allocation"
    label var t1_cret_prime_ez_allocation   "Top 1% C-Corp Retained Earnings: EZ Replication of PSZ Allocation"
    label var t1_sdiv_prime_ez_allocation   "Top 1% S-Corp Dividends: EZ Replication of PSZ Allocation"

    ****************************************************************************
    * Replication: EZ formula series.
    ****************************************************************************
    * Top 1% Equity Income from the Allocation Component
    egen t1_equinc_allocation = rowtotal(t1_*_prime_ez_allocation)

    * Dividends, Retained Earnings, and Corporate and Business Property Taxes
    gen div_cret_tax = persfactinc * (div_persfactinc + cret_persfactinc + tax_persfactinc)

    * Change format to new numeric variables
    format %10.1fc t1_equinc_allocation div_cret_tax

    foreach v in "cdiv" "cret" "sdiv" {

        if "`v'"=="cdiv" {
            local lab = "C-Corp Dividends"
        }
        else if "`v'"=="cret" {
            local lab = "C-Corp Retained Earnings"
        }
        else {
            local lab = "S-Corp Dividends"  
        }
        
        * Top 1% C-Corp Dividends, C-Corp Retained Earnings, and S-Corp Dividends
        #delimit ;
        /* gen t1_`v'_ez_formula =  t1_`v'_prime_ez_allocation / t1_equinc_allocation *
                                ((t1_snetprof_dy / snetprof_dy) * (swlth / (swlth + divwlth)) +
                                t1_divkg * (divwlth / (swlth + divwlth))) *
                                (swlth + divwlth) / (swlth + divwlth + pens_lifeins_ira) *
                                div_cret_tax; */
        gen t1_`v'_ez_formula = t1_`v'_prime_ez_allocation / t1_equinc_allocation *
                                ((scorpinc2_dy / ttscorpinc2_dy) * (swlth / (swlth + divwlth)) +
                                t1_divkg * (divwlth / (swlth + divwlth))) *
                                (swlth + divwlth) / (swlth + divwlth + pens_lifeins_ira) *
                                div_cret_tax;
        #delimit cr
                                
        format %10.1fc t1_`v'_ez_formula
        label var t1_`v'_ez_formula "Top 1% `lab': EZ Formula"
    }

end/*%>*/

capture program drop make_psz_allocation/*%<*/
program define make_psz_allocation

    tempfile orig 
    save `orig'

    *Insheet DINA data to get capital and labor mixed income
    import excel using "$dboxdatadir/piketty-saez-zucman/Dina(Distrib)_QJE.xlsx", sheet(TB2f) clear
    drop in 1/9

    * grab c and s stuff for comparison
    rename A year
    rename E fkcdiv
    rename G fksdiv
    rename H fkmik
    rename L flmil

    keep year f*

    destring _all, replace

    drop if year==.

    tempfile mixinc
    save  `mixinc'

    use `orig', clear

    * Using FR's calculations. Have made some fixes with updated DY data.
    *%<
    foreach v in "sdiv" "cdiv" "cret" {

        * 1. Allocation factors. Our replication versus their numbers.
        #delimit ;
        format %13.0g t1_*_prime_ez_allocation t1_*_prime_psz_alloc t1_*_ez_formula t1_*_psz_baseline;
    
        #delimit cr
    }
    *%>

    * 3. Zone of uncertainty.
    gen cdiv_raw = t1_div_dy
    replace cdiv_raw = 1e-9 * divallinc_dy
    gen sdiv_raw = t1_snetprof_dy
    *replace sdiv_raw = 1e-9 * scorpinc2 if year >= 2000
    replace sdiv_raw = 1e-9 * scorinc_dy
    gen pship_raw = t1_psinc_dy
    replace pship_raw = 1e-9 * partinc_dy
    gen pship_v0 = pship_raw
    gen pship_v1 = pship_raw
    gen pship_v2 = pship_raw
    gen pship_v9 = pship_raw
    gen pship_v10 = pship_raw
    gen pship_v11 = pship_raw

    * 3.0 Baseline components (essentially copying FR stuff).
    gen cwealth_v0 = (t1_div_dy + t1_kgi_dy)/(div_dy + kgi_dy) * divwlth
    replace cwealth_v0 = (divallinc_dy + kgallinc_dy)/(ttdivallinc_dy + ttkgallinc_dy) * divwlth
    gen swealth_v0 = t1_snetprof_dy / snetprof_dy * swlth
    *replace swealth_v0 = scorpinc2 / ttscorpinc2 * swlth if year >= 2000
    replace swealth_v0 = scorpinc2 / ttscorpinc2 * swlth 

    * S-div stuff. Post-2000 will replace all pre-2010 when DY finishes
    * collapse. Post-2010 is due to PSZ wealth extrapolation.
    gen     sdiv_prime_v0 = swealth_v0 / swlth * sdiv_nipa 
    replace sdiv_prime_v0 = (t1_swlth_extrap / swlth) * sdiv_nipa if year > 2010

    gen     cdiv_prime_v0 = cwealth_v0 / (divwlth + pens_lifeins_ira) * cdiv_nipa
    replace cdiv_prime_v0 = t1_divwlth_extrap / (divwlth + pens_lifeins_ira) * cdiv_nipa if year > 2010

    gen cret_prime_v0 = cwealth_v0 / (divwlth + pens_lifeins_ira) * cret
    replace cret_prime_v0 = t1_divwlth_extrap / (divwlth + pens_lifeins_ira) * cret if year > 2010

    gen household_wealth_share = (swlth + divwlth) / (swlth + divwlth + pens_lifeins_ira)
    gen equity_flow_v0 = div_cret_tax

    * 3.1. no extrapolation
    gen cwealth_v1 = (t1_div_dy + t1_kgi_dy)/(div_dy + kgi_dy) * divwlth
    replace cwealth_v1 = (divallinc_dy + kgallinc_dy)/(ttdivallinc_dy + ttkgallinc_dy) * divwlth
    *gen swealth_v1 = t1_snetprof_dy / snetprof_dy * swlth
    gen swealth_v1 = scorpinc2 / ttscorpinc2 * swlth

    gen     sdiv_prime_v1 = swealth_v1 / swlth * sdiv_nipa 
    gen     cdiv_prime_v1 = cwealth_v1 / (divwlth + pens_lifeins_ira) * cdiv_nipa
    gen     cret_prime_v1 = cwealth_v1 / (divwlth + pens_lifeins_ira) * cret

    * 3.2. divs only allocation
    gen cwealth_v2 = (t1_div_dy)/(div_dy) * divwlth
    replace cwealth_v2 = (divallinc_dy)/(ttdivallinc_dy) * divwlth

    gen     sdiv_prime_v2 = sdiv_prime_v1
    gen     cdiv_prime_v2 = cwealth_v2 / (divwlth + pens_lifeins_ira) * cdiv_nipa
    gen     cret_prime_v2 = cwealth_v2 / (divwlth + pens_lifeins_ira) * cret

    * 3.3. add pships to equity income and allocation formula
    gen     sdiv_prime_v3 = sdiv_prime_v1
    *gen     pship_prime_v3 = t1_psinc_dy
    gen     pship_prime_v3 = pship_raw
    gen     cdiv_prime_v3 = cdiv_prime_v1
    gen     cret_prime_v3 = cret_prime_v1

    * 3.4. combine 3.2 and 3.3
    gen     sdiv_prime_v4 = sdiv_prime_v1
    *gen     pship_prime_v4 = t1_psinc_dy
    gen     pship_prime_v4 = pship_raw
    gen     cdiv_prime_v4 = cdiv_prime_v2
    gen     cret_prime_v4 = cret_prime_v2

    * 3.5. Change top 1 wealth using only divs and combine with 3.4
    gen     sdiv_prime_v5 = sdiv_prime_v1
    *gen     pship_prime_v5 = t1_psinc_dy
    gen     pship_prime_v5 = pship_raw
    gen     cdiv_prime_v5 = cdiv_prime_v2
    gen     cret_prime_v5 = cret_prime_v2

    * 3.6. Pre-tax version of 3.5 for comparison to PS dollars
    gen     sdiv_prime_v6 = sdiv_prime_v1
    *gen     pship_prime_v6 = t1_psinc_dy
    gen     pship_prime_v6 = pship_raw
    gen     cdiv_prime_v6 = cdiv_prime_v2
    gen     cret_prime_v6 = cret_prime_v2

    gen equity_flow_v6 = equity_flow_v0 + pship_prime_v3 - persfactinc * tax_persfactinc 

    * 3.7. Change top 1 S wealth using heterogeneous returns and plot wealth
    local s_return_ratio = 1.5
    gen aggregate_s_return = sdiv_nipa / swlth
    *gen bottom99_s_return = aggregate_s_return - ///
    *                            (1 - 1/`s_return_ratio') * t1_snetprof_dy / swlth
    gen bottom99_s_return = aggregate_s_return - ///
                                (1 - 1/`s_return_ratio') * 1e-9 * scorinc / swlth
    gen top1_s_return = `s_return_ratio' * bottom99_s_return
    gen top1_swlth_share = (aggregate_s_return - bottom99_s_return) / (top1_s_return - bottom99_s_return)

    gen swealth_v7 = top1_swlth_share * swlth

    gen total_wealth_v1 = swealth_v1 + cwealth_v1
    gen total_wealth_v2 = swealth_v1 + cwealth_v2
    gen total_wealth_v7 = swealth_v7 + cwealth_v2

    gen cshare_v1 = cwealth_v1 / divwlth
    gen sshare_v1 = swealth_v1 / swlth
    gen cshare_v2 = cwealth_v2 / divwlth
    gen sshare_v7 = swealth_v7 / swlth
    gen totalshare_v1 = total_wealth_v1 / (swlth + divwlth)
    gen totalshare_v7 = total_wealth_v7 / (swlth + divwlth)

    * 3.7. Version with pship raw, s corp raw, c div raw, re allocated in
    *      proportion to c divs, corp tax allocated in proportion to these numbers
    gen tax_v7 = totalshare_v7 * (swlth + divwlth) / (swlth + divwlth + pens_lifeins_ira) * persfactinc * tax_persfactinc
    gen cret_prime_v7 = cret_prime_v2
    gen equitypretax_v7 = sdiv_raw + cdiv_raw + pship_raw + cret_prime_v7
    gen sdiv_v7 = sdiv_raw + (sdiv_raw / equitypretax_v7) * tax_v7
    gen cdiv_v7 = cdiv_raw + (cdiv_raw / equitypretax_v7) * tax_v7
    gen cret_v7 = cret_prime_v7 + (cret_prime_v7 / equitypretax_v7) * tax_v7
    gen pship_v7 = pship_raw + (pship_raw / equitypretax_v7) * tax_v7

    * 3.8. PS ranks with allocation => see below.

    * Numbers.
    #delimit ;
    foreach v in "cdiv" "cret" "sdiv" { ;
        gen `v'_v0 = `v'_prime_v0 / (sdiv_prime_v0 + cdiv_prime_v0 + cret_prime_v0) *
                        (swealth_v0 + cwealth_v0) / (divwlth + swlth) * 
                        household_wealth_share *
                        equity_flow_v0;
        gen `v'_v1 = `v'_prime_v1 / (sdiv_prime_v1 + cdiv_prime_v1 + cret_prime_v1) *
                        (swealth_v1 + cwealth_v1) / (divwlth + swlth) * 
                        household_wealth_share *
                        equity_flow_v0;
        gen `v'_v2 = `v'_prime_v2 / (sdiv_prime_v2 + cdiv_prime_v2 + cret_prime_v2) *
                        (swealth_v1 + cwealth_v1) / (divwlth + swlth) * 
                        household_wealth_share *
                        equity_flow_v0;
    } ;
    foreach v in "cdiv" "cret" "sdiv" "pship" { ;
        gen `v'_v3 = `v'_prime_v3 / (sdiv_prime_v3 + cdiv_prime_v3 + cret_prime_v3 + pship_prime_v3) *
                        (swealth_v1 + cwealth_v1) / (divwlth + swlth) * 
                        household_wealth_share *
                        (equity_flow_v0 + pship_prime_v3);
        gen `v'_v4 = `v'_prime_v4 / (sdiv_prime_v4 + cdiv_prime_v4 + cret_prime_v4 + pship_prime_v4) *
                        (swealth_v1 + cwealth_v1) / (divwlth + swlth) * 
                        household_wealth_share *
                        (equity_flow_v0 + pship_prime_v3);
        gen `v'_v5 = `v'_prime_v5 / (sdiv_prime_v5 + cdiv_prime_v5 + cret_prime_v5 + pship_prime_v5) *
                        (swealth_v1 + cwealth_v2) / (divwlth + swlth) * 
                        household_wealth_share *
                        (equity_flow_v0 + pship_prime_v3);
        gen `v'_v6 = `v'_prime_v6 / (sdiv_prime_v6 + cdiv_prime_v6 + cret_prime_v6 + pship_prime_v6) *
                        (swealth_v1 + cwealth_v2) / (divwlth + swlth) * 
                        household_wealth_share *
                        equity_flow_v6;
    } ;

    #delimit cr

    tempfile psz psz_cw ps_soi ps_dy
    save `psz'

    use "$calebdta/psz_combine_20180612.dta", clear

    replace tot_inc = 10*tot_inc

    #delimit ;
    gen top1_psz = onepct_lab_income 
                     + s_corp_div1_psz_rep 
                     + c_corp_re1_psz_rep 
                     + c_corp_div1_psz_rep 
                     + oth_onepct_capinc;
    gen mixed_income_combine = onepct_lab_mixed_rawpsz + onepct_cap_mixinc_rawpsz;
    gen biz_income = mixed_income_combine + s_corp_div1_psz_rep + c_corp_re1_psz_rep + c_corp_div1_psz_rep;
    gen non_labor = top1_psz - onepct_employee_inc_rawpsz;
    gen non_labor_nobiz = onepct_intrent_inc_pszraw + onepct_cap_pension_inc_rawpsz;
    gen non_biz = top1_psz - biz_income;
    #delimit cr

    keep top1_psz non_labor_nobiz non_biz biz_income year
    save `psz_cw'

    load_ps_dy
    gen sdiv_ps = scorinc * 1e-9
    gen pship_ps = partinc * 1e-9
    gen cdiv_ps = fidiv * 1e-9
    gen cret_ps = t1_re_div * 1e-9
    keep sdiv_ps-cret_ps year
    save `ps_dy'
    
    merge 1:1 year using `psz', keep(3) nogen
    merge 1:1 year using `psz_cw', keep(3) nogen

    * Getting Caleb's vars into right units.
    foreach v of varlist top1_psz non_labor_nobiz non_biz biz_income {
        *replace `v' = cond(year >= 2000,`v' * 1e-9 * ttptinc_dy, `v' * natinc)
        *replace `v' = `v' * natinc
        replace `v' = `v' * 1e-9 * ttptinc_dy
    }

    * 3.8. Version with PS ranks and pship raw, s corp raw, c div raw, re allocated in
    *      proportion to c divs, corp tax allocated in proportion to these numbers
    gen tax_v8 = totalshare_v7 * (swlth + divwlth) / (swlth + divwlth + pens_lifeins_ira) * persfactinc * tax_persfactinc
    *gen cret_prime_v8 = cret_prime_v2
    gen cret_prime_v8 = cret_ps
    gen equitypretax_v8 = sdiv_ps + cdiv_ps + pship_ps + cret_prime_v8
    gen sdiv_v8 = sdiv_ps + (sdiv_ps / equitypretax_v8) * tax_v8
    gen cdiv_v8 = cdiv_ps + (cdiv_ps / equitypretax_v8) * tax_v8
    gen cret_v8 = cret_prime_v8 + (cret_prime_v8 / equitypretax_v8) * tax_v8
    gen pship_v8 = pship_ps + (pship_ps / equitypretax_v8) * tax_v8

    * 3.9, 3.10, 3.11. Divs plus fractional cap gains allocation for alloc and wealth.
    gen cwealth_v9 = (t1_div_dy + .25*t1_kgi_dy)/(div_dy + .25*kgi_dy) * divwlth
    replace cwealth_v9 = (divallinc_dy + .25*kgallinc_dy)/(ttdivallinc_dy + .25*ttkgallinc_dy) * divwlth
    gen cwealth_v10 = (t1_div_dy + .5*t1_kgi_dy)/(div_dy + .5*kgi_dy) * divwlth
    replace cwealth_v10 = (divallinc_dy + .5*kgallinc_dy)/(ttdivallinc_dy + .5*ttkgallinc_dy) * divwlth

    gen sdiv_prime_v9 = sdiv_prime_v1
    gen sdiv_prime_v10 = sdiv_prime_v1
    gen sdiv_prime_v11 = sdiv_prime_v1
    gen cdiv_prime_v9 = cwealth_v9 / (divwlth + pens_lifeins_ira) * cdiv_nipa
    gen cdiv_prime_v10 = cwealth_v10 / (divwlth + pens_lifeins_ira) * cdiv_nipa
    gen cdiv_prime_v11 = cwealth_v2 / (divwlth + pens_lifeins_ira) * cdiv_nipa
    gen cret_prime_v9 = cwealth_v9 / (divwlth + pens_lifeins_ira) * cret
    gen cret_prime_v10 = cwealth_v10 / (divwlth + pens_lifeins_ira) * cret
    gen cret_prime_v11 = cwealth_v2 / (divwlth + pens_lifeins_ira) * cret

    #delimit ;
    foreach v in "cdiv" "cret" "sdiv" { ;
        gen `v'_v9 = `v'_prime_v9 / (sdiv_prime_v9 + cdiv_prime_v9 + cret_prime_v9) *
                        (swealth_v1 + cwealth_v9) / (divwlth + swlth) * 
                        household_wealth_share *
                        equity_flow_v0;
        gen `v'_v10 = `v'_prime_v10 / (sdiv_prime_v10 + cdiv_prime_v10 + cret_prime_v10) *
                        (swealth_v1 + cwealth_v10) / (divwlth + swlth) * 
                        household_wealth_share *
                        equity_flow_v0;
        gen `v'_v11 = `v'_prime_v11 / (sdiv_prime_v11 + cdiv_prime_v11 + cret_prime_v11) *
                        (swealth_v1 + cwealth_v2) / (divwlth + swlth) * 
                        household_wealth_share *
                        equity_flow_v0;
    } ;
    #delimit cr

    * 3.12. no extrapolation, replace pship with mixed income
    gen cwealth_v12 = cwealth_v1
    gen swealth_v12 = swealth_v1

    merge 1:1 year using `mixinc', nogen keep(3)

  
    gen pship_v12 = (fkmik + flmil)*1e-9*ttptinc_dy 

    gen sdiv_prime_v12 = sdiv_prime_v1 
    gen cdiv_prime_v12 = cdiv_prime_v1
    gen cret_prime_v12 = cret_prime_v1
    gen sdiv_v12 = sdiv_v1 
    gen cdiv_v12 = cdiv_v1
    gen cret_v12 = cret_v1

    forv i=0/12 {
        gen passthru_v`i' = sdiv_v`i' + pship_v`i'
        gen ccorp_v`i' = cdiv_v`i' + cret_v`i'
    }
    
    gen passthru_raw = sdiv_raw + pship_raw
    gen passthru_ps = sdiv_ps + pship_ps


end/*%>*//*%>*/


*******************************************************************************
** 1-line ES graph
*******************************************************************************

capture program drop ES_graph/*%<*/

program define ES_graph
    
syntax, ci(real) [ xti(string) yti(string) lab1(string) outname(string) ylab(string) ysc(string) ]

    preserve

    if "`ylab'"!= ""{
        local ylabel = "ylab(`ylab')"
    }
    if "`ysc'"!=""{
        local yscale = "yscale(`ysc')"
    }

    qui gen fig_upper=b+`ci'*se
    qui gen fig_lower=b-`ci'*se
    qui gen fig_t = t
    qui rename b* fig_b*

    #delimit ; 
    twoway (scatter fig_b fig_t if  fig_t<5 & fig_t>-5, c(l) xline(-0.0, lc(gs11) lp(shortdash)) yline(0, lc(gs11) lp(shortdash)))
        || (rcap fig_upper fig_lower fig_t  if fig_t<5 & fig_t>-5 , lpattern(solid) lcolor(dknavy) c(l) m(i) ),
        $gpr xtitle("`xti'") ytitle("`yti'") xlab(-4(1)4) `ylabel' `yscale'
        legend(label(1 "`lab1'") label(2 "95% CI") region(lcolor(white)));
    graph export "$graphdir/`outname'.pdf", replace;
    #delimit cr
    
    restore

end/*%>*/


*******************************************************************************
** 2-line ES graph
*******************************************************************************
capture program drop ES_graph2

program define ES_graph2

set more off
    
syntax, ci(real) [ xti(string) yti(string) outname(string) lab1(string) lab2(string) ylab(string)]

    preserve

    if "`ylab'"!= ""{
        local ylabel = "ylab(`ylab', grid gmin gmax)"
    }
    
    qui gen fig_upper1=b1+`ci'*se1
    qui gen fig_lower1=b1-`ci'*se1
    qui gen fig_upper2=b2+`ci'*se2
    qui gen fig_lower2=b2-`ci'*se2
    qui gen fig_t = t
    sort fig_t
    qui rename b1 fig_b1
    qui rename b2 fig_b2

    twoway (scatter fig_b1 fig_t if  fig_t<6 & fig_t>-5, c(l) lc(dknavy) mcolor(dknavy) msymbol(smtriangle) xline(-0.0, lc(gs11) lp(shortdash)) yline(0, lc(gs11) lp(shortdash))) ///
        (rcap fig_upper1 fig_lower1 fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor(dknavy) c(l) m(i) ) ///
        (scatter fig_b2 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern(solid) lc(maroon) mcolor(maroon)  msymbol(smdiamond) ) ///
        (rcap fig_upper2 fig_lower2 fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor(maroon) c(l) m(i) ), ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        xtitle("`xti'") ///
        ytitle("`yti'") ///
        xlab(-4(1)4)  ///
        ylab(-.1(.05).1, grid gmin gmax) `ylabel' ///
        legend(on order(1 3) row(1) label(1 "`lab1'") label(3 "`lab2'") region(lcolor(white)) /*label(2 "95% CI") label(4 "95% CI")*/) 


    graph export "$graphdir/`outname'.pdf", replace
    
    restore

end



capture program drop clean_switcher_ES
program define clean_switcher_ES

        *Don't want D5p:
        drop if strpos(var, "5p") 
        
        local new_obs = _N + 1
        set obs `new_obs'
        qui g t = subinstr(var, "D", "", .)
        qui replace t = subinstr(t, "p", "", .)
        qui replace t = subinstr(t, "n", "-", .)
        destring t, replace
        qui replace t = -1 in `new_obs'
        qui replace coef = 0 if t == -1
        qui replace stderr = 0 if t == -1
        sort t
        
end

capture program drop ES_graph6
program define ES_graph6

set more off
    
syntax, ci(real) [ xti(string) yti(string) outname(string) lab1(string) lab2(string) lab3(string) lab4(string) lab5(string) lab6(string) ylab(string) c1(string) c2(string) c3(string) c4(string) c5(string) c6(string) p1(string) p2(string) p3(string)] 
    preserve

    if "`ylab'"!= ""{
        local ylabel = "ylab(`ylab')"
    }
    
    forv i=1/6{
        qui gen fig_upper`i'=b`i'+`ci'*se`i'
        qui gen fig_lower`i'=b`i'-`ci'*se`i'
        qui rename b`i' fig_b`i'
    }   
    qui gen fig_t = t
    sort fig_t


    *Colors
    if "`c1'"==""{
        local c1 = "dknavy"
    }
    if "`c2'"==""{
        local c2 = "maroon"
    }
    if "`c3'"==""{
        local c3 = "navy*.7"
    }
    if "`c4'"==""{
        local c4 = "maroon*.7"
    }
    if "`c5'"==""{
        local c5 = "navy*.3"
    }
    if "`c6'"==""{
        local c6 = "maroon*.3"
    }

    if "`p1'"==""{
        local p1 = "solid"
    }
    if "`p2'"==""{
        local p2 = "dash"
    }
    if "`p3'"==""{
        local p3 = "shortdash_dot"
    }

    twoway (scatter fig_b1 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern("`p1'") lc("`c1'") mcolor("`c1'") msymbol(smtriangle) ) ///
        (rcap fig_upper1 fig_lower1 fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor("`c1'") c(l) m(i) ) ///
        (scatter fig_b2 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern("`p1'") lc("`c2'") mcolor("`c2'")  msymbol(smdiamond) ) ///
        (rcap fig_upper2 fig_lower2 fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor("`c2'") c(l) m(i) ) ///
        ///
        (scatter fig_b3 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern("`p2'") lc("`c3'") mcolor("`c3'") msymbol(smtriangle) ) ///
        (rcap fig_upper3 fig_lower3 fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor("`c3'") c(l) m(i) ) ///
        (scatter fig_b4 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern("`p2'") lc("`c4'") mcolor("`c4'")  msymbol(smdiamond) ) ///
        (rcap fig_upper4 fig_lower4 fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor("`c4'") c(l) m(i) ) ///
        ///
        (scatter fig_b5 fig_t if  fig_t<6 & fig_t>-5, c(l)  lpattern("`p3'") lc("`c5'") mcolor("`c5'") msymbol(smtriangle)) ///
        (rcap fig_upper5 fig_lower5 fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor("`c5'") c(l) m(i) ) ///
        (scatter fig_b6 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern("`p3'") lc("`c6'") mcolor("`c6'")  msymbol(smdiamond) ) ///
        (rcap fig_upper6 fig_lower6 fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor("`c6'") c(l) m(i) ), ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        xline(-0.0, lc(gs11) lp(shortdash)) yline(0, lc(gs11) lp(shortdash)) ///
        xtitle("`xti'") ///
        ytitle("`yti'") ///
        xlab(-4(1)4) `ylabel' ///
        ylab(-5(2.5)5, grid gmin gmax) ///
        legend(on order(1 3 5 7 9 11) row(3) label(1 "`lab1'") label(3 "`lab2'") label(5 "`lab3'") label(7 "`lab4'") ///
            label(9 "`lab5'") label(11 "`lab6'") region(lcolor(white)) /*label(2 "95% CI") label(4 "95% CI")*/) 


    graph export "$graphdir/`outname'.pdf", replace
    
    restore

end


capture program drop ES_graph4
program define ES_graph4

set more off
    
syntax, ci(real) [ xti(string) yti(string) outname(string) lab1(string) lab2(string) lab3(string) lab4(string) ylab(string) c1(string) c2(string) c3(string) c4(string) p1(string) p3(string)] 
    preserve

    if "`ylab'"!= ""{
        local ylabel = "ylab(`ylab')"
    }
    
    forv i=1/4{
        qui gen fig_upper`i'=b`i'+`ci'*se`i'
        qui gen fig_lower`i'=b`i'-`ci'*se`i'
        qui rename b`i' fig_b`i'
    }   
    qui gen fig_t = t
    sort fig_t


    *Colors
    if "`c1'"==""{
        local c1 = "dknavy"
    }
    if "`c2'"==""{
        local c2 = "maroon"
    }
    if "`c3'"==""{
        local c3 = "navy*.7"
    }
    if "`c4'"==""{
        local c4 = "maroon*.7"
    }

    if "`p1'"==""{
        local p1 = "solid"
    }
    if "`p3'"==""{
        local p3 = "dash"
    }

    twoway (scatter fig_b1 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern("`p1'") lc("`c1'") mcolor("`c1'") msymbol(smcircle) ) ///
        (rcap fig_upper1 fig_lower1 fig_t  if fig_t<6 & fig_t>-5 , lpattern(solid) lcolor("`c1'") c(l) m(i) ) ///
        (scatter fig_b2 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern("`p1'") lc("`c2'") mcolor("`c2'")  msymbol(smtriangle) ) ///
        (rcap fig_upper2 fig_lower2 fig_t  if fig_t<6 & fig_t>-5 , lpattern(solid) lcolor("`c2'") c(l) m(i) ) ///
        ///
		(rcap fig_upper3 fig_lower3 fig_t  if fig_t<6 & fig_t>-5 , lpattern(solid) lcolor("`c3'") c(l) m(i) ) ///
        (scatter fig_b3 fig_t if  fig_t<6 & fig_t>-5, c(l)  lpattern("`p3'") lc("`c3'") mlcolor("`c3'") mfcolor(white) msymbol(smcircle)) ///
        (rcap fig_upper4 fig_lower4 fig_t  if fig_t<6 & fig_t>-5 , lpattern(solid) lcolor("`c4'") c(l) m(i) ) ///
        (scatter fig_b4 fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern("`p3'") lc("`c4'") mlcolor("`c4'") mfcolor(white)  msymbol(smtriangle) ) ///
		, ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        xline(-0.0, lc(gs11) lp(shortdash)) yline(0, lc(gs11) lp(shortdash)) ///
        xtitle("`xti'") ///
        ytitle("`yti'") ///
        xlab(-4(1)4) `ylabel' ///
        ylab(-5(2.5)5, grid gmin gmax) ///
        legend(on order(1 3 6 8) row(2) label(1 "`lab1'") label(3 "`lab2'") label(6 "`lab3'") label(8 "`lab4'") region(lcolor(white))/*label(2 "95% CI") label(4 "95% CI")*/) 


    graph export "$graphdir/`outname'.pdf", replace
    
    restore

end
* Altered 2_5, just changing axes
capture program drop ES_graph2_5_1
program define ES_graph2_5_1

set more off
    
syntax, ci(real) [ xti(string) yti(string) outname(string) lab1(string) lab2(string) lab3(string) lab4(string) ylab(string)]

    preserve

    if "`ylab'"!= ""{
        local ylabel = "ylab(`ylab')"
    }
    
    qui gen fig_upper1_y=b1_y+`ci'*se1_y
    qui gen fig_lower1_y=b1_y-`ci'*se1_y
    qui gen fig_upper2_y=b2_y+`ci'*se2_y
    qui gen fig_lower2_y=b2_y-`ci'*se2_y
    qui rename b1_y fig_b1_y
    qui rename b2_y fig_b2_y
    qui gen fig_upper1_n=b1+`ci'*se1_n
    qui gen fig_lower1_n=b1-`ci'*se1_n
    qui gen fig_upper2_n=b2_n+`ci'*se2_n
    qui gen fig_lower2_n=b2_n-`ci'*se2_n
    qui rename b1 fig_b1
    qui rename b2_n fig_b2_n
    qui gen fig_t = t
    sort fig_t
    
    twoway (scatter fig_b1 fig_t if  fig_t<6 & fig_t>-5, c(l) lc(dknavy) mcolor(dknavy) msymbol(smtriangle) xline(-0.0, lc(gs11) lp(shortdash)) yline(0, lc(gs11) lp(shortdash))) ///
        (rcap fig_upper1_n fig_lower1_n fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor(dknavy) c(l) m(i) ) ///
        (scatter fig_b2_n fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern(solid) lc(maroon) mcolor(maroon)  msymbol(smdiamond) ) ///
        (rcap fig_upper2_n fig_lower2_n fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor(maroon) c(l) m(i) ) ///
        (scatter fig_b1_y fig_t if  fig_t<6 & fig_t>-5, c(l) lc("30 144 255") lpattern(dash) mcolor("30 144 255") msymbol(smtriangle) xline(-0.0, lc(gs11) lp(shortdash)) yline(0, lc(gs11) lp(shortdash))) ///
        (rcap fig_upper1_y fig_lower1_y fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor("30 144 255") c(l) m(i) ) ///
        (scatter fig_b2_y fig_t if  fig_t<6 & fig_t>-5, c(l) lpattern(solid) lpattern(dash) lc("255 25 25") mcolor("255 25 25")  msymbol(smdiamond) ) ///
        (rcap fig_upper2_y fig_lower2_y fig_t  if fig_t<6 & fig_t>-5 , lpattern(dash) lcolor("255 25 25") c(l) m(i) ), ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        xtitle("`xti'") ///
        ytitle("`yti'") ///
        xlab(-4(1)4) `ylabel' ///
        ylab(-5(2.5)5, grid gmin gmax) ///
        legend(on order(1 3 5 7) row(2) label(1 "`lab1'") label(3 "`lab2'") label(5 "`lab3'") label(7 "`lab4'") region(lcolor(white))/*label(2 "95% CI") label(4 "95% CI")*/) 


    graph export "$graphdir/`outname'.pdf", replace
    
    restore

end






capture program drop make_ownerdeath
program define make_ownerdeath

syntax, death_or_retirement(string)

    if "`death_or_retirement'"=="death"{
        local ownd = 1
    }
    else if "`death_or_retirement'"=="retirement"{
        local ownd = 2
    }

    if `ownd'==1{
    insheet using $rawdir_ownerdeath/ownerdeaths_table_output.csv, clear /*change according to input file name*/
    }
    else if `ownd'==2{
    insheet using $rawdir_ownerret/orderlyexits_table_output.csv, clear /*change according to input file name*/
    }

    *Intake preferred percentage impact value
    local pref_pctg_impact_top1 = .286
    local pref_pctg_impact_toppt1 = .234
    local pref_pctg_impact_mil = .25

    *Reorder rows
    sort col
    replace col = col+1 if var=="salesgt0"
    replace col = col-1 if col[_n]==col[_n-1]
    sort col


    *Make preferred percentage impact, need to update if adding more columns
    g pref_pctg_impact = 10000*coef/outmeancf/ownshare

    *Save column names
    local max = _N
    forv value=1/`max'{
        local varname`value' = var[`value']
    }


end




capture program drop ownerdeath_formatting
program define ownerdeath_formatting

syntax, death_or_retirement(string)


        if "`death_or_retirement'"=="death"{
        local deathorret1 = "Dying"
        local deathorret2 = "Owner death"
        }
        else if "`death_or_retirement'"=="retirement"{
        local deathorret1 = "Retiring"
        local deathorret2 = "Owner retirement"
        }

    *Format
        foreach var of varlist v*{

            qui{
            local varnum = subinstr("`var'", "v", "", .)
            
            *Rename variables according to column numbers
            g  tmp`varnum' = `var' 
            g col`varnum' =  tmp`varnum'

            local firstcol = tmp`varnum' in `=_N'

            
            *Format different specs differently
            format col`varnum' %12.3f
            replace col`varnum' = round(col`varnum', .001) if inlist(_varname, "r2") | `firstcol'==1
            replace col`varnum' = round(col`varnum', .01) if !inlist(_varname, "r2") & `firstcol'==0
            replace col`varnum' = round(col`varnum', .1) if !inlist(_varname, "coef", "stderr", "r2") & `firstcol'==0
            replace col`varnum' = round(col`varnum') if  tmp`varnum' > 1000
                
            tostring(col`varnum'), replace force usedisplayformat

            *Format different rows differently
            replace col`varnum' = string(real(col`varnum'), "%12.3fc") if inlist(_varname, "coef", "stderr", "outmeancf") & `firstcol'==1
            replace col`varnum' = string(real(col`varnum'), "%12.0fc") if inlist(_varname, "n", "cluster") 
            replace col`varnum' = string(real(col`varnum'), "%12.0fc") if inlist(_varname, "coef", "stderr", "outmeancf") & `firstcol'==0
            replace col`varnum' = string(real(col`varnum'), "%12.1fc") if inlist(_varname, "est_out", "est_out_out_own", "ownshare", "pref_pctg_impact") 
            
            *Drop 000s
            replace col`varnum' = ".000" if _varname=="r2" &  col`varnum' =="0"
            replace col`varnum' = " " if col`varnum'=="." 
        
            drop  tmp`varnum'
            
            *Gen additional var
            replace col`varnum' = "("+subinstr("`varnum'", ".000", "", .)+ ")" if _varname=="col"  & col`varnum'!=" "
            replace col`varnum' = "("+col`varnum'+")" if _varname=="stderr" /*standard errors*/

            replace col`varnum' = col`varnum' + "\%" if inlist(_varname, "est_out", "ownshare", "est_out_out_own", "pref_pctg_impact") & col`varnum'!=" "
            
            *Replace column names to make code more flexible
            replace col`varnum' = subinstr(col`varnum', ".", "", .) if _varname=="var"
        
            }
        }
        drop if _varname=="survival"

        g col1b = ""
        order _varname col1 col1b

        *No longer need variables in float
        drop v*
        
        
        ****************
        *Prepare for tex
        ****************
        local max = _N /*helps us know where the last row of data is */
        local max_plus1 = `max'+1
        set obs `=_N+6+5'

        *Matching regression and labels to the lines in the csv
        g labels = ""
        g order = . /*this variable helps us keep the structure of the output file as desired*/
        
        qui replace order = 0 if _varname=="col"
        qui replace labels="Impact" if _varname=="coef"
        qui replace order = 1 if _varname=="coef"
        qui replace order = 2 if _varname=="stderr"
    
        
        qui replace labels="Surviving firms only" in `max_plus1'
        qui replace order = 4 in `max_plus1'
        local ++max_plus1
        qui replace labels="Minority owner" in `max_plus1'
        qui replace order = 5 in `max_plus1'
        local ++max_plus1
        qui replace labels="Majority owner" in `max_plus1'
        qui replace order = 6 in `max_plus1'
        local ++max_plus1
        if "`death_or_retirement'"=="death"{
         qui replace labels="Death before 65" in `max_plus1'
        qui replace order = 7 in `max_plus1'
        }   
        local ++max_plus1
        if "`death_or_retirement'"=="death"{
        qui replace labels="Death after 75" in `max_plus1'
        qui replace order = 8 in `max_plus1'
        }
        local ++max_plus1
        qui replace labels="S-corporations only" in `max_plus1'
        qui replace order = 9 in `max_plus1'
        
        
        *Assigning "X"s to the subsamples
        *Might need to update this if we add columns
            // Add more "plus6" rows to add more Xs
        foreach num in 3{ 
            replace col`num' = "X" if labels=="Surviving firms only"/*Subsample: surviving firm only*/
        }
        foreach num in 4{
            *replace col`num' = "X" if labels=="`deathorret1' minority owner"/*Subsample: young minority owner death*/
            replace col`num' = "X" if labels=="Minority owner"/*Subsample: young minority owner death*/
        }
        foreach num in 5{
            *capture replace col`num' = "X" if labels=="`deathorret1' majority owner" /*Subsample: young majority owner death*/
            capture replace col`num' = "X" if labels=="Majority owner" /*Subsample: young majority owner death*/
        }
        forv num = 1/5{
            *capture replace col`num' = "X" if labels=="`deathorret2' before 65"/*Subsample: young owner death*/
            capture replace col`num' = "X" if labels=="Death before 65"/*Subsample: young owner death*/
        }
        forv num = 7/9{
            *capture replace col`num' = "X" if labels=="`deathorret2' before 65"/*Subsample: young owner death*/
            capture replace col`num' = "X" if labels=="Death before 65"/*Subsample: young owner death*/
        }
        foreach num in 6{
            *capture replace col`num' = "X" if labels=="`deathorret2' after 75" /*Subsample: old owner death*/
            capture replace col`num' = "X" if labels=="Death after 75" /*Subsample: old owner death*/
        }

        foreach num in 7{
            capture replace col`num' = "X" if labels=="S-corporations only" /*Subsample: old owner death*/
        }
        
        qui replace labels="Observations" if _varname=="n"
        qui replace order = 11 if _varname=="n"
        qui replace labels="`deathorret2's" if _varname=="cluster"
        qui replace order = 12 if _varname=="cluster"
        qui replace labels="$ R^2$" if _varname=="r2"
        qui replace order = 13 if _varname=="r2"
        
        qui replace labels="Mean of counterfactual firms" if _varname=="outmeancf"
        qui replace order = 15 if _varname=="outmeancf"

        qui replace labels="`deathorret1' owners ownership \%" if _varname=="ownshare"
        qui replace order = 16 if _varname=="ownshare"

        qui replace labels="Preferred percentage impact" if _varname=="pref_pctg_impact"
        qui replace order = 17 if _varname=="pref_pctg_impact"  

        /*Adjust if adding more rows*/
        qui replace order = 3 in 19
        qui replace order = 10 in 20
        qui replace order = 14 in 21
        qui replace order = 18 in 22


        
        drop if inlist(_varname, "adj_coef", "adj_coef_cfmean_ratio")


end





capture program drop fix_naics/*%<*/
program define fix_naics

    capture rename nc4 naics_4d

    /* 7225
        * introduced in 2012 NAICS revision.
        * was 7221 and 7222 in 2007 revision. Same in 2002
    */
    replace naics_4d = 7225 if inlist(naics_4d, 7221, 7222)

    /* 238*, 2373, 2379
        * In Naics since 2002 revision
        * Had codes from 2351-2359 in 1997 revision
        * See proposal in photo pic, attempt to aggregate
          into 3 groups
    */
    #delimit ;
    replace naics_4d = 2381 if inlist(naics_4d, 2352, 2354, 2355, 2356, 2357,
                                        2358, 2383);
    replace naics_4d = 2382 if inlist(naics_4d, 2351, 2353);
    replace naics_4d = 2389 if inlist(naics_4d, 2359);
    #delimit cr

    /* 2361 and 2362 
        * In Naics since 2002
        * Had codes from 2332-2333, 2349 in 1997 version
    */
    replace naics_4d = 2361 if naics_4d == 2332
    replace naics_4d = 2362 if naics_4d == 2333
    replace naics_4d = 2372 if naics_4d == 2331
    replace naics_4d = 2373 if naics_4d == 2341
    replace naics_4d = 2379 if inlist(naics_4d, 2349, 2371)

    /* 423*, 424*
        * In naics since 2002 
        * Had codes like 421* and 422* in 1997 version
        * 2002 revision broke out exchanges and dealers from traditional
          wholesale operations, now naics 4251 (still pretty small)
    */
    replace naics_4d = naics_4d + 20 if inrange(naics_4d, 4211, 4219)
    replace naics_4d = naics_4d + 20 if inrange(naics_4d, 4221, 4229)

    /* 5182, 5151, 5152, 517*
        * in naics since 2002
        * internet and telecom caused a bunch of new industries
    */
    replace naics_4d = 5191 if inlist(naics_4d, 5141, 5161, 5181)
    replace naics_4d = 5182 if naics_4d == 5142 
    replace naics_4d = 5151 if naics_4d == 5131
    replace naics_4d = 5175 if naics_4d == 5132 | naics_4d == 5152
    replace naics_4d = 5179 if inlist(naics_4d, 5133, 5170, 5171, 5172, 5173, 5174)

    /* 5161 internet broken out from non-internet
        * In naics since 2002
    */
    replace naics_4d = 5111 if naics_4d == 5161

    gen nc4 = naics_4d

end/*%>*/



*******************************************************************************
* Impose bounds
*******************************************************************************

capture program drop impose_bounds
program define impose_bounds

** To make upper and lower bounds optional, use fake numbers.
syntax varname, [upper(real 9999) lower(real 9999)]
    rename `varlist' `varlist'_ub
    quietly gen `varlist' = `varlist'_ub
    if `upper' != 9999 {
        quietly replace `varlist' = . if `varlist' > `upper'
    }
    if `lower' != 9999 {
        quietly replace `varlist' = . if `varlist' < `lower'
    }
end/*%>*/




*******************************************************************************
* Adjust inflation 2014
*******************************************************************************

capture program drop usd2014
program usd2014
    syntax, var(varname) yr(varname)

    replace `var'= `var'*1.503062988  if `yr'==1993 & `var'!=.
    replace `var'= `var'*1.47180133   if `yr'==1994 & `var'!=.
    replace `var'= `var'*1.441698831  if `yr'==1995 & `var'!=.
    replace `var'= `var'*1.415894851  if `yr'==1996 & `var'!=.
    replace `var'= `var'*1.391942424  if `yr'==1997 & `var'!=.
    replace `var'= `var'*1.377006398  if `yr'==1998 & `var'!=.
    replace `var'= `var'*1.357571973  if `yr'==1999 & `var'!=.
    replace `var'= `var'*1.327317133  if `yr'==2000 & `var'!=.
    replace `var'= `var'*1.297761328  if `yr'==2001 & `var'!=.
    replace `var'= `var'*1.278151458  if `yr'==2002 & `var'!=.
    replace `var'= `var'*1.253173459  if `yr'==2003 & `var'!=.
    replace `var'= `var'*1.219663817  if `yr'==2004 & `var'!=.
    replace `var'= `var'*1.181649182  if `yr'==2005 & `var'!=.
    replace `var'= `var'*1.146416065  if `yr'==2006 & `var'!=.
    replace `var'= `var'*1.116642696  if `yr'==2007 & `var'!=.
    replace `var'= `var'*1.095506864  if `yr'==2008 & `var'!=.
    replace `var'= `var'*1.08694      if `yr'==2009 & `var'!=.
    replace `var'= `var'*1.073775512  if `yr'==2010 & `var'!=.
    replace `var'= `var'*1.052064076  if `yr'==2011 & `var'!=.
    replace `var'= `var'*1.033016537  if `yr'==2012 & `var'!=.
    replace `var'= `var'*1.016449245  if `yr'==2013 & `var'!=.
    replace `var'= `var'*1            if `yr'==2014 & `var'!=.

end/*%>*/
