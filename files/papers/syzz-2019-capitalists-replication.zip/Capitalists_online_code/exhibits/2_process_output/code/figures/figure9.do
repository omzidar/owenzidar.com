
***********************************************************
* FIGURE 9
***********************************************************

capture program drop figure9
program define figure9 /*<%*/

	*-------- PANEL A and B: FI -----------*

	use "$dtadir/figure9_fi.dta", clear

	#delimit ;
	/*Graph labor, business ane other capital income share of fiscal income */  ;
	twoway
	        (scatter labinc year, c(l) m(O) lc(navy) mc(navy))
			(scatter bizinc year, c(l) m(Th) lc(maroon) mc(maroon) msize(medsmall))
			(scatter other_cap year, c(l) m(D) lc(forest_green) mc(forest_green) msize(small))
			if year>=1960 & year<=2014, 
			$gpr ytitle("Top 1% income in this form" "as share of fiscal income (%)") xtitle("") 
			legend(label(1 "Wage income") 
	               label(2 "Business income") 
	               label(3 "Other capital income")
			       row(3) region(lc(white))) 
	        ysc(titlegap(2)) yscale(r(0 10)) ylab(0(2)10)
			xlab(1960(5)2015);
	graph export "$graphdir/figure9a_fi.pdf", replace ;

	/*Graph pass-through income vs. c-corp income as share of fiscal income */ ;
	twoway
		(scatter ptinc year, c(l) lc(maroon) mc(maroon) ms(O) )
		(scatter ccorp_div year, c(l) m(T) lc(maroon*.6) mc(maroon*.6))
		if year>=1960 & year<=2014, 
		$gpr ytitle("Top 1% income in this form" "as share of fiscal income (%)") xtitle("") 
		legend(label(1 "Pass-through income") 
	           label(2 "C-corporation dividends ")
	           /*label(3 "C-corporation dividends + imputed retained earnings")*/
		       row(2) region(lc(white))) 
	    ysc(titlegap(2)) yscale(r(0 8)) ylab(0(2)8)
		xlab(1960(5)2015);
	graph export "$graphdir/figure9b_fi.pdf", replace ;
	#delimit cr

	*-------- PANEL A and B: INI -----------*

	use "$dtadir/figure9_ini.dta", clear


	*Graph pass-through income vs. c-corp income as share of fiscal income
	#delimit ;
	twoway
	        (scatter labinc year, c(l) m(O) lc(navy) mc(navy))
			(scatter bizinc_re year, c(l) m(Th) lc(maroon) mc(maroon) msize(medsmall))
			(scatter other_cap year, c(l) m(D) lc(forest_green) mc(forest_green) msize(small))
			if year>=1960 & year<=2014, 
			$gpr ytitle("Top 1% income in this form" "as share of national income (%)") xtitle("") 
			legend(label(1 "Wage income") 
	               label(2 "Business income") 
	               label(3 "Other capital income")
			       row(3) region(lc(white))) 
	        ysc(titlegap(2) range(0 10)) ylab(0(2)10)
			xlab(1960(5)2015);
	graph export "$graphdir/figure9a_ini.pdf", replace ;

	*Graph pass-through income vs. c-corp income as share of imputed national income
	
	twoway
		(scatter ptinc year, c(l) lc(maroon) mc(maroon) ms(O) )
		(scatter ccorp_div_re year, c(l) m(T) lc(maroon*.6) mc(maroon*.6))
		if year>=1960 & year<=2014, 
		$gpr ytitle("Top 1% income in this form" "as share of national income (%)") xtitle("") 
		legend(label(1 "Pass-through income") 
	           label(2 "C-corporation dividends + retained earnings")
		       row(2) region(lc(white))) 
	    ysc(titlegap(2)) yscale(r(0 8)) ylab(0(2)8)
		xlab(1960(5)2015);
	graph export "$graphdir/figure9b_ini.pdf", replace ;

	#delimit cr

	*-------- PANEL C -----------*
	use "$dtadir/figure9c.dta", clear

	sort year incdefn
	#delimit ;
	* Make graph for top 1, FI ;
	twoway (scatter waglpenshare_top1 year if incdefn=="fi", c(l) ms(sh) lcolor(black) mcolor(black) lpattern(shortdash)  )
		(scatter syzz_labshare_top1 year if incdefn=="fi", c(l)  ms(o) lcolor(black) mcolor(black) ),
		$gpr ytitle("Labor share of top 1% fiscal income (%)") xtitle("") 
		legend(label(1 "Wage income") 
			   label(2 "Wage income + .75 Pass-through [SYZZ]") 
			   order(2 1) 
			   row(2) 
			   region(lc(white))) 
		ysc(titlegap(2))  ylab(10(10)80)
		xlab(1960(5)2015)
		;
	graph export "$graphdir/figure9c_fi.pdf", replace ;

	* Make graph for top 1, INI;
	twoway (scatter psz_labshare_top1 year if incdefn=="ni", c(l) ms(X) lcolor(gs6) mcolor(gs6) lpattern(shortdash) )
		(scatter syzz_labshare_top1 year if incdefn=="ni", c(l) ms(o) lcolor(black) mcolor(black) )
		(scatter waglpenshare_top1 year if incdefn == "ni", c(l) ms(Sh) lcolor(black) mcolor(black) lpattern(shortdash) )
		,
		$gpr  
		ytitle("Labor share of top 1%" "imputed national income (%)") 
		xtitle("") 	
		legend(label(1 "Wage income + .7 (Pass-through - S-corporation) [PSZ]") 
				label(2 "Wage income + .75 Pass-through [SYZZ]") 
				label(3 "Wage income") 
				order(2 1 3) 
				row(3) 
				region(lc(white)) ) 
		ysc(titlegap(2))
		ylab(10(10)80) 
		xlab(1960(5)2015)
		;
	graph export "$graphdir/figure9c_ini.pdf", replace ;
	#delimit cr

end /*%>*/
