
***********************************************************
* FIGURE 6
***********************************************************
capture program drop figure6
program define figure6 /*<%*/

	*----PANEL A----*
		*Loop through majority, no majority, service, non service, and all, making event study graphs
		local num = 1
		foreach s in "all" "nomajority" { //"all"
			foreach type in "labor_comp" "profit" {
			* Import and merge nc2 lab comp and profit coefficients and std. errors
			import delimited "$rawdir/ES_switch_firmFX_`type'_sale_`s'_bal.csv", clear

			*Clean
	        drop if strpos(var, "5p") // Don't want D5p:
	        
	        local new_obs = _N + 1
	        set obs `new_obs'
	        qui g t = subinstr(var, "D", "", .)
	        qui replace t = subinstr(t, "p", "", .)
	        qui replace t = subinstr(t, "n", "-", .)
	        destring t, replace
	        qui replace t = -1 in `new_obs'
	        qui replace coef = 0 if t == -1
	        qui replace stderr = 0 if t == -1
	        sort t 

			rename (coef stderr) (b`num' se`num')
			foreach var of varlist b`num' se`num'{
			replace `var' = 100*`var'
			}
			tempfile `type'
			save ``type''

			local ++num
			}

		local s = subinstr("`s'", "-", "", .)

		clear 
		use `profit'
		merge 1:1 var t using `labor_comp', keep(3) nogen 

		di "`s'"
		tempfile `s'
		save ``s''
		}

		use `all', clear
		merge 1:1 t using `nomajority', nogen



		ES_graph4, ci(1.96) xti(Years Since Switch) yti("Outcome as a percentage of sales (%)") outname(figure6a) ///
			lab1("Wages, All Firms") lab2("Profits, All Firms") lab3("Wages, Non-Majority Firms") lab4("Profits, Non-Majority Firms")  ///
			c1(navy) c2(maroon) c3(navy*.7) c4(maroon*.7) p1(solid) p3(dash)
			
	*----PANEL B----*
		*Loop through majority, no majority, service, non service, and all, making event study graphs
		local num = 1
		foreach s in "all" "service" { //"all"
			foreach type in "labor_comp" "profit" {
			* Import and merge nc2 lab comp and profit coefficients and std. errors
			import delimited "$rawdir/ES_switch_firmFX_`type'_sale_`s'_bal.csv", clear

			*Clean
			 *Don't want D5p:
        drop if strpos(var, "5p") 
        
        local new_obs = _N + 1
        set obs `new_obs'
        qui g t = subinstr(var, "D", "", .)
        qui replace t = subinstr(t, "p", "", .)
        qui replace t = subinstr(t, "n", "-", .)
        destring t, replace
        qui replace t = -1 in `new_obs'
        qui replace coef = 0 if t == -1
        qui replace stderr = 0 if t == -1
        sort t 

			rename (coef stderr) (b`num' se`num')
			foreach var of varlist b`num' se`num'{
			replace `var' = 100*`var'
			}
			tempfile `type'
			save ``type''

			local ++num
			}

		local s = subinstr("`s'", "-", "", .)

		clear 
		use `profit'
		merge 1:1 var t using `labor_comp', keep(3) nogen 

		di "`s'"
		tempfile `s'
		save ``s''
		}

		use `all', clear
		merge 1:1 t using `service', nogen
		

		ES_graph4, ci(1.96) xti(Years Since Switch) yti("Outcome as a percentage of sales (%)") outname(figure6b) ///
			lab1("Wages, All Firms") lab2("Profits, All Firms") lab3("Wages, Service Firms") lab4("Profits, Service Firms")  ///
			c1(navy) c2(maroon) c3(navy*.7) c4(maroon*.7) p1(solid) p3(dash)

end /*%>*/
