
***********************************************************
* APPX FIGURE 6
***********************************************************

capture program drop appx_figure6
program define appx_figure6 /*<%*/

    * PANEL A: OWNER DEATH
    foreach incbracket in top1 toppt1 millionaire{
        use $dtadir/appx_figure6a , clear
		keep if incgroup == "`incbracket'"

        ES_graph, ci(1.96) xti(Years Since Owner Death) yti("2014 Dollars (000s)") ///
            outname("appx_figure6a_`incbracket'") lab1("Impact") ylab("-60(20)20") ysc("r(-70 20)")
    }


    * PANEL B: OWNER RET

    foreach incbracket in top1 toppt1 millionaire{
        use $dtadir/appx_figure6b , clear
		keep if incgroup == "`incbracket'"

        ES_graph, ci(1.96) xti(Years Since Owner Retirement) yti("2014 Dollars (000s)") ///
            outname("appx_figure6b_`incbracket'") lab1("Impact") ylab("-60(20)20") ysc("r(-70 20)")
    }


end /*%>*/


