
***********************************************************
* APPX FIGURE 12
***********************************************************

capture program drop appx_figure12
program define appx_figure12 /*<%*/

    ******* PANEL A, NO TRANSF *******

    *******************************************************************************
    * 4. Plot VA decomps
    *******************************************************************************
    use $dtadir/appx_figure12a, clear

    graph hbar ratio_L ratio_va_L ratio_s_owner3 , stack  over(owner_yr, sort(id) )  /// //lab( angle(90))) ///
        legend(label(2 "VA per Worker") label(1 "Workers") label(3 "Owner Share") row(1) ///
        region(lcolor(white) margin(zero))) ytitle(Share of Growth in Entrepreneurial Income) ///
        bar(1, color(navy*.4)) bar(2, color(dknavy) lcolor(dknavy)) bar(3, color(maroon)) ///
        $gpr blabel(bar, position(center) format(%12.1f) size(medsmall) color(white)) xsize(6) ylab(, nogmax)
    graph export "$graphdir/appx_figure12a.pdf", replace

    *List values for tikz
    g ratio_test = ratio_va_L + ratio_L
    list ratio_test owner_yr preyear

    

    ***** PANEL B: PLOT 2004 ******
    use $dtadir/appx_figure12b , clear


    * Graph bar comparisons of 2001 and 2014
    foreach type in top1 top01 {
        preserve
        keep if incgroup == "`type'"

        qui levelsof owner_type, local(owner)
        
        #delimit ;

        graph bar ownerpay_va ownerwage_va nonowner_wb_va, stack 
            over(stack_cat, label(labsize(large))) over(year, gap(*.4) label(labsize(vlarge)))
            $gpr
            legend(order(1 2) row(1) label(1 "Profits") label(2 "Owner Wages") 
            region(lcolor(white) margin(zero)))
            yscale(range(0 65))
            ylabel(0(15)60) title(`owner', size(vhuge) color(black))
            blabel(bar, format(%9.1f) position(center) size(vlarge) color(white))
            bar(1, color(maroon)) bar(2, color(maroon*.5)  lcolor(maroon)) bar(3, color(dknavy))
            ytitle("Share of Value Added (%)", size(huge)) plotregion(margin(zero)) ;
        graph save "$graphdir/appx_figure12b_`type'.gph", replace;

        #delimit cr
        
        restore
    }

    * COMBINE GRAPHS
        grc1leg "$graphdir/appx_figure12b_top1.gph" ///
                "$graphdir/appx_figure12b_top01.gph" ///
                , ///
                col(2) ///
                plotregion(fcolor(white) lcolor(white)) ///
                graphregion(fcolor(white) lcolor(white)) ///
                iscale(*.7)
                
        graph display, xsize(5) ysize(3.5) 
        graph export "$graphdir/appx_figure12b.pdf", replace   



end /*%>*/


