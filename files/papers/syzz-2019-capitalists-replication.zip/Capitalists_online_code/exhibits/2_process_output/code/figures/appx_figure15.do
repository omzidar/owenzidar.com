
***********************************************************
* APPX FIGURE 15
***********************************************************

capture program drop appx_figure15
program define appx_figure15 /*<%*/
    
    use $dtadir/appx_figure15, clear


    * Zone of uncertainty graph with raw data on it.   
    
     #delimit ;/*%<*/
        twoway 
            (scatter sdiv_v0 year, c(l) m(S) lc(black) mc(black))
            (scatter sdiv_v1 year, c(l) m(Dh) lc(black) mc(black))
            if year>=2000 & year<=2014, 
            $gpr ytitle("Billions of USD") xtitle("") 
            legend(label(1 "PSZ (2017)") 
                   label(2 "PSZ Updated")
                   row(1) region(lc(white))) 
            ysc(titlegap(2) range(25 325)) ylab(25(50)325) 
            xlab(2000(2)2014);
        graph export "$graphdir/appx_figure15a.pdf", replace;

        twoway 
            (scatter cdiv_v0 year, c(l) m(S) lc(black) mc(black))
            (scatter cdiv_v1 year, c(l) m(Dh) lc(black) mc(black))
            if year>=2000 & year<=2014, 
            $gpr ytitle("Billions of USD") xtitle("") 
            legend(label(1 "PSZ (2017)") 
                   label(2 "PSZ Updated")
                   row(1) region(lc(white))) 
            ysc(titlegap(2) range(25 325)) ylab(25(50)325) 
            xlab(2000(2)2014);
        graph export "$graphdir/appx_figure15b.pdf", replace;

    twoway 
            (scatter cret_v0 year, c(l) m(S) lc(black) mc(black))
            (scatter cret_v1 year, c(l) m(Dh) lc(black) mc(black))
            if year>=2000 & year<=2014, 
            $gpr ytitle("Billions of USD") xtitle("") 
            legend(label(1 "PSZ (2017)") 
                   label(2 "PSZ Updated")
                   row(1) region(lc(white))) 
            ysc(titlegap(2) range(25 325)) ylab(25(50)325) 
            xlab(2000(2)2014);
        graph export "$graphdir/appx_figure15c.pdf", replace;
    #delimit cr/*%>*/


end /*%>*/
