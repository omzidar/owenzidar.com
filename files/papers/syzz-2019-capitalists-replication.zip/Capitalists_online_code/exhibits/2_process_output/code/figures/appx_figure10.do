
***********************************************************
* APPX FIGURE 10
***********************************************************

capture program drop appx_figure10
program define appx_figure10 /*<%*/

    use $dtadir/appx_figure10 , clear
	
	
    *FISCAL INCOME
    graph bar othcap_minusC5 c5 ptcap ptlab ownerlab otherlab5 ///
        if incdefn=="fi", ///
        over(group, sort(incgroup)) stack ///
        ytitle("Income (B) ") ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        blabel(bar, position(center) format(%9.1f) color(white) size(small)) ///
        bar(1, color(gs11)) bar(2, color(dknavy) lcolor(dknavy)) ///
        bar(3, color(navy*.8) /*lcolor(navy)*/) ///
        bar(4, color(navy*.4) ) bar(5, color(maroon*.5) /*lcolor(maroon)*/) ///
        bar(6, color(maroon) lcolor(maroon)) ///
        legend(rows(3) ///
        order(6 5 4 3 2 1) /*order(4 6 3 5 2 1)*/ region(lcolor(white)) ///
        lab(1 "Other capital income") ///
        lab(2 "C-corporation dividends") ///
        lab(3 "Pass-through capital") ///
        lab(4 "Pass-through labor") ///
        lab(5 "Owner wages") ///
        lab(6 "Non-owner wages") ///
        ) 
    graph export "$graphdir/appx_figure10a.pdf", replace  
    

    *NATIONAL INCOME
    graph bar othcap_minusC5 c5 ptcap ptlab ownerlab otherlab5 ///
        if incdefn=="ni", ///
        over(group, sort(incgroup)) stack ///
        ytitle("Income (B) ") ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        blabel(bar, position(center) format(%9.1f) color(white) size(small)) ///
        bar(1, color(gs11)) bar(2, color(dknavy) lcolor(dknavy)) ///
        bar(3, color(navy*.8) /*lcolor(navy)*/) ///
        bar(4, color(navy*.4) ) bar(5, color(maroon*.5) /*lcolor(maroon)*/) ///
        bar(6, color(maroon) lcolor(maroon)) ///
        legend(rows(3) ///
        order(6 5 4 3 2 1) /*order(4 6 3 5 2 1)*/ region(lcolor(white)) ///
        lab(1 "Other capital income") ///
        lab(2 "C-corporation dividends") ///
        lab(3 "Pass-through capital") ///
        lab(4 "Pass-through labor") ///
        lab(5 "Owner wages") ///
        lab(6 "Non-owner wages") ///
        ) 
    graph export "$graphdir/appx_figure10b.pdf", replace  

  
end/*%>*/
