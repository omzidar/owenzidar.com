
***********************************************************
* APPX FIGURE 1: AGE DISTRIBUTION, AGES PRIMARY EARNER
***********************************************************

capture program drop appx_figure1
program define appx_figure1 /*<%*/

    ***** PRIMARY EARNER AGE ****
	   use $dtadir/appx_figure1a.dta , clear


        * PLOT MILLIONAIRES

        twoway (connect sL agegroup if group=="Millionaires" , lcolor(navy) mc(navy) ms(O)) ///
               (connect sPT agegroup if group=="Millionaires" , lcolor(maroon) mc(maroon) ms(Th)) ///
               (connect sK agegroup if group=="Millionaires" , lcolor(forest_green) mc(forest_green) lpattern(dash) ms(D)) ///
               (connect sC agegroup if group=="Millionaires" , lcolor(maroon) mc(maroon) lpattern(shortdash) ms(X)) ///
               , ///
            $gpr ///
            xlab(2(1)9, valuelabel) xtitle("Age Group") ///
            ytitle("Share of million-dollar earners" "with majority income of this source") ///
            legend(row(2) label(1 "Wages") ///
            label(2 "Pass-through") label(3 "Other capital") label(4 "C-corporation dividends") region(lcolor(white)))
        graph export "$graphdir/appx_figure1a.pdf", replace


    ******** IMPUTED NATIONAL INCOME ******
        use $dtadir/appx_figure1b.dta, clear

        * PLOT MILLIONAIRES
        twoway (connect sL agegroup if group=="Millionaires" , lcolor(navy) mc(navy) ms(O)) ///
               (connect sPT agegroup if group=="Millionaires" , lcolor(maroon) mc(maroon) ms(Th)) ///
               (connect sK agegroup if group=="Millionaires" , lcolor(forest_green) mc(forest_green) lpattern(dash) ms(D)) ///
               (connect sC agegroup if group=="Millionaires" , lcolor(maroon) mc(maroon) lpattern(shortdash) ms(X)) ///
               , ///
            $gpr ///
            xlab(2(1)9, valuelabel) xtitle("Age Group") ///
            ytitle("Share of million-dollar earners" "with majority income of this source") ///
            legend(row(2) label(1 "Wages") ///
            label(2 "Pass-through") label(3 "Other capital") label(4 "C-corporation dividends + RE") region(lcolor(white)))
        graph export "$graphdir/appx_figure1b.pdf", replace


end /*%>*/
