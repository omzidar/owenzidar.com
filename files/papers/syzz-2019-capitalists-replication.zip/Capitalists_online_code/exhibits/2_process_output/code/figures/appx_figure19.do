
***********************************************************
* APPX FIGURE 19
***********************************************************

capture program drop appx_figure19
program define appx_figure19 /*<%*/


    use $dtadir/appx_figure19 , clear

    foreach v in "cdiv" "cret" "sdiv" {/*%<*/

        if "`v'"=="sdiv"{
            local letter="a"
        }
        else if "`v'"=="cdiv"{
            local letter="b"
        }
        else if "`v'"=="cret"{
            local letter="c"
        }


        #delimit ;
        * Compare baseline and no extrapolation;
        twoway 
            (scatter `v'_v1 year, c(l) m(Dh) lc(black) mc(black))
            (scatter `v'_v10 year, c(l) m(O) lc(black) mc(black))
            (scatter `v'_v9 year, c(l) m(X) lc(black) mc(black))
            (scatter `v'_v11 year, c(l) m(S) lc(black) mc(black))
            (scatter `v'_v7 year, c(l) m(O) lc(black) mc(black) lw(thick))
            if year>=1990 & year<=2014, 
            $gpr ytitle("Billions of USD") xtitle("") 
            legend(label(1 "PSZ Updated")
                   label(2 "Divs only + 0.5 KGs")
                   label(3 "Divs only + 0.25 KGs")
                   label(4 "Divs only")
                   label(5 "Fiscal Income + RE + Tax")
                   row(3) region(lc(white))) 
            ysc(titlegap(2) range(25 325)) ylab(25(50)325) 
            xlab(1990(2)2014);
        graph export "$graphdir/appx_figure19`letter'.pdf", replace;
        #delimit cr

    }/*%>*/

end /*%>*/

