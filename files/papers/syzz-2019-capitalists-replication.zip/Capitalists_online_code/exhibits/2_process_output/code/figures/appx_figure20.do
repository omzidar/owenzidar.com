
***********************************************************
* APPX FIGURE 20
***********************************************************

capture program drop appx_figure20
program define appx_figure20 /*<%*/


    use $dtadir/appx_figure20 , clear

    * stack pship and s corp with shading
    #delimit ;

    local overlabs
        1 "PSZ (2018)"
        2 "PSZ Updated"
        3 "Fiscal Income + RE + Tax"
        4 "PS (2003) Ranks"

        5 "Divs Only (A+W)" 
        6 "Divs + 0.25 CapG (A+W)" 
        7 "Divs + 0.5 CapG (A+W)" 
        8 "Divs Only"

        9 "Add Pships"
        10 "Divs Only, Pships"
        11 "Divs Only (A+W), Pships"   

        12 "PSZ Updated, Mixed Income"
        ;

    graph bar sdiv_v pship_v if ver!=12, 
        over(ver, relabel(`overlabs') label(angle(30) labsize(small))) 
        stack yscale(range(0 600)) ylab(0(100)600)
        legend(row(1) /* position(12) */
            label(1 "S-corp Dividends") label(2 "Partnership Income") 
            region(lcolor(white) margin(zero))) $gpr 
        blabel(bar, format(%9.0f) position(center) size(small) color(white))
        bar(1, color(maroon)) 
        bar(2, color(maroon*.4)) 
        ytitle("Billions USD", size(medsmall)) plotregion(margin(zero)) ;
    graph export "$graphdir/appx_figure20a.pdf", replace;
	
    * stack c divs and rets with shading;
    graph bar cdiv_v cret_v if ver!=12, 
        over(ver, relabel(`overlabs') label(angle(30) labsize(small))) 
        stack yscale(range(0 600)) ylab(0(100)600)
        legend(row(1) /* position(12) */
            label(1 "C-corp Dividends") label(2 "C-corp Retained Earnings") 
            region(lcolor(white) margin(zero))) $gpr 
        blabel(bar, format(%9.0f) position(center) size(small) color(white))
        bar(1, color(navy)) 
        bar(2, color(navy*.4)) 
        ytitle("Billions USD", size(medsmall)) plotregion(margin(zero)) ;
    graph export "$graphdir/appx_figure20b.pdf", replace;
	
    #delimit cr


end /*%>*/

