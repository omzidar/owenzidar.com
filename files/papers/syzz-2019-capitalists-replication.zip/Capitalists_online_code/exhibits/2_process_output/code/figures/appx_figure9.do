
*******************************************************************************
* APPX FIGURE 9
******************************************************************************* 
capture program drop appx_figure9
program define appx_figure9
    
    use $dtadir/appx_figure9, clear
	
	
    *FISCAL INCOME, SELF MADE
    graph bar majwaglpen5 majlab25 majlab2sm5 sm2 sm2workers15 sm2ptowners1 ///
        if incdefn=="fi", over(group, sort(incgroup)) ///
        legend(row(6) region(lcolor(white)) ///
            label(1 "Wage earners (i.e. has majority income from wages)") ///
            label(2 "Human-capital rich (i.e. has majority income from labor)") ///
            label(3 "Human-capital rich, parent-linked subset") ///
            label(4 "Self-made (i.e. has bottom-99% parent), parent-linked subset") ///
            label(5 "Self-made, parent-linked workers") ///
            label(6 "Self-made, parent-linked entrepreneurs") ///
            ) ///
        ytitle("Share of People (%)") ylab(0(25)100) ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        bar(1, fcolor(gs8) lcolor(gs8)) ///
        bar(2, fcolor(maroon*.5) lcolor(maroon)) bar(3, fcolor(maroon) lcolor(maroon)) ///
        bar(4, fcolor(navy) lcolor(navy)) ///
        bar(5, color(navy*.7) lcolor(navy)) ///
        bar(6, color(navy*.4) lcolor(navy)) ///
        blabel(bar, position(inside) format(%9.1f) color(white) size(small))
    graph export "$graphdir/appx_figure9a.pdf", replace
    
    *NATIONAL INCOME, SELF MADE
    graph bar majwaglpen5 majlab25 majlab2sm5 sm2 sm2workers15 sm2ptowners1 ///
        if incdefn=="ni", over(group, sort(incgroup)) ///
        legend(row(6) region(lcolor(white)) ///
            label(1 "Wage earners (i.e. has majority income from wages)") ///
            label(2 "Human-capital rich (i.e. has majority income from labor)") ///
            label(3 "Human-capital rich, parent-linked subset") ///
            label(4 "Self-made (i.e. has bottom-99% parent), parent-linked subset") ///
            label(5 "Self-made, parent-linked workers") ///
            label(6 "Self-made, parent-linked entrepreneurs") ///
            ) ///
        ytitle("Share of People (%)") ylab(0(25)100) ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        bar(1, fcolor(gs8) lcolor(gs8)) ///
        bar(2, fcolor(maroon*.5) lcolor(maroon)) bar(3, fcolor(maroon) lcolor(maroon)) ///
        bar(4, fcolor(navy) lcolor(navy)) ///
        bar(5, color(navy*.7) lcolor(navy)) ///
        bar(6, color(navy*.4) lcolor(navy)) ///
        blabel(bar, position(inside) format(%9.1f) color(white) size(small))
    graph export "$graphdir/appx_figure9b.pdf", replace

end /*%>*/
