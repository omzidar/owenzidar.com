
***********************************************************
* FIGURE 10
***********************************************************

capture program drop figure10
program define figure10 /*<%*/

	*------- PANEL A and B -------*
	use "$dtadir/figure10ab.dta", clear

	g va_L = va/L
	g ownerpay_L = ownerpay/L

	*RESCALE
	replace va_L = va_L/1000
	replace ownerpay_L = ownerpay_L/1000

	set obs `=_N+2'
	g t1 = 40 in `=_N-1'
	g t2 = 40 in `=_N'
	replace year =2001 in `=_N-1'
	replace year =2001 in `=_N'

	*FIG A (top left)
	twoway (scatter t1 year, ms(i) ) ///
		   (scatter t2 year, ms(i) ) ///
		   (scatter va_L year if incgroup=="top1", c(l) lc(maroon) mc(maroon) ms(s) ) ///
		   (scatter va_L year if incgroup=="top01", c(l) lc(dknavy) mc(dknavy) ms(d) lpattern(dash)) ///
		   (scatter ownerpay_L year if incgroup=="top1", c(l) lc(maroon) mc(maroon) ms(sh)  ) ///
		   (scatter ownerpay_L year if incgroup=="top01", c(l) lc(dknavy) mc(dknavy) ms(dh)  lpattern(dash)), ///
		$gpr ///
		legend(row(3) label(1 Top 1%)  label(2 Top 0.1%) ///
			label(3 "Value Added / L ") label(4 "Value Added / L")  ///
			label(5 "Entrepreneurial Income / L") label(6 "Entrepreneurial Income / L") ///
			region(lcolor(white))) ///
		ytitle("Thousands of Dollars") xtitle(" ") ///
		xlab(2001(1)2014, angle(90))
	graph export $graphdir/figure10a.pdf, replace

	*FIG B (M of workers)
	g L2001_tmp = (year==2001)*L
	egen L2001 = max(L2001_tmp), by(incgroup)

	g L_adj = share_deflator_pthru_01*L

	replace L=L/1000000
	replace L_adj = L_adj/1000000


	twoway (scatter t1 year, ms(i) ) ///
		   (scatter t2 year, ms(i) ) ///
		   (scatter L year if incgroup=="top1", c(l) lc(maroon) mc(maroon) ms(s) ) ///
		   (scatter L year if incgroup=="top01", c(l) lc(dknavyn) mc(dknavy) ms(d) lpattern(dash)) ///
		   (scatter L_adj year if incgroup=="top1", c(l) lc(maroon) mc(maroon) ms(sh)  ) ///
		   (scatter L_adj year if incgroup=="top01", c(l) lc(dknavy) mc(dknavy) ms(oh)  lpattern(dash)), ///
		$gpr ///
		legend(row(3) label(1 Top 1%)  label(2 Top 0.1%) ///
			label(3 "Number of Workers") label(5 "Org.-Form-Changes Adj.")  ///
			label(4 "Number of Workers") label(6 "Org.-Form-Changes Adj.") ///
			region(lcolor(white))) ///
		ytitle("Millions of Workers") xtitle(" ")  ///
		xlab(2001(1)2014, angle(90))
	graph export $graphdir/figure10b.pdf, replace

	*------- PANEL C and D -------*
	
	use "$dtadir/figure10cd.dta", clear

	tempfile va_orig
	save `va_orig'

	***** FOR TWO DIFFERENT PRE PERIODS
	foreach yr in 2001 2004{
		use `va_orig', clear
		*******************************************************************************
		* 2. create average values for pre-period and post-period
		*******************************************************************************
		g pre  = inlist(year,`yr')
		g post = inlist(year,2014)

		keep if pre==1 | post==1

		collapse (mean) va va_adj va_L L L_adj ownerpay ownerpay_adj nonowner_wb nonowner_wb_adj ownerwage ownerwage_adj s_owner s_owner_wage, by(post incgroup)

		reshape wide va va_adj va_L L L_adj ownerpay ownerpay_adj nonowner_wb nonowner_wb_adj ownerwage ownerwage_adj s_owner s_owner_wage , i(incgroup) j(post)

		g preyear = `yr'


		*******************************************************************************
		* 3. compute growth rates
		*******************************************************************************

		foreach var in va va_adj va_L L L_adj ownerpay ownerpay_adj ownerwage s_owner s_owner_wage {
			g g_`var'=`var'1/`var'0
			g delta_log_`var' = log(`var'1)-log(`var'0)
		}

		*share due to redistribution
		g ratio_s_owner3 =  100*delta_log_s_owner/(delta_log_s_owner+ delta_log_va_L+delta_log_L_adj)

		*VA growth per worker
		g ratio_va_L =  100*delta_log_va_L/(delta_log_s_owner+ delta_log_va_L + delta_log_L_adj)

		*workers
		g ratio_L =  100*delta_log_L_adj/(delta_log_s_owner+ delta_log_va_L + delta_log_L_adj)


		tempfile year`yr'
		save `year`yr''
	}


	clear
	use `year2001'
	append using `year2004'


	*******************************************************************************
	* 4. Plot VA decomps
	*******************************************************************************
	g order = 1 if incgroup=="top1"
	replace order = 3 if incgroup=="top01"

	egen id = group(preyear order)

	*LABELS FOR GRAPH
	g owner_yr = "Top 1% (2001-2014)" if id==1 
	replace owner_yr = "Top 0.1% (2001-2014)" if id==2
	replace owner_yr = "Top 1% (2004-2014)" if id==3
	replace owner_yr = "Top 0.1% (2004-2014)" if id==4


	graph hbar ratio_L ratio_va_L ratio_s_owner3 , stack  over(owner_yr, sort(id) )  /// //lab( angle(90))) ///
		legend(label(2 "VA per Worker") label(1 "Workers") label(3 "Owner Share") row(1) ///
		region(lcolor(white) margin(zero))) ytitle(Share of Growth in Entrepreneurial Income (%)) ///
		bar(1, color(navy*.4)) bar(2, color(dknavy) lcolor(dknavy)) bar(3, color(maroon)) ///
		$gpr blabel(bar, position(center) format(%12.1f) size(medsmall) color(white)) xsize(6) ylab(, nogmax)
	graph export $graphdir/figure10c.pdf, replace


	*******************************************************************************
	* 5. Plot extraction graphs
	*******************************************************************************
	use `va_orig', clear

	*KEEP 2001, 2004, 2014
	keep if inlist(year, 2001, 2014)

	replace ownerpay = ownerpay - ownerwage
	replace ownerpay_adj = ownerpay_adj - ownerwage_adj


	foreach var in ownerpay ownerwage nonowner_wb{
		g `var'_va  = 100*`var'_adj/va_adj
	}

	*Make stackable biz income and total owner payment
	preserve
		keep year incgroup nonowner_wb_va
		g stack_cat = "Worker Pay" // setting up the data so we can stack just one of the variables

		tempfile nonowner_wb_va
		save `nonowner_wb_va'
	restore

	preserve
		keep year incgroup ownerwage_va ownerpay_va
		g stack_cat = "Entrep. Inc." // setting up the data so we can stack just one of the variables

		tempfile ownerpay_va
		save `ownerpay_va'
	restore


	clear

	append using `nonowner_wb_va'
	append using `ownerpay_va'


	*CLEAN OWNER TYPE
	g owner_type = "Top 1%" if incgroup=="top1"
	replace owner_type = "Top 0.1%" if incgroup=="top01"
	replace owner_type = "Millionaires" if incgroup=="M"

	g order = 1 if incgroup=="top1"
	replace order = 3 if incgroup=="top01"
	replace order = 2 if incgroup=="M"


	* Graph bar comparisons of 2001 and 2014
	foreach type in top1 top01 {
		preserve
		keep if incgroup == "`type'"

		qui levelsof owner_type, local(owner)
		
		#delimit ;

		graph bar ownerpay_va ownerwage_va nonowner_wb_va, stack 
			over(stack_cat, label(labsize(large))) over(year, gap(*.4) label(labsize(vlarge)))
			$gpr
			legend(order(1 2 3) row(2) label(1 "Entrep. Inc.: Profits") label(2 "Entrep. Inc.: Owner Wages") label(3 "Worker Pay")
			region(lcolor(white) margin(zero)) )
			yscale(range(0 65))
			ylabel(0(15)60) title(`owner', size(vhuge) color(black))
			blabel(bar, format(%9.1f) position(center) size(vlarge) color(white))
			bar(1, color(maroon)) bar(2, color(maroon*.5)  lcolor(maroon)) bar(3, color(dknavy))
			ytitle("Share of Value Added (%)", size(huge)) plotregion(margin(zero)) ;
		graph save $graphdir/figure10d_`type'.gph, replace;

		#delimit cr
		
		restore
	}

	* COMBINE GRAPHS
		grc1leg "$graphdir/figure10d_top1.gph" ///
				"$graphdir/figure10d_top01.gph" ///
				, ///
				col(2) ///
				plotregion(fcolor(white) lcolor(white)) ///
				graphregion(fcolor(white) lcolor(white)) ///
				iscale(*.7)
				
		graph display, xsize(5) ysize(3.5) 
		graph export "$graphdir/figure10d.pdf", replace	

end /*%>*/


