
***********************************************************
* FIGURE 1
***********************************************************
capture program drop figure1
program define figure1 /*<%*/


	* INSHEET DATA
	use "$dtadir/figure1.dta", clear
	
		
	*GRAPH MAJORITY LABOR vs. BUSINESS vs. OTHER CAPITAL INCOME, FI
	twoway (scatter majlinc incgroup if incdefn == "fi", c(l) mcolor(navy) lcolor(navy) ms(O)) ///
			(scatter majbinc incgroup if incdefn == "fi", c(l) mcolor(maroon) lcolor(maroon) ms(T) lpattern(dash)) ///
			(scatter majkinc incgroup if incdefn == "fi", c(l) mcolor(maroon*.7) lcolor(maroon*.7) ms(Dh) lpattern(shortdash)) ///
			,  ///
			xtitle(Fiscal Income Bin) ytitle(Share of People (%)) ylab(0(20)100) ///
			legend(lab(1 Wages) lab(2 Business) ///
				lab(3 "Other capital income: interest," "rents, royalties, estates, trusts") order(1 2 3) row(1) ///
				region(lcolor(white)) symxsize(8)) ///
			$gpr xlab(1(1)11,valuelabel angle(90) labsize(small))
	graph export "$graphdir/figure1a_fi.pdf", replace

	*GRAPH MAJORITY LABOR vs. BUSINESS vs. OTHER CAPITAL INCOME, INI
	twoway (scatter majlinc incgroup if incdefn == "ni", c(l) mcolor(navy) lcolor(navy) ms(O)) ///
			(scatter majbinc incgroup if incdefn == "ni", c(l) mcolor(maroon) lcolor(maroon) ms(T) lpattern(dash)) ///
			(scatter majkinc incgroup if incdefn == "ni", c(l) mcolor(maroon*.7) lcolor(maroon*.7) ms(Dh) lpattern(shortdash)) ///
			,  ///
			xtitle(Imputed National Income Bin) ytitle(Share of People (%)) ylab(0(20)100)  ///
			legend(lab(1 Wages) lab(2 Business) ///
				lab(3 "Other capital income: interest," "rents, royalties, estates, trusts") order(1 2 3) row(1) ///
				region(lcolor(white)) symxsize(8)) ///
			$gpr xlab(12(1)22,valuelabel angle(90) labsize(small))
	graph export "$graphdir/figure1a_ini.pdf", replace
	
	*GRAPH LABOR vs. BUSINESS vs. OTHER CAPITAL INCOME, FI
	twoway (scatter labor incgroup if incdefn == "fi", c(l) mcolor(navy) lcolor(navy) ms(O)) ///
			(scatter business incgroup if incdefn == "fi", c(l) mcolor(maroon) lcolor(maroon) ms(T) lpattern(dash)) ///
			(scatter othercapital incgroup if incdefn == "fi", c(l) mcolor(maroon*.7) lcolor(maroon*.7) ms(Dh) lpattern(shortdash)) ///
			,  ///
			xtitle(Fiscal Income Bin) ytitle("Share of Bin's Fiscal Income (%)") ylab(0(20)100) ///
			legend(lab(1 Wages) lab(2 Business) lab(3 "Other capital income: interest," "rents, royalties, estates, trusts") order(1 2 3) row(1) ///
				region(lcolor(white)) symxsize(8)) ///
			$gpr xlab(1(1)11,valuelabel angle(90) labsize(small))
	graph export "$graphdir/figure1b_fi.pdf", replace
	
	*GRAPH LABOR vs. BUSINESS vs. OTHER CAPITAL INCOME, INI
	twoway (scatter labor incgroup if incdefn == "ni", c(l) mcolor(navy) lcolor(navy) ms(O)) ///
			(scatter business incgroup if incdefn == "ni", c(l) mcolor(maroon) lcolor(maroon) ms(T) lpattern(dash)) ///
			(scatter othercapital incgroup if incdefn == "ni", c(l) mcolor(maroon*.7) lcolor(maroon*.7) ms(Dh) lpattern(shortdash)) ///
			,  ///
			xtitle(Imputed National Income Bin) ytitle("Share of Bin's INI (%)") ylab(0(20)100) ///
			legend(lab(1 Wages) lab(2 Business) lab(3 "Other capital income: interest," "rents, royalties, estates, trusts") order(1 2 3) row(1) ///
				region(lcolor(white)) symxsize(8)) ///
			$gpr xlab(12(1)22,valuelabel angle(90) labsize(small))
	graph export "$graphdir/figure1b_ini.pdf", replace
	
	
	*GRAPH PASS-THROUGH VS. C, FI
	twoway (scatter pt incgroup if incdefn == "fi", c(l) mcolor(maroon) lcolor(maroon) ms(O)) ///
			(scatter c incgroup if incdefn == "fi", c(l) mcolor(maroon) lcolor(maroon) ms(S) lpattern(dash)) ///
			,  ///
			xtitle(Fiscal Income Bin) ytitle("Share of Bin's Fiscal Income (%)") ///
			legend(lab(1 Business income from private pass-through firms) lab(2 Business income from other firms (C-corporation dividends)) ///
			 order(1 2 3) row(3) ///
				region(lcolor(white))) ///
			$gpr xlab(1(1)11,valuelabel angle(90) labsize(small))
	graph export "$graphdir/figure1c_fi.pdf", replace

	*GRAPH PASS-THROUGH VS. C, INI
	twoway (scatter pt incgroup if incdefn == "ni", c(l) mcolor(maroon) lcolor(maroon) ms(O)) ///
		   (scatter c incgroup if incdefn == "ni", c(l) mcolor(maroon) lcolor(maroon) ms(S) lpattern(dash)) ///
			,  ///
			xtitle(Imputed National Income Bin) ytitle("Share of Bin's INI (%)") ///
			legend(lab(1 Business income from private pass-through firms) lab(2 " Business income from other firms (C-corporation dividends" " + retained earnings)") ///
			 order(1 2 3) row(3) ///
				region(lcolor(white))) ///
			$gpr xlab(12(1)22,valuelabel angle(90) labsize(small))
	graph export "$graphdir/figure1c_ini.pdf", replace

end /*%>*/
