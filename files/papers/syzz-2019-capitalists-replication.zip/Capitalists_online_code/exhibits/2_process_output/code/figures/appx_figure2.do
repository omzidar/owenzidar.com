***********************************************************
* APPENDIX FIGURE 2
***********************************************************
capture program drop appx_figure2
program define appx_figure2 /*<%*/


	use $dtadir/appx_figure2 , clear
	

	*********************************			
	* TOP1
	*********************************	

	twoway (connect sL agegroup if group=="P99-100" , lcolor(navy) mc(navy) ms(O)) ///
		   (connect sPT agegroup if group=="P99-100" , lcolor(maroon) mc(maroon) ms(Th)) ///
		   (connect sK agegroup if group=="P99-100" , lcolor(forest_green) mc(forest_green) lpattern(dash) ms(D)) ///
		   (connect sC agegroup if group=="P99-100" , lcolor(maroon) mc(maroon) lpattern(shortdash) ms(X)) ///
		   , ///
		$gpr ///
		xlab(2(1)9, valuelabel) xtitle(Age Group) ///
		ytitle("Share of top 1% earners" "with majority income of this source") ///
		legend(row(2) label(1 "Wages") ///
		label(2 "Pass-through") label(3 "Other capital") label(4 "C-corporation dividends") region(lcolor(white)))
	graph export "$graphdir/appx_figure2a.pdf", replace

	
	*********************************			
	* TOP0.1
	*********************************	

	twoway (connect sL agegroup if group=="P99.9-100" , lcolor(navy) mc(navy) ms(O)) ///
		   (connect sPT agegroup if group=="P99.9-100" , lcolor(maroon) mc(maroon) ms(Th)) ///
		   (connect sK agegroup if group=="P99.9-100" , lcolor(forest_green) mc(forest_green) lpattern(dash) ms(D)) ///
		   (connect sC agegroup if group=="P99.9-100" , lcolor(maroon) mc(maroon) lpattern(shortdash) ms(X)) ///
		   , ///
		$gpr ///
		xlab(2(1)9, valuelabel) xtitle(Age Group) ///
		ytitle("Share of top 0.1% earners" "with majority income of this source") ///
		legend(row(2) label(1 "Wages") ///
		label(2 "Pass-through") label(3 "Other capital") label(4 "C-corporation dividends") region(lcolor(white)))
	graph export "$graphdir/appx_figure2b.pdf", replace

	
end /*%>*/
