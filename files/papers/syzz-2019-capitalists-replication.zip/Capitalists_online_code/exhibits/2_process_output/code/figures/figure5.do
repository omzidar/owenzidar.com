
***********************************************************
* FIGURE 5
***********************************************************

capture program drop figure5
program define figure5 /*<%*/

	* PANEL A: OWNER DEATH
		import delim "$rawdir/ES_sp_0_64_millionaire_profits_numw2pre_dif.csv", clear
			
		drop if strpos(var, "5") != 0 /* Don't want time horizon = 5 */
		local new_obs = _N + 1
		set obs `new_obs'
		qui g t = _n - 5 if _n < 4
		qui replace t = _n - 4 if missing(t)
		qui replace t = -1 in `new_obs'
		sort t
		*Rescale by 1000
		qui replace coef = 0 if missing(coef)
		qui replace stderr = 0 if missing(stderr)

		qui replace coef = coef/1000
		qui replace stderr = stderr/1000

		qui rename (coef stderr) (b se)

		ES_graph, ci(1.96) xti(Years Since Owner Death) yti("Profits Per Pre-period Worker (000s)") ///
			outname("figure5a") lab1("Impact")  ylab("-30(10)10")
		
	* PANEL B: OWNER RETIREMENT
		import delim "$rawdir/ES_sp_millionaire_profits_numw2pre_dif", clear
		
		drop if strpos(var, "5") != 0 /* Don't want time horizon = 5 */
		local new_obs = _N + 1
		set obs `new_obs'
		qui g t = _n - 5 if _n < 4
		qui replace t = _n - 4 if missing(t)
		qui replace t = -1 in `new_obs'
		sort t
		*Rescale by 1000
		qui replace coef = 0 if missing(coef)
		qui replace stderr = 0 if missing(stderr)

		qui replace coef = coef/1000
		qui replace stderr = stderr/1000

		qui rename (coef stderr) (b se)

		ES_graph, ci(1.96) xti(Years Since Owner Retirement) yti("Profits Per Pre-period Worker (000s)") ///
			outname("figure5b") lab1("Impact") ylab("-50(10)10") 

end /*%>*/
