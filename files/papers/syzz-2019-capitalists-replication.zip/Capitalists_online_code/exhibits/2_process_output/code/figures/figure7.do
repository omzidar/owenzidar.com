
*******************************************************************************
* FIGURE 7
*******************************************************************************	
capture program drop figure7
program define figure7
	
	*-------------------*
	*----  PANEL A -----*
	*-------------------*


		*Insheet data
		use "$dtadir/figure7a.dta", clear

		*GRAPH MAJORITY LABOR vs. BUSINESS vs. OTHER CAPITAL INCOME, FI
		#delimit ;
		twoway (scatter majlinc incgroup if incdefn == "fi", c(l) mcolor(navy*.3) lcolor(navy*.3) ms(Oh)) 
				(scatter majbinc incgroup if incdefn == "fi", c(l) mcolor(maroon*.3) lcolor(maroon*.3) ms(Th) lpattern(dash)) 
				(scatter majkinc incgroup if incdefn == "fi", c(l) mcolor(maroon*.7) lcolor(maroon*.7) ms(Dh) lpattern(shortdash))
				(scatter majbinc_adj incgroup if incdefn == "fi", c(l) mcolor(maroon) lcolor(maroon) ms(T) lpattern(dash)) 
				(scatter majhcinc incgroup if incdefn == "fi", c(l) mcolor(navy) lcolor(navy) ms(O)) 
				,  
				xtitle(Fiscal Income Bin) ytitle(Share of people (%)) ylab(0(20)100) 
				legend(lab(1 Wages) lab(5 Wages + .75 Pass-through) lab(2 Business)  lab(4 Business - .75 Pass-through)  
					lab(3 "Other capital income: interest," "rents, royalties, estates, trusts") order(1 5 2 4 3) row(3) 
					region(lcolor(white)) symxsize(8)) 
				$gpr xlab(1(1)11, valuelabel angle(90) labsize(small));
		graph export "$graphdir/figure7a_fi.pdf", replace;
		#delimit cr


		*GRAPH MAJORITY LABOR vs. BUSINESS vs. OTHER CAPITAL INCOME, INI
		#delimit ;
		twoway (scatter majlinc incgroup if incdefn == "ni", c(l) mcolor(navy*.3) lcolor(navy*.3) ms(Oh)) 
				(scatter majbinc incgroup if incdefn == "ni", c(l) mcolor(maroon*.3) lcolor(maroon*.3) ms(Th) lpattern(dash)) 
				(scatter majkinc incgroup if incdefn == "ni", c(l) mcolor(maroon*.7) lcolor(maroon*.7) ms(Dh) lpattern(shortdash)) 
				(scatter majbinc_adj incgroup if incdefn == "ni", c(l) mcolor(maroon) lcolor(maroon) ms(T) lpattern(dash)) 
				(scatter majhcinc incgroup if incdefn == "ni", c(l) mcolor(navy) lcolor(navy) ms(O)) 
				,  
				xtitle(Imputed National Income Bin) ytitle(Share of people (%)) ylab(0(20)100)  
				legend(lab(1 Wages) lab(5 Wages + .75 Pass-through) lab(2 Business)  lab(4 Business - .75 Pass-through)  
					lab(3 "Other capital income: interest," "rents, royalties, estates, trusts") order(1 5 2 4 3) row(3) 
					region(lcolor(white)) symxsize(8)) 
				$gpr xlab(12(1)22,valuelabel angle(90) labsize(small));
		graph export "$graphdir/figure7a_ini.pdf", replace;
		#delimit cr

	*-------------------*
	*----  PANEL B -----*
	*-------------------*

		
		*Insheet data
		use "$dtadir/figure7b.dta", clear

		*FISCAL INCOME, SELF MADE
		graph bar majwaglpen majlab2 majlab2sm sm2 sm2workers1 sm2ptowners1 ///
			if incdefn=="fi", over(group, sort(incgroup)) ///
			legend(row(6) region(lcolor(white)) ///
				label(1 "Wage earners (i.e. has majority income from wages)") ///
				label(2 "Human-capital rich (i.e. has majority income from labor)") ///
				label(3 "Human-capital rich, parent-linked subset") ///
				label(4 "Self-made (i.e. has bottom-99% parent), parent-linked subset") ///
				label(5 "Self-made, parent-linked workers") ///
				label(6 "Self-made, parent-linked entrepreneurs") ///
				) ///
			ytitle("Share of People (%)") ylab(0(25)100) ///
			plotregion(fcolor(white) lcolor(white)) ///
			graphregion(fcolor(white) lcolor(white)) ///
			bar(1, fcolor(gs8) lcolor(gs8)) ///
			bar(2, fcolor(maroon*.5) lcolor(maroon)) bar(3, fcolor(maroon) lcolor(maroon)) ///
			bar(4, fcolor(navy) lcolor(navy)) ///
			bar(5, color(navy*.7) lcolor(navy)) ///
			bar(6, color(navy*.4) lcolor(navy)) ///
			blabel(bar, position(inside) format(%9.1f) color(white) size(small))
		graph export "$graphdir/figure7b_fi.pdf", replace
		
		*NATIONAL INCOME, SELF MADE
		graph bar majwaglpen majlab2 majlab2sm sm2 sm2workers1 sm2ptowners1 ///
			if incdefn=="ni", over(group, sort(incgroup)) ///
			legend(row(6) region(lcolor(white)) ///
				label(1 "Wage earners (i.e. has majority income from wages)") ///
				label(2 "Human-capital rich (i.e. has majority income from labor)") ///
				label(3 "Human-capital rich, parent-linked subset") ///
				label(4 "Self-made (i.e. has bottom-99% parent), parent-linked subset") ///
				label(5 "Self-made, parent-linked workers") ///
				label(6 "Self-made, parent-linked entrepreneurs") ///
				) ///
			ytitle("Share of People (%)") ylab(0(25)100) ///
			plotregion(fcolor(white) lcolor(white)) ///
			graphregion(fcolor(white) lcolor(white)) ///
			bar(1, fcolor(gs8) lcolor(gs8)) ///
			bar(2, fcolor(maroon*.5) lcolor(maroon)) bar(3, fcolor(maroon) lcolor(maroon)) ///
			bar(4, fcolor(navy) lcolor(navy)) ///
			bar(5, color(navy*.7) lcolor(navy)) ///
			bar(6, color(navy*.4) lcolor(navy)) ///
			blabel(bar, position(inside) format(%9.1f) color(white) size(small))
		graph export "$graphdir/figure7b_ini.pdf", replace


end /*%>*/
