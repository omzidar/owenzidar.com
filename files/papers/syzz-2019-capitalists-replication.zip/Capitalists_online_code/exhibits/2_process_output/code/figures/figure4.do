
***********************************************************
* FIGURE 4
***********************************************************
capture program drop figure4
program define figure4 /*<%*/

	*---- PANEL A ----*
	use "$dtadir/figure4a.dta", clear
	
	#delimit ;
	twoway (scatter yvar_none agibin, c(l) lcolor(navy) mc(navy) ms(O) ) 
		   (scatter yvar_nc4 agibin, c(l) lcolor(cranberry) mc(cranberry) ms(S) lpattern(dash) ) 
		   (scatter yvar_nc4sa agibin, c(l) lcolor(green) mc(green) ms(T) lpattern(shortdash) ) 
		   , 
		   legend(label(1 "No controls") label(2 "Net of 4-digit industry FEs") 
		   	label(3 "Net of industry-sales FEs") region(lcolor(white)) row(3) ) 
			$gpr 
			ytitle("Profits (000s) per worker") xtitle("Fiscal income percentile")
			xlab(90(1)100);
	#delimit cr
	
	graph export "$graphdir/figure4a.pdf", replace 
	
	*---- PANEL B ----*
	use "$dtadir/figure4b.dta", clear
	
	#delimit ;
	twoway (scatter ppw_nc4 agibin if fifth_yr == 1, c(l) m(O) lc(navy) mc(navy)) ||
		(scatter  ppw_nc4 agibin if fifth_yr == 0, c(l) m(S) lc(cranberry) mc(cranberry) msize(medsmall) lpattern(dash)) 
			 
			 ,  
			$gpr ytitle("Profits (000s) per worker") ylab(5(1)8) xtitle("Fiscal income percentile in year before founding") xlab(90(1)100)
			legend(order(1 2) label(1 "Startup's fifth year") label(2 "Startup's first five years") row(3) region(lc(white))) 
			;
	#delimit cr
	graph export "$graphdir/figure4b.pdf", replace
	

end /*%>*/
