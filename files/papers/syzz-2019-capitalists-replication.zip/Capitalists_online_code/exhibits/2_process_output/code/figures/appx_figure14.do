
***********************************************************
* APPX FIGURE 14
***********************************************************

capture program drop appx_figure14
program define appx_figure14 /*<%*/

    use $dtadir/appx_figure14 , clear

    
    global col1 "red*.5"
    global col2 "green*.5"
    global col3 "blue*.5"

	** Panel A
    #delimit ;
    twoway (rarea mountain_lab1 zero year, color($col1) lw(none)) 
           (rarea scorp_mount1 mountain_lab1 year, color($col2) lw(none)) 
           (rarea oth_mount1 scorp_mount1 year, color($col3) lw(none)) 
        if year>=1960 & year<=2014, 
        xscale(range(1960 2014)) xlabel(1960(5)2010) $gpr
        legend(order(1 "Labor income" 
            2 "S-corporation profits" 
            3 "Capital income (excl. S-corporation profits)") row(3) region(lc(white))) xtitle("")
        /* title("The role of S-corporation profits for the top 1%") */ 
        ytitle("% of National Income");
    graph export "$graphdir/appx_figure14a.pdf", replace;
    #delimit cr

   
	** Panel B
    #delimit ;
    twoway 
        (rarea lab_pens_decomp zero year, color($col1) lw(none)) 
        (rarea lab_mixed_decomp lab_pens_decomp year, color(red*.8) lw(none)) 
        (rarea scorp_decomp lab_mixed_decomp year, color($col2) lw(none)) 
        (rarea capmix_inc_decomp scorp_decomp year, color(blue*.8) lw(none)) 
        (rarea capinc_area capmix_inc_decomp year, color($col3) lw(none)) 
        if year>=1960 & year<=2014, 
        xscale(range(1960 2014)) xlabel(1960(5)2010) $gpr xtitle("")
        legend(order(1 "Labor (excl. pass-through)" 
                     2 "Other pass-through labor" 
                     3 "S-corporation profits"  
                     4 "Other pass-through capital" 
                     5 "Capital (excl. pass-through)")
                row(3) region(lc(white)))
        /* title("Composition of 1% Income") */ 
        ytitle("% of National Income");
    graph export "$graphdir/appx_figure14b.pdf", replace;
    #delimit cr

	
	** Panel C
    #delimit ;
    twoway 
        
        (rarea lab_pens_decomp zero year, color($col1) lw(none))
        (rarea capmix_inc_decomp lab_pens_decomp year, color($col2) lw(none))
        (rarea cappens_decomp capmix_inc_decomp year, color($col3) lw(none)) 
        if year>=1960 & year<=2014, 
        xscale(range(1960 2014)) xlabel(1960(5)2010) $gpr xtitle("")
        legend(order(1 "Labor (excl. pass-through)" 
                     2 "Pass-through" 
                     3 "Capital (excl. pass-through)")
               row(3) region(lc(white)))
        /* title("Composition of 1% Income") */ 
        ytitle("% of National Income");
    graph export "$graphdir/appx_figure14c.pdf", replace;
    #delimit cr



end /*%>*/
