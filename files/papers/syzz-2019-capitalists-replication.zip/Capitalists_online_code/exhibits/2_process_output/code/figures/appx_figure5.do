
***********************************************************
* APPX FIGURE 5: STATE DISTRIBUTION
***********************************************************

capture program drop appx_figure5
program define appx_figure5 /*<%*/


	*---- TOP1 ----*
        use $dtadir/appx_figure5 , clear
		keep if incgroup == "top1"
		

        #delimit ;
            graph bar s_profits_ccorp s_profits_pt sh_pop, horizontal
                over(state_other, sort(order) label(labsize(small))) /*bargap(13)*/
                ysize(6) xsize(5) ylabel(, labsize(medsmall))  
                ytitle("Share of population and profits by corporate form (%)", size(medsmall))
                legend(row(2) order(1 3 2)  label(1 "C-corporations") label(2 "Top 1% owned pass-throughs")
                label(3 "Population") size(medsmall)
                region(lcolor(white)) symxsize(4.4)) plotregion(margin(b = 1))
                $gpr ;
            graph export "$graphdir/appx_figure5a.pdf", replace
            ;
        #delimit cr
		
    *---- MILLIONAIRE ----*
        use $dtadir/appx_figure5 , clear
		keep if incgroup == "millionaire"


        #delimit ;
            graph bar s_profits_ccorp s_profits_pt sh_pop, horizontal
                over(state_other, sort(order) label(labsize(small))) /*bargap(13)*/
                ysize(6) xsize(5) ylabel(, labsize(medsmall))  
                ytitle("Share of population and profits by corporate form (%)", size(medsmall))
                legend(row(2) order(1 3 2) label(1 "C-corporations") label(2 "Millionaire-owned pass-throughs")
                label(3 "Population") size(medsmall)
                region(lcolor(white)) symxsize(4.4)) plotregion(margin(b = 1))
                $gpr ;
            graph export "$graphdir/appx_figure5b.pdf", replace
            ;
        #delimit cr

  

    *---- TOP0.1 ----*
        use $dtadir/appx_figure5 , clear
		keep if incgroup == "toppt1"


        #delimit ;
            graph bar s_profits_ccorp s_profits_pt sh_pop, horizontal
                over(state_other, sort(order) label(labsize(small))) /*bargap(13)*/
                ysize(6) xsize(5) ylabel(, labsize(medsmall))  
                ytitle("Share of population and profits by corporate form (%)", size(medsmall))
                legend(row(2) order(1 3 2)  label(1 "C-corporations") label(2 "Top 0.1% owned pass-throughs")
                label(3 "Population") size(medsmall)
                region(lcolor(white)) symxsize(4.4)) plotregion(margin(b = 1))
                $gpr ;
            graph export "$graphdir/appx_figure5c.pdf", replace
            ;
        #delimit cr


end /*%>*/
