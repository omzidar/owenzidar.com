
***********************************************************
* APPX FIGURE 18
***********************************************************

capture program drop appx_figure18
program define appx_figure18 /*<%*/

    use $dtadir/appx_figure18 , clear

        * 1. Allocation factors. Our replication versus their numbers.
        #delimit ;
		
        * 2. Final numbers. Ours versus theirs.;
        twoway 
            (scatter t1_sdiv_ez_formula year, c(l) m(S) lc(black) mc(black))
            (scatter t1_sdiv_psz_baseline year, c(l) m(Dh) lc(black) mc(black))
            if year>=1990 & year<=2014, 
            $gpr ytitle("Billions of USD") xtitle("") 
            legend(label(1 "Final Component in Replication") 
                   label(2 "Final Component in PSZ")
                   row(2) region(lc(white))) 
            ysc(titlegap(2) range(25 325)) ylab(25(50)325)
            xlab(1990(2)2014);
        graph export "$graphdir/appx_figure18a.pdf", replace;

        twoway 
            (scatter t1_cdiv_ez_formula year, c(l) m(S) lc(black) mc(black))
            (scatter t1_cdiv_psz_baseline year, c(l) m(Dh) lc(black) mc(black))
            if year>=1990 & year<=2014, 
            $gpr ytitle("Billions of USD") xtitle("") 
            legend(label(1 "Final Component in Replication") 
                   label(2 "Final Component in PSZ")
                   row(2) region(lc(white))) 
            ysc(titlegap(2) range(25 325)) ylab(25(50)325)
            xlab(1990(2)2014);
        graph export "$graphdir/appx_figure18b.pdf", replace;
		
        twoway 
            (scatter t1_cret_ez_formula year, c(l) m(S) lc(black) mc(black))
            (scatter t1_cret_psz_baseline year, c(l) m(Dh) lc(black) mc(black))
            if year>=1990 & year<=2014, 
            $gpr ytitle("Billions of USD") xtitle("") 
            legend(label(1 "Final Component in Replication") 
                   label(2 "Final Component in PSZ")
                   row(2) region(lc(white))) 
            ysc(titlegap(2) range(25 325)) ylab(25(50)325)
            xlab(1990(2)2014);
        graph export "$graphdir/appx_figure18c.pdf", replace;

        #delimit cr

end /*%>*/
