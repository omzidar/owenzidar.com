
***********************************************************
* APPX FIGURE 16
***********************************************************

capture program drop appx_figure16
program define appx_figure16 /*<%*/

    
    foreach year in 1990 2000{

        local start = `year'

        if "`start'"=="1990"{
            local letter="a"
        }
        else if "`start'"=="2000"{
            local letter="b"
        }

		use $dtadir/appx_figure16`letter' , clear

        
        sort ver
        #delimit ;
        keep if inlist(ver, 1, 2, 12) ;
        local overlabs2
            1 "PSZ (2018)"
            2 "PSZ Updated"
            3 "PSZ Updated, Mixed Income"
            ;    
        graph hbar sdiv_Bgrowth pship_Bgrowth cdiv_Bgrowth cret_Bgrowth, stack 
            over(ver, relabel(`overlabs2') label(labsize(small)))
            legend(order(1 2 3 4) row(1) 
                label(1 "S Divs") label(2 "Pships") label(3 "C Divs") label(4 "C Retained")
                region(lcolor(white) margin(zero))) $gpr 
            blabel(bar, format(%9.2f) position(center) size(small) color(white))
            bar(1, color(maroon)) 
            bar(2, color(maroon*.4)) 
            bar(3, color(dknavy)) 
            bar(4, color(navy*.4)) xsize(7)
            ytitle("Contribution to Top 1% Growth since `start'", size(medsmall)) plotregion(margin(zero)) ;
        graph export "$graphdir/appx_figure16`letter'.pdf", replace;
        #delimit cr



    }

end /*%>*/

