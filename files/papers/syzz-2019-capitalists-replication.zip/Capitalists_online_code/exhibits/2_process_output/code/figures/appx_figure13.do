
***********************************************************
* APPX FIGURE 13
***********************************************************

capture program drop appx_figure13
program define appx_figure13 /*<%*/

	use $dtadir/appx_figure13, clear

	  #delimit ;
	  twoway (scatter exited agibin if agibin > 50, c(l) m(O) lc(navy) mc(navy) msize(medsmall) yaxis(1))
	   || (scatter sr1 agibin if agibin > 50, c(l) m(S) lc(cranberry) mc(cranberry) yaxis(2))
	   || (scatter sr3 agibin if agibin > 50, c(l) m(T) lc(green) mc(green) yaxis(2)) ,  
	   $gpr ytitle("P(2001 firm missing from 2014 data)", axis(1)) ytitle("Within-bin profits-per-worker Sharpe ratio", axis(2)) 
	   xtitle("Fiscal income percentile") legend(label(1 "Firm exit rate") label(2 "2001-2004 Sharpe ratio") 
	   label(3 "2011-2014 Sharpe ratio") row(3) region(lc(white)) ) ysc(titlegap(2)) ysc(titlegap(2)) xsc(titlegap(2)) xlab(90(1)100)
	  ;
	  #delimit cr
	  graph export "$graphdir/appx_figure13.pdf", replace
	  
end /*%>*/

