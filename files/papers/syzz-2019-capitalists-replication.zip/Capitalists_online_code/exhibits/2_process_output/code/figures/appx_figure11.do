
***********************************************************
* APPX FIGURE 11
***********************************************************

capture program drop appx_figure11
program define appx_figure11 /*<%*/

    *----- PANEL A ------*  
		local firstyr = 1980
		local lastyr  = 2012
		
		
		use $dtadir/appx_figure11a , clear

		
		#delimit ;
		twoway (scatter sh_nfirms_sp year if year<=`lastyr' , c(l) m(O) lc(navy) mc(navy))
			(scatter  sh_profits_sp year if year<=`lastyr'  , c(l) m(S) lc(cranberry) mc(cranberry) msize(medsmall))
			(scatter  sh_sales_sp year if year<=`lastyr'  , c(l) m(D) lc(green) mc(green) ),
			ytitle("Pass-through Share of" "Business Activity") xtitle("Year")
			$gpr ylabel(0 "0%" 20 "20%" 40 "40%" 60 "60%" 80 "80%") 
			legend(label(1 "Firms") label(2 "Profits") label(3 "Sales")
			row(1) region(lc(white))) ysc(titlegap(2))
			xlab(`firstyr'(2)`lastyr', angle(vertical));
		graph export "$graphdir/appx_figure11a.pdf", replace;
		#delimit cr

    *----- PANEL B and D ------*    
	
		use $dtadir/appx_figure11bd , clear

    *Graph Panel B
		#delimit ;
		twoway (scatter nfirms year if year>=2001 & incgroup=="all", c(l) m(O) lc(navy) mc(navy))
			(scatter  nfirms year if year>=2001 & incgroup=="top101", c(l) m(S) lc(cranberry) mc(cranberry) msize(medsmall))
			(scatter  nfirms year if year>=2001 & incgroup=="top01", c(l) m(D) lc(green) mc(green) ),
			$gpr ytitle(Number of Pass-throughs (M)) xtitle("Year") xlab(90(1)100)
			legend(label(1 "All") label(2 "Top 1-0.1% Owner")
			label(3 "Top 0.1% Owner")
			row(1) region(lc(white))) ysc(titlegap(2))
			xlab(2001(1)2014, angle(vertical));
		#delimit cr
		graph export "$graphdir/appx_figure11b.pdf", replace


    *Graph Panel D
		drop if year==2000
		keep if incgroup=="top01"

		#delimit ;
		twoway (scatter profits_scaled year if year>=2001, c(l) m(O) lc(navy) mc(navy))
			(scatter profits_adj_scaled year if year>=2001, c(l) m(S) lc(cranberry) mc(cranberry) msize(medsmall)),
			$gpr ytitle("Growth of Aggregate Top 0.1% Firm Profits") xtitle("Year") xlab(90(2)100)
			legend(label(1 "Profits") label(2 "Profits holding profit share fixed")
			row(1) region(lc(white))) ysc(titlegap(2)) 
			xlab(2001(1)2014, angle(vertical));
		#delimit cr 
		graph export "$graphdir/appx_figure11d.pdf", replace


    *----- PANEL C ------*  
		use $dtadir/appx_figure11c , clear
		
		
		#delimit ;
		graph bar tot_scaled_1 tot_scaled_2, over(year) stack
			$gpr bar(1, color(gs10)) bar(2, color(black))
			ytitle("Percentage of Pass-through Profits") xsize(5.8)
			legend(label(1 "Profits holding sales share fixed")
				   label(2 "Profits from org. form changes") region(lc(white))
				   col(1));
		graph export "$graphdir/appx_figure11c.pdf", replace;
		#delimit cr/*%>*/

end /*%>*/
