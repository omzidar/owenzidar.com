
***********************************************************
* APPX FIGURE 8, CONSERVARTIVE
***********************************************************

capture program drop appx_figure8
program define appx_figure8 /*<%*/

	use $dtadir/appx_figure8, clear
	
	
    *FISCAL INCOME
    graph bar othcap_minusC c ptcap ptlab ownerlab otherlab ///
        if incdefn=="fi", ///
        over(group, sort(incgroup)) stack ///
        ytitle("Income (B) ") ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        blabel(bar, position(center) format(%9.1f) color(white) size(small)) ///
        bar(1, color(gs11)) bar(2, color(dknavy) lcolor(dknavy)) ///
        bar(3, color(navy*.8) /*lcolor(navy)*/) ///
        bar(4, color(navy*.4) ) bar(5, color(maroon*.5) /*lcolor(maroon)*/) ///
        bar(6, color(maroon) lcolor(maroon)) ///
        legend(rows(3) ///
        order(6 5 4 3 2 1) /*order(4 6 3 5 2 1)*/ region(lcolor(white)) ///
        lab(1 "Other capital income") ///
        lab(2 "C-corporation dividends") ///
        lab(3 "Pass-through capital") ///
        lab(4 "Pass-through labor") ///
        lab(5 "Owner wages") ///
        lab(6 "Non-owner wages") ///
        ) 
    graph export "$graphdir/appx_figure8a.pdf", replace  
    

    *NATIONAL INCOME
    graph bar othcap_minusC c ptcap ptlab ownerlab otherlab ///
        if incdefn=="ni", ///
        over(group, sort(incgroup)) stack ///
        ytitle("Income (B) ") yscale(range(0 3000)) ylab(0(1000)3000) ///
        plotregion(fcolor(white) lcolor(white)) ///
        graphregion(fcolor(white) lcolor(white)) ///
        blabel(bar, position(center) format(%9.1f) color(white) size(small)) ///
        bar(1, color(gs11)) bar(2, color(dknavy) lcolor(dknavy)) ///
        bar(3, color(navy*.8) /*lcolor(navy)*/) ///
        bar(4, color(navy*.4) ) bar(5, color(maroon*.5) /*lcolor(maroon)*/) ///
        bar(6, color(maroon) lcolor(maroon)) ///
        legend(rows(3) ///
        order(6 5 4 3 2 1) /*order(4 6 3 5 2 1)*/ region(lcolor(white)) ///
        lab(1 "Other capital income") ///
        lab(2 "C-corporation dividends + RE") ///
        lab(3 "Pass-through capital") ///
        lab(4 "Pass-through labor") ///
        lab(5 "Owner wages") ///
        lab(6 "Non-owner wages") ///
        ) 
    graph export "$graphdir/appx_figure8b.pdf", replace  

 
    
end/*%>*/
