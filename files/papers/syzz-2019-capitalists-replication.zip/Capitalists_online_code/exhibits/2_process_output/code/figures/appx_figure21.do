
***********************************************************
* APPX FIGURE 21
***********************************************************

capture program drop appx_figure21
program define appx_figure21 /*<%*/


    ****** PANELS A, B, C ********
	use $dtadir/appx_figure21abc , clear
	
    foreach v in "cdiv" "cret" "sdiv" {/*%<*/

        if "`v'"=="sdiv"{
            local letter="a"
        }
        else if "`v'"=="cdiv"{
            local letter="b"
        }
        else if "`v'"=="cret"{
            local letter="c"
        }


        #delimit ;
        * Compare baseline and no extrapolation and divs only;
        twoway 
            (scatter `v'_v0 year, c(l) m(S) lc(black) mc(black))
            (scatter `v'_v1 year, c(l) m(Dh) lc(black) mc(black))
            (scatter `v'_v7 year, c(l) m(O) lc(black) mc(black) lw(thick))
            (scatter `v'_v8 year, c(l) m(t) lc(black) mc(black))
            (scatter `v'_v2 year, c(l) m(Oh) lc(black) mc(black))
            (scatter `v'_v3 year, c(l) m(X) lc(black) mc(black))
            (scatter `v'_v4 year, c(l) m(+) lc(black) mc(black))
            (scatter `v'_v5 year, c(l) m(O) lc(black) mc(black))
            if year>=1990 & year<=2014, 
            $gpr ytitle("Billions of USD") xtitle("") 
            legend(label(1 "PSZ (2018)") 
                   label(2 "PSZ Updated")
                   label(3 "Fiscal Income + RE + Tax")
                   label(4 "PS (2003) Ranks")
                   label(5 "Divs Only")
                   label(6 "Add Pships")
                   label(7 "Divs Only, Pships")
                   label(8 "Divs Only (A+W), Pships")
                   row(4) region(lc(white))) 
            ysc(titlegap(2) range(25 325)) ylab(25(50)325) 
            xlab(1990(2)2014);
        graph export "$graphdir/appx_figure21`letter'.pdf", replace;
    } ;

    #delimit cr/*%>*/

    ****** PANELS D AND E ********
    foreach year in 1990 2000{

        local start = `year'


        if "`start'"=="1990"{
            local letter="d"
        }
        else if "`start'"=="2000"{
            local letter="e"
        }
		
		use $dtadir/appx_figure21`letter' , clear

        #delimit ;
        local overlabs
            1 "PSZ (2018)"
            2 "PSZ Updated"
            3 "Fiscal Income + RE + Tax"
            4 "PS (2003) Ranks"

            5 "Divs Only (A+W)" 
            6 "Divs + 0.25 CapG (A+W)" 
            7 "Divs + 0.5 CapG (A+W)" 
            8 "Divs Only"

            9 "Add Pships"
            10 "Divs Only, Pships"
            11 "Divs Only (A+W), Pships"   

            12 "PSZ Updated, Mixed Income"
            ;    

        graph hbar sdiv_Bgrowth pship_Bgrowth cdiv_Bgrowth cret_Bgrowth if ver!=12, stack 
            over(ver, relabel(`overlabs') label(labsize(small)))
            legend(order(1 2 3 4) row(1) 
                label(1 "S Divs") label(2 "Pships") label(3 "C Divs") label(4 "C Retained")
                region(lcolor(white) margin(zero))) $gpr 
            blabel(bar, format(%9.2f) position(center) size(small) color(white))
            bar(1, color(maroon)) 
            bar(2, color(maroon*.4)) 
            bar(3, color(dknavy)) 
            bar(4, color(navy*.4)) xsize(7)
            ytitle("Contribution to Top 1% Growth since `start'", size(medsmall)) plotregion(margin(zero)) ;
        graph export $graphdir/appx_figure21`letter'.pdf, replace;
        #delimit cr
		
 


    }


end /*%>*/
