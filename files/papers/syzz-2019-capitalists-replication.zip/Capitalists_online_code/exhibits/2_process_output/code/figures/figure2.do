
***********************************************************
* FIGURE 2
***********************************************************
capture program drop figure2
program define figure2 /*<%*/

	* ------- PANEL A -----------*
		* Insheet data
		use "$dtadir/figure2a.dta", clear

		*Calculate total S and P income
		g totSinc  = Sinc*N/1000000000
		g totPinc  = Pinc*N/1000000000

		* Fill in Execucomp, 2014 Compustat data
		g execucomp = 32.7  //from Compustat, 2014
		replace group="Execucomp" if group=="P98-99" //Just using this row
		qui ds group execucomp, not
		foreach var in `r(varlist)'{
			replace `var' = . if group=="Execucomp"
		}
		replace execucomp = . if group!="Execucomp"

		
		*List number of Pass-through owners
		g N_k = ptowner /1000 //rescale down to 1000
		list group N_k if group!=  "Execucomp"

		*Can only get dollar sign in display if do the following
		qui{
		local exec = execucomp in 1
		local s_g1 = totSinc in 2
		local p_g1 = totPinc in 2

		local s_g2 = totSinc in 3
		local p_g2 = totPinc in 3

		local s_g3 = totSinc in 4
		local p_g3 = totPinc in 4

		foreach v in exec s_g1 s_g2 s_g3 p_g1 p_g2 p_g3{
			di "`v'"
			local vv = ``v''
			local `v'_str = "$" + string(`vv', "%12.1f")
		}
		}
		
		*Pass-through dollars
		graph bar totSinc totPinc execucomp, ///
			over(group ) stack ///
			ytitle("Income (B) ") ylab(0(50)250) ///
			$gpr ///
			bar(1, color(navy*.4) lcolor(dknavy)) bar(2, color(dknavy)) ///
			bar(3, color(maroon*.8) ) ///
			legend(rows(1) ///
			order(3 1 2 ) region(lcolor(white)) 	///
			lab(1 "S-corporation") ///
			lab(2 "Partnership") ///
			lab(3 "Salary + Options") ///
			) ///
			text(`=`exec'/2' `=9-1' "`exec_str'", place(e) color(white) size(small)) ///
			text(`=`s_g1'/2' `=35.5-2' "`s_g1_str'", place(e) color(white) size(small)) ///
			text(`=`p_g1'/2+`s_g1'' `=35.5-1.5' "`p_g1_str'", place(e) color(white) size(small)) ///
			text(`=`s_g2'/2' `=62-2' "`s_g2_str'", place(e) color(white) size(small)) ///
			text(`=`p_g2'/2+`s_g2'' `=62-2' "`p_g2_str'", place(e) color(white) size(small)) ///
			text(`=`s_g3'/2' `=88-2' "`s_g3_str'", place(e) color(white) size(small)) ///
			text(`=`p_g3'/2+`s_g3'' `=88-2' "`p_g3_str'", place(e) color(white) size(small)) 
		graph export "$graphdir/figure2a.pdf", replace


	*------ PANEL B --------*
		* Insheet data
		use "$dtadir/figure2b.dta", clear

		* Calculate shares
		egen tot_majKinc = sum(majKinc)
		egen tot_majLinc = sum(majLinc)
		egen tot_majCinc = sum(majCinc)
		egen tot_majPTinc = sum(majPTinc)


		g sK = 100*majKinc/tot_majKinc
		g sL = 100*majLinc/tot_majLinc
		g sC  = 100*majCinc/tot_majCinc
		g sPT = 100*majPTinc/tot_majPTinc
		
		*Drop under 20
		drop if age<20
		
		* GRAPH
		twoway (connect sL agegroup , lcolor(navy) mc(navy) ms(O)) ///
			   (connect sPT agegroup , lcolor(maroon) mc(maroon) ms(Th)) ///
			   (connect sK agegroup , lcolor(forest_green) mc(forest_green) ms(D) lpatter(dash)) ///
			   (connect sC agegroup , lcolor(maroon) mc(maroon) lpattern(shortdash) ms(X)) ///
			   , ///
			$gpr ///
			xlab(2(1)9, valuelabel) xtitle(Age Group) ///
			ytitle("Share of million-dollar earners" "with majority income of this source (%)") ///
			legend(row(2) label(1 "Wages") ///
			label(2 "Pass-through") label(3 "Other capital") label(4 "C-corporation dividends") region(lcolor(white)))
		graph export "$graphdir/figure2b.pdf", replace


end /*%>*/
