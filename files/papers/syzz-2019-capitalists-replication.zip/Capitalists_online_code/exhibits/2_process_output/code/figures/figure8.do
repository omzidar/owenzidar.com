
***********************************************************
* FIGURE 8
***********************************************************

capture program drop figure8
program define figure8 /*<%*/	
	
	*-------------------*
	*----  PANEL A -----*
	*-------------------*

		use "$dtadir/figure8a.dta", clear


		*GRAPH LABOR vs. BUSINESS vs. OTHER CAPITAL INCOME, FI
		#delimit ;
		twoway (scatter labor incgroup if incdefn == "fi", c(l) mcolor(navy*.3) lcolor(navy*.3) ms(Oh)) 
				(scatter business incgroup if incdefn == "fi", c(l) mcolor(maroon*.3) lcolor(maroon*.3) ms(th) lpattern(dash)) 
				(scatter othercapital incgroup if incdefn == "fi", c(l) mcolor(maroon*.7) lcolor(maroon*.7) ms(Dh) lpattern(shortdash)) 
				(scatter biz_minus_75 incgroup if incdefn == "fi", c(l) mcolor(maroon) lcolor(maroon) ms(T) lpattern(dash)) 
				(scatter labor_plus_75 incgroup if incdefn == "fi", c(l) mcolor(navy) lcolor(navy) ms(O)) 
				,  
				xtitle(Fiscal Income Bin) ytitle("Share of Bin's Fiscal Income (%)") ylab(0(20)100) 
				legend(lab(1 Wages) lab(5 Wages + .75 Pass-through) 
					  lab(2 Business) lab(4 Business - .75 Pass-through) 
					  lab(3 "Other capital income") order(1 5 2 4 3) row(3) 
					region(lcolor(white)) symxsize(8)) 
				$gpr xlab(1(1)11,valuelabel angle(90) labsize(small));
		graph export "$graphdir/figure8a_fi.pdf", replace;
		#delimit cr
		
		*GRAPH LABOR vs. BUSINESS vs. OTHER CAPITAL INCOME, INI
		#delimit ;
		twoway (scatter labor incgroup if incdefn == "ni", c(l) mcolor(navy*.3) lcolor(navy*.3) ms(Oh)) 
				(scatter business incgroup if incdefn == "ni", c(l) mcolor(maroon*.3) lcolor(maroon*.3) ms(th) lpattern(dash)) 
				(scatter othercapital incgroup if incdefn == "ni", c(l) mcolor(maroon*.7) lcolor(maroon*.7) ms(Dh) lpattern(shortdash)) 
				(scatter biz_minus_75 incgroup if incdefn == "ni", c(l) mcolor(maroon) lcolor(maroon) ms(T) lpattern(dash)) 
				(scatter labor_plus_75 incgroup if incdefn == "ni", c(l) mcolor(navy) lcolor(navy) ms(O)) 
				,  
				xtitle(Imputed National Income Bin) ytitle("Share of Bin's INI (%)") ylab(0(20)100) 
				legend(lab(1 Wages) lab(5 Wages + .75 Pass-through) 
					  lab(2 Business) lab(4 Business - .75 Pass-through) 
					  lab(3 "Other capital income") order(1 5 2 4 3) row(3) 
					region(lcolor(white)) symxsize(8)) 
				$gpr xlab(12(1)22,valuelabel angle(90) labsize(small));
		graph export "$graphdir/figure8a_ini.pdf", replace;
		#delimit cr


	*-------------------*
	*----  PANEL B -----*
	*-------------------*

		use "$dtadir/figure8b.dta", clear

		
		*FISCAL INCOME
		graph bar othcap_minusC c ptcap ptlab ownerlab otherlab ///
			if incdefn=="fi", ///
			over(group, sort(incgroup)) stack ///
			ytitle("Income (B) ") ///
			plotregion(fcolor(white) lcolor(white)) ///
			graphregion(fcolor(white) lcolor(white)) ///
			blabel(bar, position(center) format(%9.1f) color(white) size(small)) ///
			bar(1, color(gs11)) bar(2, color(dknavy) lcolor(dknavy)) ///
			bar(3, color(navy*.8) /*lcolor(navy)*/) ///
			bar(4, color(navy*.4) ) bar(5, color(maroon*.5) /*lcolor(maroon)*/) ///
			bar(6, color(maroon) lcolor(maroon)) ///
			legend(rows(3) ///
			order(6 5 4 3 2 1) region(lcolor(white)) ///
			lab(1 "Other capital income") ///
			lab(2 "C-corporation dividends") ///
			lab(3 "Pass-through capital") ///
			lab(4 "Pass-through labor") ///
			lab(5 "Owner wages") ///
			lab(6 "Non-owner wages") ///
			) 
		graph export "$graphdir/figure8b_fi.pdf", replace	

		*NATIONAL INCOME
		graph bar othcap_minusC c ptcap ptlab ownerlab otherlab ///
			if incdefn=="ni", ///
			over(group, sort(incgroup)) stack ///
			ytitle("Income (B) ") yscale(range(0 3000)) ylab(0(1000)3000) ///
			plotregion(fcolor(white) lcolor(white)) ///
			graphregion(fcolor(white) lcolor(white)) ///
			blabel(bar, position(center) format(%9.1f) color(white) size(small)) ///
			bar(1, color(gs11)) bar(2, color(dknavy) lcolor(dknavy)) ///
			bar(3, color(navy*.8) /*lcolor(navy)*/) ///
			bar(4, color(navy*.4) ) bar(5, color(maroon*.5) /*lcolor(maroon)*/) ///
			bar(6, color(maroon) lcolor(maroon)) ///
			legend(rows(3) ///
			order(6 5 4 3 2 1) region(lcolor(white)) ///
			lab(1 "Other capital income") ///
			lab(2 "C-corporation dividends + RE") ///
			lab(3 "Pass-through capital") ///
			lab(4 "Pass-through labor") ///
			lab(5 "Owner wages") ///
			lab(6 "Non-owner wages") ///
			) 
		graph export "$graphdir/figure8b_ini.pdf", replace	

		* get labels for the brackets
		egen totinc = rowtotal(othercap2 ptcap ptlab ownerlab otherlab)
			
		foreach var in othercap2 ptcap ptlab ownerlab otherlab c{
			g sh_`var' = `var'/totinc
		}

		egen sh_lab = rowtotal(sh_ptlab sh_ownerlab sh_otherlab)

		egen sh_ownpay = rowtotal(sh_ptlab sh_ownerlab sh_ptcap)
					
		sort incdefn group
	        
	    list sh_ownpay group incdefn

	    list sh_lab group incdefn
		
		drop totinc sh_lab sh_ptlab sh_ownerlab sh_othercap2 sh_otherlab sh_ptcap


end/*%>*/
