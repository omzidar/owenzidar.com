
***********************************************************
* APPX FIGURE 17
***********************************************************

capture program drop appx_figure17
program define appx_figure17 /*<%*/


    ***** PANEL A ******
        use $dtadir/appx_figure17a , clear

        #delimit;
        graph bar (asis) corp_mut_share-other_share,
            bargap(20) bar(4, color(erose))
            ytitle("Share of Total Realized Capital Gains (%)")
            legend(region(lcolor(white)))
            over(period) graphregion(lcolor(white) fcolor(white)) 
            plotregion(color(white));
        graph export "$graphdir/appx_figure17a.pdf", replace;
        #delimit cr

    ***** PANEL B ******
		use $dtadir/appx_figure17b , clear

		* make graph
		#delimit ;
		twoway (connected cret cret_frac kg year, 
				msize(small small small)
				color(navy navy maroon)
				msymbol(s o t)
				lp(dash shortdash solid)),  
				ytitle("Billions of Real USD (2014$)") xtitle("Year") 
				ylab(0(200)1000) xscale(range(1960 2015)) xlab(1960(5)2015)
				legend(label(1 "Macroeconomic Retained Earnings")
					   label(2 "Household Share of Macro Retained Earnings")
					   label(3 "Total Fiscal Income Realized Capital Gains")
					   row(3) region(lc(white)))
				graphregion(lcolor(white) fcolor(white)) 
				plotregion(color(white));
		#delimit cr
		graph export "$graphdir/appx_figure17b.pdf", replace    




end /*%>*/
