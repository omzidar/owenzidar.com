***********************************************************
* APPX TABLE 10
***********************************************************

capture program drop appx_table10
program define appx_table10

	use $dtadir/appx_table10, clear

	*** SET UP FOR OUTPUT
	
	*Replace Yes and No with just a check
	foreach var of varlist *tab*{
		replace `var' = "" if `var'=="No" & regexm(v1,"_FE")
		replace `var' = " $ \checkmark$" if `var'=="Yes" & regexm(v1,"_FE")
	}

	*Drop group row
	drop in `=_N'
	*Insert empty row
	replace order = order+1 if !regexm(v1, "ln_sales")

	set obs `=_N+1'

	egen order_temp = max(order*regexm(v1, "ln_sales"))
	sort order

	replace order = order_temp+1 in `=_N'
	sort order

	drop order_temp


	*Relabel for export
	g label = "" 

	replace label  = " $\ln$(Firm size)"  if v1=="ln_sales"
	replace label  = ""  if v1=="ln_sales_se"

	replace label  = " $\ln$(Firm size of \#250)"  if v1=="ln_sales250"
	replace label  = ""  if v1=="ln_sales250_se"

	replace label  = v1  if v1=="Observations"
	replace label  = " $ R^2$" if v1=="R-squared"
	replace label  = subinstr(v1, "_FE", " fixed effects", . ) if regexm(v1, "FE")


	* SET UP TEX
	g begin = "\begin{tabular}{l l c c ccc c ccc}" in 1
	g endt = "\end{tabular} " in 1


	g panelA = "\multicolumn{8}{l}{\textit{Panel A. S-corporations in Smith, Yagan, Zidar and Zwick (2018) sample}}\\" in 1
	g panelB = "\multicolumn{8}{l}{\textit{Panel B. Partnerships in Smith, Yagan, Zidar and Zwick (2018) sample }}\\" in 1

	g mid = "\midrule" in 1
	g top = "\toprule" in 1
	g bot = "\bottomrule" in 1

	g title0 = " & & \multicolumn{9}{c}{ $ \ln$ (Total compensation) }  \\ " in 1
	g title1 = " & & Table 1 & & \multicolumn{7}{c}{Table 2}  \\ " in 1
	g title2 = " & & (4) & & (1) & (2) & (4) & & (5) & (6) & (8)  \\ " in 1
	g title3 = " & &  & & \multicolumn{3}{c}{Top 1000} & & \multicolumn{3}{c}{Top 500}  \\ " in 1


	g title = " & & (1) & & (2) & (3) & (4) & & (5) & (6) & (7)  \\ " in 1

	g cmid0 = "\cmidrule{3-11}" in 1
	g cmid1 = "\cmidrule{3-3} \cmidrule{5-11}" in 1
	g cmid2 = " \cmidrule{5-7} \cmidrule{9-11} " in 1

	g empty = " " 


	*OUTPUT 
	listtex begin if _n == 1 using "$tabdir/appx_table10.tex", replace rstyle(none)
	listtex top if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)
	listtex title0 if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)
	listtex cmid0 if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)

	listtex title if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)
	listtex mid if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)

	listtex title3 if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)
	listtex cmid2 if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)

	**PANEL A
	listtex empty if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(tabular)
	listtex panelA if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)
	listtex empty if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(tabular)

	listtex empty label scorp_tab1_col4 empty scorp_tab2_col1 scorp_tab2_col2 scorp_tab2_col4 ///
		empty scorp_tab2_col5 scorp_tab2_col6 scorp_tab2_col8 , appendto("$tabdir/appx_table10.tex") rstyle(tabular)



	**PANEL B
	listtex empty if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(tabular)
	listtex empty if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(tabular)
	listtex panelB if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)
	listtex empty if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(tabular)

	listtex empty label pship_tab1_col4 empty pship_tab2_col1 pship_tab2_col2 pship_tab2_col4 ///
		empty pship_tab2_col5 pship_tab2_col6 pship_tab2_col8 , appendto("$tabdir/appx_table10.tex") rstyle(tabular)

	listtex bot if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)
	listtex endt if _n == 1, appendto("$tabdir/appx_table10.tex") rstyle(none)

end
