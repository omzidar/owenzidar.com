#!/usr/bin/env python

from string import Template
from csv import DictReader, reader
import re, sys, glob

table_templ = """

\\begin{tabular}{l$cols}
%    \\toprule
$header \\\\
\\midrule 
$rows
%    \\bottomrule
%    \\addlinespace
\\end{tabular}
"""


### Table 02_a.
out = open("table02_a.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(open("../../input/dta/table02_a.csv"))
next(f)
header = """                 & & Top Passthru & \multicolumn{2}{c}{C-corp} \\\\ 
                                 \cmidrule(lr){3-3} \cmidrule(lr){4-5}
             & Industry (NAICS) & Profit (\$M) & Rank & Profit (\$M)"""
rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    r1 = l[0]
    indy = "%s (%s)" % (l[1], l[2])
    profits = str(int(float(l[3])/1e6))
    r2 = l[4]
    profits2 = str(int(float(l[5])/1e6))
#    rows.append(" & ".join([indy, r1, profits, r2, profits2]) + " \\\\")
    rows.append(" & ".join([r1, indy, profits, r2, profits2]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "l" + "r"*(3),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()

### Table 05_b.
out = open("table02_b.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(open("../../input/dta/table02_b.csv"))
next(f)
header = """                 & & C-corp & \multicolumn{2}{c}{Top Passthru} \\\\ 
                                 \cmidrule(lr){3-3} \cmidrule(lr){4-5}
             & Industry (NAICS) & Profit (\$M) & Rank & Profit (\$M)"""
rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    r1 = l[0]
    indy = "%s (%s)" % (l[1], l[2])
    profits = str(int(float(l[3])/1e6))
    r2 = l[4]
    profits2 = str(int(float(l[5])/1e6))
#    rows.append(" & ".join([indy, r1, profits, r2, profits2]) + " \\\\")
    rows.append(" & ".join([r1, indy, profits, r2, profits2]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "l" + "r"*(3),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()

