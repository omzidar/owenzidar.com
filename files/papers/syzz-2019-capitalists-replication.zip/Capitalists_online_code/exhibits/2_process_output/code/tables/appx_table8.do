
***********************************************************
* APPX TABLE OWNER RETIREMENT
***********************************************************
capture program drop appx_table8
program define appx_table8 /*<%*/
	
		use $dtadir/appx_table8, clear

		*SETUP TEX TABLE
		*Panel rows
		g panel_A  = "\textit{A. Inferred Top 1\% Owner Retirement}" in 1
		g panel_B  = "\textit{B. Inferred Top 0.1\% Owner Retirement}" in 1
		
		g panel_A_v2  = "Top 1\%" in 1
		g panel_B_v2  = "Top 0.1\%" in 1
		g panel_C_v2  = "Millionaires" in 1
		

		*Title rows
		g title0  = " & \multirow{3}{3.2cm}{\centering Profits per pre-period worker (\\$/worker)} & & \multirow{3}{2cm}{\centering Firm survival (pp)} & & & & & \\ " in 1
		g title1  = " &  & & & & & & & \\" in 1
		g title2  = " &  & & & & \multicolumn{4}{c}{ Profits per pre-period worker (\\$/worker)} \\" in 1
		
		
		*Tabular, need to update if we add or remove columns
		g tab = "\begin{tabular}{l C{3cm} c C{2cm} c cccc}" in 1
		*Hline
		g hline = "\hline" in 1
		g top = "\toprule" in 1
		*Midrule
		g mid = "\midrule" in 1 
		*Bottomrule
		g bot = "\bottomrule" in 1
		*End
		g end = "\end{tabular}" in 1
		*CLINE
		g cmidrule = "\cmidrule{2-2} \cmidrule{4-4} \cmidrule{6-9}" in 1
		
		
	*NOTE: if you want to remove any of the columns, simply remove the desired column from the global below
	*Don't forget to change the "tab" and "cmidrule" variables if adding or removing columns
		global columns_panelA = "labels col1_1 col1b_1 col2_1 col1b_1 col3_1 col4_1 col5_1 col7_1"
		global columns_panelB = "labels col1_2 col1b_2 col2_2 col1b_2 col3_2 col4_2 col5_2 col7_2"

		replace col7_1 = "(6)" in 1
		replace col7_2 = "(6)" in 1

		****************
		* OUTPUT
		****************	
		*****Output

		listtex tab if _n == 1 using "$tabdir/appx_table8.tex", replace rstyle(none)
		listtex top if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)
		listtex title0 if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)
		listtex title1 if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)
		listtex title2 if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)
		listtex $columns_panelA if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(tabular)
		listtex cmidrule if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)
		listtex panel_A  if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(tabular)
		listtex mid if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)
		listtex $columns_panelA if _n>1 & _n<=21, appendto("$tabdir/appx_table8.tex") rstyle(tabular)  /*listing columns 1-6*/

		listtex panel_B if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(tabular)
		listtex mid if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)
		listtex $columns_panelB if _n>1 & _n<=19, appendto("$tabdir/appx_table8.tex") rstyle(tabular)  /*listing columns 1-6*/
			
		listtex bot if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)
		listtex end if _n == 1, appendto("$tabdir/appx_table8.tex") rstyle(none)


end /*%>*/


