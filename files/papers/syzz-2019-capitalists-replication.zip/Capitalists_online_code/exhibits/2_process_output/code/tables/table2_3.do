
***********************************************************
* TABLES 2 and 3
***********************************************************
capture program drop table2_3
program define table2_3 /*<%*/

	local owd = "`c(pwd)'"
	
	cd $tabdo

    * Make the tex tables (if using python 3, comment if using python 2)
    !python py/table2_py3.py
    !python py/table3_py3.py

    * Make the tex tables (if using python 2, comment if using python 3)
    *!python $tabdir/py/table2.py
    *!python $tabdir/py/table3.py
	
	cd "`owd'"

end /*%>*/
