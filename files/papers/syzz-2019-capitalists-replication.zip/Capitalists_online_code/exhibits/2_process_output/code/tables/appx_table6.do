*******************************************************************************
** Appx Table 6: Construction of Owner Retirement Analysis Sample
*******************************************************************************
capture program drop appx_table6/*%<*/
program define appx_table6

syntax

	clear
	
	set obs 13

	*SETUP TEX TABLE
	g titlerow = " Step & Sample Size at End of Step " in 1
	
	*Tabular
	g tab = "\begin{tabular}{L{6cm} c}" in 1
	*Hline
	g hline = "\hline" in 1
	g top = "\toprule" in 1
	*Midrule
	g mid = "\midrule" in 1 
	*Bottomrule
	g bot = "\bottomrule" in 1
	*End
	g end = "\end{tabular}" in 1

	*CONTENT
	g col1 = ""
	replace col1 = "Distinct firms 2005-2010" in 1
	*
	replace col1 = "Restrict to firms with an inferred retirement" in 3
	*
	replace col1 = "Restrict to firms with top 1\% owner in $ t-1$" in 5
	*	
	replace col1 = "Restrict to firms with $ t-1$ sales $ >$\\$100K and positive sales in $ [t-4, t-1]$" in 7
	*
	replace col1 = "Restrict to firms with at least one pre-period worker" in 9
	*
	replace col1 = "Restrict to firms with working owner's ownership share $ \geq 20\%$" in 11
	*	
	replace col1 = "Match to at least one counterfactual firm" in 13
	*		
	
	
	g col2 = ""
	replace col2 = "9,489,180" in 1
	*
	replace col2 = "191,656" in 3
	*
	replace col2 = "21,616" in 5
	*
	replace col2 = "18,115" in 7
	*
	replace col2 = "18,115" in 9
	*
	replace col2 = "16,827" in 11
		*
	replace col2 = "16,548" in 13
		
	****************
	* OUTPUT, calculated using logs
	****************	
	*****Output
	listtex tab if _n == 1 using "$tabdir/appx_table6.tex", replace rstyle(none)
	listtex top if _n == 1, appendto("$tabdir/appx_table6.tex") rstyle(none)
	listtex titlerow if _n == 1, appendto("$tabdir/appx_table6.tex") rstyle(tabular)
	listtex mid if _n == 1, appendto("$tabdir/appx_table6.tex") rstyle(none)	
	listtex col1 col2, appendto("$tabdir/appx_table6.tex") rstyle(tabular)
	listtex bot if _n == 1, appendto("$tabdir/appx_table6.tex") rstyle(none)
	listtex end if _n == 1, appendto("$tabdir/appx_table6.tex") rstyle(none)
	

end

