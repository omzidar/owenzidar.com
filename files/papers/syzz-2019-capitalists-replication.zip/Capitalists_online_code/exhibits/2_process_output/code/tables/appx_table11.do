***********************************************************
* APPX TABLE 11
***********************************************************
capture program drop appx_table11
program define appx_table11

	use $dtadir/appx_table11, clear

	** ADD STARS TO THE GL RESULTS
	foreach var of varlist tab*{
		qui{
			g `var'_temp = `var'
			destring `var'_temp, replace force ignore("yesno(),")

			*CHECK PVAL
			local df_r = `var'_temp in 9 //observations
			di "`df_r'"
			local b1 = `var'_temp in 2 //coefficient
			local se1 = `var'_temp in 3 //se
			local pval = tprob(`df_r', abs(`b1'/`se1'))
			di "`pval'"

			if `pval' < .1 & `pval' >= .05 {
				replace `var' = `var'+"*" in 2
			}
			if `pval' < .05 & `pval' >= .01 {
				replace `var' = `var'+"**" in 2
			} 
			if `pval' < .01 {
				replace `var' = `var'+"***" in 2
			}

			*REDUCE TO 2 DIGITS IN THE SE FOR GL RESULTS
			replace `var' = "("+string(round(`var'_temp, 0.01), "%12.2f") +")" in 3

		drop *_temp

		}

	}


	** Clean up a bit more
	foreach corp in scorp pship{
		foreach var of varlist `corp'_v* {
			replace `var' = subinstr(`var', " Largest", "", .)
		}

		replace `corp'_v7 = "\multicolumn{2}{c}{ Top "+ `corp'_v7 + "}" in 1
		replace `corp'_v8 = " " in 1
		replace `corp'_v9 = "\multicolumn{2}{c}{ Top "+ `corp'_v9 + "}" in 1
		replace `corp'_v10 = " " in 1
	}

	*replace tab3_col1 = "Gabaix and Landier (2008)" in 1


	** LABELS 
	g label = ""

	replace label  = "D.$\ln$(Firm size)"  if v1=="d_ln_market"
	replace label  = ""  if v1=="d_ln_market_se"

	replace label  = "D.5 $\ln$(Firm size of \#250)"  if v1=="D5_ln_sales250"
	replace label  = ""  if v1=="D5_ln_sales250_se"

	replace label  = "D.10 $\ln$(Firm size of \#250)"  if v1=="D10_ln_sales250"
	replace label  = ""  if v1=="D10_ln_sales250_se"

	replace label  = v1  if v1=="Observations"
	replace label  = " $ R^2$" if v1=="R-squared"
	replace label  = subinstr(v1, "_FE", " fixed effects", . ) if regexm(v1, "FE")



	* SET UP TEX
	g begin = "\begin{tabular}{l c c cc c cc c cc c cc}" in 1
	g endt = "\end{tabular} " in 1

	g mid = "\midrule" in 1
	g top = "\toprule" in 1
	g bot = "\bottomrule" in 1

	g title0 = " & Gabaix and Landier (2008) & & \multicolumn{11}{c}{Smith, Yagan, Zidar, and Zwick (2018)}  \\ " in 1
	g title1 = " & & & \multicolumn{5}{c}{S-corporations} & &  \multicolumn{5}{c}{Partnerships} \\ " in 1

	g title = " & (1) & & (2) & (3) & & (4) & (5) & & (6) & (7) & & (8) & (9) \\ " in 1

	g cmid0 = "\cmidrule{2-2} \cmidrule{4-14}" in 1
	g cmid1 = " \cmidrule{4-8} \cmidrule{10-14}" in 1
	g cmid2 = "\cmidrule{4-5} \cmidrule{7-8} \cmidrule{10-11} \cmidrule{13-14}" in 1

	g empty = " " 

	*OUTPUT 
	listtex begin if _n == 1 using "$tabdir/appx_table11.tex", replace rstyle(none)
	listtex top if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)
	listtex title0 if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)
	listtex cmid0 if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)

	listtex title if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)
	listtex mid if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)

	listtex title1 if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)
	listtex cmid1 if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)

	listtex label tab3_col1 empty scorp_v7 empty scorp_v9 empty ///
		pship_v7 empty pship_v9 if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(tabular)
	listtex cmid2 if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)
	listtex empty if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(tabular)


	listtex label tab3_col1 empty scorp_v7 scorp_v8 empty scorp_v9 scorp_v10 empty ///
		pship_v7 pship_v8 empty pship_v9 pship_v10 ///
		if _n > 1  /*& !regexm(v1, "market")*/, appendto("$tabdir/appx_table11.tex") rstyle(tabular)


	listtex bot if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)
	listtex endt if _n == 1, appendto("$tabdir/appx_table11.tex") rstyle(none)

end	
