
***********************************************************
* TABLE 4
***********************************************************
capture program drop table4
program define table4 /*<%*/
	
		use $dtadir/table4, clear

		*SETUP TEX TABLE
		*Panel rows
		g panel_A  = "\textit{A. Owner Deaths}" in 1
		g panel_B  = "\textit{B. Owner Retirements}" in 1
		
		g panel_A_v2  = "Top 1\%" in 1
		g panel_B_v2  = "Top 0.1\%" in 1
		g panel_C_v2  = "Millionaires" in 1
		

		*Title rows
		g title0  = " & \multirow{3}{3.2cm}{\centering Profits per pre-period worker (\\$/worker)} & & \multirow{3}{2cm}{\centering Firm survival (pp)} & & & & & & & && \\" in 1
		g title1  = " &  & & & & \multicolumn{5}{c}{ } & & \multicolumn{3}{c}{ Profits per pre-period } \\" in 1
		g title2  = " &  & & & & \multicolumn{5}{c}{ Profits per pre-period worker (\\$/worker)} & & \multicolumn{3}{c}{ worker (\\$/worker)} \\" in 1
		
		g inctitle  = " & \multicolumn{9}{c}{ } & & \multirow{2}{2cm}{\centering Top-1\% Owners} & & \multirow{2}{2cm}{\centering Top-0.1\% Owners} \\" in 1
		g inctitle2  = " & \multicolumn{9}{c}{ Million-Dollar-Earning Owners} & & & & \\" in 1
		
		*Tabular, need to update if we add or remove columns
		g tab = "\begin{tabular}{l C{2.85cm} c C{1.85cm} c ccccc c C{1.8cm} c C{1.8cm}}" in 1
		*Hline
		g hline = "\hline" in 1
		g top = "\toprule" in 1
		*Midrule
		g mid = "\midrule" in 1 
		*Bottomrule
		g bot = "\bottomrule" in 1
		*End
		g end = "\end{tabular}" in 1
		*CLINE
		g cmidrule = "\cmidrule{2-2} \cmidrule{4-4} \cmidrule{6-10} \cmidrule{12-14}" in 1
		g cmidrule2 = "\cmidrule{2-10} \cmidrule{12-12} \cmidrule{14-14}" in 1
		g empty = ""
	
		
	*NOTE: if you want to remove any of the columns, simply remove the desired column from the global below
	*Don't forget to change the "tab" and "cmidrule" variables if adding or removing columns
		global columns_panelA = "labels_1 col1_1 col1b_1 col2_1 col1b_1 col3_1 col4_1 col5_1 col6_1 col7_1 col1b_1 col8_1 col1b_1 col9_1"
		global columns_panelB = "labels_2 col1_2 col1b_2 col2_2 col1b_2 col3_2 col4_2 col5_2 col1b_2 col7_2 col1b_2 col8_2 col1b_2 col9_2"

		****************
		* OUTPUT
		****************	
		local tabname = "table4"
		listtex tab if _n == 1 using "$tabdir/`tabname'.tex", replace rstyle(none)
		listtex top if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex inctitle if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex inctitle2 if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex cmidrule2 if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex title0 if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex title1 if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex title2 if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex $columns_panelA if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
		listtex cmidrule if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex panel_A if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
		listtex mid if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex $columns_panelA if _n>1 & _n<=21, appendto("$tabdir/`tabname'.tex") rstyle(tabular)  /*listing columns 1-6*/

		listtex panel_B  if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
		listtex mid if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex $columns_panelB if _n>1 & _n<=21 ///
				& order!=8, appendto("$tabdir/`tabname'.tex") rstyle(tabular)  /*listing columns 1-6*/
			
		listtex bot if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
		listtex end if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)

		forv j=1/2{
		replace labels_`j' = "Mean, cntrfctual firms" if labels_`j'=="Outcome mean of counterfactual firms"
		replace labels_`j' = "Preferred pp impact" if labels_`j'=="Preferred percentage impact"
		replace labels_`j' = "Dying owners' ownership \%" if labels_`j'=="Ownership share of dying owners"
		replace labels_`j' = "Ret owners' ownership \%" if labels_`j'=="Ownership share of retiring owners"
		}

		

end /*%>*/
