#!/usr/bin/env python

from string import Template
from csv import DictReader, reader
import re, sys, glob

table_templ = """

\\begin{tabular}{l$cols}
%    \\toprule
$header \\\\
\\midrule 
$rows
%    \\bottomrule
%    \\addlinespace
\\end{tabular}
"""


### Table 01d_a.
out = open("table03_a.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(open("../../input/dta/table03_a.csv"))
next(f)
header = """ & Partnership Industry (NAICS) &  Top 0.1\% Profits (\$M)"""

rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    r1 = l[0]
    indy = "%s (%s)" % (l[1], l[2])
    profits = str(int(float(l[3])/1e6))
    rows.append(" & ".join([r1, indy, profits]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "r"*(2),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()


### Table 01d_b.
out = open("table03_b.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(open("../../input/dta/table03_b.csv"))
next(f)
header = """ & Partnership Industry (NAICS) &  Top 1-0.1\% Profits (\$M)"""

rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    r1 = l[0]
    indy = "%s (%s)" % (l[1], l[2])
    profits = str(int(float(l[3])/1e6))
    rows.append(" & ".join([r1, indy, profits]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "r"*(2),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()

