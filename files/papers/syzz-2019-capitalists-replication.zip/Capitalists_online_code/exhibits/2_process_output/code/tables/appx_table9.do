***********************************************************
* APPX TABLE 9 
***********************************************************

capture program drop appx_table9
program define appx_table9

	use $dtadir/appx_table9, clear

	** ADD STARS TO THE GL RESULTS
	foreach var of varlist tab*{
		qui{
			g `var'_temp = `var'
			destring `var'_temp, replace force ignore("yesno(),")

			*CHECK PVAL
			local df_r = `var'_temp in 5 //observations
			di "`df_r'"
			local b1 = `var'_temp in 1 //coefficient
			local se1 = `var'_temp in 2 //se
			local pval = tprob(`df_r', abs(`b1'/`se1'))

			if `pval' < .1 & `pval' >= .05 {
				replace `var' = `var'+"*" in 1
			}
			if `pval' < .05 & `pval' >= .01 {
				replace `var' = `var'+"**" in 1
			} 
			if `pval' < .01 {
				replace `var' = `var'+"***" in 1
			}

			*REDUCE TO 2 DIGITS IN THE SE FOR GL RESULTS
			replace `var' = "("+string(round(`var'_temp, 0.01), "%12.2f") +")" in 2

			*If results from table 2
			if `var'_temp!=. in 3{
				*CHECK PVAL
				local b2 = `var'_temp in 1 //coefficient
				local se2 = `var'_temp in 2 //se
				
				local pval = tprob(`df_r', abs(`b2'/`se2'))

				if `pval' < .1 & `pval' >= .05 {
					replace `var' = `var'+"*" in 3
				}
				if `pval' < .05 & `pval' >= .01 {
					replace `var' = `var'+"**" in 3
				} 
				if `pval' < .01 {
					replace `var' = `var'+"***" in 3
				}

			*REDUCE TO 2 DIGITS IN THE SE FOR GL RESULTS
			replace `var' = "("+string(round(`var'_temp, 0.01), "%12.2f") +")" in 2

			}
		drop *_temp

		}

	}


	*** SET UP FOR OUTPUT
	
	*Some cols are missing Firm FE spec
	replace tab1_col4 = "No" if tab1_col4=="" & v1=="Firm_FE"

	*Some cols are missing Year FE spec
	foreach var of varlist tab*{
		replace `var' = "No" if `var'=="" & v1=="Year_FE"
	}


	*Replace Yes and No with just a check
	foreach var of varlist *tab*{
		replace `var' = "" if `var'=="No" & regexm(v1,"_FE")
		replace `var' = " $ \checkmark$" if `var'=="Yes" & regexm(v1,"_FE")
	}

	*Drop group row
	drop in `=_N'

	*Insert empty row
	replace order = order+1 if !regexm(v1, "ln_sales")

	set obs `=_N+1'

	egen order_temp = max(order*regexm(v1, "ln_sales"))
	replace order = order_temp+1 in `=_N'
	sort order

	drop order_temp


	*Relabel for export
	g label = "" 

	replace label  = " $\ln$(Firm size)"  if v1=="ln_sales"
	replace label  = ""  if v1=="ln_sales_se"

	replace label  = " $\ln$(Firm size of \#250)"  if v1=="ln_sales250"
	replace label  = ""  if v1=="ln_sales250_se"

	replace label  = v1  if v1=="Observations"
	replace label  = " $ R^2$" if v1=="R-squared"
	replace label  = subinstr(v1, "_FE", " fixed effects", . ) if regexm(v1, "FE")


	* SET UP TEX
	g begin = "\begin{tabular}{l l c c ccc c ccc}" in 1
	g endt = "\end{tabular} " in 1


	g panelA = "\multicolumn{8}{l}{\textit{Panel A. Gabaix and Landier (2008) }}\\" in 1
	g panelB = "\multicolumn{8}{l}{\textit{Panel B. Estimates in Smith, Yagan, Zidar and Zwick (2018) sample }}\\" in 1

	g mid = "\midrule" in 1
	g top = "\toprule" in 1
	g bot = "\bottomrule" in 1

	g title0 = " & & \multicolumn{9}{c}{ $ \ln$ (Total compensation) }  \\ " in 1
	g title1 = " & & Table 1 & & \multicolumn{7}{c}{Table 2}  \\ " in 1
	g title2 = " & & (4) & & (1) & (2) & (4) & & (5) & (6) & (8)  \\ " in 1
	g title3 = " & &  & & \multicolumn{3}{c}{Top 1000} & & \multicolumn{3}{c}{Top 500}  \\ " in 1


	g title = " & & (1) & & (2) & (3) & (4) & & (5) & (6) & (7)  \\ " in 1

	g cmid0 = "\cmidrule{3-11}" in 1
	g cmid1 = "\cmidrule{3-3} \cmidrule{5-11}" in 1
	g cmid2 = " \cmidrule{5-7} \cmidrule{9-11} " in 1

	g empty = " " 


	*OUTPUT 
	listtex begin if _n == 1 using "$tabdir/appx_table9.tex", replace rstyle(none)
	listtex top if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)
	listtex title0 if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)
	listtex cmid0 if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)

	listtex title if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)
	listtex mid if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)

	listtex title3 if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)
	listtex cmid2 if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)

	**PANEL A
	listtex empty if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(tabular)
	listtex panelA if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)
	listtex empty if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(tabular)
	listtex empty label tab1_col4 empty tab2_col1 tab2_col2 tab2_col4 ///
		empty tab2_col5 tab2_col6 tab2_col8 , appendto("$tabdir/appx_table9.tex") rstyle(tabular)

	**PANEL B
	listtex empty if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(tabular)
	listtex empty if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(tabular)
	listtex panelB if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)
	listtex empty if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(tabular)

	listtex empty label syzz_tab1_col4 empty syzz_tab2_col1 syzz_tab2_col2 syzz_tab2_col4 ///
		empty syzz_tab2_col5 syzz_tab2_col6 syzz_tab2_col8 , appendto("$tabdir/appx_table9.tex") rstyle(tabular)

	listtex bot if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)
	listtex endt if _n == 1, appendto("$tabdir/appx_table9.tex") rstyle(none)

end
