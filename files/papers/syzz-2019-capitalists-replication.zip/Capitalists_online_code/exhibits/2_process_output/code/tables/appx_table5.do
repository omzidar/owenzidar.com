*******************************************************************************
** Appx Table 5: Construction of Owner Death Analysis Sample
*******************************************************************************

capture program drop appx_table5/*%<*/
program define appx_table5

syntax

	clear
	
	set obs 15

	*SETUP TEX TABLE
	g titlerow = " Step & Sample Size at End of Step " in 1
	
	*Tabular
	g tab = "\begin{tabular}{L{6cm} c}" in 1
	*Hline
	g hline = "\hline" in 1
	g top = "\toprule" in 1
	*Midrule
	g mid = "\midrule" in 1 
	*Bottomrule
	g bot = "\bottomrule" in 1
	*End
	g end = "\end{tabular}" in 1

	*CONTENT
	g col1 = ""
	replace col1 = "Distinct firms 2005-2010" in 1
	*
	replace col1 = "Restrict to firms with one owner death 2005-2010" in 3
	*
	replace col1 = "Restrict to dying owners in the top 1\%" in 5
	*
	replace col1 = "Restrict to dying owners under age 65" in 7
	*	
	replace col1 = "Restrict to firms with $ t-1$ sales $ >$\\$100K and positive sales in $ [t-4, t-1]$ " in 9
	*
	replace col1 = "Restrict to firms with at least one pre-period worker" in 11
	*
	replace col1 = "Restrict to firms with dying owner's ownership share $ \geq 20\%$" in 13
	*	
	replace col1 = "Match to at least one counterfactual firm" in 15
	*		
	
	
	g col2 = ""

	replace col2 = "9,489,180" in 1
	*
	replace col2 = "349,039" in 3
	*
	replace col2 = "64,589" in 5
	*
	replace col2 = "18,933" in 7
	*
	replace col2 = "4,676" in 9
	*
	replace col2 = "3,273" in 11
	*
	replace col2 = "2,496" in 13
	*
	replace col2 = "2,436" in 15

		
	****************
	* OUTPUT, calculated using logs
	****************	
	*****Output
	listtex tab if _n == 1 using "$tabdir/appx_table5.tex", replace rstyle(none)
	listtex top if _n == 1, appendto("$tabdir/appx_table5.tex") rstyle(none)
	listtex titlerow if _n == 1, appendto("$tabdir/appx_table5.tex") rstyle(tabular)
	listtex mid if _n == 1, appendto("$tabdir/appx_table5.tex") rstyle(none)	
	listtex col1 col2, appendto("$tabdir/appx_table5.tex") rstyle(tabular)
	listtex bot if _n == 1, appendto("$tabdir/appx_table5.tex") rstyle(none)
	listtex end if _n == 1, appendto("$tabdir/appx_table5.tex") rstyle(none)
	

end
