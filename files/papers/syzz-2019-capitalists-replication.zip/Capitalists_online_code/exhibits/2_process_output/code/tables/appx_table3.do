***********************************************************
* APPX TABLE 3
***********************************************************
capture program drop appx_table3
program define appx_table3 /*<%*/

	local owd = "`c(pwd)'"
	
	cd $tabdo

    * Make the tex tables (if using python 3, comment if using python 2)
    !python py/appx_table3_py3.py

      * Make the tex tables (if using python 3, comment if using python 2)
    *!python py/appx_table3.py

	cd "`owd'"

end /*%>*/
