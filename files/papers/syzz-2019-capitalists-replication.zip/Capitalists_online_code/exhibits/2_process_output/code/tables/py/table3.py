#!/usr/bin/env python

from string import Template
from csv import DictReader, reader
import re, sys, glob

table_templ = """

\\begin{tabular}{l$cols}
%    \\toprule
$header \\\\
\\midrule 
$rows
%    \\bottomrule
%    \\addlinespace
\\end{tabular}
"""

### Table 03.
out = file("table03_a.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(file("../../input/dta/table03_a.csv"))
f.next()
header = """                  & \multicolumn{2}{c}{Top 0.1\% Owners} \\\\ 
                                 \cmidrule(lr){2-3} 
             Industry (NAICS) & Rank & Profits (\$M)"""
rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    r1 = l[0]
    indy = "%s (%s)" % (l[1], l[2])
    profits = str(int(float(l[3])/1e6))
    rows.append(" & ".join([indy, r1, profits]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "r"*(2),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()

### Table 01d_b.
out = file("table03_b.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(file("../../input/dta/table03_b.csv"))
f.next()
header = """                  & \multicolumn{2}{c}{Top 1-0.1\% Owners} \\\\ 
                                 \cmidrule(lr){2-3} 
             Industry (NAICS) & Rank & Profits (\$M) """
rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    r1 = l[0]
    indy = "%s (%s)" % (l[1], l[2])
    profits = str(int(float(l[3])/1e6))
    rows.append(" & ".join([indy, r1, profits]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "r"*(2),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()
