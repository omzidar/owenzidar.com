#!/usr/bin/env python

from string import Template
from csv import DictReader, reader
import re, sys, glob

table_templ = """

\\begin{tabular}{l$cols}
    \\toprule
$header \\\\
\\midrule 
$rows
    \\bottomrule
    \\addlinespace
\\end{tabular}
"""

### Table 8.
out = file("appx_table3.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(file("../../input/dta/appx_table3.csv"))
f.next()
header = """                  & \multicolumn{4}{c}{Top 0.1\% Owners} & &  \multicolumn{4}{c}{Top 1-0.1\% Owners}  \\\\ 
                                 \cmidrule(lr){2-5}   \cmidrule(lr){7-10}
             Industry (NAICS) & S Firms & S Owners & P Firms & P Owners & Industry (NAICS) & S Firms & S Owners & P Firms & P Owners"""
rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    row = l[0]
    indy1 = "%s (%s)" % (l[1], l[2])
    indy2 = "%s (%s)" % (l[8], l[9])
    sfirmcount1 = str(l[4])
    sfirmcount2 = str(l[11])
    pfirmcount1 = str(l[6])
    pfirmcount2 = str(l[13])
    sowncount1 = str(l[5])
    sowncount2 = str(l[12])
    powncount1 = str(l[7])
    powncount2 = str(l[14])
    rows.append(" & ".join([indy1, sfirmcount1, sowncount1, pfirmcount1, powncount1, indy2, sfirmcount2, sowncount2, pfirmcount2, powncount2]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "c"*(4)+"l"+"c"*(4),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()
