#!/usr/bin/env python

from string import Template
from csv import DictReader, reader
import re, sys, glob

table_templ = """

\\begin{tabular}{l$cols}
%    \\toprule
$header \\\\
\\midrule 
$rows
%    \\bottomrule
%    \\addlinespace
\\end{tabular}
"""

### Table 02_a.
out = file("table02_a.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(file("../../input/dta/table02_a.csv"))
f.next()
header = """                 & & Top Passthru & \multicolumn{2}{c}{C-corp} \\\\ 
                                 \cmidrule(lr){3-3} \cmidrule(lr){4-5}
             & Industry (NAICS) & Profit (\$M) & Rank & Profit (\$M)"""
rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    r1 = l[0]
    indy = "%s (%s)" % (l[1], l[2])
    profits = str(int(float(l[3])/1e6))
    r2 = l[4]
    profits2 = str(int(float(l[5])/1e6))
    rows.append(" & ".join([indy, r1, profits, r2, profits2]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "r"*(4),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()

### Table 02_b.
out = file("table02_b.tex", "w+")

out.write("\\footnotesize \n\n")

f = reader(file("../../input/dta/table02_b.csv"))
f.next()
header = """                 & & C-corp & \multicolumn{2}{c}{Top Passthru} \\\\ 
                                 \cmidrule(lr){3-3} \cmidrule(lr){4-5}
             & Industry (NAICS) & Profit (\$M) & Rank & Profit (\$M)"""
rows = []
count = 0
for l in f:
    if count == 15:
        rows.append("\\midrule")
    r1 = l[0]
    indy = "%s (%s)" % (l[1], l[2])
    profits = str(int(float(l[3])/1e6))
    r2 = l[4]
    profits2 = str(int(float(l[5])/1e6))
    rows.append(" & ".join([indy, r1, profits, r2, profits2]) + " \\\\")
    count += 1

out.write(Template(table_templ).substitute({"cols": "r"*(4),
                                          "header": header, 
                                            "rows": "\n".join(rows)}))
out.close()
