
*******************************************************************************
* APPX TABLE 4: Correlate Regressions, TOP 1-0.1% and TOP 0.1%
*******************************************************************************

capture program drop appx_table4
program define appx_table4
	
	use $dtadir/appx_table4, clear
	 
	*EXPORT
		qui{
		g begin = "\begin{tabular}{lcccccccc}" in 1
		g end = "\end{tabular}" in 1

		g title = "& Pass-through & C-corp & Pass-through & C-corp & Pass-through & C-corp & Pass-through & C-corp \\" in 1
		g panelA = "\multicolumn{9}{l}{\textit{Panel A. Top 1-0.1\% Profits by Corporate Form}} \\" in 1
		g panelB = "\multicolumn{9}{l}{\textit{Panel B. Top 0.1\% Profits by Corporate Form}} \\" in 1

		g top = "\toprule" in 1
		g bot = "\bottomrule" in 1
		g mid = "\midrule" in 1
		g cline = "\cmidrule{2-3} \cmidrule{4-5} \cmidrule{6-7} \cmidrule{8-9}" in 1
		g skip = "\\" in 1
		g medskip = "\smallskip \\" in 1
		g c = "&" in 1

	}

	local tabname = "appx_table4"
	listtex begin if _n==1 using "$tabdir/`tabname'.tex", replace rstyle(none)
	listtex top if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)

	listtex panelA if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex mid if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex title if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex cline if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex row *1 *2 *3 *4 if (row<100|row==.) & incgroup=="top101", appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex skip if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex row *1 *2 *3 *4 if row>100 & row!=. & incgroup=="top101", appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex mid if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)

	listtex medskip if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex panelB if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex mid if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex title if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex cline if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex row *1 *2 *3 *4 if (row<100|row==.) & incgroup=="top01", appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex skip if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex row *1 *2 *3 *4 if row>100 & row!=. & incgroup=="top01", appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex bot if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex end if _n==1, appendto("$tabdir/`tabname'.tex") rstyle(none)

end
