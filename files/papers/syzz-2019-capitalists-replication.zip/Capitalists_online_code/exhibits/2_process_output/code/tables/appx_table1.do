
***********************************************************
* APPX TABLE 1
***********************************************************
capture program drop appx_table1
program define appx_table1 /*<%*/

	use $dtadir/appx_table1, clear

	*Clean
	sort type count
	
	keep if lab!=""
	
	*Attempt simple comma solution for strings, as well as rounding for larger numbers
	qui{
	foreach var of varlist *_all *_topdiff *_top01 { 
		rename `var' `var'_temp
		g `var' = `var'_temp
		format `var' %12.2f

		replace `var' = round(`var', .01)
		replace `var' = round(`var') if `var'_temp > 1000
	
		tostring(`var'), replace force usedisplayformat
	
		*Format specific variables, no decimals
		*Firm
		replace `var' = string(real(`var'), "%12.0fc") if inlist(lab, "Sales", "Profits", "Assets", "Number of firm-years", "Entrepreneurial income") 
		*Owner
		replace `var' = string(real(`var'), "%12.0fc") if inlist(lab, "Income", "Wage income", "Pass-through income", "Entrepreneurial income", "Business income","Number of owner-years") 

		*Format specific variables, Only one decimal
		*Firm
		replace `var' = string(real(`var'), "%12.1fc") if inlist(lab, "Number of owners") ///
					| regexm(lab, "Employees") | regexm(lab, "per worker") | regexm(lab, "per owner")
		*Owner
		replace `var' = string(real(`var'), "%12.1fc") if inlist(lab, "Age", "Number of firms owned") 


		*Make sure double zeros are replaced
		replace `var' = subinstr(`var', ".00", "", .)
		replace `var' = "0" if `var'=="-0"

		*Format last rows
		if regexm("`var'", "mean"){
			replace `var' = "\multicolumn{4}{c}{"+ `var'+"}" if lab=="Number of firm-years"|lab=="Number of owner-years"
		}

		drop `var'_temp
	}
	
	
	local num = _N+1
	set obs `num'
	replace type="blank" in `num'

	sort type count
	
	*Tabular
	qui g tab = "\begin{tabular}{lcccccccccccccc}" in 1
	*Hline
	qui g hline = "\hline" in 1
	g top = "\toprule" in 1
	*Midrule
	qui g mid = "\midrule" in 1 
	*Bottomrule
	qui g bot = "\bottomrule" in 1
	*End
	qui g end = "\end{tabular}" in 1
	
	*Space
	g space = "" 
	}

	*COMPLETE TABLE FOR DRAFT
	*Basic column setup
	g panelrow_firm = "& \multicolumn{4}{c}{A. All Firms} & & \multicolumn{4}{c}{B. Firms with Top 1-0.1\% Owner} & & \multicolumn{4}{c}{C. Firms with Top 0.1\% Owner}" in 1
	g panelrow_own = "& \multicolumn{4}{c}{A. All Owners} & & \multicolumn{4}{c}{B. Top 1-0.1\% Owners} & & \multicolumn{4}{c}{C. Top 0.1\% Owners}" in 1
	g labels = " & Mean & p10 & p50 & p90 & & Mean & p10 & p50 & p90 & & Mean & p10 & p50 & p90"
	g firmrow = "\textbf{A. Firm Summary Statistics} " in 1
	g ownerrow = "\textbf{B. Owner Summary Statistics} " in 1
	*Cmid
	g cmid = "\cmidrule{2-5} \cmidrule{7-10} \cmidrule{12-15}" in 1
	g cmid_full = "\cmidrule{1-15}" in 1
	
	*Output
	local tabname="appx_table1"
	listtex tab if _n == 1 using "$tabdir/`tabname'.tex", replace rstyle(none)
	listtex firmrow if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex cmid_full if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex panelrow_firm if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex cmid if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex labels if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex cmid if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex lab *all space *topdiff space *top01 if type=="firm" & varname!="firmobs", appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex lab mean_all space mean_topdiff space mean_top01 if type=="firm" & varname=="firmobs", appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex lab *all space *topdiff space *top01 if type=="blank", appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex ownerrow if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex cmid_full if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex panelrow_own if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex cmid if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex labels if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex cmid if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	listtex lab *all space *topdiff space *top01 if type=="owner" & varname!="ownerobs", appendto("$tabdir/`tabname'.tex") rstyle(tabular)
	listtex lab mean_all space mean_topdiff space mean_top01 if type=="owner" & varname=="ownerobs", appendto("$tabdir/`tabname'.tex") rstyle(tabular)

	listtex end if _n == 1, appendto("$tabdir/`tabname'.tex") rstyle(none)
	
	drop panelrow* firmrow ownerrow

end /*%>*/

