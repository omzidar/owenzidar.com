The files in this folder process input files and create the figures and tables in the paper. 

1. /exhibits/1_run_syzz processes output from /analysis/stata to create 
disclosable input files, which we use to make our main figures and tables. 

2. /exhibits/2_process_output uses the output from /exhibits/code/1_run_syzz
 to make the final tables and figures.

3. master_syzz.do calls the .do files that produce input files, and then calls the .do files used to produce the figures and tables in the paper.