
***********************************************************
* APPX TABLE 11
***********************************************************
capture program drop appx_table11_input
program define appx_table11_input

	
	** INSHEET GABAIX AND LANDIER TABLE 3
		import excel using "$dumpdir/GL_tabs.xlsx", clear sheet(tab3)

		*Rename variables
		local i = 1
		foreach col in B {
			rename `col' tab3_col`i'

			local ++i
		}


		drop in 1


		*Rename for later merge
		rename A v1
		replace v1 = subinstr(v1, "Obs", "Observations", .)
		replace v1 = subinstr(v1, "R2", "R-squared", .)
		replace v1 = subinstr(v1, "Adj ", "", .)

		*Keep se clustered by firm
		replace v1 = v1[_n-1] + "_se" if v1==""
		drop if regexm(v1, "_se_se")

		tempfile tab3

		save `tab3'

	** INSHEET SYZZ RESULTS
		foreach corp in  scorp pship{

		if "`corp'"=="scorp"{
			insheet using "$dbox_rawdir/18_11_09_gabaix/out/gabaixlandier_ts.txt", clear 
		}
		else if "`corp'"=="pship"{
			insheet using "$dbox_rawdir/18_11_13_gabaix/pship/out/gabaixlandier_ts.txt", clear 

		}

	drop in 1 
	drop in `=_N-1'/`=_N'


	drop v2

	drop in 1/2

	* ONLY KEEP 1000 and 500 LARGES
	drop v3-v6

	*Keep se clustered by firm
	replace v1 = v1[_n-1] + "_se" if v1==""
	drop if regexm(v1, "_se_se")

	*Reorder and add a space before observations
	g order = _n
	replace order =  order+1  if inlist(v1, "Observations", "R-squared")

	set obs `=_N+1'
	replace order = `=_N-3' in `=_N'
	sort order

	replace order = -2 if v1=="Sample"
	sort order

	*rename vars
	foreach var of varlist v7-v10 {
		rename `var' `corp'_`var'
	}


	tempfile `corp'
	save ``corp''
	}

	clear

	use `scorp'
	merge 1:1 v1 using `pship', nogen


	** MERGE GL RESULTS
	merge 1:1 v1 using `tab3', nogen

	** CLEAN UP
	drop if regexm(v1, "Constant")

	replace order = -1 if v1=="d_ln_market"
	replace order = -0 if v1=="d_ln_market_se"

	sort order

	save $dtadir/appx_table11, replace

end	
