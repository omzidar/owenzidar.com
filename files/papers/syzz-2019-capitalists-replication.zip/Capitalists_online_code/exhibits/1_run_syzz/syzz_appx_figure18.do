
***********************************************************
* APPX FIGURE 18
***********************************************************

capture program drop appx_figure18_input
program define appx_figure18_input /*<%*/

    *Draw raw data
    import excel "$frraw/psz_replication_fr.xlsx", firstrow sheet("Data") clear

    rename Variable year
    drop if year==""

    *Drop duplicate variables
    drop AP divwlth

    *Drop variables with missing values
    foreach var of varlist _all {
        capture assert mi(`var')
        if !_rc {
            drop `var'
        }
    }

    *Label variables
    ds year, not
    foreach v in `r(varlist)' {
        local newlabel = `v'[1] + " (" + `v'[2] + "): " + `v'[4]
        label var `v' "`newlabel'"
    }
    label var year  "Year"

    *Drop string variables
    drop if string(real(year))!=year

    *Destring all variables
    destring _all, replace

    * Variable adjustments
    gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth

    *Pension, Life Insurance, and IRA Equities & Mutual Funds
    gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ + lifeinsmutfund*equmutfund/liabmutfund + iraequ

    * Change format to numeric variables
    format %5.4f t1_cdiv_natinc-t1_cwlth_hhwlth div_persfactinc-tax_persfactinc cdiv_dom_natinc cdiv_for_natinc
    format %10.1fc natinc hhwlth persfactinc t1_div_dy-psinc_dy divwlth pens_lifeins_ira

    make_psz_components

    * This code builds on Francesco's replication in xpfr-20180608.do

    tempfile orig 
    save `orig'

    *Insheet DINA data to get capital and labor mixed income
    import excel using "$dboxdatadir/piketty-saez-zucman/Dina(Distrib)_QJE.xlsx", sheet(TB2f) clear
    drop in 1/9

    * grab c and s stuff for comparison
    rename A year
    rename E fkcdiv
    rename G fksdiv
    rename H fkmik
    rename L flmil

    keep year f*

    destring _all, replace

    drop if year==.

    tempfile mixinc
    save  `mixinc'

    use `orig', clear

    * Using FR's calculations. Have made some fixes with updated DY data.
	format %13.0g t1_*_prime_ez_allocation t1_*_prime_psz_alloc t1_*_ez_formula t1_*_psz_baseline

	** Trim and save
	keep year t1_sdiv_ez_formula t1_sdiv_psz_baseline t1_cdiv_ez_formula ///
		 t1_cdiv_psz_baseline t1_cret_ez_formula t1_cret_psz_baseline
	keep if inrange(year, 1990, 2014)
	save $dtadir/appx_figure18 , replace
        

end /*%>*/
