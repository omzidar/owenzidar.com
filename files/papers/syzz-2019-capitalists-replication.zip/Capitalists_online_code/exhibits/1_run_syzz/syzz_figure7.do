
***********************************************************
* FIGURE 7 INPUT
***********************************************************
capture program drop figure7_input
program define figure7_input /*<%*/


	*-------------------*
	*----  PANEL A -----*
	*-------------------*
		*Insheet data
		insheet using $dta_majinc/usdinasyzz_2014clps_resub_750.csv, clear

		*Only keep percentiles
		drop if inlist(group, "All", "Millionaires")
		drop if incgroup<12 | incgroup==21 | incgroup==24 |incgroup==25 //dropping anything below P90, and p99-100 and p99.9-99.99, P99.99-100

		*Define value labels
		label drop _all
		label define bins 0 ""
		drop incgroup
		g incgroup = _n
		local n = _N
		forv i=1/`n'{
			qui levelsof group if incgroup==`i', local(label)
			tokenize `label'
			label define bins `i' "`1'", add
		}
		label values incgroup bins 

		*majority income of each type
		foreach var in majkinc majbinc majlinc majhcinc majbinc_adj {
			replace `var' = 100*`var'
		}

		keep incgroup incdefn majkinc majbinc majlinc majhcinc majbinc_adj 

		save "$dtadir/figure7a.dta", replace


	*-------------------*
	*----  PANEL B -----*
	*-------------------*

		import delimited $dta_majinc/usdinasyzz_2014clps_resub_750.csv, clear

		*Get total fiscal and national income
		g totinc_tmp = tot if group=="All"
		egen totinc_all = max(tot), by(year equalsplit incdefn)
		drop *_tmp
		
		*Only keep groups we are interested in
		keep if inlist(group, "P99-100", "Millionaires", "P99.9-100")
		replace group = "Million-dollar earners" if group=="Millionaires"
		
		replace group = "Top 1%" if group=="P99-100"
		replace group = "Top 0.1%" if group=="P99.9-100"
		
		* Put millionaires between top 1% and 0.1%
		replace incgroup = 22 if incgroup == 26
		
		*Rescale shares and vars in billions
		foreach var in pt ptlab ptcap othercap2 c ownerlab otherlab{
			replace `var'=`var'/10^9 
		}
		
		foreach var in  majwaglpen majlab2 majlab2sm sm2 majlab2sm2 sm2workers1 sm2ptowners1 {
			replace `var' = 100*`var'
		}
		
		*Separate capital income into cdiv and other cap inc
		g othcap_minusC = othercap2 - c

		keep group incgroup incdefn majwaglpen majlab2 majlab2sm sm2 sm2workers1 sm2ptowners1

		save "$dtadir/figure7b.dta", replace
		
end
			
