
***********************************************************
* APPX FIGURE 17
***********************************************************

capture program drop appx_figure17_input
program define appx_figure17_input /*<%*/


    ***** PANEL A ******
        import delimited using "$dboxstatadir/raw/asset_comp_by_year.csv", clear

        gen period = cond(inrange(year,1996,1999), 1, ///
                        cond(inrange(year,2003,2007), 2, ///
                            cond(inrange(year,2010,2012), 3, .)))

        label define periodlbl 1 "1996-99" 2 "2003-07" 3 "2010-12"
        label values period periodlbl

        egen hard_assets = rowtotal(net_depbiz_pers_prop net_depbiz_real_prop ///
            net_farmland net_livestock net_other_land net_resrent_prop ///
            net_timber net_all_res)

        egen fin_assets = rowtotal(net_fut_con net_gov_ob net_other_bonds ///
            net_put_call net_te_bond_mut_funds)

        egen stocks = rowtotal(net_corps net_mut_funds)

        collapse (sum) hard_assets stocks fin_assets net_pship_scorp_estate ///
            net_pthrough net_tot, by(period)

        gen corp_mut_share = 100 * (stocks) / net_tot
        gen hard_share = 100 * (hard_assets) / net_tot 
        *gen fin_share = 100 * (fin_assets) / net_tot
        gen passthru_sale_share = 100 * net_pship_scorp_estate / net_tot
        gen passthru_share = 100 * net_pthrough / net_tot
        egen non_other_share = rowtotal(corp_mut_share-passthru_share)
        gen other_share = 100 - non_other
        drop non_other_share

        label var corp_mut_share "Stocks/Mutual Funds"
        label var hard_share "Hard Assets/Real Estate"
        *label var fin_share "Non-Stock Financial Assets"
        label var passthru_share "Pass-through Gains"
        label var passthru_sale_share "Pass-through Asset Sales"
        label var other_share "Other/Unidentified"

		** Trim and save
		keep corp_mut_share-other_share period
        save $dtadir/appx_figure17a , replace

    ***** PANEL B ******
    clear

    tempfile rekg wealth
    * load retained earnings and household equity 
    insheet using "$dumpdir/psz_replication_cre_apportion.csv", clear
    drop if year == .
    * Variable adjustments
    gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth
    * Pension, Life Insurance, and IRA Equities & Mutual Funds
    gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ + lifeinsmutfund*equmutfund/liabmutfund + iraequ
    keep year divwlth pens_lifeins_ira cret
    save `wealth'

    * add realized cap gains
    insheet using "$dboxdir/out/rpiout181018_usdinaclps/usdina19622014clps.csv", clear
    keep if ranktype == "pt" & defn == "psz" & equalsplit == 1
    keep if threshold == 0
    bys year: egen ttkginc = total(kginc)
    bys year: egen ttkgest = total(kgest)
    gen ttkgallinc_dy = 1e-9 * (ttkginc + ttkgest)
    keep year ttkgallinc_dy
    merge 1:1 year using `wealth', keep(3) nogen
    save `rekg'

    * make real
    rename ttkgallinc_dy kg
    usd2014, var(cret) yr(year)
    usd2014, var(kg) yr(year)

    gen cret_frac_real = cret * divwlth / (divwlth + pens_lifeins_ira)
    keep if year > 1961 & year < 2015

	** Trim and save 
	keep year cret cret_frac kg 
    save $dtadir/appx_figure17b , replace


end /*%>*/
