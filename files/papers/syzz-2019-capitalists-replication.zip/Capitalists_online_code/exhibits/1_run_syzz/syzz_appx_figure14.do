
***********************************************************
* APPX FIGURE 14
***********************************************************

capture program drop appx_figure14_input
program define appx_figure14_input /*<%*/

    * Combines data from flow of funds, nipa, psz, irs/bea, and DY's dina clps.
    use "$calebdta/psz_combine_20180612.dta", clear

    * Not sure why units are off for GNP
    replace tot_inc = 10*tot_inc

    tempfile orig
    save  `orig'
    
    global col1 "red*.5"
    global col2 "green*.5"
    global col3 "blue*.5"

   * 1. Original PSZ appendix graph.
    gen mountain_lab = onepct_lab_income
    gen scorp_mount  = s_corp_div1_psz_rep + mountain_lab
    gen re_mount     = c_corp_re1_psz_rep + scorp_mount
    gen oth_mount    = re_mount + oth_onepct_capinc + c_corp_div1_psz_rep
    gen zero         = 0
    
    gen mountain_lab1 = onepct_lab_income
    gen scorp_mount1  = s_corp_div1_psz_rep + mountain_lab
    gen oth_mount1    = scorp_mount1 + oth_onepct_capinc + c_corp_div1_psz_rep + c_corp_re1_psz_rep
    
    replace mountain_lab1 = 100*mountain_lab1
    replace scorp_mount1 = 100*scorp_mount1
    replace oth_mount1 = 100*oth_mount1




    * Taking apart labor and capital
    gen mountain_decomp   = onepct_employee_inc_rawpsz
    gen lab_pens_decomp   = onepct_lab_pension_rawpsz + mountain_decomp
    gen lab_mixed_decomp  = onepct_lab_mixed_rawpsz + lab_pens_decomp
    gen scorp_decomp      = s_corp_div1_psz_rep + lab_mixed_decomp
    gen capmix_inc_decomp = onepct_cap_mixinc_rawpsz + scorp_decomp
    gen re_decomp         = c_corp_re1_psz_rep + capmix_inc_decomp
    gen ccorp_div_decomp  = c_corp_div1_psz_rep + re_decomp
    gen interest_decomp   = net_interest_rawpsz + ccorp_div_decomp
    gen rents_decomp      = interest_decomp + housing_rents_rawpsz
    gen cappens_decomp    = onepct_cap_pension_inc_rawpsz + rents_decomp

    g labinc_area = onepct_employee_inc_rawpsz+onepct_lab_pension_rawpsz
    g capinc_area = capmix_inc_decomp + c_corp_re1_psz_rep+ c_corp_div1_psz_rep+net_interest_rawpsz+housing_rents_rawpsz +onepct_cap_pension_inc_rawpsz
    
    foreach v of varlist mountain_decomp-cappens_decomp labinc_area-capinc_area{
        replace `v' = 100*`v'
    }

    ** Trim and save
	keep mountain_lab1 zero year scorp_mount1 oth_mount1 lab_pens_decomp ///
		 lab_mixed_decomp capmix_inc_decomp scorp_decomp capinc_area cappens_decomp
	keep if inrange(year, 1960, 2014)
	save $dtadir/appx_figure14 , replace



end /*%>*/
