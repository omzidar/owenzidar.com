
***********************************************************
* TABLE 1
***********************************************************
capture program drop table1_input
program define table1_input /*<%*/

	*Insheet S+P Firm data
	qui{
	foreach type in fullsample top1nottoppt1own toppt1own{
		import delimited "$rawdir/spstats_`type'.csv", clear
		
		local obs_`type' = n[6]
		drop n
		
		di "`obs_`type''"

		if "`type'" == "fullsample"{
			local name = "all"
		}
		else if "`type'" == "top1nottoppt1own"{
			local name = "topdiff"
		}
		
		else if "`type'" == "toppt1own"{
			local name = "top01"
		}
				
		qui ds varname, not
		foreach var in `r(varlist)'{
			rename `var' `var'_`name'
		}
		
		qui tempfile firm_`type'
		qui save `firm_`type''
	}
	}

	*Insheet S+P Owner data
	qui{
	local i = 0
	foreach type in fullsample toppt1owner top1nottoppt1owner{
		local ++i
		import delimited "$rawdir/spownerstats_`type'_.csv", clear
		
		local obs_owner_`type' = n[3]

		drop n
		
		if "`type'" == "fullsample"{
			local name = "all"
		}
		else if "`type'" == "top1nottoppt1owner"{
			local name = "topdiff"
		}
		
		else if "`type'" == "toppt1owner"{
			local name = "top01"
		}
				
		qui ds varname, not
		foreach var in `r(varlist)'{
			rename `var' `var'_`name'
		}
				
		tempfile owner_`type'
		save `owner_`type''
	}
	}
	
	*Merge Firm data, S+P
	clear
	use `firm_fullsample'
	merge 1:1 varname using `firm_top1nottoppt1own', nogen
	merge 1:1 varname using `firm_toppt1own', nogen
	g type = "firm"
	
	
	tempfile firm
	save `firm'
	
	*Merge Owner data
	clear
	use `owner_fullsample'
	merge 1:1 varname using `owner_top1nottoppt1owner', nogen
	merge 1:1 varname using `owner_toppt1owner', nogen
	g type = "owner"
	
	append using `firm'
	
	tempfile sp
	save `sp'


	*** INSHEET S, P DATA
	*Insheet S, P Firm data
	foreach corp in s p{
	qui{
	foreach type in fullsample top1nottoppt1own toppt1own{
		import delimited "$rawdir/`corp'stats_`type'.csv", clear

		local obs_`type'_`corp' = n[6]
		drop n
		
		if "`type'" == "fullsample"{
			local name = "all"
		}
		else if "`type'" == "top1nottoppt1own"{
			local name = "topdiff"
		}
		
		else if "`type'" == "toppt1own"{
			local name = "top01"
		}
				
		qui ds varname, not
		foreach var in `r(varlist)'{
			rename `var' `var'_`name'
		}
		
		keep if varname=="Nowners"

		replace varname = varname+"_`corp'" if varname=="Nowners"

		qui tempfile firm_`type'_`corp'
		qui save `firm_`type'_`corp''
	}
	}

	*Insheet S, P Owner data
	qui{
	foreach type in fullsample toppt1owner top1nottoppt1owner{
		import delimited "$rawdir/`corp'ownerstats_`type'_.csv", clear
		
		local obs_owner_`type'_`corp' = n[3]	
		drop n
		if "`type'" == "fullsample"{
			local name = "all"
		}
		else if "`type'" == "top1nottoppt1owner"{
			local name = "topdiff"
		}
		else if "`type'" == "toppt1owner"{
			local name = "top01"
		}
		qui ds varname, not
		foreach var in `r(varlist)'{
			rename `var' `var'_`name'
		}

		keep if varname=="ownerpay_psinc"
		replace varname = subinstr(varname,"_psinc", "_`corp'inc", .) if varname=="ownerpay_psinc"

		tempfile owner_`type'_`corp'
		save `owner_`type'_`corp''
	}
	}
	
	*Merge Firm data
	clear
	use `firm_fullsample_`corp''
	merge 1:1 varname using `firm_top1nottoppt1own_`corp'', nogen
	merge 1:1 varname using `firm_toppt1own_`corp'', nogen
	g type = "firm"
	
	tempfile firm_`corp'
	save `firm_`corp''
	
	*Merge Owner data
	clear
	use `owner_fullsample_`corp''
	merge 1:1 varname using `owner_top1nottoppt1owner_`corp'', nogen
	merge 1:1 varname using `owner_toppt1owner_`corp'', nogen
	g type = "owner"
	
	append using `firm_`corp''
	
	tempfile `corp'
	save ``corp''
	}


	use `sp', clear
	append using `s'
	append using `p'
	
	*Generate table labels - FIRM
	qui{
	g lab = ""
	g count = .
	replace lab = "Sales" if varname=="sales"
	replace count = 1 if lab == "Sales"
	replace lab = "Profits" if varname =="profits"
	replace count = 2 if lab == "Profits"
	replace lab = "Profit margin" if varname =="pm"
	replace count = 3 if lab == "Profit margin"
	replace lab = "Assets" if varname =="TASSEND"
	replace count = 4 if lab == "Assets"
	replace lab = "Employees" if varname =="numw2"
	replace count = 5 if lab == "Employees"
	replace lab = "Employees $\mid$ Employees $>$ 0" if varname =="numw2nz"
	replace count = 6 if lab == "Employees $\mid$ Employees $>$ 0"
	replace lab = "Number of owners" if varname =="Nowners"
	replace count = 7 if lab == "Number of owners"

	replace lab = "Number of owners, S-corp only" if varname =="Nowners_s"
	replace count = 8 if lab == "Number of owners, S-corp only"
	replace lab = "Number of owners, Pship only" if varname =="Nowners_p"
	replace count = 9 if lab == "Number of owners, Pship only"

	replace lab = "Sales per worker" if varname =="sales_w2"
	replace count = 10 if lab == "Sales per worker" 
	replace lab = "Profits per worker" if varname =="profit_w2"
	replace count = 11 if lab == "Profits per worker" 
	replace lab = "Profits per owner" if varname =="profit_owner"
	replace count = 13 if lab == "Profits per owner" 	
	replace lab = "Entrepreneurial income" if varname =="totownerpayment" & type=="firm" 	
	replace count = 14 if lab == "Entrepreneurial income"  & type=="firm" 	
	replace lab = "Entrep. income per owner" if varname =="ownerpay_owner"
	replace count = 15 if lab == "Entrep. income per owner"
	replace lab = "Entrep. income per owner" if varname =="ownerpay_owner"
	replace count = 16 if lab == "Entrep. income per owner"
	replace lab = "Entrep. income per worker" if varname =="ownerpay_w2"
	replace count = 17 if lab == "Entrep. income per worker"	
	replace lab = "Entrep. income / profit" if varname =="ownerpay_profit"
	replace count = 18 if lab == "Entrep. income / profit"		
	replace lab = "Entrep. income / sales" if varname =="ownerpay_sales"
	replace count = 19 if lab == "Entrep. income / sales"
	}

	assert varname != ""
	local new =  _N + 1
	set obs `new'
	replace varname = "firmobs" if varname == "" 
	replace lab = "Number of firm-years" if varname =="firmobs"
	replace type = "firm" if varname =="firmobs"
	replace count = 21 if lab == "Number of firm-years"	

	*fullsample top1nottoppt1own toppt1own
	replace mean_all = `obs_fullsample' if varname =="firmobs"
	replace mean_topdiff = `obs_top1nottoppt1own' if varname =="firmobs"
	replace mean_top01 = `obs_toppt1own' if varname =="firmobs"
	
	*Generate table labels - OWNER
	qui{
	replace lab = "Income" if varname=="psinc"
	replace count = 1 if lab == "Income"
	replace lab = "Age" if varname =="age"
	replace count = 2 if lab == "Age"
	replace lab = "Number of firms owned" if varname =="Nfirms"
	replace count = 3 if lab == "Number of firms owned"
	replace lab = "Wage income" if varname =="totalwages"
	replace count = 4 if lab == "Wage income"	
	replace lab = "Pass-through income" if varname =="totalord_inc"
	replace count = 5 if lab == "Pass-through income"
	replace lab = "Entrepreneurial income" if varname =="totalownerpayments" & type=="owner" 
	replace count = 6 if lab == "Entrepreneurial income" & type=="owner" 
	replace lab = "Pthru income / entrep. income" if regexm(varname,"ordinc_ownerpay")
	replace count = 8 if lab == "Pthru income / entrep. income"	
	replace lab = "Wage income / income" if regexm(varname,"wage_psinc")
	replace count = 9 if lab ==  "Wage income / income" 	
	replace lab = "Entrep. income / income" if regexm(varname,"ownerpay_psinc")
	replace count = 10 if lab ==  "Entrep. income / income"

	replace lab = "Entrep. inc. / inc., S-corp owners only" if regexm(varname,"ownerpay_sinc")
	replace count = 11 if lab ==  "Entrep. inc. / inc., S-corp owners only"
	replace lab = "Entrep. inc. / inc., Pship owners only" if regexm(varname,"ownerpay_pinc")
	replace count = 12 if lab ==  "Entrep. inc. / inc., Pship owners only"

	replace lab = "Business income / income" if regexm(varname,"totalnetcorpinc_psinc")
	replace count = 13 if lab ==  "Business income / income" 
	replace lab = "Only earns passive income" if varname =="onlypassive"
	replace count = 14 if lab == "Only earns passive income" 	
	}

	assert varname != ""
	local new_owner =  _N + 1
	set obs `new_owner'
	replace varname = "ownerobs" if varname == "" 
	replace lab = "Number of owner-years" if varname =="ownerobs"
	replace type = "owner" if varname =="ownerobs"
	replace count = 15 if lab == "Number of owner-years"	

	replace mean_topdiff = `obs_owner_top1nottoppt1owner' if varname =="ownerobs"
	replace mean_top01 = `obs_owner_toppt1owner' if varname =="ownerobs"
	
	save $dtadir/table1.dta, replace

end /*%>*/
