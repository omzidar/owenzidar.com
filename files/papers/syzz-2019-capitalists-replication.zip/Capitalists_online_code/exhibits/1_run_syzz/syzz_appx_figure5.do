
***********************************************************
* APPX FIGURE 5: STATE DISTRIBUTION
***********************************************************

capture program drop appx_figure5_input
program define appx_figure5_input /*<%*/

    * 0. Pull in state population data
    insheet using "$dboxdir/data/census_pop/nst-est2014-01.csv", clear

    keep v1 v6
    rename (v1 v6) (statename pop2014)

    keep if _n>=5 & _n<61

    foreach var in statename pop2014{
        replace `var' = subinstr(`var', ".", "", .)
        replace `var' = subinstr(`var', ",", "", .)
        replace `var' = subinstr(`var', "  ", "", .)
    }

    destring pop2014, replace
    egen totpop = max(pop2014)
    g sh_pop2014 = 100*pop2014/totpop

    drop if inlist(statename, "United States", "West", "South", "Midwest", "Northeast", "District of Columbia")

    *qui Merge stateabbrev
    qui merge 1:1 statename using "$dboxdatadir/fips_statenames_xwalk.dta", nogen keep(3) keepusing(stateabb)

    rename stateabb state
    drop statename
    

    tempfile pop 
    save `pop'

    * 1. Pull in data for C-corps
    insheet using "$dta_firmstats1/state_shares_soi_2014_ccorp.csv", clear
    drop if mi(state)

    *Only keep 50 states
    drop if inlist(state,"","AA", "DC", "PR", "VI", "FR")

    egen tot_profits =  total(profits)
    g s_profits_ccorp  = profits/ tot_profits *100

    keep state s_profits_ccorp

    tempfile ccorp
    save `ccorp'

    foreach incgroup in millionaire top1 toppt1{
        * 2. Pull in data for Top1% owned S-corps
        insheet using "$dta_statestats/state_shares_scorp_2014_`incgroup'.csv", clear
        drop if mi(state)

        *Only keep 50 states
        drop if inlist(state,"","AA", "DC", "PR", "VI", "FR")

        egen tot_profits =  total(profits)

        keep state profits tot_profits

        tempfile scorp_`incgroup'
        save `scorp_`incgroup''
        
        * 3. Pull in data for Top1% owned Pships
        insheet using "$dta_statestats/state_shares_pship_2014_`incgroup'.csv", clear
        drop if mi(state)

        *Only keep 50 states
        drop if inlist(state,"","AA", "DC", "PR", "VI", "FR")

        egen tot_profits =  total(profits)

        keep state profits tot_profits

        tempfile pship_`incgroup'
        save `pship_`incgroup''


        *Collapse S+P
        use `scorp_`incgroup'', clear
        append using `pship_`incgroup''

        collapse (sum) profits tot_profits, by(state)

        g s_profits_pt = profits/tot_profits*100

        tempfile pt_`incgroup'
        save `pt_`incgroup''
    }

	*---- TOP1 ----*
        * 4. combine into a bar graph like original capitalist paper (rpi 14 fig 3c)
        *four types: population share, c-corp profit share, top1 s-corp share, top 1 pship share
        clear
        use `ccorp'
        qui merge 1:1 state using `pt_top1'
        assert _merge==3
        qui drop _merge
        qui merge 1:1 state using `pop'
        assert _merge==3
        qui drop _merge
        

        *Collapse other states
        g state_other = state

        gsort -s_profits_pt
        replace state_other = "Other" if _n>15


        collapse (sum) s_profits* sh_pop* , by(state_other)

        gsort -s_profits_pt

        g order = _n
        replace order = 100 if state_other=="Other"

		g incgroup = "top1"
        save $dtadir/appx_figure5 , replace
		
    *---- MILLIONAIRE ----*
        * 4. combine into a bar graph like original capitalist paper (rpi 14 fig 3c)
        *four types: population share, c-corp profit share, top1 s-corp share, top 1 pship share
        clear
        use `ccorp'
        qui merge 1:1 state using `pt_millionaire'
        assert _merge==3
        qui drop _merge
        qui merge 1:1 state using `pop'
        assert _merge==3
        qui drop _merge
        

        *Collapse other states
        g state_other = state

        *replace state_other = "Other" if s_profits_pt<1.65
        gsort -s_profits_pt
        replace state_other = "Other" if _n>15

        collapse (sum) s_profits* sh_pop* , by(state_other)

        gsort -s_profits_pt

        g order = _n
        replace order = 100 if state_other=="Other"


        g incgroup = "millionaire"
		append using $dtadir/appx_figure5
        save $dtadir/appx_figure5 , replace

  

    *---- TOP0.1 ----*
        * 4. combine into a bar graph like original capitalist paper (rpi 14 fig 3c)
        *four types: population share, c-corp profit share, top1 s-corp share, top 1 pship share
        clear
        use `ccorp'
        qui merge 1:1 state using `pt_toppt1'
        assert _merge==3
        qui drop _merge
        qui merge 1:1 state using `pop'
        assert _merge==3
        qui drop _merge
        

        *Collapse other states
        g state_other = state

        gsort -s_profits_pt
        replace state_other = "Other" if _n>15

        collapse (sum) s_profits* sh_pop* , by(state_other)

        gsort -s_profits_pt

        g order = _n
        replace order = 100 if state_other=="Other"


        g incgroup = "toppt1"
		append using $dtadir/appx_figure5
		
		** Trim and save
		keep s_profits_ccorp s_profits_pt sh_pop state_other incgroup order
		keep if inlist(incgroup, "top1", "millionaire", "toppt1")
        save $dtadir/appx_figure5 , replace


end /*%>*/
