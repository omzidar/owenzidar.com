
***********************************************************
* APPX FIGURE 11
***********************************************************

capture program drop appx_figure11_input
program define appx_figure11_input /*<%*/

    *----- PANEL A ------*  
		use $dboxdatadir/soi-tax-stats/public/dta/soi_public_1980_2014.dta, clear

		local firstyr = 1980
		local lastyr  = 2012

		local shareof "Corporate and Partnership Activity"
		foreach var in nfirms sales profits{
				qui g sh_`var'_sp = (`var'_pship+`var'_scorp)*100/(`var'_ccorp + `var'_scorp + `var'_pship)
			}

		** Trim and save
		keep year sh_nfirms_sp sh_profits_sp sh_sales_sp
		keep if year<=`lastyr'
		save $dtadir/appx_figure11a , replace

    *----- PANEL B and D ------*    
		*Insheet pship data
		foreach type in all top1 top01{ 
			insheet using "$rawdir_decomp/decomp_outP/masked_p_totals_`type'.csv", clear

			g incgroup = "`type'"

			tempfile data_`type'
			save `data_`type''
		}
		*merge income groups
		clear
		use `data_all'
		append using `data_top1'
		append using `data_top01'

		g type = "P"

		tempfile P
		save `P'

		*Insheet scorp data
		foreach type in all top1 top01{ 
			insheet using "$rawdir_decomp/decomp_outS/masked_s_totals_`type'.csv", clear

			g incgroup = "`type'"

			tempfile data_`type'
			save `data_`type''
		}
		*merge income groups
		clear
		use `data_all'
		append using `data_top1'
		append using `data_top01'

		g type = "S"
		tempfile S
		save `S'

		* Append and collapse
		clear
		use `P'
		append using `S'

		*rescale number of firms
		foreach var of varlist nfirms*{
			replace `var'=`var'/10^6
		}

		*Collapse to create S+P
		collapse (sum) nfirms profits , by(year incgroup)

		*create top 1-0.1%
		foreach var in nfirms profits{
			g `var'_tmp = `var' if incgroup=="top01"
			egen `var'_top01 = max(`var'_tmp) if incgroup!="all", by(year)
			replace `var' = `var'-`var'_top01 if incgroup=="top1"
			replace incgroup = "top101" if incgroup=="top1"
			drop *_tmp *_top01
		}

    *Graph Panel B
		* --> figure code cut here

    *Graph Panel D
		drop if year==2000
		*keep if incgroup=="top01"

		sort year
		qui merge m:1 year using "$transform/transformers_deflator_aggregate_20180531.dta",nogen keep(3) keepusing(share_deflator*)
		ds share_deflator*
		foreach var in `r(varlist)' {
			replace `var' = . if incgroup!="top01"
		}
		
		g profits_adj = profits * share_deflator_pthru_01

		foreach outcome in profits profits_adj {
			g `outcome'holder=(year==2001)*`outcome'
			egen `outcome'2001=max(`outcome'holder) 
			g `outcome'_scaled=`outcome'/`outcome'2001
		}
		
		** Trim and save
		keep year incgroup nfirms profits_scaled profits_adj_scaled
		keep if inlist(incgroup, "all", "top101", "top01")
		keep if year>=2001
		save $dtadir/appx_figure11bd , replace


    *----- PANEL C ------*  
		insheet using "$dboxdatadir/naics_4d_correlates.csv", clear
		keep total_profits_pship_20* top*1_profits_app_pship_20* total_profits_loki_20* top*1_profits_app_loki_20* naics_4d
		reshape long top01_profits_app_pship_ total_profits_pship_ ///
					 top01_profits_app_loki_ total_profits_loki_, i(naics_4d) j(year)
		keep if year > 2000

		* outlier: 7139... total profits -4.96e12
		replace total_profits_pship_ = . if naics_4d == 7139 & year == 2007
		gen top01_passthru = top01_profits_app_pship_ + top01_profits_app_loki_
		gen total_passthru = total_profits_pship_ + total_profits_loki_

		merge 1:1 naics_4d year using "$transform/transformers_deflator_nc4_20180531.dta", keep(3) nogen
		gen profits_top01_org = share_deflator_pthru_01 * top01_passthru
		gen profits_total_org = share_deflator_pthru_01 * total_passthru

		collapse (sum) top01_profits_pthru=top01_passthru ///
			total_profits_pthru=total_passthru ///
			profits_*_org, by(year)

		
		foreach outcome of varlist *to*_profits_pthru profits_*_org {
			g `outcome'holder = (year == 2001) * `outcome'
			egen `outcome'2001 = max(`outcome'holder) 
			g `outcome'_scaled = `outcome'/`outcome'2001
		}

		gen tot_scaled_1 = profits_total_org/total_profits_pthru
		gen tot_scaled_2 = 1 - tot_scaled_1
		replace tot_scaled_1 = 1 if year == 2001
		replace tot_scaled_2 = 0 if year == 2001
		
		** Trim and save
		keep year tot_scaled_1 tot_scaled_2
		save $dtadir/appx_figure11c , replace

end /*%>*/
