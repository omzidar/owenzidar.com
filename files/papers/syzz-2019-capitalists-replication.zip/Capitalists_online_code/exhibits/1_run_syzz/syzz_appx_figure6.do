
***********************************************************
* APPX FIGURE 6
***********************************************************

capture program drop appx_figure6_input
program define appx_figure6_input /*<%*/

    * PANEL A: OWNER DEATH
	clear
	save $dtadir/appx_figure6a, replace emptyok
	
    foreach incbracket in top1 toppt1 millionaire{
        capture import delim "$rawdir_ownerdeath/ES_sp_0_64_`incbracket'_profits_numw2pre_dif", clear
            
        drop if strpos(var, "5") != 0 /* Don't want time horizon = 5 */
        local new_obs = _N + 1
        set obs `new_obs'
        qui g t = _n - 5 if _n < 4
        qui replace t = _n - 4 if missing(t)
        qui replace t = -1 in `new_obs'
        sort t
        *Rescale by 1000
        qui replace coef = 0 if missing(coef)
        qui replace stderr = 0 if missing(stderr)

        qui replace coef = coef/1000
        qui replace stderr = stderr/1000

        qui rename (coef stderr) (b se)
		
		gen incgroup = "`incbracket'"
		append using $dtadir/appx_figure6a
		
		** Trim and save
		order incgroup
		keep incgroup b se t
		keep if inlist(incgroup, "top1", "toppt1", "millionaire")
		save $dtadir/appx_figure6a, replace

    }


    * PANEL B: OWNER RET
	clear
	save $dtadir/appx_figure6b, replace emptyok

    foreach incbracket in top1 toppt1 millionaire{
        capture import delim "$rawdir_ownerret/ES_sp_`incbracket'_profits_numw2pre_dif", clear
            
        drop if strpos(var, "5") != 0 /* Don't want time horizon = 5 */
        local new_obs = _N + 1
        set obs `new_obs'
        qui g t = _n - 5 if _n < 4
        qui replace t = _n - 4 if missing(t)
        qui replace t = -1 in `new_obs'
        sort t
        *Rescale by 1000
        qui replace coef = 0 if missing(coef)
        qui replace stderr = 0 if missing(stderr)

        qui replace coef = coef/1000
        qui replace stderr = stderr/1000

        qui rename (coef stderr) (b se)

        gen incgroup = "`incbracket'"
		append using $dtadir/appx_figure6b
		
		** Trim and save
		keep incgroup b se t
		keep if inlist(incgroup, "top1", "toppt1", "millionaire")
		save $dtadir/appx_figure6b, replace
    }


end /*%>*/


