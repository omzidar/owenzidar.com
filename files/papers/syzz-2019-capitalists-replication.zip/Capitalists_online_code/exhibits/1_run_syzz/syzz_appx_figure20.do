
***********************************************************
* APPX FIGURE 20
***********************************************************

capture program drop appx_figure20_input
program define appx_figure20_input /*<%*/


    *Draw raw data
    import excel "$frraw/psz_replication_fr.xlsx", firstrow sheet("Data") clear

    rename Variable year
    drop if year==""

    *Drop duplicate variables
    drop AP divwlth

    *Drop variables with missing values
    foreach var of varlist _all {
        capture assert mi(`var')
        if !_rc {
            drop `var'
        }
    }

    *Label variables
    ds year, not
    foreach v in `r(varlist)' {
        local newlabel = `v'[1] + " (" + `v'[2] + "): " + `v'[4]
        label var `v' "`newlabel'"
    }
    label var year  "Year"

    *Drop string variables
    drop if string(real(year))!=year

    *Destring all variables
    destring _all, replace

    * Variable adjustments
    gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth

    *Pension, Life Insurance, and IRA Equities & Mutual Funds
    gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ + lifeinsmutfund*equmutfund/liabmutfund + iraequ

    * Change format to numeric variables
    format %5.4f t1_cdiv_natinc-t1_cwlth_hhwlth div_persfactinc-tax_persfactinc cdiv_dom_natinc cdiv_for_natinc
    format %10.1fc natinc hhwlth persfactinc t1_div_dy-psinc_dy divwlth pens_lifeins_ira

    make_psz_components
    make_psz_allocation

    *****************************************************************
    * Dollars in 2014 under various scenarios, well labeled
    *****************************************************************
    keep if year == 2014

    * reshape long in 2014
    keep sdiv_v* cdiv_v* cret_v* pship_v* tax_v* year
    #delimit ;
    reshape long sdiv_v cdiv_v cret_v pship_v tax_v, i(year) j(ver);
    #delimit cr

    * put our preferred thing up front and drop pre-tax graph
    drop if ver == 6
    replace ver = ver + 1

    * Reorder 
    g ver_og = ver
    replace ver = 1 if ver_og == 1 //"PSZ (2018)"
    replace ver = 2 if ver_og == 2 //"PSZ Updated"
    replace ver = 3 if ver_og == 8 //"Fiscal Income + RE + Tax"
    replace ver = 4 if ver_og == 9 //"PS (2003) Ranks"
    replace ver = 5 if ver_og == 12 //"Divs Only (A+W)"
    replace ver = 6 if ver_og == 10 //"Divs + 0.25 CapG (A+W)" 
    replace ver = 7 if ver_og == 11 //"Divs + 0.5 CapG (A+W)" 
    replace ver = 8 if ver_og == 3 //"Divs Only" 
    replace ver = 9 if ver_og == 4 //"Add Pships"
    replace ver = 10 if ver_og == 5 //"Divs Only, Pships"
    replace ver = 11 if ver_og == 6 //"Divs Only (A+W), Pships"
    replace ver = 12 if ver_og == 13 //"PSZ Updated, Mixed Income"

    sort ver
	
	** Trim and save
	keep sdiv_v pship_v ver cdiv_v cret_v
	keep if ver != 12
	save $dtadir/appx_figure20 , replace
	


end /*%>*/

