***********************************************************
* FIGURE 9 INPUT
***********************************************************
capture program drop figure9_input
program define figure9_input /*<%*/
	*-------- FISCAL INCOME -----------*

		*Import NI data to get retained earnings
		insheet using "$dboxdir/out/rpiout181018_usdinaclps/usdina19622014clps.csv", clear
		
		*Use PS definition (i.e., FI)
		keep if defn == "ps" 
		*Use ranked by fiinc
		keep if ranktype == "tufi" 

		*Label variables
			* Fiscal income components
			label variable fiwag "Fiscal income, wages and pensions"
			label variable fibus "Fiscal income, business inc"
			label variable firen "Fiscal income, rents"
			label variable fidiv "Fiscal income, dividends"
			label variable fiint "Fiscal income, interest"
			label variable fikgi "Fiscal income, capital gains"	
			label variable fiinc "Fiscal income (incl. KG)"
			label variable fninc "Fiscal income (excl. KG)"	
			label variable fnps "Fiscal income (excl. KG), flat income for non-filers, matching PS shares"	

		*Generate ALL category
		preserve
			keep if threshold == 0
			qui ds year defn threshold equalsplit ranktype, not
			foreach var in `r(varlist)'{
				rename `var' all_`var'
			}

			* Fiscal income components
			label variable all_fiwag "Fiscal income, wages and pensions"
			label variable all_fibus "Fiscal income, business inc"
			label variable all_firen "Fiscal income, rents"
			label variable all_fidiv "Fiscal income, dividends"
			label variable all_fiint "Fiscal income, interest"
			label variable all_fikgi "Fiscal income, capital gains"	
			label variable all_fiinc "Fiscal income (incl. KG)"
			label variable all_fninc "Fiscal income (excl. KG)"	
			label variable all_fnps "Fiscal income (excl. KG), flat income for non-filers, matching PS shares"	

			tempfile all
			save `all'
		restore

		*Collapse top 1-0.1 and 0.1 into just top 1
		keep if threshold==99

		*Merge "all" category
		merge m:1 year defn using `all', nogen //merge is perfect

		* rename the top 1 vars
		qui ds all_*
		foreach var in `r(varlist)'{
			local name = subinstr("`var'", "all_", "", .)
			rename `name' t1_`name'
		}



		*CALCULATE VARIABLES AS SHARE OF TOTAL FISCAL INCOME (NO CAPITAL GAINS) 
		qui ds t1_*
		foreach var in `r(varlist)'{
			replace `var' = 100*`var'/all_fninc
		}


		* Define labor, business and capital income as share of national income 
		* All variables in share 
		gen labinc =  t1_fiwag  //wages
		gen t1_mixedinc = t1_fibus - t1_scorinc - t1_partinc //mixed income
		gen other_cap = t1_firen + t1_fiint //other capital
		gen pshipinc = t1_partinc //partnership income
		gen ptinc = t1_fibus  //pass-through income
		gen ccorp_div = t1_fidiv  //c-corp dividends 
		gen bizinc = ccorp_div+ptinc


		* keep variables of interest
		keep year labinc bizinc other_cap ptinc ccorp_div

		* save
		save "$dtadir/figure9_fi.dta", replace
	


	*-------- IMPUTED NATIONAL INCOME -----------*
		* Combines data from flow of funds, nipa, psz, irs/bea, and DY's dina clps.
	    use "$calebdta/psz_combine_20180612.dta", clear
		
	    replace tot_inc = 10*tot_inc


		/*Keep years 1960-2014*/
		keep if inrange(year, 1960, 2014)

		* Define variables 
		gen onepct_lab_income_M = onepct_lab_income - onepct_lab_mixed_rawpsz 
		gen mixed_income_combine = onepct_lab_mixed_rawpsz + onepct_cap_mixinc_rawpsz 
		gen other_cap1_M = oth_onepct_capinc - onepct_cap_mixinc_rawpsz
		gen passthru_income = mixed_income_combine + s_corp_div1_psz_rep
		gen ccorp_income = c_corp_div1_psz_rep 
		gen ccorp_income_re = c_corp_re1_psz_rep + c_corp_div1_psz_rep 
		gen bizinc = ccorp_income+passthru_income 
		gen bizinc_re = ccorp_income_re+passthru_income 


		qui ds _all 
		foreach var in onepct_lab_income_M mixed_income_combine ///
				other_cap1_M passthru_income ccorp_income ccorp_income_re bizinc bizinc_re { 
			replace `var' = 100*`var' 
		} 

		* keep variables of interest
		keep year onepct_lab_income_M bizinc_re other_cap1_M passthru_income ccorp_income_re 

		rename (onepct_lab_income_M bizinc_re other_cap1_M passthru_income ccorp_income_re ) (labinc bizinc_re other_cap ptinc ccorp_div_re)

		* save
		save "$dtadir/figure9_ini.dta", replace

	*-------- PANEL C -----------*

		* Get labshare directly from tb2f
		import excel using "$dta_majinc/PSZ2017AppendixTablesII(Distrib)_for9c.xlsx", ///
			clear firstrow sheet("tb2f_labshare") cellrange(A1:B54)

		gen psz_labshare_top1_tb2f = tb2f_labshare * 100
		gen incdefn = "ni"
		gen equalsplit = 1

		keep year psz_labshare_top1_tb2f incdefn equalsplit

		tempfile tb2f_labshare
		save `tb2f_labshare', replace

		insheet using $dta_majinc/usdinasyzz_mainclps_resub_750.csv, clear
		
		* Reshape to get the top 1 and all categories separate
		keep if inlist(group, "All", "Top 1", "Top .1", "Top .01")
		g thresh = "_all" if groupnum == 1
		replace thresh = "_top1" if groupnum==3
		replace thresh = "_top01" if groupnum==5
		replace thresh = "_top001" if groupnum==6

		drop group*

		qui ds thresh equal incdefn year, not
		reshape wide `r(varlist)', i(equal incdefn year) j(thresh, string)

		foreach size in top1 top01 top001{
			g `size'_psz_labshare = labnaive_`size'/tot_all * 100
			g `size'_syzz_labshare = labsoph_`size'/tot_all * 100
			g `size'_waglpen = waglpen_`size'/tot_all * 100
		}


		sort year
		

		merge 1:1 year incdefn equalsplit using `tb2f_labshare', assert(1 2 3) nogen

		foreach size in top1 top01 top001 {
			* LABOR SHARE
			g psz_labshare_`size' = labnaive_`size'/tot_`size' * 100 if incdefn == "fi"
			g syzz_labshare_`size' = labsoph_`size'/tot_`size' * 100

			* CAPITAL SHARE
			g psz_capshare_`size' = 100 - psz_labshare_`size'
			g syzz_capshare_`size' = 100 - syzz_labshare_`size'
			
			* WAGE SHARE
			g waglpenshare_`size' = waglpen_`size' / tot_`size' * 100

		}

		replace psz_labshare_top1 = psz_labshare_top1_tb2f if psz_labshare_top1 == . 

		* keep variables of interest
		keep incdefn year waglpenshare_top1  syzz_labshare_top1 psz_labshare_top1
		
		sort year
		keep if year < 2015
		
		save "$dtadir/figure9c.dta", replace
end
