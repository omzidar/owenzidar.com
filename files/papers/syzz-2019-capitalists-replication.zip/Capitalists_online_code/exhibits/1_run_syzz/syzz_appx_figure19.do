
***********************************************************
* APPX FIGURE 19
***********************************************************

capture program drop appx_figure19_input
program define appx_figure19_input /*<%*/


    *Draw raw data
    import excel "$frraw/psz_replication_fr.xlsx", firstrow sheet("Data") clear

    rename Variable year
    drop if year==""

    *Drop duplicate variables
    drop AP divwlth

    *Drop variables with missing values
    foreach var of varlist _all {
        capture assert mi(`var')
        if !_rc {
            drop `var'
        }
    }

    *Label variables
    ds year, not
    foreach v in `r(varlist)' {
        local newlabel = `v'[1] + " (" + `v'[2] + "): " + `v'[4]
        label var `v' "`newlabel'"
    }
    label var year  "Year"

    *Drop string variables
    drop if string(real(year))!=year

    *Destring all variables
    destring _all, replace

    * Variable adjustments
    gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth

    *Pension, Life Insurance, and IRA Equities & Mutual Funds
    gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ + lifeinsmutfund*equmutfund/liabmutfund + iraequ

    * Change format to numeric variables
    format %5.4f t1_cdiv_natinc-t1_cwlth_hhwlth div_persfactinc-tax_persfactinc cdiv_dom_natinc cdiv_for_natinc
    format %10.1fc natinc hhwlth persfactinc t1_div_dy-psinc_dy divwlth pens_lifeins_ira

    make_psz_components
    make_psz_allocation
	
	** Trim and save
	local keepvars
	foreach var in cdiv cret sdiv {
		foreach n in 1 10 9 11 7 {
			local keepvars `keepvars' `var'_v`n'	
		}
	}
	keep year `keepvars'
	keep if inrange(year, 1990, 2014)
	save $dtadir/appx_figure19 , replace
	

end /*%>*/

