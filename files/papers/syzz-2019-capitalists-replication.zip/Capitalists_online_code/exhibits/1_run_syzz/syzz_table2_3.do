
***********************************************************
* TABLE 2-3 INPUT
***********************************************************
capture program drop table2_3_input
program define table2_3_input /*<%*/


    insheet using "$dboxdatadir/naics_4d_correlates.csv", clear
    gen scorp_min = total_profits_loki_real > 100e6 & total_profits_loki_real != .
    gen row = _n

    * Excluding 5511 and having a footnote
    drop if naics_4d == 5511

    * Ccorp profits seem to be three orders of magnitude too small
    replace profits_ccorp_2014 = profits_ccorp_2014*1000


    tempfile orig
    save `orig'

    * Calculate top 1-0.1% profits and apportioned profits
    gen top101_profits_loki_2014 = top1_profits_loki_2014 - top01_profits_loki_2014
    gen top101_profits_app_loki_2014 = top1_profits_app_loki_2014 - top01_profits_app_loki_2014
    gen top101_profits_app_pship_2014 = top1_profits_app_pship_2014 - top01_profits_app_pship_2014

    * With apportioned profits. /*%<*/
    gsort - top101_profits_app_pship_2014
    replace row = _n
    gsort - top101_profits_app_pship_2014
    gen top101_rank = _n
    gsort - top01_profits_app_pship_2014
    gen top01_rank = _n
    gsort - total_profits_pship_2014
    replace row = _n
    format %15.0f total* top* 
    export delimited row longname naics_4d total_profits_pship_2014 ///
        top101_rank top101_profits_app_pship_2014 ///
        top01_rank top01_profits_app_pship_2014 ///
        using $rawdir/fact03.csv, delimit(,) replace
    drop top101_rank top01_rank/*%>*/

    * Table with C-corps versus pass-thru./*%<*/
    recode mill_profits_*_2014 mill_ord_inc_*_2014 (.=0)
    gen mill_passthru_2014 = mill_profits_loki_2014 + mill_profits_pship_2014
    gen mill_passthru_ord_inc_2014 = mill_ord_inc_loki_2014 + mill_ord_inc_pship_2014
    gen millcount_passthru_2014 = mill_firmcount_loki_2014 + mill_firmcount_pship_2014
    gsort - mill_passthru_ord_inc_2014
    gen mill_rank = _n
    gsort - profits_ccorp_2014
    gen ccorp_rank = _n
    format %15.0f mill* profits*
    export delimited row longname naics_4d mill_passthru_2014 mill_passthru_ord_inc_2014 profits_ccorp_2014 ///
        millcount_passthru_2014 count_ccorp_2014 ///
        mill_rank ccorp_rank ///
        using $rawdir/fact02.csv, delimit(,) replace
    drop mill_rank ccorp_rank
    /*%>*/


    ****** MAKE THE TABLES *******

    * Millionaires instead of top 1. /*%<*/
    insheet using $rawdir/fact02.csv, clear
    keep if mill_rank <= 30
    sort mill_rank
    format %15.0f mill* profits*
    keep longname naics_4d mill_passthru_ord_inc_2014 ///
        mill_rank profits_ccorp_2014 ccorp_rank
    order mill_rank longname naics_4d ///
        mill_passthru_ord_inc_2014 ///
        ccorp_rank profits_ccorp_2014 
    outsheet using $dtadir/table02_a.csv, comma replace

    insheet using $rawdir/fact02.csv, clear
    keep if ccorp_rank <= 30
    sort ccorp_rank
    format %15.0f mill* profits*
    keep longname naics_4d mill_passthru_ord_inc_2014 ///
        mill_rank profits_ccorp_2014 ccorp_rank
    order ccorp_rank longname naics_4d ///
        profits_ccorp_2014 ///
        mill_rank mill_passthru_ord_inc_2014 
    outsheet using $dtadir/table02_b.csv, comma replace/*%>*/

    * Pships apportioned.
    insheet using $rawdir/fact03.csv, clear
    keep if top01_rank <= 15
    sort top01_rank
    format %15.0f total*
    keep row longname naics_4d total_profits_pship_2014 ///
        top*_profits_app_pship_2014 ///
        top101_rank top01_rank 
    order top01_rank longname naics_4d ///
        top01_profits_app_pship_2014 ///
        top101_rank top101_profits_app_pship_2014 ///
        row total_profits_pship_2014 
    export delimited using $dtadir/table03_a.csv, delimit(,) replace

    insheet using $rawdir/fact03.csv, clear
    keep if top101_rank <= 15
    sort top101_rank
    format %15.0f total*
    keep row longname naics_4d total_profits_pship_2014 ///
        top*_profits_app_pship_2014 ///
        top101_rank top01_rank 
    order top101_rank longname naics_4d ///
        top101_profits_app_pship_2014 ///
        top01_rank top01_profits_app_pship_2014 ///
        row total_profits_pship_2014 
    export delimited using $dtadir/table03_b.csv, delimit(,) replace/*%>*/



end
