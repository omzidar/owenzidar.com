
*******************************************************************************
* APPX FIGURE 9
******************************************************************************* 
capture program drop appx_figure9_input
program define appx_figure9_input
    
	import delimited $dta_majinc/usdinasyzz_2014clps_resub_750.csv, clear

    *Get total fiscal and national income
    g totinc_tmp = tot if group=="All"
    egen totinc_all = max(tot), by(year equalsplit incdefn)
    drop *_tmp

    *Only keep groups we are interested in
    keep if inlist(group, "P99-100", "Millionaires", "P99.9-100")
    replace group = "Million-dollar earners" if group=="Millionaires"
    replace group = "Top 1%" if group=="P99-100"
    replace group = "Top 0.1%" if group=="P99.9-100"
	
	replace incgroup = 22 if incgroup == 26

    *Rescale shares and vars in billions
    foreach var in pt ptlab ptcap othercap2 c ownerlab otherlab{
        replace `var'=`var'/10^9 //in billions
    }
    
    foreach var in  majwaglpen5 majlab25 majlab2sm5 sm2 majlab2sm25 sm2workers15 sm2ptowners1 {
        replace `var' = 100*`var'
    }
    
    *Separate capital income into cdiv and other cap inc
    g othcap_minusC = othercap2 - c
	
	** Trim and save
	keep majwaglpen5 majlab25 majlab2sm5 sm2 sm2workers15 sm2ptowners1 ///
		 group incgroup incdefn
    save $dtadir/appx_figure9 , replace

end /*%>*/
