
***********************************************************
* APPX TABLE 10
***********************************************************
capture program drop appx_table10_input
program define appx_table10_input

	foreach corp in scorp pship{

	if "`corp'"=="scorp"{
		insheet using "$dbox_rawdir/18_11_09_gabaix/out/gabaixlandier.txt", clear 
	}
	else if "`corp'"=="pship"{
		insheet using "$dbox_rawdir/18_11_13_gabaix/pship/out/gabaixlandier.txt", clear 

	}

	drop in 1 
	drop in `=_N-1'/`=_N'


	drop v2

	*Clean up for merge
	foreach var of varlist v3-v9{
		replace `var' = proper(`var') //to get Yes and No
		replace `var' = subinstr(`var', "T", "tab", .) in 1
		replace `var' = subinstr(`var', " C", "_col", .) in 1

		local varname = `var' in 1

		rename `var' `corp'_`varname'

	}
	replace v1 = subinstr(v1, " FX", "_FE", .)

	drop in 1/2

	*Keep se clustered by firm
	replace v1 = v1[_n-1] + "_se" if v1==""
	drop if regexm(v1, "_se_se")


	g order = _n
	sort order


	tempfile `corp'
	save ``corp''
}

	clear
	use `scorp'
	merge 1:1 v1 using `pship', nogen



	** Drop variables we are not using

	drop if order==. & v1!="group"

	save $dtadir/appx_table10, replace
	
end
