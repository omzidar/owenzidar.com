
***********************************************************
* APPX FIGURE 12
***********************************************************

capture program drop appx_figure12_input
program define appx_figure12_input /*<%*/

    ******* PANEL A, NO TRANSF *******
    foreach incgroup in top1 top01{
    *INSHEET S
    insheet using "$rawdir_decomp/decomp_outS/masked_s_totals_`incgroup'.csv", clear

    keep year sales profits numw2 nfirms nowners totownerpayment totordinc totownerwage wagebill wb_p1099

    g corp="S"

    tempfile scorp
    save `scorp'

    *INSHEET P
    insheet using "$rawdir_decomp/decomp_outP/masked_p_totals_`incgroup'.csv", clear

    keep year sales profits numw2 nfirms nowners totownerpayment totordinc totownerwage wagebill wb_p1099

    g corp="P"

    tempfile pship
    save `pship'

    *COLLAPSE to get total pass-through
    clear
    use `scorp'
    append using `pship'

    collapse (sum) sales profits numw2 nfirms nowners totownerpayment totordinc totownerwage wagebill wb_p1099, by(year)

    label var wagebill "compofcr + slwgljob + penplded + empbene"

    order year 

    rename totownerpayment ownerpay
    rename totownerwage    ownerwage
    rename wb_p1099 wb_w2 
    rename numw2 L 

    * keep subset of vars
    qui g incgroup = "`incgroup'" //define which income group we are looking at

    keep incgroup year L ownerwage totordinc wb_w2 ownerpay

    tempfile data_`incgroup'
    save `data_`incgroup''
    }
    

    *Append income groups
    clear
    foreach incgroup in top1 top01{
        qui append using `data_`incgroup''
    }

    * Create main variables
    qui{
    g va             = totordinc + wb_w2
    g nonowner_wb    = wb_w2- ownerwage
    g s_owner        = ownerpay/va
    g s_worker       = nonowner_wb/va
    g va_L           = va/L *1000000
    g nonowner_wb_L  = nonowner_wb/L *1000000
    }

    foreach var in L ownerwage totordinc wb_w2 ownerpay va nonowner_wb {
        g `var'_adj = `var' 
    }

    order year incgroup va* L* ownerpay* ownerwage* nonowner_wb* totordinc*

    keep year va va_adj va_L L L_adj ownerpay ownerpay_adj ownerwage ownerwage_adj incgroup nonowner_wb nonowner_wb_adj 

    g s_owner      = ownerpay/va
    g s_owner_wage = ownerwage/va

    *summ s_owne*

    tempfile va_orig
    save `va_orig'

    ***** FOR TWO DIFFERENT PRE PERIODS
    foreach yr in 2001 2004{
        use `va_orig', clear
        *******************************************************************************
        * 2. create average values for pre-period and post-period
        *******************************************************************************
        g pre  = inlist(year,`yr')
        g post = inlist(year,2014)

        keep if pre==1 | post==1

        collapse (mean) va va_adj va_L L L_adj ownerpay ownerpay_adj nonowner_wb nonowner_wb_adj ownerwage ownerwage_adj s_owner s_owner_wage, by(post incgroup)

        reshape wide va va_adj va_L L L_adj ownerpay ownerpay_adj nonowner_wb nonowner_wb_adj ownerwage ownerwage_adj s_owner s_owner_wage , i(incgroup) j(post)

        g preyear = `yr'


        *******************************************************************************
        * 3. compute growth rates
        *******************************************************************************

        foreach var in va va_adj va_L L L_adj ownerpay ownerpay_adj ownerwage s_owner s_owner_wage {
            g g_`var'=`var'1/`var'0
            g delta_log_`var' = log(`var'1)-log(`var'0)
        }

        ** TWO DECOMPS
        *share due to redistribution
        g ratio_s_owner2 =  100*delta_log_s_owner/(delta_log_s_owner+ delta_log_va_adj)

        *share due to VA growth
        g ratio_va =  100*delta_log_va_adj/(delta_log_s_owner+ delta_log_va_adj)


        ** THREE DECOMPS
        *share due to redistribution
        g ratio_s_owner3 =  100*delta_log_s_owner/(delta_log_s_owner+ delta_log_va_L+delta_log_L_adj)

        *VA growth per worker
        g ratio_va_L =  100*delta_log_va_L/(delta_log_s_owner+ delta_log_va_L + delta_log_L_adj)

        *workers
        g ratio_L =  100*delta_log_L_adj/(delta_log_s_owner+ delta_log_va_L + delta_log_L_adj)


        tempfile year`yr'
        save `year`yr''
    }


    clear
    use `year2001'
    append using `year2004'


    *******************************************************************************
    * 4. Plot VA decomps
    *******************************************************************************
    g order = 1 if incgroup=="top1"
    replace order = 3 if incgroup=="top01"

    egen id = group(preyear order)

    *LABELS FOR GRAPH
    g owner_yr = "Top 1% (2001-2014)" if id==1 
    replace owner_yr = "Top 0.1% (2001-2014)" if id==2
    replace owner_yr = "Top 1% (2004-2014)" if id==3
    replace owner_yr = "Top 0.1% (2004-2014)" if id==4

	** Trim and save
	keep owner_yr id  ratio_L ratio_va_L ratio_s_owner3 preyear
	save $dtadir/appx_figure12a , replace 
	
    

    ***** PANEL B: PLOT 2004 ******
    use `va_orig', clear

    *KEEP 2001, 2004, 2014
    keep if inlist(year, 2004, 2014)

    replace ownerpay = ownerpay - ownerwage
    replace ownerpay_adj = ownerpay_adj - ownerwage_adj


    foreach var in ownerpay ownerwage nonowner_wb{
        g `var'_va  = 100*`var'_adj/va_adj
    }

    *Make stackable biz income and total owner payment
    preserve
        keep year incgroup nonowner_wb_va
        g stack_cat = "Worker Pay" // setting up the data so we can stack just one of the variables

        tempfile nonowner_wb_va
        save `nonowner_wb_va'
    restore

    preserve
        keep year incgroup ownerwage_va ownerpay_va
        g stack_cat = "Entrep. Inc." // setting up the data so we can stack just one of the variables

        tempfile ownerpay_va
        save `ownerpay_va'
    restore


    clear

    append using `nonowner_wb_va'
    append using `ownerpay_va'


    *CLEAN OWNER TYPE
    g owner_type = "Top 1%" if incgroup=="top1"
    replace owner_type = "Top 0.1%" if incgroup=="top01"
    replace owner_type = "Millionaires" if incgroup=="M"

    g order = 1 if incgroup=="top1"
    replace order = 3 if incgroup=="top01"
    replace order = 2 if incgroup=="M"
	
	** Trim and save
	keep incgroup owner_type ownerpay_va ownerwage_va nonowner_wb_va stack_cat year
	keep if inlist(incgroup, "top1", "top01")
	save $dtadir/appx_figure12b , replace

 

end /*%>*/


