
***********************************************************
* TABLE 4
***********************************************************
capture program drop table4_input
program define table4_input /*<%*/
	
	****************
	*Insheet tables and transpose
	****************

	*Identify column with survival variable
	local i = 1
	foreach type in death retirement{ 

		if "`type'"=="death"{
        local ownd = 1
	    }
	    else if "`type'"=="retirement"{
	        local ownd = 2
	    }

	    if `ownd'==1{
	    insheet using $rawdir/ownerdeaths_table_output.csv, clear 
	    }
	    else if `ownd'==2{
	    insheet using $rawdir/orderlyexits_table_output.csv, clear 
	    }

	    *Reorder rows
	    sort col
	    replace col = col+1 if var=="salesgt0"
	    replace col = col-1 if col[_n]==col[_n-1]
	    sort col


	    *Make preferred percentage impact, need to update if adding more columns
	    g pref_pctg_impact = 10000*coef/outmeancf/ownshare

	    *Save column names
	    local max = _N
	    forv value=1/`max'{
	        local varname`value' = var[`value']
	    }


		tempfile `type'_toclean
		save ``type'_toclean'

		*--- MILLIONAIRES ----*
		*For main table, drop top1 and toppt1
		drop if inlist(sample, "top1", "toppt1")
		
		*Keep S only 
		preserve
		keep if orgform=="s"

		keep in 1

		tempfile s 
		save `s'
		restore

		*Keep S+P only 
		keep if orgform=="sp"
		append using `s'

		tempfile millionaires
		save `millionaires'


		*--- Top 1 ----*
		use ``type'_toclean', clear
		keep if inlist(sample, "top1")

		*Keep S+P only 
		keep if orgform=="sp"
		
		*Only keep profits
		keep in 1

		tempfile top1
		save `top1'

		*--- Top 1 ----*
		use ``type'_toclean', clear
		keep if inlist(sample, "toppt1")

		*Keep S+P only 
		keep if orgform=="sp"
		
		*Only keep profits
		keep in 1

		tempfile top01
		save `top01'


		*--- APPEND ALL ----*
		use `millionaires', clear
		append using `top1' `top01'

		*identify column with survival outcome
		g survival = (var=="salesgt0")

		*Drop variables we won't use
		drop sample var orgform /*flag*/

		*transpose csv to make it easier to make latex tables
		xpose, clear varname
		order _varname 


		if "`type'"=="retirement"{
			forv j = 8(-1)6{
				local j1 = `j'+1
				rename v`j' v`j1'
			}
		}

        ownerdeath_formatting, death_or_retirement(`type')  //program
		
		sort order
		drop if order==.

		foreach var of varlist col* labels {
			rename 	`var' `var'_`i'
		}


		*Save data
		tempfile data_`type'
		save `data_`type''

		local ++i
	}

	use `data_death', clear
	merge 1:1 order using `data_retirement' , nogen
	
	save $dtadir/table4.dta, replace

end /*%>*/
