***********************************************************
* FIGURE 2 INPUT
***********************************************************
capture program drop figure2_input
program define figure2_input /*<%*/

	* ------- PANEL A -----------*
	
	insheet using "$dta_ps03/person_stats_fi_simple/all_2014_byPT.csv", clear case
	keep group N Sinc Pinc incgroup ptowner

	*Only keep percentiles
	drop if inlist(group, "All", "Millionaires")
	drop if incgroup<12 | incgroup==21 | incgroup==23 //dropping anything

	*Define value labels
	label drop _all
	label define bins 0 ""
	drop incgroup
	g incgroup = _n
	local n = _N
	forv i=1/`n'{
		qui levelsof group if incgroup==`i', local(label)
		tokenize `label'
		label define bins `i' "`1'", add
	}
	label values incgroup bins 

	keep if inlist(group,"P98-99", "P99-99.9","P99.9-99.99","P99.99-100")

 	save $dtadir/figure2a.dta, replace

	* ------- PANEL B -----------*

	forv a=1/9{
	insheet using "$dta_age_mean/all_2014_age`a'.csv", clear case

	keep group N majLinc majBinc majKinc majSinc majCinc majPTinc majKGinc inc incgroup agegroup agebin
	recode N majKinc majSinc majCinc majPTinc majKGinc inc incgroup agegroup (.=0)

	tempfile data_age`a'
	save `data_age`a''
	}
	clear

	forv a=1/9{
	append using `data_age`a''
	}


	keep if group=="Millionaires"

	* keep vars of interest
	keep majKinc majLinc majCinc majPTinc agegroup agebin

	* label
	lab var majKinc "majority capital income"
	lab var majLinc "majority labor income"
	lab var majCinc "majority C-corp income"
	lab var majPTinc "majority pass-through income"
	
	*LABEL AGES
	g age=agegroup*10

	*Label values
	lab define agebin 1 "<20"
	lab define agebin 2 "20-29", add
	lab define agebin 3 "30-39", add
	lab define agebin 4 "40-49", add
	lab define agebin 5 "50-59", add
	lab define agebin 6 "60-69", add
	lab define agebin 7 "70-79", add
	lab define agebin 8 "80-89", add
	lab define agebin 9 "90+", add
	lab values agegroup agebin

 	save $dtadir/figure2b.dta, replace

end
