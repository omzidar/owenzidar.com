
***********************************************************
* APPX TABLE 1
***********************************************************
capture program drop appx_table1_input
program define appx_table1_input /*<%*/

	*Insheet S Firm data
	qui{
	foreach type in fullsample top1nottoppt1own toppt1own{
		import delimited "$raw_sumstats/out_sfirms/sstats_`type'.csv", clear
		
		local obs_`type' = n[6]
		drop n
		
		if "`type'" == "fullsample"{
			local name = "all"
		}
		else if "`type'" == "top1nottoppt1own"{
			local name = "topdiff"
		}
		
		else if "`type'" == "toppt1own"{
			local name = "top01"
		}
				
		qui ds varname, not
		foreach var in `r(varlist)'{
			rename `var' `var'_`name'
		}
		
		
		qui tempfile firm_`type'
		qui save `firm_`type''
	}
	}

	*Insheet S Owner data
	qui{
	foreach type in fullsample top1nottoppt1owner toppt1owner{
		import delimited "$raw_sumstats/out_sowners/sownerstats_`type'_.csv", clear
		
		local obs_owner_`type' = n[3]	
		
		drop n
		
		if "`type'" == "fullsample"{
			local name = "all"
		}
		else if "`type'" == "top1nottoppt1owner"{
			local name = "topdiff"
		}
		
		else if "`type'" == "toppt1owner"{
			local name = "top01"
		}
				
		qui ds varname, not
		foreach var in `r(varlist)'{
			rename `var' `var'_`name'
		}
				
		tempfile owner_`type'
		save `owner_`type''
	}
	}
	
	*Merge Firm data
	clear
	use `firm_fullsample'
	merge 1:1 varname using `firm_top1nottoppt1own', nogen
	merge 1:1 varname using `firm_toppt1own', nogen
	g type = "firm"
	
	tempfile firm
	save `firm'
	
	*Merge Owner data
	clear
	use `owner_fullsample'
	merge 1:1 varname using `owner_top1nottoppt1owner', nogen
	merge 1:1 varname using `owner_toppt1owner', nogen
	g type = "owner"
	
	append using `firm'
	
	*Generate table labels - FIRM
	qui{
	g lab = ""
	g count = .
	replace lab = "Sales" if varname=="sales"
	replace count = 1 if lab == "Sales"
	replace lab = "Profits" if varname =="profits"
	replace count = 2 if lab == "Profits"
	replace lab = "Profit margin" if varname =="pm"
	replace count = 3 if lab == "Profit margin"
	replace lab = "Assets" if varname =="TASSEND"
	replace count = 4 if lab == "Assets"
	replace lab = "Employees" if varname =="numw2"
	replace count = 5 if lab == "Employees"
	replace lab = "Employees $\mid$ Employees $ >$ 0" if varname =="numw2nz"
	replace count = 6 if lab == "Employees $\mid$ Employees $ >$ 0"
	replace lab = "Number of owners" if varname =="Nowners"
	replace count = 7 if lab == "Number of owners"
	replace lab = "Sales per worker" if varname =="sales_w2"
	replace count = 8 if lab == "Sales per worker" 
	replace lab = "Profits per worker" if varname =="profit_w2"
	replace count = 9 if lab == "Profits per worker" 
	replace lab = "Profits per worker, employees-weighted" if varname =="wprofit_w2"
	replace count = 10 if lab == "Profits per worker, employees-weighted" 	
	replace lab = "Profits per owner" if varname =="profit_owner"
	replace count = 11 if lab == "Profits per owner" 	
	replace lab = "Entrepreneurial income" if varname =="totownerpayment"
	replace count = 12 if lab == "Entrepreneurial income" 	
	replace lab = "Entrep. income per owner" if varname =="ownerpay_owner"
	replace count = 13 if lab == "Entrep. income per owner"
	replace lab = "Entrep. income per owner" if varname =="ownerpay_owner"
	replace count = 14 if lab == "Entrep. income per owner"
	replace lab = "Entrep. income per worker" if varname =="ownerpay_w2"
	replace count = 15 if lab == "Entrep. income per worker"	
	replace lab = "Entrep. income / profit" if varname =="ownerpay_profit"
	replace count = 16 if lab == "Entrep. income / profit"		
	replace lab = "Entrep. income / sales" if varname =="ownerpay_sales"
	replace count = 17 if lab == "Entrep. income / sales"
	}

	assert varname != ""
	local new =  _N + 1
	set obs `new'
	replace varname = "firmobs" if varname == "" 
	replace lab = "Number of firm-years" if varname =="firmobs"
	replace type = "firm" if varname =="firmobs"
	replace count = 19 if lab == "Number of firm-years"	

	*fullsample top1nottoppt1own toppt1own
	replace mean_all = `obs_fullsample' if varname =="firmobs"
	replace mean_topdiff = `obs_top1nottoppt1own' if varname =="firmobs"
	replace mean_top01 = `obs_toppt1own' if varname =="firmobs"
	
	*Generate table labels - OWNER
	qui{
	replace lab = "Income" if varname=="psinc"
	replace count = 1 if lab == "Income"
	replace lab = "Age" if varname =="age"
	replace count = 2 if lab == "Age"
	replace lab = "Number of firms owned" if varname =="Nfirms"
	replace count = 3 if lab == "Number of firms owned"
	replace lab = "Wage income" if varname =="totalwages"
	replace count = 4 if lab == "Wage income"	
	replace lab = "S-corporation income" if varname =="totalord_inc"
	replace count = 5 if lab == "S-corporation income"
	replace lab = "Entrepreneurial income" if varname =="totalownerpayments"
	replace count = 6 if lab == "Entrepreneurial income"
	replace lab = "S-corp income / entrep. income" if regexm(varname,"ordinc_ownerpay")
	replace count = 8 if lab == "S-corp income / entrep. income"	
	replace lab = "Wage income / income" if regexm(varname,"wage_psinc")
	replace count = 9 if lab ==  "Wage income / income" 	
	replace lab = "Entrep. income / income" if regexm(varname,"ownerpay_psinc")
	replace count = 10 if lab ==  "Entrep. income / income"
	replace lab = "Business income / income" if regexm(varname,"totalnetcorpinc_psinc")
	replace count = 11 if lab ==  "Business income / income" 
	replace lab = "Only earns passive income" if varname =="onlypassive"
	replace count = 12 if lab == "Only earns passive income" 	
	}

	assert varname != ""
	local new_owner =  _N + 1
	set obs `new_owner'
	replace varname = "ownerobs" if varname == "" 
	replace lab = "Number of owner-years" if varname =="ownerobs"
	replace type = "owner" if varname =="ownerobs"
	replace count = 13 if lab == "Number of owner-years"	

	replace mean_all = `obs_owner_fullsample' if varname =="ownerobs"
	replace mean_topdiff = `obs_owner_top1nottoppt1owner' if varname =="ownerobs"
	replace mean_top01 = `obs_owner_toppt1owner' if varname =="ownerobs"
	
	save $dtadir/appx_table1, replace

end /*%>*/
