
*******************************************************************************
* APPX TABLE 4: Correlate Regressions, TOP 1-0.1% and TOP 0.1%
*******************************************************************************

capture program drop appx_table4_input
program define appx_table4_input
	
	****** INSHEET CORRELATES DATA **********
	insheet using "$dboxdatadir/naics_4d_correlates.csv", clear
	
		rename naics_4d nc4 

		foreach prefix in total top01 {
		  foreach suffix in 00_04 10_14 {
			gen `prefix'_mu_oi_`suffix' = 1000*`prefix'_profits_oi_loki_`suffix'/(`prefix'_sales_oi_loki_`suffix'-1000*`prefix'_profits_oi_loki_`suffix')
		  }
		  gen `prefix'_mu_oi_delta = `prefix'_mu_oi_10_14 - `prefix'_mu_oi_00_04
		  gen `prefix'_mu_oi_scptd = 100*(`prefix'_mu_oi_10_14 - `prefix'_mu_oi_00_04)/`prefix'_mu_oi_00_04 if inrange(`prefix'_mu_oi_00_04,0.01,1)
		  gen `prefix'_prof_oi_loki_scptd = 100*(`prefix'_profits_oi_loki_10_14 - `prefix'_profits_oi_loki_00_04)/`prefix'_profits_oi_loki_00_04 if inrange(`prefix'_profits_oi_loki_00_04,100000,99999999999999999999)
		}
	 
		impose_bounds share_deflator_2014, upper(1.5) /*program*/

		g skilled_99_03 = skilled_99_13 - skilled_03_13
		g growth_skilled = skilled_03_13/skilled_99_03
		
		
		* International correlate
		drop intl_profits
		g intl_profits_scorp =  cond(frn_net_incm_scorp_real_99_13 >= 0 & profits_scorp_real_99_13 >= 0, ///
				frn_net_incm_scorp_real_99_13/(profits_scorp_real_99_13 + frn_net_incm_scorp_real_99_13), 0)
		
		g intl_profits_ccorp =  cond(frn_net_incm_ccorp_real_99_13 >= 0 & profits_ccorp_real_99_13 >= 0, ///
				frn_net_incm_ccorp_real_99_13/(profits_ccorp_real_99_13 + frn_net_incm_ccorp_real_99_13), 0)

		
	tempfile correlate_formerge
	save `correlate_formerge'


	** INSHEET CCORP DATA
	use "$dboxdatadir/CBP/byindustry/CBP_ind_bycorpform.dta", clear
		keep if corp=="C" //c-corp
		keep if year==2014

		replace ap = ap*1000
		rename ap wagebill_ccorp
		rename est est_ccorp
		rename emp numw2_ccorp

		keep nc4 *_ccorp

	tempfile ccorp
	save `ccorp'

	** INSHEET SCORP DATA, TOP 1
	insheet using "$rawdir_decomp/decomp_outS/masked_s4d_decomp_top1.csv", clear

		keep if year==2014

		*keep variables we are using
		keep nc4 totownerwage wb_p1099 wagebill numw2 nfirms

		*g non-owner pay
		g owner_wb = totownerwage
		g nonowner_wb = wb_p1099-owner_wb

		qui ds nc4, not
		foreach var in `r(varlist)'{
			rename `var' `var'_scorp
		}

		foreach var of varlist *_scorp{
			rename `var' `var'_top1
		}

	tempfile scorp_top1
	save `scorp_top1'

	** INSHEET SCORP DATA, TOP 0.1
	insheet using "$rawdir_decomp/decomp_outS/masked_s4d_decomp_top01.csv", clear

		keep if year==2014

		*keep variables we are using
		keep nc4 totownerwage wb_p1099 wagebill numw2 nfirms

		*g non-owner pay
		g owner_wb = totownerwage
		g nonowner_wb = wb_p1099-owner_wb

		qui ds nc4, not
		foreach var in `r(varlist)'{
			rename `var' `var'_scorp
		}

		foreach var of varlist *_scorp{
			rename `var' `var'_top01
		}

	tempfile scorp_top01
	save `scorp_top01'

	** INSHEET PSHIP DATA, TOP 1
	insheet using "$rawdir_decomp/decomp_outP/masked_p4d_decomp_top1.csv", clear

		keep if year==2014

		*keep variables we are using
		keep nc4 totownerwage wb_p1099 wagebill numw2 nfirms

		*g non-owner pay
		g owner_wb = totownerwage
		g nonowner_wb = wb_p1099-owner_wb

		qui ds nc4, not
		foreach var in `r(varlist)'{
			rename `var' `var'_pship
		}

		foreach var of varlist *_pship{
			rename `var' `var'_top1
		}

	tempfile pship_top1
	save `pship_top1'

	** INSHEET PSHIP DATA
	insheet using "$rawdir_decomp/decomp_outP/masked_p4d_decomp_top1.csv", clear

		keep if year==2014

		*keep variables we are using
		keep nc4 totownerwage wb_p1099 wagebill numw2 nfirms

		*g non-owner pay
		g owner_wb = totownerwage
		g nonowner_wb = wb_p1099-owner_wb

		qui ds nc4, not
		foreach var in `r(varlist)'{
			rename `var' `var'_pship
		}

		foreach var of varlist *_pship{
			rename `var' `var'_top01
		}

	tempfile pship_top01
	save `pship_top01'


	** INSHEET SOI CORRELATES DATA
	insheet using "$dboxdatadir/soi_indy_correlates_masked_20170210b.csv", clear

		egen mean_officer_share_ccorp_99_14 = mean(mean_officer_share_ccorp), by(naics_4d)
		
		keep if year==2014
		drop year

		keep mean_officer_share_ccorp mean_officer_share_ccorp_99_14 naics_4d
		rename naics_4d nc4
	
	tempfile soi_corr
	save `soi_corr'


	**Merge data sources
		use `correlate_formerge', clear
		merge 1:1 nc4 using `scorp_top1', nogen //keep(3)
		merge 1:1 nc4 using `scorp_top01', nogen //keep(3)
		merge 1:1 nc4 using `pship_top1', nogen //keep(3)
		merge 1:1 nc4 using `pship_top01', nogen //keep(3)
		merge 1:1 nc4 using `ccorp', nogen //keep(3)
		merge 1:1 nc4 using `soi_corr', nogen //keep(3)


	***** SOME NAICS CHANGED, NEED TO FIX AND COLLAPSE
		capture drop if nc4==.
		
		rename nc4 naics_4d
		
		fix_naics
			
		* AVG SOME VARS TO FIX NAICS	
		*Gen SALES WEIGHT FOR MEANS
		egen totsales = rowtotal(total_sales_pship_2014 total_sales_loki_2014 sale_ccorp_2014)
		drop if naics_4d==5175 //not merging because missing key variables
		tempfile orig
		save `orig'
		collapse (sum) *_scorp_top* *_pship_top* *_ccorp top*_profits_* total_profits_loki_2014 total_profits_pship_2014 profits_ccorp_2014 ///
		total_sales_pship_2014 total_sales_loki_2014 sale_ccorp_2014 count_ccorp_2014 capital_scorp_real_99_13 capital_ccorp_real_99_13, by(naics_4d)	

		tempfile sums
		save `sums' 

	* SUM VARS TO FIX NAICS
		use `orig', clear
		collapse (mean) cstat_adv_99_13 cstat_rd_99_13 skilled_99_13 herf_99_13 compuse97 mean_officer_share_scorp_99_13 ///
			mean_officer_share_ccorp mean_officer_share_ccorp_99_14 intl_profits* [aw=totsales], by(naics_4d)
		
	*Fix intl profit outliers
		replace intl_profits_scorp = . if intl_profits_scorp > 10 | intl_profits_scorp < -1
		replace intl_profits_ccorp = . if intl_profits_ccorp > 10 | intl_profits_ccorp < -1

	*Merge summed and mean variables, and reattach industry names
		merge 1:1 naics_4d using `sums', nogen //perfect merge
		rename naics_4d nc4
		merge 1:1 nc4 using `correlate_formerge', nogen keepusing(longname) keep(1 3)
		rename nc4 naics_4d

	*Rename s-corp profits in naics_4d_correlates
		rename top1_profits_app_loki_2014 top1_profits_app_scorp_2014
		rename top01_profits_app_loki_2014 top01_profits_app_scorp_2014

	*GENERATE Top1-0.1 
	foreach var of varlist top1_*{
		local varname = subinstr("`var'", "top1_", "", .)

		g top101_`varname' = top1_`varname' - top01_`varname'
	}

	foreach var of varlist *_top1{
		local varname = subinstr("`var'", "_top1", "", .)

		g `varname'_top101 = `varname'_top1 - `varname'_top01
	}

foreach type in top101 top01{
	*Gen additional correlates and weights, pass-through
	g avg_wages_pt_`type' = (wagebill_scorp_`type'+wagebill_pship_`type')/(numw2_scorp_`type'+numw2_pship_`type')
	g w2_firm_pt_`type' = (numw2_scorp_`type'+numw2_pship_`type')/(nfirms_scorp_`type'+nfirms_pship_`type')
	egen `type'_profits_app_pt_2014 = rowtotal(`type'_profits_app_scorp_2014 `type'_profits_app_pship_2014)
	g capital_per_worker_pt_`type' = capital_scorp_real_99_13/numw2_scorp_`type'
	}

	egen total_sales_pt_2014 = rowtotal(total_sales_loki_2014 total_sales_pship_2014)
	egen total_profits_pt_2014 = rowtotal(total_profits_loki_2014 total_profits_pship_2014)
	g intl_profits_pt=intl_profits_scorp

	*Gen additional correlates, ccorp
	g avg_wages_ccorp = wagebill_ccorp/numw2_ccorp
	g w2_firm_ccorp = numw2_ccorp/count_ccorp_2014
	g capital_per_worker_ccorp= (capital_ccorp_real_99_13)/(numw2_ccorp)

	g mean_officer_share = mean_officer_share_scorp_99_13

	replace profits_ccorp_2014 = 1e3*profits_ccorp_2014

	drop if naics_4d == 6239 //negative pship sales
	drop if naics_4d == 5511 //outlier
	drop if naics_4d == 4246 //negative scorp sales


	* GEN 1D NAICS
	g naics_1d = floor(naics_4d/1000)
		
	tempfile orig
	save `orig'


	*******************************************************************************
	*MAKE CORRELOGRAM, SALES WGT
	*******************************************************************************

	foreach grp in top101 top01{
	* Make correlogram data.
		clear
		tempfile correlogram_sales
		set obs 1
		gen row = .
		save `correlogram_sales'


	*CORRELATES
		#delimit ;
		local lhs_pt `grp'_profits_app_pt_2014 ;
		local wgt_pt total_sales_pt_2014 ;
		local corrs_pt
			cstat_rd_99_13
			capital_per_worker_pt_`grp'
			herf_99_13
			compuse97
			mean_officer_share
			avg_wages_pt_`grp'
			skilled_99_13
			;
		local lhs_ccorp profits_ccorp_2014 ;
		local wgt_ccorp sale_ccorp_2014 ;
		local corrs_ccorp
			cstat_rd_99_13 
			capital_per_worker_ccorp
			herf_99_13
			compuse97
			mean_officer_share
			avg_wages_ccorp
			skilled_99_13
			;
		#delimit cr
			
		local count = 1
		use `orig', clear
		foreach type in pt ccorp {
			foreach v of varlist `corrs_`type'' {

				di as error "`lhs_`type''"
				qui sum `lhs_`type'' [aw=`wgt_`type''] 
				replace `lhs_`type''= `lhs_`type''/`r(sd)'

				qui sum `v' [aw=`wgt_`type''] 
				qui replace `v' = `v'/`r(sd)'
				reg `lhs_`type'' `v' [aw=`wgt_`type''] 
				local b = _b[`v']
				local se = _se[`v']
				local varname = "`v'"
				clear
				set obs 1
				qui gen row = `count'
				qui gen xvar_b = `b'
				qui gen xvar_se = `se'
				g varname = subinstr(subinstr("`varname'", "_`type'", "", .), "_`grp'", "", .)
				g type = "`type'"
				*qui gen ci_upper = `b' + 1.96*`se' 
				*qui gen ci_lower = `b' - 1.96*`se'
				append using `correlogram_sales'
				save `correlogram_sales', replace
				local count = `count' + 1
				use `orig', clear
			}
	}
		
		*RESHAPE DATA
		use `correlogram_sales', clear
	   
		drop if missing(type)
		drop row

		replace type = "_"+type
		
		reshape long xvar, i(varname type) j(coef, string)
		qui g order = 1 if coef=="_b"
		qui replace order = 2 if coef=="_se"	
		drop coef
		reshape wide xvar, i(varname order) j(type, string)

		*SAVE RESULTS
		g row = .
		replace row = 7 if varname=="herf_99_13"
		replace row = 6 if varname=="cstat_rd_99_13"
		replace row = 5 if varname=="capital_per_worker"
		replace row = 4 if varname=="compuse97"
		replace row = 3 if varname=="mean_officer_share"
		replace row = 2 if varname=="avg_wages"
		replace row = 1 if varname=="skilled_99_13"


		#delimit ;
		label define ylabels
			7 "Concentration"		
			6 "R\&D"
			5 "Capital per Worker"		
			4 "Share Using a Computer"
			3 "Officer Share of Wages"
			2 "Average Wages"
			1 "Skill Share of Workers"
			; 
		#delimit cr
		label values row ylabels
		sort row order

		order row order varname *pt *ccorp

		*Rename vars for easier merge later
		foreach type in pt ccorp {
			format xvar_`type' %12.2f
			g coef_`type'_1 = string(xvar_`type', "%12.2f")

			replace coef_`type'_1 = "("+coef_`type'_1+")" if order==2
		}
		
		drop xvar*

		* Add specification identifier
		set obs `=_N+1'
		replace row = 100+1 in `=_N'

		foreach type in pt ccorp {
			replace coef_`type'_1 = "Yes" in `=_N'
		}

		save `correlogram_sales', replace

	************************************************************************************************
	* MAKE CORRELOGRAM, PROFIT WEIGHTS
	************************************************************************************************

	* Make correlogram data.
		clear
		tempfile correlogram_profits
		set obs 1
		gen row = .
		save `correlogram_profits'


	*CORRELATES
		#delimit ;
		local lhs_pt `grp'_profits_app_pt_2014 ;
		local wgt_pt total_profits_pt_2014 ;
		local corrs_pt
			cstat_rd_99_13
			capital_per_worker_pt_`grp'
			herf_99_13
			compuse97
			mean_officer_share
			avg_wages_pt_`grp'
			skilled_99_13
			;
		local lhs_ccorp profits_ccorp_2014 ;
		local wgt_ccorp profits_ccorp_2014 ;
		local corrs_ccorp
			cstat_rd_99_13 
			capital_per_worker_ccorp
			herf_99_13
			compuse97
			mean_officer_share
			avg_wages_ccorp
			skilled_99_13
			;
		#delimit cr
			
		local count = 1
		use `orig', clear
		foreach type in pt ccorp {
			foreach v of varlist `corrs_`type'' {

				di as error "`lhs_`type''"
				keep if `wgt_`type''>0
				qui sum `lhs_`type'' [aw=`wgt_`type''] 
				replace `lhs_`type''= `lhs_`type''/`r(sd)'

				qui sum `v' [aw=`wgt_`type''] 
				qui replace `v' = `v'/`r(sd)'
				reg `lhs_`type'' `v' [aw=`wgt_`type''] 
				local b = _b[`v']
				local se = _se[`v']
				local varname = "`v'"
				clear
				set obs 1
				qui gen row = `count'
				qui gen xvar_b = `b'
				qui gen xvar_se = `se'
				g varname = subinstr(subinstr("`varname'", "_`type'", "", .), "_`grp'", "", .)
				g type = "`type'"
				*qui gen ci = `b' + 1.96*`se' if _n == 1
				*qui replace ci = `b' - 1.96*`se' if _n == 2
				append using `correlogram_profits'
				save `correlogram_profits', replace
				local count = `count' + 1
				use `orig', clear
			}
	}
		
		*RESHAPE DATA
		use `correlogram_profits', clear
		drop if missing(type)
		drop row

		replace type = "_"+type
		
		reshape long xvar, i(varname type) j(coef, string)
		qui g order = 1 if coef=="_b"
		qui replace order = 2 if coef=="_se"	
		drop coef
		reshape wide xvar, i(varname order) j(type, string)

		*SAVE RESULTS
		g row = .
		replace row = 7 if varname=="herf_99_13"
		replace row = 6 if varname=="cstat_rd_99_13"
		replace row = 5 if varname=="capital_per_worker"
		replace row = 4 if varname=="compuse97"
		replace row = 3 if varname=="mean_officer_share"
		replace row = 2 if varname=="avg_wages"
		replace row = 1 if varname=="skilled_99_13"


		#delimit ;
		label define ylabels
			7 "Concentration"		
			6 "R\&D"
			5 "Capital per Worker"		
			4 "Share Using a Computer"
			3 "Officer Share of Wages"
			2 "Average Wages"
			1 "Skill Share of Workers"
			; 
		#delimit cr
		label values row ylabels
		sort row order

		order row order varname *pt *ccorp

		*Rename vars for easier merge later
		foreach type in pt ccorp {
			format xvar_`type' %12.2f
			g coef_`type'_2 = string(xvar_`type', "%12.2f")

			replace coef_`type'_2 = "("+coef_`type'_2+")" if order==2
		}
		
		drop xvar*

		* Add specification identifier
		set obs `=_N+1'
		replace row = 100+2 in `=_N'

		foreach type in pt ccorp {
			replace coef_`type'_2 = "Yes" in `=_N'
		}

		save `correlogram_profits', replace 


	*******************************************************************************
	*MAKE CORRELOGRAM, PROFIT WGT, RESTRICT SAMPLE
	*******************************************************************************

		* Make correlogram data.
		clear
		tempfile correlogram_profits_restricted
		set obs 1
		gen row = .
		save `correlogram_profits_restricted'
			
		local count = 1
		use `orig', clear
		foreach type in pt ccorp {
			foreach v of varlist `corrs_`type'' {

				*Restrict sample
				di as error "`lhs_`type''"
				keep if `wgt_`type''>1e8

				qui sum `lhs_`type'' [aw=`wgt_`type''] 
				replace `lhs_`type''= `lhs_`type''/`r(sd)'

				qui sum `v' [aw=`wgt_`type''] 
				qui replace `v' = `v'/`r(sd)'
				reg `lhs_`type'' `v' [aw=`wgt_`type''] 
				local b = _b[`v']
				local se = _se[`v']
				local varname = "`v'"
				clear
				set obs 1
				qui gen row = `count'
				qui gen xvar_b = `b'
				qui gen xvar_se = `se'
				g varname = subinstr(subinstr("`varname'", "_`type'", "", .), "_`grp'", "", .)
				g type = "`type'"
				append using `correlogram_profits_restricted'
				save `correlogram_profits_restricted', replace
				local count = `count' + 1
				use `orig', clear
			}
	}
		
		*RESHAPE DATA
		use `correlogram_profits_restricted', clear
		drop if missing(type)
		drop row

		replace type = "_"+type
		
		reshape long xvar, i(varname type) j(coef, string)
		qui g order = 1 if coef=="_b"
		qui replace order = 2 if coef=="_se"	
		drop coef
		reshape wide xvar, i(varname order) j(type, string)

		*SAVE RESULTS
		g row = .
		replace row = 7 if varname=="herf_99_13"
		replace row = 6 if varname=="cstat_rd_99_13"
		replace row = 5 if varname=="capital_per_worker"
		replace row = 4 if varname=="compuse97"
		replace row = 3 if varname=="mean_officer_share"
		replace row = 2 if varname=="avg_wages"
		replace row = 1 if varname=="skilled_99_13"


		#delimit ;
		label define ylabels
			7 "Concentration"		
			6 "R\&D"
			5 "Capital per Worker"		
			4 "Share Using a Computer"
			3 "Officer Share of Wages"
			2 "Average Wages"
			1 "Skill Share of Workers"
			; 
		#delimit cr
		label values row ylabels
		sort row order

		order row order varname *pt *ccorp

		*Rename vars for easier merge later
		foreach type in pt ccorp {
			format xvar_`type' %12.2f
			g coef_`type'_3 = string(xvar_`type', "%12.2f")

			replace coef_`type'_3 = "("+coef_`type'_3+")" if order==2
		}
		
		drop xvar*

		* Add specification identifier
		set obs `=_N+1'
		replace row = 100+2 in `=_N'

		foreach type in pt ccorp {
			replace coef_`type'_3 = "Yes" in `=_N'
		}

		set obs `=_N+1'
		replace row = 100+3 in `=_N'

		foreach type in pt ccorp {
			replace coef_`type'_3 = "Yes" in `=_N'
		}


		save `correlogram_profits_restricted', replace 


	*******************************************************************************
	*MAKE CORRELOGRAM, PROFIT WGT, RESTRICT SAMPLE, NAICS 1D CONTROL
	*******************************************************************************

	* Make correlogram data.
		clear
		tempfile correlogram_profits_restr_1d
		set obs 1
		gen row = .
		save `correlogram_profits_restr_1d'

	*CORRELATES	
		local count = 1
		use `orig', clear
		foreach type in pt ccorp {
			foreach v of varlist `corrs_`type'' {

				*Restrict sample
				di as error "`lhs_`type''"
				keep if `wgt_`type''>1e8

				qui sum `lhs_`type'' [aw=`wgt_`type''] 
				replace `lhs_`type''= `lhs_`type''/`r(sd)'

				qui sum `v' [aw=`wgt_`type''] 
				qui replace `v' = `v'/`r(sd)'
				reg `lhs_`type'' `v' i.naics_1d [aw=`wgt_`type''] 
				local b = _b[`v']
				local se = _se[`v']
				local varname = "`v'"
				clear
				set obs 1
				qui gen row = `count'
				qui gen xvar_b = `b'
				qui gen xvar_se = `se'
				g varname = subinstr(subinstr("`varname'", "_`type'", "", .), "_`grp'", "", .)
				g type = "`type'"
				append using `correlogram_profits_restr_1d'
				save `correlogram_profits_restr_1d', replace
				local count = `count' + 1
				use `orig', clear
			}
	}
		
		*RESHAPE DATA
		use `correlogram_profits_restr_1d', clear
		drop if missing(type)
		drop row

		replace type = "_"+type
		
		reshape long xvar, i(varname type) j(coef, string)
		qui g order = 1 if coef=="_b"
		qui replace order = 2 if coef=="_se"	
		drop coef
		reshape wide xvar, i(varname order) j(type, string)

		*SAVE RESULTS
		g row = .
		replace row = 7 if varname=="herf_99_13"
		replace row = 6 if varname=="cstat_rd_99_13"
		replace row = 5 if varname=="capital_per_worker"
		replace row = 4 if varname=="compuse97"
		replace row = 3 if varname=="mean_officer_share"
		replace row = 2 if varname=="avg_wages"
		replace row = 1 if varname=="skilled_99_13"


		#delimit ;
		label define ylabels
			7 "Concentration"		
			6 "R\&D"
			5 "Capital per Worker"		
			4 "Share Using a Computer"
			3 "Officer Share of Wages"
			2 "Average Wages"
			1 "Skill Share of Workers"
			; 
		#delimit cr
		label values row ylabels
		sort row order

		order row order varname *pt *ccorp

		*Rename vars for easier merge later
		foreach type in pt ccorp {
			format xvar_`type' %12.2f
			g coef_`type'_4 = string(xvar_`type', "%12.2f")

			replace coef_`type'_4 = "("+coef_`type'_4+")" if order==2
		}
		
		drop xvar*

		* Add specification identifier
		set obs `=_N+1'
		replace row = 100+2 in `=_N'
		label values row ylabels

		foreach type in pt ccorp {
			replace coef_`type'_4 = "Yes" in `=_N'
		}

		set obs `=_N+1'
		replace row = 100+3 in `=_N'

		foreach type in pt ccorp {
			replace coef_`type'_4 = "Yes" in `=_N'
		}

		set obs `=_N+1'
		replace row = 100+4 in `=_N'

		foreach type in pt ccorp {
			replace coef_`type'_4 = "Yes" in `=_N'
		}

		save `correlogram_profits_restr_1d', replace 



	*******************************************************************************
	*MERGE ALL, MAKE TABLES
	*******************************************************************************
	*Merge
		clear
		use `correlogram_sales'
		merge 1:1 varname row order using `correlogram_profits', nogen

		merge 1:1 varname row order using `correlogram_profits_restricted', nogen

		merge 1:1 varname row order using `correlogram_profits_restr_1d', nogen
		
		g incgroup = "`grp'"

		tempfile data_`grp'
		save `data_`grp''

		
	}

	clear
	append using `data_top101'
	append using `data_top01'


	*Clean up
		drop varname
		lab define ylabels 101 "Weight by Sales", add
		lab define ylabels 102 "Weight by Profits", add
		lab define ylabels 103 "Size $>$100M", add
		lab define ylabels 104 "Control for 1-D NAICS", add
		label values row ylabels

		gsort -incgroup row order

		replace row = . if order==2
		
	save $dtadir/appx_table4, replace
	
end
