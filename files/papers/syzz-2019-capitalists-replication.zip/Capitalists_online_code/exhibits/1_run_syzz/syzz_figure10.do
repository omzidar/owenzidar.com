***********************************************************
* FIGURE 10 INPUT
***********************************************************
capture program drop figure10_input
program define figure10_input /*<%*/

	*------- PANEL A and B -------*

		*Insheet pship data
		foreach type in top1 top01{	
			insheet using $rawdir_decomp/decomp_outP/masked_p_totals_`type'.csv, clear

			g incgroup = "`type'"

			tempfile data_`type'
			save `data_`type''
		}
		*merge income groups
		clear
		use `data_top1'
		append using `data_top01'

		g type = "P"

		tempfile P
		save `P'

		*Insheet scorp data
		foreach type in all top1 top01{	
			insheet using $rawdir_decomp/decomp_outS/masked_s_totals_`type'.csv, clear

			g incgroup = "`type'"

			tempfile data_`type'
			save `data_`type''
		}
		*merge income groups
		clear
		use `data_top1'
		append using `data_top01'

		g type = "S"
		tempfile S
		save `S'

		* Append and collapse
		clear
		use `P'
		append using `S'

		collapse (sum) sales profits numw2 nfirms nowners totownerpayment totordinc totownerwage wagebill wb_p1099, by(year incgroup)

		lab var sales "Sales"
		lab var profits "Profits"
		lab var numw2 "Employment"
		lab var nfirms "Number of firms"
		lab var nowners "Number of owners"
		lab var totownerpayment "Total owner payment"
		lab var totordinc "Total ordinary income"
		lab var totownerwage "Total owner wages"
		lab var wagebill "Total wage bill"
		lab var wb_p1099 "Wage bill plus 1099 contractors"


		rename numw2 L 
		rename totownerpay ownerpay
		rename totownerwage ownerwage
		rename wb_p1099 wb_w2 


		* Only keep 2001-2014
		keep if year>2000


		* Create main variables
		g va             = totordinc + wb_w2
		lab var va "Value added (VA) = total ordinary income plus wage bill and 1099"
		g nonowner_wb    = wb_w2- ownerwage
		lab var nonowner_wb "non-owner wages"
		g s_owner        = ownerpay/va
		lab var s_owner "owner share of VA"
		g s_worker		 = nonowner_wb/va
		lab var s_worker "worker share of VA"


		*FIX OUTLIER IN 2003
		sort incgroup year

		assert year[_n-1]==2002 if year==2003
		assert year[_n+1]==2004 if year==2003
		
		replace va=1/2*(va[_n-1]+va[_n+1]) if year ==2003  // &incgroup=="top01"
		replace ownerpay=1/2*(ownerpay[_n-1]+ownerpay[_n+1]) if year ==2003  //&incgroup=="top01"


		* merge deflator to account for C- to S-/Pship transformations
		qui merge m:1 year using "$transform/transformers_deflator_aggregate_20180531.dta",nogen keep(3)

		* keep variables of interest
		keep year incgroup L va ownerpay share_deflator_pthru_01

		save "$dtadir/figure10ab.dta", replace



	*------- PANEL C and D -------*


		foreach incgroup in top1 top01{
		*INSHEET S
		insheet using "$rawdir_decomp/decomp_outS/masked_s_totals_`incgroup'.csv", clear

		keep year sales profits numw2 nfirms nowners totownerpayment totordinc totownerwage wagebill wb_p1099

		g corp="S"

		tempfile scorp
		save `scorp'

		*INSHEET P
		insheet using "$rawdir_decomp/decomp_outP/masked_p_totals_`incgroup'.csv", clear

		keep year sales profits numw2 nfirms nowners totownerpayment totordinc totownerwage wagebill wb_p1099

		g corp="P"

		tempfile pship
		save `pship'

		*COLLAPSE to get total pass-through
		clear
		use `scorp'
		append using `pship'

		collapse (sum) sales profits numw2 nfirms nowners totownerpayment totordinc totownerwage wagebill wb_p1099, by(year)

		label var wagebill "compofcr + slwgljob + penplded + empbene"

		order year 

		* Rename for ease
		rename totownerpayment ownerpay
		rename totownerwage	   ownerwage
		rename wb_p1099 wb_w2 
		rename numw2 L 

		* keep subset of vars
		qui g incgroup = "`incgroup'" //define which income group we are looking at

		keep incgroup year L ownerwage totordinc wb_w2 ownerpay

		tempfile data_`incgroup'
		save `data_`incgroup''
		}
		

		*Append income groups
		clear
		foreach incgroup in top1 top01{
			qui append using `data_`incgroup''
		}

		* Create main variables
		qui{
		g va             = totordinc + wb_w2
		g nonowner_wb    = wb_w2- ownerwage
		g s_owner        = ownerpay/va
		g s_worker		 = nonowner_wb/va
		g va_L		     = va/L *1000000
		g nonowner_wb_L  = nonowner_wb/L *1000000
		}

		* merge deflator to account for C- to S-/Pship transformations
		qui merge m:1 year using "$transform/transformers_deflator_aggregate_20180531.dta",nogen keep(3)

		* adjust for ``tranformers''
		foreach var in L ownerwage totordinc wb_w2 ownerpay va nonowner_wb {
			g `var'_adj = `var'*share_deflator_pthru_01 
		}

		drop sales_s*

		order year incgroup va* L* ownerpay* ownerwage* nonowner_wb* totordinc*

		* keep variables we need
		keep year va va_adj va_L L L_adj ownerpay ownerpay_adj ownerwage ownerwage_adj incgroup nonowner_wb nonowner_wb_adj 


		g s_owner      = ownerpay/va
		g s_owner_wage = ownerwage/va


		save "$dtadir/figure10cd.dta", replace


end
