
***********************************************************
* FIGURE 4 INPUT
***********************************************************
capture program drop figure4_input
program define figure4_input /*<%*/

	insheet using "$raw_hockey/G_hockey_sp_allsizes_ppw_2014_yesapportion_data.csv", clear

	save "$dtadir/figure4a.dta", replace

	insheet using "$dboxdir/dump/4steph/fig_4b_input.csv", clear

	save "$dtadir/figure4b.dta", replace

end
