
***********************************************************
* APPX TABLE 3
***********************************************************
capture program drop appx_table3_input
program define appx_table3_input /*<%*/

	insheet using "$dboxdatadir/naics_4d_correlates.csv", clear
    gen scorp_min = total_profits_loki_real > 100*10^6 & total_profits_loki_real != .
    gen row = _n

    summ total_profits_loki_real

    * Excluding 5511 and having a footnote
    drop if naics_4d == 5511

	* Top 0.1 and Top 1 % Firma and Owner Counts, S-Corp and P-Ships
	gsort - top01_firmcount_loki_2014
	gen top01_rank = _n
	foreach vartype in loki pship{
		g top101_ownercount_`vartype'_2014 = top1_ownercount_`vartype'_2014 - top01_ownercount_`vartype'_2014
		g top101_firmcount_`vartype'_2014 = top1_firmcount_`vartype'_2014 - top01_firmcount_`vartype'_2014
	}
	gsort - top101_firmcount_loki_2014
	gen top101_rank = _n
	#delimit ;
	keep longname naics_4d *_rank 
		top01_ownercount_loki_2014 
		top01_firmcount_loki_2014 
		top01_firmcount_pship_2014 
	 	top01_ownercount_pship_2014 
		top101_firmcount_loki_2014 
		top101_ownercount_loki_2014 
		top101_firmcount_pship_2014 
		top101_ownercount_pship_2014 ;
	#delimit cr
		
		
	tempfile orig
	save `orig'
	foreach lvl in 01 101{
		keep longname naics_4d top`lvl'*
		g row`lvl' = top`lvl'_rank
		keep if  row`lvl'<=30

		rename (row`lvl' longname naics_4d) (row longname_`lvl' naics_4d_`lvl')

		sort top`lvl'_rank

		tempfile top`lvl'
		save `top`lvl''
		
		use `orig', clear

	}
	use `top01', clear
	merge 1:1 row using `top101', keep(3) nogen
	
    format %12.0f /*total**/ top*
	#delimit ;
    order row longname_01 naics_4d_01
        top01_rank top01_firmcount_loki_2014 top01_ownercount_loki_2014
		top01_firmcount_pship_2014 top01_ownercount_pship_2014
		longname_101 naics_4d_101
		top101_rank top101_firmcount_loki_2014 top101_ownercount_loki_2014
		top101_firmcount_pship_2014 top101_ownercount_pship_2014;
	#delimit cr
    export delimited using "$dtadir/appx_table3.csv", delimit(,) replace

end /*%>*/
