
***********************************************************
* APPX FIGURE 13
***********************************************************

capture program drop appx_figure13_input
program define appx_figure13_input /*<%*/

	** The data for appendix figure 13 is entirely processed online
	import delimited using "$dboxdir/dump/4steph/fig_i13_input.csv", clear
    
	** Trim and save
	keep exited agibin sr1 sr3
	keep if agibin > 50
	save $dtadir/appx_figure13 , replace
	  
end /*%>*/
