
***********************************************************
* APPX TABLE 9 
***********************************************************

capture program drop appx_table9_input
program define appx_table9_input

	* INSHEET GABAIX AND LADIER TABLES 1 and 2
		** TABLE 1
		import excel using "$dumpdir/GL_tabs.xlsx", clear sheet(tab1)

		*Rename variables
		local i = 1
		foreach col in B C D E{
			rename `col' tab1_col`i'

			local ++i
		}


		drop in 1

		*Rename for later merge
		rename A v1
		replace v1 = subinstr(v1, "Obs", "Observations", .)
		replace v1 = subinstr(v1, "R2", "R-squared", .)

		*Keep se clustered by firm
		replace v1 = v1[_n-1] + "_se" if v1==""
		drop if regexm(v1, "_se_se")

		tempfile tab1
		save `tab1'

		** TABLE 2
		import excel using "$dumpdir/GL_tabs.xlsx", clear sheet(tab2)

		*Rename variables
		local i = 1
		foreach col in B C D E F G H I {
			rename `col' tab2_col`i'

			local ++i
		}


		drop in 1

		*Rename for later merge
		rename A v1
		replace v1 = subinstr(v1, "Obs", "Observations", .)
		replace v1 = subinstr(v1, "R2", "R-squared", .)

		replace v1 = subinstr(v1, "ln_market_cap", "ln_sales", .)


		*Keep se clustered by firm
		replace v1 = v1[_n-1] + "_se" if v1==""
		drop if regexm(v1, "_se_se")


		tempfile tab2

		save `tab2'
	
	* INSHEET SYZZ RESULTS
		insheet using "$dbox_rawdir/18_11_13_gabaix/both/out/gabaixlandier.txt", clear

		drop in 1 
		drop in `=_N-1'/`=_N'


		drop v2

	*Clean up for merge
	foreach var of varlist v3-v9{
		replace `var' = proper(`var') //to get Yes and No
		replace `var' = subinstr(`var', "T", "tab", .) in 1
		replace `var' = subinstr(`var', " C", "_col", .) in 1

		local varname = `var' in 1

		rename `var' syzz_`varname'

	}
	replace v1 = subinstr(v1, " FX", "_FE", .)

	drop in 1/2

	*Keep se clustered by firm
	replace v1 = v1[_n-1] + "_se" if v1==""
	drop if regexm(v1, "_se_se")


	g order = _n


	** Merge tab 1, tab 2
	merge 1:1 v1 using `tab1', nogen
	merge 1:1 v1 using `tab2', nogen
	
	sort order
	
*	* Drop variables we are not using
	drop tab1_col1 tab1_col2 tab1_col3 tab2_col3 tab2_col7

	drop if order==. & v1!="group"

	save $dtadir/appx_table9, replace

end
