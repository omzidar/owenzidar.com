
*******************************************************************************
* APPX FIGURE 7
******************************************************************************* 
capture program drop appx_figure7_input
program define appx_figure7_input
    
    *INSHEET TOP 1% DATASET
		insheet using $dta_majinc/usdinasyzz_2014clps_resub_596.csv, clear

        *Get total fiscal and national income
        g totinc_tmp = tot if group=="All"
        egen totinc_all = max(tot), by(year equalsplit incdefn)
        drop *_tmp

        keep if group=="P99-100"
        g order = 1

        tempfile top1
        save  `top1'

    *INSHEET MILLIONAIRE DATASET
		insheet using $dta_majinc/usdinasyzz_2014clps_resub_816.csv, clear

        *Get total fiscal and national income
        g totinc_tmp = tot if group=="All"
        egen totinc_all = max(tot), by(year equalsplit incdefn)
        drop *_tmp

        keep if group=="Millionaires"
        g order = 2

        tempfile mill
        save  `mill'

    *INSHEET TOP 0.1% DATASET
		insheet using $dta_majinc/usdinasyzz_2014clps_resub_717.csv, clear

        *Get total fiscal and national income
        g totinc_tmp = tot if group=="All"
        egen totinc_all = max(tot), by(year equalsplit incdefn)
        drop *_tmp

        keep if group=="P99.9-100"
        g order = 3

        tempfile top01
        save  `top01'

    * APPEND ALL
    clear
    use `top1'
    append using `mill'
    append using `top01'

    sort incdefn order
    
    *RENAME GROUPS
    replace group = "Million-dollar earners" if group=="Millionaires"
    replace group = "Top 1%" if group=="P99-100"
    replace group = "Top 0.1%" if group=="P99.9-100"
	
	replace incgroup = 22 if incgroup == 26


    *Rescale shares and vars in billions
    foreach var in pt ptlab ptcap othercap2 c ownerlab otherlab{
        replace `var'=`var'/10^9 //in billions
    }
    
    foreach var in  majwaglpen majlab2 majlab2sm sm2 majlab2sm2 sm2workers1 sm2ptowners1 {
        replace `var' = 100*`var'
    }

	** Trim and save
	keep majwaglpen majlab2 majlab2sm sm2 sm2workers1 sm2ptowners1 incdefn ///
		 group incgroup year
	save $dtadir/appx_figure7, replace
	

end /*%>*/
