***********************************************************
* APPX FIGURE 4: PROFIT BY PROFIT BIN AND INDUSTRY, TOP 1 and TOP 0.1
***********************************************************

capture program drop appx_figure4_input
program define appx_figure4_input /*<%*/


    ***********************************************************
    * Code, more brackets
    ***********************************************************

    * Define label 
    lab drop _all
    lab define profitbin -1 "<$500k"
    lab define profitbin 0 "$500k-$1m", add
    lab define profitbin 1 "$1m-$5m", add
    lab define profitbin 2 "$5m-$10m", add
    lab define profitbin 3 "$10m-$25m", add
    lab define profitbin 4 "$25m-$50m", add
    lab define profitbin 5 "$50m-$100m", add
    lab define profitbin 6 "$100m-$250m", add
    lab define profitbin 7 "$250m+", add


    * 1. Pull in data for C-corps
    insheet using "$dta_firmstats3/size_bins_soi_v4.do/profitbin_soi_2014_ccorp.csv", clear
    drop if profitbin==-1

    replace profitbin = 7 if profitbin==8
    collapse (sum) nfirms profits, by(profitbin)

    *Label value
    lab values profitbin profitbin

    //Conditional on sales >500k
    egen tot_firms   =  total(nfirms)
    g s_firms_ccorp  = nfirms/ tot_firms *100

    egen tot_profits =  total(profits)
    g s_profits_ccorp  = profits/ tot_profits *100

    rename (nfirms profits) (nfirms_ccorp profits_ccorp)

    keep profitbin s_firms_ccorp s_profits_ccorp nfirms_ccorp profits_ccorp

    tempfile ccorp
    save `ccorp'


    foreach incgroup in millionaire top1 toppt1{
        * 2. Pull in data for millionaire-owned scorps
        insheet using "$dta_firmstats3/size_bins_scorp_v5.do/profitbin_scorp_2014_`incgroup'.csv", clear
        drop if profitbin==-1

        replace profitbin = 7 if profitbin==8
        collapse (sum) nfirms profits, by(profitbin)

        *Label value
        lab values profitbin profitbin

        //Conditional on sales >500k
        egen tot_firms   =  total(nfirms)
        egen tot_profits =  total(profits)

        keep profitbin  *firms *profits

        tempfile scorp_`incgroup'
        save `scorp_`incgroup''

        * 3. Pull in data for millionaire-owned pships
        insheet using "$dta_firmstats3/size_bins_pship_v5.do/profitbin_pship_2014_`incgroup'.csv", clear
        drop if profitbin==-1

        *Label value
        lab values profitbin profitbin

        replace profitbin = 7 if profitbin==8
        collapse (sum) nfirms profits, by(profitbin)

        //Conditional on sales >500k
        egen tot_firms   =  total(nfirms)
        egen tot_profits =  total(profits)

        keep profitbin *firms *profits

        tempfile pship_`incgroup'
        save `pship_`incgroup''


        //Collapse S+P
        use `scorp_`incgroup'', clear
        append using `pship_`incgroup''

        collapse (sum) *firms *profits , by(profitbin)

        g s_firms_pt = nfirms/tot_firms*100 
        g s_profits_pt = profits/tot_profits*100 

        drop tot_*

        rename (nfirms profits) (nfirms_pt profits_pt)

        tempfile pt_`incgroup'
        save `pt_`incgroup''
    }

    *---- TOP 1 -----*
    * 4. combine, TOP 1 GRAPHS
    clear
    use `ccorp'
    qui merge 1:1 profitbin using `pt_top1'
    assert _merge==3
    qui drop _merge

    g incgroup = "top1"

    tempfile top1
    save `top1'


    *---- TOP 0.1 -----*
    * 4. combine, TOP 0.1 GRAPHS
    clear
    use `ccorp'
    qui merge 1:1 profitbin using `pt_toppt1'
    assert _merge==3
    qui drop _merge

    g incgroup = "toppt1"

    tempfile toppt1
    save `toppt1'

    
	append using `top1'
	
	** Trim and save
	keep s_profits_ccorp s_profits_pt profitbin incgroup
	keep if inlist(incgroup, "top1", "toppt1")
	save $dtadir/appx_figure4 , replace
	

end /*%>*/

