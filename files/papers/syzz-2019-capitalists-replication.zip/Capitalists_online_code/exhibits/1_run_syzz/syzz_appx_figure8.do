
***********************************************************
* APPX FIGURE 8, CONSERVARTIVE
***********************************************************

capture program drop appx_figure8_input
program define appx_figure8_input /*<%*/

	*INSHEET TOP 1% DATASET
		insheet using $dta_majinc/usdinasyzz_2014clps_resub_596.csv, clear
		
        *Get total fiscal and national income
        g totinc_tmp = tot if group=="All"
        egen totinc_all = max(tot), by(year equalsplit incdefn)
        drop *_tmp

        keep if group=="P99-100"
        g order  = 1

        tempfile top1
        save  `top1'

    *INSHEET MILLIONAIRE DATASET
		insheet using $dta_majinc/usdinasyzz_2014clps_resub_816.csv, clear
		
        *Get total fiscal and national income
        g totinc_tmp = tot if group=="All"
        egen totinc_all = max(tot), by(year equalsplit incdefn)
        drop *_tmp

        keep if group=="Millionaires"
        g order  = 2

        tempfile mill
        save  `mill'

    *INSHEET TOP 0.1% DATASET
		insheet using $dta_majinc/usdinasyzz_2014clps_resub_717.csv, clear

        *Get total fiscal and national income
        g totinc_tmp = tot if group=="All"
        egen totinc_all = max(tot), by(year equalsplit incdefn)
        drop *_tmp

        keep if group=="P99.9-100"
        g order  = 3

        tempfile top01
        save  `top01'

    * APPEND ALL
    clear
    use `top1'
    append using `mill'
    append using `top01'



    *RENAME GROUPS
    replace group = "Million-dollar earners" if group=="Millionaires"
    replace group = "Top 1%" if group=="P99-100"
    replace group = "Top 0.1%" if group=="P99.9-100"

	replace incgroup = 22 if incgroup == 26


    *Rescale shares and vars in billions
    foreach var in pt ptlab ptcap othercap2 othercap3 c ownerlab otherlab othercap {
        replace `var'=`var'/10^9 //in billions
    }
    
    *Separate capital income into cdiv and other cap inc
    g othcap_minusC = othercap2 - c if incdefn == "fi"
    replace othcap_minusC = othercap3 - c if incdefn == "ni"
	
    ** Trim and save
	keep othcap_minusC c ptcap ptlab ownerlab otherlab group incgroup year incdefn
	save $dtadir/appx_figure8, replace

end/*%>*/
