***********************************************************
* FIGURE 8 INPUT
***********************************************************
capture program drop figure8_input
program define figure8_input /*<%*/

	*-------------------*
	*----  PANEL A -----*
	*-------------------*

		*Insheet data
		import delimited $dta_majinc/usdinasyzz_2014clps_resub_750.csv, clear
		
		*Only keep percentiles
		drop if inlist(group, "All", "Millionaires")
		drop if incgroup<12 | incgroup==21 | incgroup==24 |incgroup==25 //dropping anything below P90, and p99-100 and p99.9-99.99, P99.99-100

		*Define value labels
		label drop _all
		label define bins 0 ""
		drop incgroup
		g incgroup = _n
		local n = _N
		forv i=1/`n'{
			qui levelsof group if incgroup==`i', local(label)
			tokenize `label'
			label define bins `i' "`1'", add
		}
		label values incgroup bins 

		gen labor = 100 * waglpen / tot
		gen business = 100 * (c + pt) / tot
		gen othercapital = 100 * othercap / tot

		gen labor_plus_75 = 100 * (waglpen + ptlab) / tot
		gen biz_minus_75 = 100 * (c + ptcap) / tot


		* keep variables of interest
		keep incgroup incdefn labor business othercapital biz_minus_75 labor_plus_75

		save "$dtadir/figure8a.dta", replace

	*-------------------*
	*----  PANEL B -----*
	*-------------------*
	
		import delimited $dta_majinc/usdinasyzz_2014clps_resub_750.csv, clear
		
		*Get total fiscal and national income
		g totinc_tmp = tot if group=="All"
		egen totinc_all = max(tot), by(year equalsplit incdefn)
		drop *_tmp

		*Only keep groups we are interested in
		keep if inlist(group, "P99-100", "Millionaires", "P99.9-100")
		replace group = "Million-dollar earners" if group=="Millionaires"
		
		replace group = "Top 1%" if group=="P99-100"
		replace group = "Top 0.1%" if group=="P99.9-100"
		
		replace incgroup = 22 if incgroup == 26

		*Rescale shares and vars in billions
		foreach var in pt ptlab ptcap othercap2 othercap3 c ownerlab otherlab othercap {
			replace `var'=`var'/10^9 //in billions
		}
		
		*Separate capital income into cdiv and other cap inc
		g othcap_minusC = othercap2 - c if incdefn == "fi"
		replace othcap_minusC = othercap3 - c if incdefn == "ni"
	
		
		*keep variables of interest
		keep incgroup group incdefn othcap_minusC c ptcap ptlab ownerlab otherlab othercap2

		save "$dtadir/figure8b.dta", replace

end
