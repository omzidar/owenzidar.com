
***********************************************************
* APPX FIGURE 16
***********************************************************

capture program drop appx_figure16_input
program define appx_figure16_input /*<%*/

    *Draw raw data
    import excel "$frraw/psz_replication_fr.xlsx", firstrow sheet("Data") clear

    rename Variable year
    drop if year==""

    *Drop duplicate variables
    drop AP divwlth

    *Drop variables with missing values
    foreach var of varlist _all {
        capture assert mi(`var')
        if !_rc {
            drop `var'
        }
    }

    *Label variables
    ds year, not
    foreach v in `r(varlist)' {
        local newlabel = `v'[1] + " (" + `v'[2] + "): " + `v'[4]
        label var `v' "`newlabel'"
    }
    label var year  "Year"

    *Drop string variables
    drop if string(real(year))!=year

    *Destring all variables
    destring _all, replace

    * Variable adjustments
    gen divwlth = hhequ + monmkt_nonmuni - corpequ_nonprof - monmkt_nonprof - iraequ - swlth

    *Pension, Life Insurance, and IRA Equities & Mutual Funds
    gen pens_lifeins_ira = pensequ + pensmutfund*equmutfund/liabmutfund + lifeinsequ + lifeinsmutfund*equmutfund/liabmutfund + iraequ

    * Change format to numeric variables
    format %5.4f t1_cdiv_natinc-t1_cwlth_hhwlth div_persfactinc-tax_persfactinc cdiv_dom_natinc cdiv_for_natinc
    format %10.1fc natinc hhwlth persfactinc t1_div_dy-psinc_dy divwlth pens_lifeins_ira

    make_psz_components
    make_psz_allocation
    
    foreach year in 1990 2000{

        local start = `year'

        if "`start'"=="1990"{
            local letter="a"
        }
        else if "`start'"=="2000"{
            local letter="b"
        }


        tempfile orig
        save `orig'

        forval i=0/12 {
            gen equity_v`i' = sdiv_v`i' + cdiv_v`i' + cret_v`i'
            gen bizinc_v`i' = sdiv_v`i' + cdiv_v`i' + cret_v`i' + pship_v`i'

            * Non-labor nobiz is top 1 psz income - employee payments - 
            * passthru - ccorp income => pension income + int + rents
            gen capinc_v`i' = bizinc_v`i' + non_labor_nobiz
            gen othcap_v`i' = non_labor_nobiz
            gen topinc_v`i' = bizinc_v`i' + non_biz
            gen othinc_v`i' = non_biz
        }
        keep if year == `start' | year == 2014
        sort year

        gen ratio = 1e-9 * ttptinc_dy/natinc
        qui sum ratio
        gen totalinc = 1e-9 * ttptinc_dy

        #delimit ;
        foreach v in "equity" "sdiv" "cdiv" "cret" {;
            forval i=0/12 {;
                gen `v'_growth_v`i' = (100 * `v'_v`i'[2]/totalinc[2]) - 
                                      (100 * `v'_v`i'[1]/totalinc[1]);
                if ("`v'" != "equity") {;
                    gen `v'_Egrowthshare_v`i' = `v'_growth_v`i'/equity_growth_v`i';           
                };
            };
        };
        foreach v in "bizinc" "sdiv" "cdiv" "cret" "pship" {;
            forval i=0/12 {;
                cap gen `v'_growth_v`i' = (100 * `v'_v`i'[2]/totalinc[2]) - 
                                      (100 * `v'_v`i'[1]/totalinc[1]);
                if ("`v'" != "bizinc") {;
                    gen `v'_Bgrowthshare_v`i' = `v'_growth_v`i'/bizinc_growth_v`i';           
                };
            };
        };
        foreach v in "capinc" "sdiv" "cdiv" "cret" "pship" "othcap" {;
            forval i=0/12 {;
                cap gen `v'_growth_v`i' = (100 * `v'_v`i'[2]/totalinc[2]) - 
                                      (100 * `v'_v`i'[1]/totalinc[1]);
                if ("`v'" != "capinc") {;
                    gen `v'_Kgrowthshare_v`i' = `v'_growth_v`i'/capinc_growth_v`i';           
                };
            };
        };
        foreach v in "topinc" "sdiv" "cdiv" "cret" "pship" "othinc" {;
            forval i=0/12 {;
                cap gen `v'_growth_v`i' = (100 * `v'_v`i'[2]/totalinc[2]) - 
                                      (100 * `v'_v`i'[1]/totalinc[1]);
                if ("`v'" != "topinc") {;
                    gen `v'_Ygrowthshare_v`i' = `v'_growth_v`i'/topinc_growth_v`i';           
                };
            };
        };

        keep if year == 2014;
        keep sdiv_growth_* cdiv_growth_* cret_growth_* pship_growth_* 
            othcap_growth_* othinc_growth_* *_Egrowthshare* 
            year *_Bgrowthshare_* *_Kgrowthshare_* *_Ygrowthshare_*;
        reshape long sdiv_growth_v cdiv_growth_v cret_growth_v 
            pship_growth_v othcap_growth_v othinc_growth_v
            sdiv_Egrowthshare_v cdiv_Egrowthshare_v cret_Egrowthshare_v
            sdiv_Bgrowthshare_v cdiv_Bgrowthshare_v cret_Bgrowthshare_v
            sdiv_Kgrowthshare_v cdiv_Kgrowthshare_v cret_Kgrowthshare_v
            sdiv_Ygrowthshare_v cdiv_Ygrowthshare_v cret_Ygrowthshare_v
            pship_Egrowthshare_v pship_Bgrowthshare_v pship_Kgrowthshare_v
            pship_Ygrowthshare_v
            othcap_Kgrowthshare_v othinc_Ygrowthshare_v, i(year) j(ver);

        * put our preferred thing up front and drop pre-tax graph;
        drop if ver == 6;
        replace ver = ver + 1;
        #delimit cr
        
        * Reorder 
        g ver_og = ver
        replace ver = 1 if ver_og == 1 //"PSZ (2018)"
        replace ver = 2 if ver_og == 2 //"PSZ Updated"
        replace ver = 3 if ver_og == 8 //"Fiscal Income + RE + Tax"
        replace ver = 4 if ver_og == 9 //"PS (2003) Ranks"
        replace ver = 5 if ver_og == 12 //"Divs Only (A+W)"
        replace ver = 6 if ver_og == 10 //"Divs + 0.25 CapG (A+W)" 
        replace ver = 7 if ver_og == 11 //"Divs + 0.5 CapG (A+W)" 
        replace ver = 8 if ver_og == 3 //"Divs Only" 
        replace ver = 9 if ver_og == 4 //"Add Pships"
        replace ver = 10 if ver_og == 5 //"Divs Only, Pships"
        replace ver = 11 if ver_og == 6 //"Divs Only (A+W), Pships"
        replace ver = 12 if ver_og == 13 //using mixed income instead"

		
		
        sort ver
		
		** Trim and save
		keep ver year sdiv_Bgrowth pship_Bgrowth cdiv_Bgrowth cret_Bgrowth
		keep if inlist(ver, 1, 2, 12)
		save $dtadir/appx_figure16`letter' , replace
		

        use `orig', clear


    }

end /*%>*/

