
***********************************************************
* APPX FIGURE 10
***********************************************************

capture program drop appx_figure10_input
program define appx_figure10_input /*<%*/

    import delimited $dta_majinc/usdinasyzz_2014clps_resub_750.csv, clear

    *Get total fiscal and national income
    g totinc_tmp = tot if group=="All"
    egen totinc_all = max(tot), by(year equalsplit incdefn)
    drop *_tmp

    *Only keep groups we are interested in
    keep if inlist(group, "P99-100", "Millionaires", "P99.9-100")
    replace group = "Million-dollar earners" if group=="Millionaires"
    replace group = "Top 1%" if group=="P99-100"
    replace group = "Top 0.1%" if group=="P99.9-100"

	replace incgroup = 22 if incgroup == 26

    *Rescale shares and vars in billions
    foreach var in pt ptlab ptcap othercap25 othercap35 c5 ownerlab otherlab5{
        replace `var'=`var'/10^9 //in billions
    }
    
    *Separate capital income into cdiv and other cap inc
    g othcap_minusC5 = othercap25 - c5 if incdefn == "fi"
	replace othcap_minusC5 = othercap35 - c5 if incdefn == "ni"
    
	** Trim and save
	keep othcap_minusC5 c5 ptcap ptlab ownerlab otherlab5 incdefn group incgroup year
	save $dtadir/appx_figure10, replace
  
end/*%>*/
