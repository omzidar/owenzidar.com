***********************************************************
* APPENDIX FIGURE 2
***********************************************************
capture program drop appx_figure2_input
program define appx_figure2_input /*<%*/


	***********	
	*Prep data
	***********
	forv a=1/9{
	insheet using "$dta_age_mean/all_2014_age`a'.csv", clear case

	keep group N majLinc majBinc majKinc majSinc majCinc majPTinc majKGinc inc incgroup agegroup agebin
	recode N majKinc majSinc majCinc majPTinc majKGinc inc incgroup agegroup (.=0)

	tempfile data_age`a'
	save `data_age`a''
	}
	clear

	forv a=1/9{
	append using `data_age`a''
	}

	egen tot_majKinc = sum(majKinc), by(group)
	egen tot_majLinc = sum(majLinc), by(group)
	egen tot_majBinc = sum(majBinc), by(group)

	egen tot_majSinc = sum(majSinc), by(group)
	egen tot_majCinc = sum(majCinc), by(group)
	egen tot_majPTinc = sum(majPTinc), by(group)
	egen tot_majKGinc = sum(majKGinc), by(group)


	g sK = 100*majKinc/tot_majKinc
	g sL = 100*majLinc/tot_majLinc
	g sB = 100*majBinc/tot_majBinc

	g sS  = 100*majSinc/tot_majSinc
	g sC  = 100*majCinc/tot_majCinc
	g sPT = 100*majPTinc/tot_majPTinc
	g sKG = 100*majKGinc/tot_majKGinc
	
	*LABEL AGES
	g age=agegroup*10
	drop if age<20

	*Label values
	lab define agebin 1 "<20"
	lab define agebin 2 "20-29", add
	lab define agebin 3 "30-39", add
	lab define agebin 4 "40-49", add
	lab define agebin 5 "50-59", add
	lab define agebin 6 "60-69", add
	lab define agebin 7 "70-79", add
	lab define agebin 8 "80-89", add
	lab define agebin 9 "90+", add
	lab values agegroup agebin
	
	** Trim and save
	keep sL agegroup group sPT sK sC
	keep if inlist(group, "P99-100", "P99.9-100")
	save $dtadir/appx_figure2, replace
	
	
end /*%>*/
