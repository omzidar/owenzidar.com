***********************************************************
* APPX TABLE OWNER DEATH 1
***********************************************************
capture program drop appx_table7_input
program define appx_table7_input /*<%*/
	

	****************
	*Insheet table and transpose
	****************
	foreach type in death{
	local i=1
	foreach inc in top1 toppt1{ 

		make_ownerdeath, death_or_retirement(`type') 

		*For this table, drop top1 and toppt1
		keep if inlist(sample, "`inc'")
		
		*Keep S only 
		preserve
		keep if orgform=="s"

		keep in 1

		tempfile s 
		save `s'
		restore
		

		*Keep S+P only 
		keep if orgform=="sp"
		append using `s'
		

		*identify column with survival outcome
		g survival = (var=="salesgt0")

		*Drop variables we won't use
		drop sample var orgform /*flag*/

		*transpose csv to make it easier to make latex tables
		xpose, clear varname
		order _varname 

		if "`type'"=="retirement"{
			rename v6 v7
		}

        ownerdeath_formatting, death_or_retirement(`type')  //program

		sort order
		drop if order==.

		foreach var of varlist col* {
			rename 	`var' `var'_`i'
		}

		tempfile data_`inc'
		save `data_`inc''

		local ++i

		}
		
		}
	
		use `data_top1', clear
		merge 1:1 order using `data_toppt1', nogen
		
		save $dtadir/appx_table7, replace

end /*%>*/
