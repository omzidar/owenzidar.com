
***********************************************************
* FIGURE 1 INPUT
***********************************************************
capture program drop figure1_input
program define figure1_input /*<%*/

	*----------------------------------------------------*
	*----  2014, Fiscal Income and National Income  -----*
	*----------------------------------------------------*

	local labshare 999
	
	import delimited $dta_majinc/usdinasyzz_2014clps_resub_`labshare'.csv, clear

	*Only keep percentiles
	drop if inlist(group, "All", "Millionaires")
	drop if incgroup<12 | incgroup==21 | incgroup==24 |incgroup==25 //dropping anything below P90, and p99-100 and p99.9-99.99, P99.99-100
	
	*Define value labels
	label drop _all
	label define bins 0 ""
	drop incgroup
	g incgroup = _n
	local n = _N
	forv i=1/`n'{
		qui levelsof group if incgroup==`i', local(label)
		tokenize `label'
		label define bins `i' "`1'", add
	}
	label values incgroup bins 
	
	*majority income of each type
	foreach var in majkinc majbinc majlinc {
		replace `var' = 100*`var'
	}
		
	gen labor = 100 * waglpen / tot
	gen business = 100 * (c + pt) / tot
	gen othercapital = 100 * othercap / tot
	
	*GRAPH PT vs. CORP
	replace pt = pt / tot * 100
	replace c = c / tot * 100

	save $dtadir/figure1.dta, replace

end
