***********************************************************
* FIGURE 3 INPUT
***********************************************************
capture program drop figure3_input
program define figure3_input /*<%*/

	*----- PANEL A  --------*

	* Define label 
		lab drop _all
		lab define salebin -1 "<$500k"
		lab define salebin 0 "$500k-$1m", add
		lab define salebin 1 "$1m-$5m", add
		lab define salebin 2 "$5m-$10m", add
		lab define salebin 3 "$10m-$50m", add
		lab define salebin 4 "$50m-$500m", add
		lab define salebin 5 "$500m+", add


	* 1. Pull in data for C-corps
		insheet using "$dta_firmstats1/sale_bins_soi_2014_ccorp.csv", clear
		drop if salebin2==-1

		*Label value
		lab values salebin2 salebin

		//Conditional on sales >500k
		egen tot_firms   =  total(nfirms)
		g s_firms_ccorp  = nfirms/ tot_firms *100

		egen tot_profits =  total(profits)
		g s_profits_ccorp  = profits/ tot_profits *100


		keep salebin2 s_firms_ccorp s_profits_ccorp

		tempfile ccorp
		save `ccorp'

	* 2. Pull in data for millionaire-owned S-corps 

	foreach incgroup in millionaire top1 toppt1{
		* 2. Pull in data for millionaire-owned scorps
		insheet using "$dta_firmstats2/sales_bins_scorp_2014_`incgroup'.csv", clear
		drop if salebin2==-1

		*Label value
		lab values salebin2 salebin

		//Conditional on sales >500k
		egen tot_firms   =  total(nfirms)
		egen tot_profits =  total(profits)

		keep salebin2  *firms *profits

		tempfile scorp_`incgroup'
		save `scorp_`incgroup''

	* 3. Pull in data for millionaire-owned pships
		insheet using "$dta_firmstats2/sales_bins_pship_2014_`incgroup'.csv", clear
		drop if salebin2==-1

		*Label value
		lab values salebin2 salebin

		//Conditional on sales >500k
		egen tot_firms   =  total(nfirms)
		egen tot_profits =  total(profits)

		keep salebin2 *firms *profits

		tempfile pship_`incgroup'
		save `pship_`incgroup''


		//Collapse S+P
		use `scorp_`incgroup'', clear
		append using `pship_`incgroup''

		collapse (sum) *firms *profits , by(salebin2)

		g s_firms_pt = nfirms/tot_firms*100 
		g s_profits_pt = profits/tot_profits*100 

		tempfile pt_`incgroup'
		save `pt_`incgroup''
	}

	* 4. combine
		clear
		use `ccorp'
		qui merge 1:1 salebin2 using `pt_millionaire'
		assert _merge==3
		qui drop _merge

		keep s_profits_ccorp s_profits_pt salebin2

		save "$dtadir/figure3a.dta", replace

	*----- PANEL B  --------*
		* 1. Pull in data
		insheet using "$dboxdatadir/naics_4d_correlates.csv", clear

		fix_naics

		*Outlier
		replace top1_profits_app_loki_2014 = . if naics_4d==4246


		collapse (sum) *_profits_app*2014 total_profits_*_2014 *_numw2_*_2014 profits_ccorp*2014, by( nc4)	

		drop if nc4==5511
		g nc1 = floor(nc4/1000)
		g nc2 = floor(nc4/100)
		
		g nc1_sep = nc1*10
		replace nc1_sep = 52 if inlist(nc2, 52, 53)
		replace nc1_sep = 54 if inlist(nc2, 51, 54, 56) 
		replace nc1_sep = 55 if inlist(nc2, 55) 

		collapse (sum) *_profits_app*2014 total_profits_*_2014 *_numw2_*_2014 profits_ccorp*2014, by( nc1_sep)	

		*Drop gov category
		keep if inrange(nc1, 10, 80)

		foreach var of varlist *_2014{
			local varname  = subinstr("`var'", "_app", "", .)
			local varname = subinstr("`varname'", "_2014", "", .)
			local varname = subinstr("`varname'", "loki", "scorp", .)
			rename `var' `varname'
		}
		

		*Gen pass-through
		foreach var in total mill top1 top01 {
			g `var'_profits_pthru = `var'_profits_scorp + `var'_profits_pship
		}

		foreach var of varlist *_profits_* *_numw2_* profits_ccorp{
			egen tot_`var' = total(`var')
			g sh_`var' = `var'/tot_`var'*100
		}


		tempfile naics_4d_correlates
		save `naics_4d_correlates'

	* 2. Insheet 2014 ACS data
		use "$ipumsdir/dta/collapsed_acs2014_byind_4d.dta", clear

		drop if nc1_sep==90
		drop if nc1_sep==55

		*Construct share of high skill and low skill by industry
		egen tot_highskill = total(highskill)
		g sh_highskill = highskill/tot_highskill*100

		egen tot_lowskill = total(lowskill)
		g sh_lowskill = lowskill/tot_lowskill*100

		* Dristrib of tot workers
		g highlow = highskill + lowskill
		egen tot_workers = total(highlow)
		g sh_totworkers = highlow/tot_workers*100

		tempfile acs2014
		save `acs2014'


	* 3. Merge
		use `acs2014', clear
		qui merge 1:1 nc1 using `naics_4d_correlates'
		assert _merge==3
		qui drop _merge

		drop tot_*
		
		*Label industries
		lab drop _all
		lab def naics 10 "Agriculture & Forestry"
		lab def naics 20 "Construction & Mining", add
		lab def naics 30 "Manufacturing", add
		lab def naics 40 "Retail & Wholesale Trade", add
		lab def naics 52 "Fin, Insur & Real Estate", add
		lab def naics 54 "Info & Professional Svcs", add
		lab def naics 60 "Health Care", add
		lab def naics 70 "Entertnmt, Food & Hotels", add
		lab def naics 80 "Other Svcs", add

		lab values nc1_sep naics


	* 4. Save
	keep sh_profits_ccorp sh_mill_profits_pthru sh_totworkers nc1

	save "$dtadir/figure3b.dta", replace

end
